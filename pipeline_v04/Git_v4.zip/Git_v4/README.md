# MeasureTrace Git_v4

연구 계획서의 계산식으로 원시 데이터(RAW)를 다시 계산해, **최종 보고서 초안의 수치 주장이 그 데이터로 지지되는지** 판정하는 감사 에이전트.

기준 문서 (확정)
- `docs/MeasureTrace_파이프라인_v4_기술명세.md` — 6단계 · 17개 과업, 설계 원칙 R1–R7, 입력, 허용오차
- `docs/MeasureTrace_오류코드_E01-E07_기술명세.md` — 오류 코드 E01–E07, 검사 대상 아님, 허용오차

판정은 **Supported / Unsupported** 두 가지이고 오류 코드는 그 이유다. 판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것이다.

## 실행

```powershell
pip install -r requirements.txt
Copy-Item .env.example .env      # LLM_API_KEY 넣기 (.env 는 커밋 금지 — .gitignore 에 있음)
python -m unittest discover -s tests -v    # 시험 — 가짜 LLM, 토큰 0
```

**웹 화면**: `python run.py` → http://127.0.0.1:8765

**명령줄**:

```powershell
python cli.py new 데모 --data samples\annealing_demo\data --report samples\annealing_demo\report   # 1 INGEST
python cli.py extract <실행 ID>        # 2 EXTRACT            ← LLM 호출 (토큰 사용)
python cli.py confirm <실행 ID>        # 3 CONFIRM 질문 + 관계 도식 + 답 양식(answers_template.json)
python cli.py answer <실행 ID> 답.json --who 홍길동   # '아니오'가 있으면 2 EXTRACT 다시 ← LLM
python cli.py recompute <실행 ID>      # 4 RECOMPUTE (격리 실행, LLM 없음)
python cli.py validate <실행 ID>       # 5 VALIDATE + 6 AUDIT ← LLM 호출 (토큰 사용)
python cli.py status
```

LLM 을 부르는 단계는 2 EXTRACT(2-1a · 2-1c · 2-2 · 2-4)와 5-1 뿐이다. 실제 실행 한 번 ≈ 입력 3.5만·출력 3만 토큰(claude-opus-5-5).
응답은 `workspace/llm_cache/` 에 캐시되고(같은 입력 → 토큰 0), `MT_OFFLINE=1` 이면 캐시만 쓴다. 호출 기록은 `workspace/outputs/llm_calls.jsonl`(R7).

샘플: `samples/annealing_demo`(연구 자료 `data/`, 보고서 `report/`) — 정답 `samples/annealing_demo_answer_key.json`(업로드하지 않음).
`samples/annealing_demo_rerun` 은 S07 에서 3행이 빠지고 S12 의 형식만 바뀐 재실행본(6-2 E07 확인용).

## 입력

| 입력 | 형식 | 비고 |
|---|---|---|
| RAW_DATA | CSV 등 | 계산의 유일한 데이터 입력 |
| 연구 계획서 | **.docx** | 계산식은 Word 수식(OMML) · 가공 방법 · 설계(독립 단위·반복 수) · 검정 방법 |
| 장비 사양서 | PDF | 측정 범위·오차 |
| 최종 보고서 초안 | 문서 | 별도 경로(report/), 5-1 전까지 열지 않음 |

사용하지 않음: **PROCESSED_DATA**(연구자의 숫자로 연구자의 숫자를 검증하는 순환 — 분류만 하고 목록에 남김), 그림, 외부 문헌.

## 과업 ↔ 코드

| 단계 | 과업 | 주체 | 구현 |
|---|---|---|---|
| 1 INGEST | 1-1 입력 격리·분류 · 1-2 해시 2종 · 1-3 산출물 이력 장부 | PY | `stages/ingest.py` · `hashing.py` · `lineage.py` · `store.py` |
| 2 EXTRACT | 2-1a 데이터 내용 파악 (행·열 헤더만) | LLM | `stages/extract.py` `_part_a` |
| | 2-1b 계획서 수식 변환 (Word 수식 → LaTeX, `extract/equations.json`) | PY | `docx_equations.py` · `extract.part_equations` |
| | 2-1c 연구 내용 추출 (식·가공 방법·설계·검정·매칭표) + 계산 코드 초안 `compute(files)` | LLM | `_part_c` · `_part_code` |
| | 2-2 측정 조건 추출 (쪽 번호·원문 인용 — 파이썬이 원문 대조) | LLM | `_part_s` |
| | 2-3 데이터 구조화 (단위 E01 · 결측·사양 이탈 E02, 잠정) | PY | `_part_structure` |
| | 2-4 누락 점검 (E03) | LLM→PY | `_part_m_llm` · `_part_m_check` |
| 3 CONFIRM | 3-1 데이터 해석 승인 · 3-2 장비 사양 확인 · 3-3 데이터 이상 확인 (최대 3회, 바뀐 항목만) | USER | `stages/confirm.py` |
| 4 RECOMPUTE | 4-1 수치 재계산 (RAW 만, 승인 코드 해시 고정, 격리 실행) · 4-2 계산 로그 | PY | `stages/recompute.py` · `sandbox.py` · `sandbox_runner.py` |
| 5 VALIDATE | 5-1 주장 추출·분류 · 5-2 재계산값과 비교 · 5-3 오류 코드 분류 | LLM→PY | `stages/validate.py` · `codes.py` · `units.py` · `design.py` |
| 6 AUDIT | 6-1 결과 출력 · 6-2 수정 후 재평가 (E07) | PY | `stages/audit.py` → `audit_report.md` |

## 오류 코드

| 코드 | 이름 | 탐지 → 확정 | 결과 |
|---|---|---|---|
| E01 | 단위 누락·불일치 | 2-3 → 3-3 → 5-2 | Unsupported (3회 뒤에도 단위 미확정인 열을 쓰는 주장 포함) |
| E02 | 측정값 이상 (사양 범위 이탈·결측) | 2-2 → 2-3(잠정) → 3-2 → 3-3 | 기록 (그대로 진행 결정) · 3회 뒤에도 미결정이면 Unsupported |
| E03 | 필요 데이터 누락 | 2-4 → 3-1 | Unsupported (그 데이터가 필요한 주장) |
| E04 | 반복 단위·표본 수 불일치 | 2-1c → 3-1 → 5-2 | Unsupported |
| E05 | 주장 수치 불일치 (방향 포함) | 4-1 → 5-1 → 5-2 | Unsupported |
| E06 | 재계산 대응 없음 — 사유: 식 없음 · 데이터 없음 · 미확정 · 검정 방법 없음 | 5-2 | Unsupported |
| E07 | 데이터 버전 변경 | 1-2 · 4-2 → 6-2 | 기록 (어떤 파일이 몇 행 바뀌었는지, 형식만 변경 구분) |

검사 대상 아님: 문헌 인용(인용 번호·참고문헌 원문·문장 위치만 기록) · 정성 문장. 혼합 문장은 자기 값만 검사하고 문헌값은 기록.
허용오차: 주장 판정(E05)은 재계산값을 보고서 수치의 유효 자릿수로 반올림해 비교, 도구 정확도는 정답 대비 상대 오차 ≤ 1e-6(시험).

## Word 수식 → LaTeX (`mtagent/docx_equations.py`)

`extract(docx 경로, 파일 sha256)` → `{plan_sha256, converter, equations[{id, sentence, omml_sha256, plan_sha256, latex, status, error}], failed, plan_text}`.
문단 안의 가장 바깥 m:oMath 를 문서 순서대로 EQ01… 로 번호 매겨 dwml `oMath2Latex` 로 바꾸고, 수식마다 예외를 따로 잡아 그 수식만 `failed`.
적분(m:chr 없음 = ∫)은 변환기에 넘기는 사본에만 표준 기본값을 채우고 `filled_defaults` 에 기록한다. Word 호환 감싸개(mc:Fallback)는 건너뛴다.
출력 문자열은 보정하지 않는다 — 뺄셈 `−`(U+2212) · `×` · `Δ` 는 그대로 나온다(`∑` 는 `\sum`).

## 파일

```
run.py · cli.py        웹 화면 · 명령줄
docs/                  확정 기술 명세 (파이프라인 v4 · 오류 코드 E01–E07)
mtagent/
  config.py  store.py  lineage.py  util.py  llm.py        설정 · 실행 폴더 · 1-3 장부 · 공통 · LLM(구조화 출력·캐시·호출 기록)
  readers.py  hashing.py  docx_equations.py               표·Word·PDF 읽기 · 1-2 해시 2종 · 2-1b 수식 변환
  units.py  design.py  codes.py                           단위 · 조건 이름 맞추기 · 오류 코드
  sandbox.py  sandbox_runner.py                           정적 점검 · 격리 실행
  stages/ ingest · extract · confirm · recompute · validate · audit
web/                   표준 라이브러리 HTTP 서버 + 화면 (127.0.0.1 전용)
tests/                 test_pipeline.py · test_equations_pipeline.py · test_docx_equations.py · fake_llm.py · make_eq_docx.py
samples/               시험 자료 (생성형 AI 로 만든 가상 자료)
workspace/             실행하면 생김 — inputs · outputs · llm_cache (.gitignore)
```

## 남은 확인 (명세 7장)

1. 실제 Word 수식 편집기로 입력·저장한 `.docx` 로 수식 변환 시험 (현재 시험 자료는 손으로 만든 XML)
2. 데모 연구 계획서·데이터와 주입할 오류 확정 — 오류를 심는 사람과 검사 규칙 작성자를 분리
3. 생성형 AI 사용 내역 기록 · 팀원 PC 에서 import 와 전체 실행 흐름 확인
