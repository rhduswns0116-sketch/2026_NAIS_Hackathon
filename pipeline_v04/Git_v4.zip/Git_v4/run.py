"""MeasureTrace Git_v4 실행 — 웹 화면을 연다.

  python run.py                 http://127.0.0.1:8765 (브라우저 자동)
  python run.py --port 9000 --no-browser
"""
import sys

from web.server import main

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
