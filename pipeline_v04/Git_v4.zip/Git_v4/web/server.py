"""MeasureTrace Git_v4 웹 화면 — 파이썬 표준 라이브러리 HTTP 서버 (이 컴퓨터에서만).

  python run.py            → http://127.0.0.1:8765 (브라우저 자동으로 열림, 끄기 Ctrl+C)

보안: 127.0.0.1 에만 열고, Host·Origin 을 확인하며(DNS 리바인딩 차단), 쓰기 요청(POST·PUT)에는
화면이 붙이는 X-MeasureTrace 헤더를 요구한다(다른 사이트의 단순 요청 차단). 같은 실행에 동시에 두 작업을 돌리지 않는다.
"""
from __future__ import annotations

import json
import sys
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mtagent import lineage, store  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import audit, confirm, extract, ingest, recompute, validate  # noqa: E402

STATIC = ROOT / "web" / "static"
TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8"}
WRITE_HEADER = "X-MeasureTrace"
_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()


def run_lock(rid: str) -> threading.Lock:
    with _locks_guard:
        return _locks.setdefault(rid, threading.Lock())


def run_view(rid: str) -> dict:
    """저장된 결과로 1~6 단계를 다시 그릴 수 있는 한 벌 (다시 실행하지 않음)."""
    st = store.state(rid)
    out = {"state": st, "ingest": store.read(rid, "ingest.json"), "extract": None, "confirm": None,
           "recompute": store.read(rid, "recompute/calc_log.json"), "validate": store.read(rid, "validate.json"),
           "audit": store.read(rid, "audit.json"), "lineage": lineage.entries(rid), "uploads": []}
    if st["stages"].get("extract"):
        out["extract"] = extract.view(rid)
    if st["stages"].get("confirm"):
        out["confirm"] = confirm.view(rid)
    if not st["stages"].get("ingest"):
        out["uploads"] = [{"zone": z, "path": r, "size": p.stat().st_size} for z, r, p in store.input_files(rid)]
    if out["validate"]:
        out["validate"] = {k: v for k, v in out["validate"].items() if k != "sent"}
    return out


class Handler(BaseHTTPRequestHandler):
    port = 8765
    server_version = "MeasureTrace"

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code: int, obj) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"), "application/json; charset=utf-8")

    def _trusted(self, write: bool) -> bool:
        hosts = {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}
        if self.headers.get("Host") not in hosts:
            return False
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://{h}" for h in hosts}:
            return False
        return not write or self.headers.get(WRITE_HEADER) == "1"

    def _refuse(self) -> None:
        if self.command in ("POST", "PUT"):
            self.close_connection = True
        self._json(403, {"error": "허용되지 않은 요청 — 이 컴퓨터의 MeasureTrace 화면에서만 쓸 수 있음"})

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n > 5 * 1024 * 1024:
            raise ValueError("요청 본문이 너무 큼")
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def _guard(self, fn, rid: str | None = None) -> None:
        lock = run_lock(rid) if rid else None
        if lock and not lock.acquire(blocking=False):
            return self._json(409, {"error": "이 실행에서 다른 작업이 진행 중 — 끝난 뒤 다시"})
        try:
            fn()
        except ValueError as e:
            self._json(400, {"error": str(e)})
        except Exception as e:
            traceback.print_exc()
            self._json(500, {"error": f"{type(e).__name__}: {e}"})
        finally:
            if lock:
                lock.release()

    def _parts(self) -> tuple[list[str], dict]:
        u = urlparse(self.path)
        return [unquote(p) for p in u.path.split("/") if p], parse_qs(u.query)

    def do_OPTIONS(self) -> None:
        self._refuse()

    def do_GET(self) -> None:
        if not self._trusted(write=False):
            return self._refuse()
        parts, _ = self._parts()
        if not parts or parts == ["index.html"]:
            return self._send(200, (STATIC / "index.html").read_bytes(), TYPES[".html"])
        if len(parts) == 2 and parts[0] == "static":
            f = STATIC / Path(parts[1]).name
            if f.suffix in TYPES and f.exists():
                return self._send(200, f.read_bytes(), TYPES[f.suffix])
        if parts == ["api", "status"]:
            return self._guard(lambda: self._json(200, {"llm": LLM().status()}))
        if parts == ["api", "runs"]:
            return self._guard(lambda: self._json(200, store.list_runs()))
        if len(parts) == 3 and parts[:2] == ["api", "runs"]:
            return self._guard(lambda: self._json(200, run_view(parts[2])))
        if len(parts) == 4 and parts[:2] == ["api", "runs"] and parts[3] == "audit_report.md":
            def md():
                p = store.out_dir(parts[2]) / "audit_report.md"
                if not p.exists():
                    raise ValueError("아직 6 AUDIT 를 하지 않음")
                self._send(200, p.read_bytes(), "text/markdown; charset=utf-8")
            return self._guard(md)
        self._send(404, b"not found", "text/plain")

    def do_POST(self) -> None:
        if not self._trusted(write=True):
            return self._refuse()
        parts, _ = self._parts()
        if parts == ["api", "runs"]:
            return self._guard(lambda: self._json(200, {"run_id": store.new_run(self._body().get("project"))}))
        if len(parts) < 4 or parts[:2] != ["api", "runs"]:
            return self._send(404, b"not found", "text/plain")
        rid, what = parts[2], "/".join(parts[3:])
        if what not in {"ingest", "extract", "confirm/start", "confirm/submit", "recompute", "validate", "audit"}:
            return self._send(404, b"not found", "text/plain")

        def act():
            body = self._body()
            if not isinstance(body, dict):
                raise ValueError("요청 본문은 JSON 객체여야 함")
            if what == "ingest":
                ingest.run(rid)
            elif what == "extract":
                extract.run(rid)
            elif what == "confirm/start":
                confirm.start(rid)
            elif what == "confirm/submit":
                confirm.submit(rid, body.get("respondent", ""), body.get("answers") or {})
            elif what == "recompute":
                recompute.run(rid)
            elif what == "validate":
                validate.run(rid, report=body.get("report"))
                audit.run(rid)
            else:
                audit.run(rid)
            self._json(200, run_view(rid))
        self._guard(act, rid)

    def do_PUT(self) -> None:
        if not self._trusted(write=True):
            return self._refuse()
        parts, query = self._parts()
        if not (len(parts) == 4 and parts[:2] == ["api", "runs"] and parts[3] == "files"):
            return self._send(404, b"not found", "text/plain")
        rid = parts[2]

        def put():
            n = int(self.headers.get("Content-Length") or 0)
            self._json(200, store.save_upload(rid, (query.get("zone") or [""])[0], (query.get("path") or [""])[0], self.rfile, n))
        self._guard(put, rid)

    def log_message(self, fmt, *args) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")


def main(argv: list[str]) -> int:
    port = int(argv[argv.index("--port") + 1]) if "--port" in argv else 8765
    Handler.port = port
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}"
    print(f"MeasureTrace Git_v4 화면: {url}   (끄기: Ctrl+C)")
    if "--no-browser" not in argv:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
