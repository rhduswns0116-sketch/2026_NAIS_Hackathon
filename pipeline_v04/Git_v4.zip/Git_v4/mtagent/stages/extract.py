"""2 EXTRACT — 식·조건·데이터를 파악한다 (LLM 은 측정값을 보지 않음 — R2). 최종 보고서 초안은 열지 않는다(R4).

2-1 입력 데이터 분석
    a [LLM] 데이터 내용 파악   RAW 표 묶음마다 행·열 헤더(열 이름과 문자 라벨: 시료 ID·조건 이름 등)만 보고 무엇을 잰 데이터인지.
                               숫자 값은 보내지 않는다.
    b [PY]  계획서 수식 변환   docx 의 Word 수식(m:oMath)을 dwml 로 LaTeX 로 → equations.json (docx_equations). LLM 없음.
                               변환 실패는 수식 단위로 남기고 3-1 에서 연구자가 직접 입력.
    c [LLM] 연구 내용 추출     식의 뜻·가공 방법(raw → 계산 입력값)·설계(독립 단위·반복 수)·검정 방법·실험↔데이터↔식↔장비 매칭표,
                               그리고 계산 코드 초안 compute(files) — 실행하지 않음(승인 뒤 4 RECOMPUTE 에서만).
2-2 측정 조건 추출 [LLM]      장비 사양서의 측정 범위·오차·유효 범위 — 쪽 번호·원문 인용. 인용·숫자가 원문에 있는지 파이썬이 확인.
2-3 데이터 구조화 [PY]        파이썬만 값을 읽어 단위 누락·모호(E01)·결측·사양 범위 이탈(E02). 이상치는 잠정(사양 승인 전).
2-4 누락 점검 [LLM→PY]        LLM 은 계획서만 읽고 필요한 시료·반복·측정점을 뽑고, 파이썬이 실제 파일과 대조(E03).
"""
from __future__ import annotations

import json
import re
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from importlib import metadata
from pathlib import Path

from mtagent import design, docx_equations, lineage, readers, sandbox, store, units
from mtagent.llm import LLM, arr, boolean, num, obj, s
from mtagent.util import canonical, now, sha_obj, sha_text, write_json

PARTS = ("2-1", "2-2", "2-3", "2-4")
ROLES = ["id", "condition", "replicate", "independent", "measured", "time", "other"]
VALUE_ROLES = ("measured", "independent")   # 단위를 따지는 숫자 열
KINDS = sorted(sandbox.RESULT_KINDS)
FILES = {"2-1a": "data_content.json", "2-1b": "equations.json", "2-1c": "research.json", "2-1c-code": "code.json",
         "2-2": "spec.json", "2-3": "structure.json", "2-4": "missing.json"}
COMMON = ("너는 연구 재현성 감사 도구 MeasureTrace 의 추출 담당이다. 사람이 3 CONFIRM 단계에서 너의 결과를 확인한다. "
          "문서에 없는 내용은 지어내지 말고 null 로 두거나 questions 에 연구자에게 물을 질문으로 적는다. 한국어로 답한다.")


def _feedback(feedback: dict, part: str) -> str:
    items = [x for x in (feedback or {}).get(part, []) if x and x.strip()]
    if not items:
        return ""
    return "\n\n[연구자 수정 요청 — 3 CONFIRM 에서 받음. 반드시 반영할 것]\n" + "\n".join(f"- {x.strip()}" for x in items)


# ── 입력 모으기 ──────────────────────────────────────────────────────────
def _inputs(rid: str) -> dict:
    ing = store.read(rid, "ingest.json")
    base = store.in_dir(rid) / "data"
    by = lambda cat: [x for x in ing["files"] if x["zone"] == "data" and x["category"] == cat]  # noqa: E731
    raw, plans, specs = by("raw"), by("plan"), by("spec")
    if not raw or not plans:
        raise ValueError("RAW 데이터와 연구 계획서가 모두 있어야 함 (1 INGEST 분류 확인)")
    tables = {x["path"]: readers.read_table(base / x["path"]) for x in raw}
    tables = {k: v for k, v in tables.items() if v}
    equations = part_equations(base, plans)                 # 2-1b [PY]
    return {"ingest": ing, "base": base, "raw": raw, "specs": specs, "tables": tables, "equations": equations,
            "plan": _plan_doc(base, plans, equations), "groups": _groups(tables),
            "reports_not_opened": sum(1 for x in ing["files"] if x["zone"] == "report")}


def _dwml_version() -> str | None:
    try:
        return metadata.version("dwml")
    except metadata.PackageNotFoundError:
        return None


# ── 2-1b 계획서 수식 변환 [PY] ───────────────────────────────────────────
def part_equations(base: Path, plans: list[dict]) -> dict:
    """Word 계획서마다 docx_equations.extract(경로, 1 INGEST 의 파일 해시). 여러 계획서면 EQ 번호를 이어 붙인다."""
    files, equations, notes = [], [], []
    for x in plans:
        if not x["path"].lower().endswith(".docx"):
            notes.append(f"{x['path']}: Word(.docx)가 아닌 계획서 — 수식을 읽지 않음")
            continue
        try:
            r = docx_equations.extract(base / x["path"], x["sha256"])
        except Exception as e:           # 깨진 docx 등 — 이 파일만
            notes.append(f"{x['path']}: 수식을 읽지 못함 — {type(e).__name__}: {e}")
            continue
        remap = {}
        for e in r["equations"]:
            nid = f"EQ{len(equations) + 1:02d}"
            remap[e["id"]] = nid
            equations.append({"id": nid, "latex": e["latex"], "context": e["sentence"], "omml_sha256": e["omml_sha256"],
                              "plan_sha256": e["plan_sha256"], "status": e["status"], "error": e.get("error"),
                              "filled_defaults": e.get("filled_defaults"), "converter": r["converter"], "file": x["path"]})
        files.append({"file": x["path"], "plan_sha256": r["plan_sha256"], "converter": r["converter"],
                      "failed": [remap[i] for i in r["failed"]],
                      "plan_text": re.sub(r"\[(EQ\d+)\]", lambda m: f"[{remap.get(m.group(1), m.group(1))}]", r["plan_text"])})
        if not r["equations"]:
            notes.append(f"{x['path']}: Word 수식이 없음 — 계산식이 글로만 적혀 있으면 식 목록 없이 진행")
    return {"converter": next((f["converter"] for f in files if f["converter"]), None), "dwml": _dwml_version(),
            "files": files, "equations": equations, "failed": [e["id"] for e in equations if e["status"] != "ok"],
            "notes": notes}


def _plan_doc(base: Path, plans: list[dict], eq: dict) -> dict:
    """LLM 에 보낼 계획서 글 — Word 계획서는 식 자리에 "[EQ01] $ LaTeX $" 가 들어간 글(변환 실패는 원문 확인 표시)."""
    by_file = {f["file"]: f for f in eq["files"]}
    texts = []
    for x in plans:
        p = base / x["path"]
        ext = p.suffix.lower()
        if x["path"] in by_file:
            text = by_file[x["path"]]["plan_text"]
        elif ext in (".docx", ".doc", ".hwp", ".hwpx"):     # 변환 실패한 docx · 읽지 않는 형식 — 바이트를 글로 보내지 않는다
            text = f"(이 계획서를 읽지 못함 — {ext} 는 .docx 로 다시 저장해 주세요)"
        else:
            try:
                text = ("\n".join(f"[p.{i}]\n{t}" for i, t in enumerate(readers.read_pdf_pages(p), 1)) if ext == ".pdf"
                        else readers.read_text(p))
            except Exception as e:
                text = f"(이 계획서를 읽지 못함 — {type(e).__name__})"
        texts.append(f"=== 연구 계획서: {x['path']} ===\n{text}")
    return {"text": "\n\n".join(texts), "equations": eq["equations"], "files": [x["path"] for x in plans]}


def _groups(tables: dict) -> list[dict]:
    """같은 열 구성의 RAW 파일 묶음(G1…) — 행·열 헤더(열 이름·문자 라벨)만, 숫자 값 없음."""
    by_cols: dict[tuple, list[str]] = {}
    for path, t in tables.items():
        by_cols.setdefault(tuple(t["columns"]), []).append(path)
    groups = []
    for i, (cols, paths) in enumerate(by_cols.items(), 1):
        profile = []
        for ci, c in enumerate(cols):
            vals = [r[ci] for p in paths for r in tables[p]["rows"] if ci < len(r) and r[ci] != ""]
            numeric = bool(vals) and sum(readers.to_float(v) is not None for v in vals) >= 0.9 * len(vals)
            # 행 헤더(문자 라벨)만 — 숫자 열이나 숫자 모양의 값은 보내지 않는다
            labels = [] if numeric else list(dict.fromkeys(v for v in vals if readers.to_float(v) is None))[:40]
            profile.append({"name": c, "numeric": numeric, "row_labels": labels})
        rows = [len(tables[p]["rows"]) for p in paths]
        groups.append({"group_id": f"G{i}", "columns": list(cols), "files": sorted(paths), "rows_min": min(rows),
                       "rows_max": max(rows), "profile": profile,
                       "comments": list(dict.fromkeys(c for p in paths for c in tables[p]["comments"]))[:5]})
    return groups


# ── 2-1a 데이터 내용 파악 [LLM] ─────────────────────────────────────────
SCHEMA_A = obj({"summary": s("이 표 묶음이 무엇을 측정한 데이터인지 한두 문장"),
                "layout": s(enum=["long", "wide", "other"]),
                "columns": arr(obj({"name": s(), "role": s(enum=ROLES), "quantity": s(nullable=True),
                                    "unit": s("SI 기호, 모르면 null", nullable=True),
                                    "unit_source": s(enum=["header", "plan", "guess", "none"]),
                                    "meaning": s()})),
                "questions": arr(s())})
SYSTEM_A = COMMON + """
과업 2-1a 데이터 내용 파악: 원시 데이터(RAW) 표 한 묶음(같은 열 구성의 파일들)의 행·열 헤더 — 열 이름과 문자 라벨(시료 ID·조건 이름 등),
파일 이름, 연구 계획서를 보고 각 열이 무엇인지 판단한다. 측정값(숫자)은 받지 않는다(값은 파이썬이 다룬다).
- role: id(독립 단위·시료 식별) · condition(처리 조건·집단) · replicate(단위 안의 반복·측정 위치) · independent(연구자가 정해 준 값: 인가 전압·시간 등)
  · measured(장비가 잰 측정값) · time(측정 시각) · other
- unit: 열 이름에 단위가 있으면 그 단위(unit_source=header). 없고 계획서가 그 열의 단위를 명시하면 그 단위(plan).
  둘 다 없으면 추정하지 말고 null(none). 어쩔 수 없이 추정했다면 guess 로 표시한다. SI 기호로 적는다(A, nA, V, mV, S, nS, Ω, s, Hz, C).
- columns 는 받은 열 이름 순서대로 모두 적는다."""


def _part_a(ctx: dict, llm: LLM, fb: str) -> dict:
    out = {"groups": [], "sent": {}}
    for g in ctx["groups"]:
        payload = {"group_id": g["group_id"], "columns": g["profile"], "files": g["files"][:60],
                   "n_files": len(g["files"]), "rows_per_file": [g["rows_min"], g["rows_max"]], "header_comments": g["comments"]}
        user = ("[원시 데이터(RAW) 표 묶음 — 행·열 헤더만, 측정값 없음]\n" + json.dumps(payload, ensure_ascii=False, indent=1)
                + "\n\n[연구 계획서]\n" + ctx["plan"]["text"] + fb)
        res = llm.json("2-1a", SYSTEM_A, user, SCHEMA_A, effort="medium")
        known = {c["name"]: c for c in res.get("columns", [])}
        res["columns"] = [known.get(c) or {"name": c, "role": "other", "quantity": None, "unit": None,
                                           "unit_source": "none", "meaning": "(LLM 이 답하지 않음)"} for c in g["columns"]]
        out["groups"].append({**g, "analysis": res})
        out["sent"][g["group_id"]] = user
    return out


def column_info(data_content: dict) -> dict[str, dict]:
    """열 이름 → 2-1a 분석 (여러 묶음에 같은 열 이름이 있으면 첫 묶음)."""
    info = {}
    for g in data_content.get("groups", []):
        for c in g["analysis"]["columns"]:
            info.setdefault(c["name"], {**c, "group_id": g["group_id"]})
    return info


# ── 2-1c 연구 내용 추출 [LLM] ───────────────────────────────────────────
# API 제약: 한 스키마에 null 허용(유니언) 항목은 16개까지, 스키마 문법 크기에도 상한이 있다
# → 두 번에 나눠 묻고(식·가공 방법·매칭 / 설계·검정·보고값), 글 항목은 '없으면 빈 문자열'로 받아 파이썬이 None 으로 바꾼다
EMPTY = "없으면 빈 문자열"
SCHEMA_C = obj({
    "purpose": s(),
    "equations": arr(obj({"id": s(), "meaning": s(), "role": s("계산에서 맡는 역할"),
                          "variables": arr(obj({"symbol": s(), "meaning": s(), "unit": s(EMPTY),
                                                "column": s("이 변수가 오는 데이터 열 이름, " + EMPTY)}))})),
    "steps": arr(obj({"order": num(nullable=False, integer=True), "description": s(), "inputs": s(), "outputs": s(),
                      "equation_ids": arr(s())})),
    "matching": arr(obj({"experiment": s(), "data_columns": arr(s()), "equation_ids": arr(s()),
                         "instrument": s(EMPTY), "instrument_range": s("사용한 장비 범위 이름(예: 10 nA), " + EMPTY),
                         "results": s()})),
    "questions": arr(s())})
SCHEMA_C2 = obj({
    "design": obj({"conditions": arr(obj({"name": s("데이터의 조건 열 값 그대로"), "label": s("계획서 표기"),
                                          "samples": arr(s())})),
                   "independent_unit": s(), "id_column": s(EMPTY), "condition_column": s(EMPTY),
                   "replicate": s("단위 안의 기술적 반복, " + EMPTY), "replicates_per_unit": num(integer=True),
                   "points_per_replicate": num(integer=True), "degrees_of_freedom": num(integer=True), "quote": s()}),
    "test": obj({"present": boolean(), "method": s(EMPTY),
                 "alternative": s(nullable=True, enum=["two-sided", "greater", "less"]), "alpha": num(),
                 "equation_ids": arr(s()), "quote": s(EMPTY)}),
    "outputs": arr(obj({"id": s("영문·숫자·밑줄 식별자"), "name": s(), "symbol": s(EMPTY),
                        "unit": s("SI 기호, 무차원이면 빈 문자열"), "equation_id": s(EMPTY),
                        "per": s(enum=["condition", "comparison", "overall"]), "kind": s(enum=KINDS)})),
    "reporting": s("보고 형식·단위·반올림 규칙, " + EMPTY),
    "questions": arr(s())})
RETRY_EMPTY = ("\n\n[다시 요청] 앞선 답에서 {} 가 빈 목록이었다. 계획서의 가공 방법(raw → 계산 입력값 → 보고값)과 "
               "실험 — 데이터 열 — 식 — 장비 연결을 반드시 한 항목 이상 채운다. 계획서에 없으면 questions 에 이유를 적는다.")


def blank_to_none(x):
    if isinstance(x, dict):
        return {k: blank_to_none(v) for k, v in x.items()}
    if isinstance(x, list):
        return [blank_to_none(v) for v in x]
    return None if isinstance(x, str) and not x.strip() else x


SYSTEM_C = COMMON + """
과업 2-1c 연구 내용 추출 (식·가공 방법·매칭): 연구 계획서에서 식의 뜻과 가공 방법을 뽑고 실험—데이터—식—장비를 연결한다.
- equations: 주어진 식 목록(id 고정, LaTeX 는 파이썬이 Word 수식에서 변환함)마다 뜻·역할·변수를 적는다. 목록에 없는 식을 만들지 않는다.
  status 가 failed(latex 가 null)인 식은 변환에 실패한 식이다 — 식을 지어내지 말고 context 로 알 수 있는 뜻만 적으며,
  questions 에 그 식의 원문 확인을 요청한다.
  변수의 column 은 그 값이 오는 데이터 열 이름(받은 열 목록 중에서), 계산해서 나오는 값이면 빈 문자열.
- steps: 가공 방법 — raw 데이터에서 계산 입력값을 거쳐 보고값까지의 순서(식으로 적히지 않은 가공도 포함).
- matching: 실험마다 쓰는 데이터 열 · 식 · 장비와 장비 범위 · 나오는 결과."""
SYSTEM_C2 = COMMON + """
과업 2-1c2 연구 내용 추출 (설계·검정·보고값): 연구 계획서에서 실험 설계(독립 단위·반복 수)·검정 방법·보고할 값을 뽑는다.
- design.conditions: name 은 데이터의 조건 열 값 그대로(예: annealed), label 은 계획서 표기(예: 어닐링 (A)).
  samples 는 시료 ID 를 범위 표기(S01–S10) 없이 모두 풀어 적는다. degrees_of_freedom 은 계획서 설계에서 나오는 자유도.
- test: 계획서에 검정 방법이 없으면 present=false.
- outputs: 보고서에 나올 수 있는 모든 최종 수치 — 조건별 평균·표준편차·표본 수(n), 검정 통계량, 자유도, p값, 증가율·차이 등.
  per: condition(조건마다 하나) · comparison(조건 비교 하나) · overall. kind: value · n · df · p_value · test_statistic · percent_change · difference · ratio · other.
- quote 는 계획서 문장을 글자 그대로 인용한다."""


def _part_c(ctx: dict, a: dict, llm: LLM, fb: str) -> dict:
    cols = [{"group_id": g["group_id"], "columns": [{k: c[k] for k in ("name", "role", "unit", "meaning")}
                                                    for c in g["analysis"]["columns"]]} for g in a["groups"]]
    eqs = [{"id": e["id"], "latex": e["latex"], "context": e["context"], "status": e["status"]}
           for e in ctx["plan"]["equations"]]
    specs = [x["path"] for x in ctx["specs"]]
    user = ("[연구 계획서 — 식 자리는 [EQxx] $ LaTeX $ 로 표시]\n" + ctx["plan"]["text"]
            + "\n\n[식 목록 — id 고정]\n" + json.dumps(eqs, ensure_ascii=False, indent=1)
            + "\n\n[데이터 열 (2-1a)]\n" + json.dumps(cols, ensure_ascii=False, indent=1)
            + "\n\n[장비 사양서 파일]\n" + json.dumps(specs, ensure_ascii=False) + fb)
    with ThreadPoolExecutor(max_workers=2) as pool:
        f1 = pool.submit(llm.json, "2-1c", SYSTEM_C, user, SCHEMA_C, "high")
        f2 = pool.submit(llm.json, "2-1c2", SYSTEM_C2, user, SCHEMA_C2, "high")
        r1, r2 = blank_to_none(f1.result()), blank_to_none(f2.result())
    empty = [k for k in ("steps", "matching") if not r1.get(k)]
    if empty:
        try:   # 다시 묻기는 덤 — 실패해도 첫 답으로 진행하고 3-1 에서 사람이 채운다
            again = blank_to_none(llm.json("2-1c", SYSTEM_C, user + RETRY_EMPTY.format(", ".join(empty)), SCHEMA_C, "high"))
        except Exception as e:
            again = {"questions": [f"(다시 묻기 실패: {type(e).__name__}) 가공 방법·실험 연결을 3-1 에서 직접 적어 주세요."]}
        for k in empty:
            if again.get(k):
                r1[k] = again[k]
        r1["questions"] = (r1.get("questions") or []) + (again.get("questions") or [])
        empty = [k for k in empty if not r1.get(k)]
    res = {k: r1.get(k) for k in ("purpose", "equations", "steps", "matching")}
    res.update({k: r2.get(k) for k in ("design", "test", "outputs", "reporting")})
    res["questions"] = list(dict.fromkeys((r1.get("questions") or []) + (r2.get("questions") or [])))   # 같은 질문 한 번만
    # 파이썬 보정: 식 id 는 계획서의 것만, LaTeX 는 2-1b 원본으로, 시료 범위 표기는 풀기
    latex = {e["id"]: e for e in ctx["plan"]["equations"]}
    got = {e["id"]: e for e in res.get("equations") or [] if e.get("id") in latex}
    res["equations"] = [{"id": i, "latex": e["latex"], "context": e["context"], "omml_sha256": e["omml_sha256"],
                         **{k: e.get(k) for k in ("status", "error", "filled_defaults", "converter", "file")},
                         **{k: v for k, v in (got.get(i) or {"meaning": "(LLM 이 설명하지 않음)", "role": "",
                                                              "variables": []}).items() if k != "id"}}
                        for i, e in latex.items()]
    for c in (res.get("design") or {}).get("conditions") or []:
        c["samples"] = design.expand_samples(c.get("samples") or [])
    ids = [o["id"] for o in res.get("outputs") or []]
    if len(ids) != len(set(ids)):
        res["questions"].append("보고값 id 가 겹침 — 확인 필요")
    res["empty_after_retry"] = empty       # 기록용 — 다시 물어도 빈 항목
    res["sent"] = user
    return res


# ── 2-1c 계산 코드 초안 [LLM] ───────────────────────────────────────────
SCHEMA_CODE = obj({"code": s("파이썬 소스 전체"), "explanation": s(), "assumptions": arr(s())})
SYSTEM_CODE = COMMON + f"""
과업 2-1c3 계산 코드 초안: 추출 결과(식·가공 방법·설계·검정·보고값 목록)와 데이터 형식을 보고, 계획서대로 RAW 데이터에서 보고값을
다시 계산하는 파이썬 코드를 쓴다. 코드는 지금 실행하지 않는다 — 연구자가 3 CONFIRM 에서 승인하고 해시를 고정한 뒤 격리 환경에서 한 번 실행된다.
규칙:
1. `def compute(files: dict) -> dict:` — files 는 RAW 파일만 {{상대 경로: 읽기 전용 실제 경로}}. 다른 파일을 열지 않는다.
2. import 는 {', '.join(sorted(sandbox.ALLOWED_IMPORTS))} 만. 파일 쓰기·네트워크·os·sys·subprocess·eval·exec·getattr 금지. open() 은 읽기 모드만.
3. 반환 {{"results": [...], "intermediate": {{...}}}}. results 항목: {{"id", "name", "value"(float, 반올림하지 않음),
   "unit"(SI 기호, 무차원이면 null), "condition"(조건별 값이면 설계 조건의 name 그대로, 아니면 null), "kind", "equation_id"(식 id 또는 null)}}.
4. 보고값 목록(outputs)을 모두 계산한다. per=condition 이면 조건마다 id 를 "<output id>__<조건 name>" 으로 하나씩, kind 는 outputs 의 kind 그대로.
5. 이상치를 임의로 빼지 않는다(제외 여부는 사람이 결정). 숫자로 바꿀 수 없는 값은 조용히 버리지 말고 intermediate["skipped_rows"] 에 (파일, 줄, 이유)를 남긴다.
6. 계획서에 없는 가정은 코드 주석 'ASSUMPTION:' 과 assumptions 목록에 적는다.
7. 중간값(가공 방법의 단계별 값: 위치별·시료별 값 등)은 intermediate 에 JSON 으로 담는다."""


def _part_code(ctx: dict, a: dict, b: dict, llm: LLM, fb: str) -> dict:
    fmt = [{"group_id": g["group_id"], "files": g["files"], "rows_per_file": [g["rows_min"], g["rows_max"]],
            "delimiter": ctx["tables"][g["files"][0]]["delimiter"], "encoding": ctx["tables"][g["files"][0]]["encoding"],
            "columns": [{k: c[k] for k in ("name", "role", "unit")} for c in g["analysis"]["columns"]]}
           for g in a["groups"]]
    research = {k: v for k, v in b.items() if k not in ("sent", "questions", "empty_after_retry")}
    user = ("[추출 결과 (확인 전)]\n" + json.dumps(research, ensure_ascii=False, indent=1)
            + "\n\n[데이터 형식 — files 의 키는 이 상대 경로]\n" + json.dumps(fmt, ensure_ascii=False, indent=1) + fb)
    res = llm.json("2-1c3", SYSTEM_CODE, user, SCHEMA_CODE, effort="high")
    code = res["code"].replace("\r\n", "\n").rstrip() + "\n"
    res.update(code=code, sha256=sha_text(code), static_problems=sandbox.static_check(code), executed=False, sent=user)
    return res


# ── 2-2 측정 조건 추출 [LLM → PY 확인] ──────────────────────────────────
SCHEMA_S = obj({"instrument": s(),
                "ranges": arr(obj({"quantity": s(), "dimension": s(enum=["current", "voltage", "resistance", "conductance",
                                                                          "temperature", "time", "frequency", "other"]),
                                   "range_name": s(nullable=True), "min": num(), "max": num(), "unit": s(),
                                   "accuracy": s(nullable=True), "resolution": s(nullable=True),
                                   "page": num(nullable=False, integer=True), "quote": s()})),
                "overflow_value": num(), "overflow_quote": s(nullable=True),
                "conditions": arr(obj({"name": s(), "value": s(), "page": num(nullable=False, integer=True), "quote": s()})),
                "questions": arr(s())})
SYSTEM_S = COMMON + """
과업 2-2 측정 조건 추출: 장비 사양서(쪽마다 [p.N] 표시)에서 측정 범위(유효한 판독값 범위)·오차(정확도)·분해능·범위 밖 표시값·동작 조건을 뽑는다.
이 값은 결과의 오차범위로 쓰지 않고, 원시 데이터의 사양 범위 이탈 판단에만 쓴다.
- ranges: 측정 범위마다 하나. min/max 는 그 범위에서 유효한 판독값의 하한·상한이고 unit 은 그 단위.
  문서가 하한을 명시하지 않으면 min 은 null. quote 는 min/max 가 적힌 근거 문장을 그 쪽 글자 그대로 인용, page 는 그 쪽 번호.
- conditions: 측정 결과의 유효성에 영향을 주는 동작 조건(온도·습도·예열 시간·적분 시간 등)마다 하나. value 는 문서의 값 그대로,
  quote 는 그 값이 적힌 문장을 그 쪽 글자 그대로 인용한다.
- 문서에 없는 값을 추정하지 않는다."""
NUM = r"\d+(?:\.\d+)?(?:[eE][+-]?\d+)?"


def _num_in(x: float, text: str) -> bool:
    text = re.sub(r"(?<=\d),(?=\d{3}\b)", "", text or "")          # 1,000 → 1000
    nums = [float(m) for m in re.findall(NUM, text)]
    return any(abs(abs(x) - n) <= 1e-9 * max(1.0, abs(x)) for n in nums)


def _part_s(ctx: dict, llm: LLM, fb: str) -> dict:
    out = {"files": [], "sent": {}, "unreadable": []}
    for x in ctx["specs"]:
        try:
            pages = readers.read_pdf_pages(ctx["base"] / x["path"]) if x["path"].lower().endswith(".pdf") \
                else [readers.read_text(ctx["base"] / x["path"])]
        except Exception as e:           # 깨진 사양서 — 이 파일만 건너뛰고(사양 범위 검사 안 함) 3 CONFIRM 참고 질문으로 남긴다
            out["unreadable"].append({"file": x["path"], "error": f"{type(e).__name__}: {e}"[:300]})
            continue
        if not any(p.strip() for p in pages):
            out["unreadable"].append({"file": x["path"], "error": "글자를 뽑지 못함(스캔 이미지 PDF 일 수 있음)"})
            continue
        user = "\n\n".join(f"[p.{i}]\n{t}" for i, t in enumerate(pages, 1)) + fb
        res = llm.json("2-2", SYSTEM_S, f"[장비 사양서: {x['path']}]\n{user}", SCHEMA_S, effort="medium")
        norm = [readers.normalize_space(p) for p in pages]
        for i, r in enumerate(res.get("ranges", [])):
            r["id"] = f"spec{len(out['files'])}_{i}"
            problems = []
            page_ok = 1 <= (r.get("page") or 0) <= len(pages)
            q = readers.normalize_space(r.get("quote"))
            if not page_ok or not q or q not in norm[r["page"] - 1]:
                problems.append("인용이 그 쪽 원문에 없음")
            for k in ("min", "max"):
                if r.get(k) is not None and q and not _num_in(r[k], q):
                    problems.append(f"{k}={r[k]} 가 인용 안에 없음")
            if units.parse(r.get("unit")) is None:
                problems.append(f"단위 '{r.get('unit')}' 를 해석하지 못함")
            r.update(verified=not problems, problems=problems)
        for i, c in enumerate(res.get("conditions", [])):
            c["id"] = f"cond{len(out['files'])}_{i}"
            q = readers.normalize_space(c.get("quote"))
            problems = []
            if not (1 <= (c.get("page") or 0) <= len(pages) and q and q in norm[c["page"] - 1]):
                problems.append("인용이 그 쪽 원문에 없음")
            value = re.sub(r"(?<=\d),(?=\d{3}\b)", "", c.get("value") or "")
            missing = [n for n in re.findall(NUM, value) if q and not _num_in(float(n), q)]
            if missing:
                problems.append(f"값의 숫자 {', '.join(missing)} 가 인용 안에 없음")
            c.update(verified=not problems, problems=problems)
        ov = res.get("overflow_value")
        res["overflow_verified"] = ov is None or bool(res.get("overflow_quote")) and _num_in(ov, res["overflow_quote"])
        out["files"].append({"file": x["path"], "pages": len(pages), **res})
        out["sent"][x["path"]] = user
    out["ranges"] = [r for f in out["files"] for r in f.get("ranges", [])]
    out["overflow_values"] = [f["overflow_value"] for f in out["files"] if f.get("overflow_value") is not None]
    return out


# ── 2-3 데이터 구조화 [PY] ─────────────────────────────────────────────
def _pick_range(col: str, unit: str | None, spec: dict, research: dict) -> tuple[dict | None, str]:
    dim = units.dimension(unit)
    cands = [r for r in spec.get("ranges", []) if dim and units.dimension(r.get("unit")) == dim
             and (r.get("min") is not None or r.get("max") is not None)]
    if not cands:
        return None, "같은 차원의 사양 범위 없음 — 범위 판정 안 함"
    wanted = [m.get("instrument_range") for m in research.get("matching") or [] if col in (m.get("data_columns") or [])]
    for w in filter(None, wanted):
        wn = readers.normalize_space(w).replace(" ", "").lower()
        hit = [r for r in cands if (r.get("range_name") or "").replace(" ", "").lower() == wn]
        if len(hit) == 1:
            return hit[0], f"계획서가 정한 범위 '{w}'"
    if len(cands) == 1:
        return cands[0], "같은 차원의 사양 범위가 하나"
    return None, f"같은 차원의 사양 범위가 {len(cands)}개 — 계획서가 범위를 정하지 않아 판정 안 함(3-2 에서 확인)"


def _part_structure(ctx: dict, a: dict, b: dict, spec: dict) -> dict:
    """단위 누락·모호(E01 후보) · 결측·숫자 아닌 값·사양 범위 이탈·범위 밖 표시값(E02 후보). 사양 기반 판정은 잠정."""
    columns, issues = [], []
    overflow = spec.get("overflow_values") or []

    def add(kind, file, col, rows, detail, tentative=False):
        issues.append({"id": f"{kind}:{file}:{col}", "kind": kind, "file": file, "column": col, "count": len(rows),
                       "rows": rows[:20], "detail": detail, "tentative": tentative,
                       "code": "E01" if kind.startswith("unit_") else "E02"})

    for g in a["groups"]:
        for c in g["analysis"]["columns"]:
            name, ci = c["name"], g["columns"].index(c["name"])
            prof = g["profile"][ci]
            hdr = units.from_header(name)
            llm_u = c.get("unit") if units.parse(c.get("unit")) is not None else None
            entry = {"group_id": g["group_id"], "column": name, "role": c["role"], "numeric": prof["numeric"],
                     "header_unit": hdr, "llm_unit": c.get("unit"), "llm_unit_source": c.get("unit_source")}
            if prof["numeric"] and c["role"] in VALUE_ROLES:
                if hdr and (llm_u is None or units.dimension(llm_u) == units.dimension(hdr)):
                    st, sug = "ok", [hdr]
                elif hdr:
                    st, sug = "ambiguous", [hdr, llm_u]
                elif llm_u:
                    st, sug = "ambiguous", [llm_u]
                else:
                    st, sug = "missing", [v["unit"] for e in b.get("equations") or [] for v in e.get("variables") or []
                                          if v.get("column") == name and v.get("unit")]
                entry.update(unit=hdr or llm_u, unit_status=st, suggestions=list(dict.fromkeys(x for x in sug if x)))
                if st != "ok":
                    add("unit_" + st, g["group_id"], name, [], ("단위 누락" if st == "missing" else "모호한 단위")
                        + f" — 헤더 {hdr or '없음'}, LLM {c.get('unit') or '없음'}({c.get('unit_source')})")
                if c["role"] == "measured":
                    rng, note = _pick_range(name, entry["unit"], spec, b)
                    entry.update(spec_range=rng and {k: rng.get(k) for k in ("id", "quantity", "range_name", "min", "max", "unit")},
                                 spec_note=note)
            columns.append(entry)
            for path in g["files"]:
                t = ctx["tables"][path]
                blank, nonnum, outside, over = [], [], [], []
                for r, line in zip(t["rows"], t["lines"]):
                    v = r[ci] if ci < len(r) else ""
                    if c["role"] == "other":             # 메모·설명 열의 빈칸은 측정값 결측이 아님(E02 대상 아님)
                        break
                    # 결측 표기(NA·null 등)는 숫자 열에서만 결측 — 문자 열에선 'none' 같은 값이 정상 이름일 수 있다
                    if v == "" or prof["numeric"] and v.lower() in ("na", "n/a", "nan", "null", "none", "-"):
                        blank.append({"line": line, "value": v})
                        continue
                    if not prof["numeric"]:
                        continue
                    x = readers.to_float(v)
                    if x is None:
                        nonnum.append({"line": line, "value": v})
                        continue
                    if any(abs(x - o) <= 1e-9 * abs(o) for o in overflow):
                        over.append({"line": line, "value": v})
                        continue
                    rng = entry.get("spec_range")
                    if rng and entry.get("unit"):
                        y = units.convert(x, entry["unit"], rng["unit"])
                        lo, hi = rng.get("min"), rng.get("max")
                        bad = (abs(y) > hi if lo is None and hi is not None else
                               (lo is not None and y < lo) or (hi is not None and y > hi))
                        if bad:
                            outside.append({"line": line, "value": v})
                if blank:
                    add("missing_value", path, name, blank, f"빈 값·결측 표기 {len(blank)}개")
                if nonnum:
                    add("non_numeric", path, name, nonnum, f"숫자가 아닌 값 {len(nonnum)}개")
                if over:
                    add("overflow", path, name, over, f"장비의 범위 밖 표시값 {len(over)}개 (잠정 — 3-2 확인 전)", tentative=True)
                if outside:
                    rng = entry["spec_range"]
                    lim = f"{rng.get('min')} ~ {rng.get('max')} {rng.get('unit')}" if rng.get("min") is not None \
                        else f"|값| ≤ {rng.get('max')} {rng.get('unit')} (하한 미기재)"
                    add("out_of_spec", path, name, outside,
                        f"사양 범위({rng.get('range_name') or rng.get('quantity')}: {lim}) 밖 {len(outside)}개 (잠정 — 3-2 확인 전)",
                        tentative=True)
    return {"columns": columns, "issues": issues, "spec_status": "잠정 (3-2 에서 사양 확인 전)",
            "note": "통계적으로 튀는 값은 판정하지 않음 — 장비 사양 범위 밖 값만 이상치로 봄. 도구가 값을 자동으로 빼지 않음"}


# ── 2-4 누락 점검 [LLM → PY] ────────────────────────────────────────────
SCHEMA_M = obj({"conditions": arr(obj({"name": s("계획서 표기"), "samples": arr(s())})),
                "replicates": arr(s("시료 안의 반복·위치 이름")), "points_per_replicate": num(integer=True),
                "rows_per_file": num(integer=True), "file_rule": s(nullable=True),
                "required_documents": arr(s(enum=["plan", "spec", "raw", "other"])), "quote": s(), "questions": arr(s())})
SYSTEM_M = COMMON + """
과업 2-4 누락 점검: 연구 계획서만 읽고 결론을 내리는 데 필요한 데이터를 뽑는다 — 조건별 시료 목록, 시료 안의 반복·위치 목록,
반복마다 측정점 수, 파일당 행 수, 파일 규칙, 필요한 문서. 실제로 받은 파일 목록은 보여 주지 않는다(파이썬이 대조한다).
시료 ID 와 반복 이름은 범위 표기(S01–S10, P1–P7) 없이 모두 풀어 적는다. 계획서에 없으면 null 또는 빈 목록."""


def _part_m_llm(ctx: dict, llm: LLM, fb: str) -> dict:
    user = "[연구 계획서]\n" + ctx["plan"]["text"] + fb
    res = llm.json("2-4", SYSTEM_M, user, SCHEMA_M, effort="medium")
    for c in res.get("conditions", []):
        c["samples"] = design.expand_samples(c.get("samples") or [])
    res["replicates"] = design.expand_samples(res.get("replicates") or [])
    res["sent"] = user
    return res


def _part_m_check(ctx: dict, a: dict, req: dict) -> dict:
    info = column_info(a)
    id_col = next((n for n, c in info.items() if c["role"] == "id"), None)
    rep_col = next((n for n, c in info.items() if c["role"] == "replicate"), None)
    counts: dict[tuple, int] = {}
    file_of: dict[str, str] = {}
    rows_of: dict[str, int] = {}
    for path, t in ctx["tables"].items():
        ii = t["columns"].index(id_col) if id_col in t["columns"] else None
        ri = t["columns"].index(rep_col) if rep_col in t["columns"] else None
        for r in t["rows"]:
            sid = r[ii] if ii is not None and ii < len(r) and r[ii] else Path(path).stem
            rep = r[ri] if ri is not None and ri < len(r) else ""
            counts[(sid, rep)] = counts.get((sid, rep), 0) + 1
            file_of.setdefault(sid, path)
            rows_of[sid] = rows_of.get(sid, 0) + 1
    missing = []
    points, per_file = req.get("points_per_replicate"), req.get("rows_per_file")
    planned = set()
    for c in req.get("conditions", []):
        for sid in c.get("samples", []):
            planned.add(sid)
            base = {"condition": c["name"], "sample": sid, "file": file_of.get(sid)}
            if sid not in rows_of:
                missing.append({**base, "kind": "시료 없음", "detail": f"계획서의 시료 {sid} 가 데이터에 없음"})
                continue
            if req.get("replicates") and rep_col:
                for rep in req["replicates"]:
                    n = counts.get((sid, rep), 0)
                    if n == 0:
                        missing.append({**base, "kind": "반복 없음", "detail": f"{sid} {rep_col}={rep} 없음"})
                    elif points and n < points:
                        missing.append({**base, "kind": "측정점 부족", "detail": f"{sid} {rep_col}={rep}: {n}/{points}점"})
            elif per_file and rows_of[sid] < per_file:
                missing.append({**base, "kind": "행 수 부족", "detail": f"{sid}: {rows_of[sid]}/{per_file}행"})
    if "spec" in (req.get("required_documents") or []) and not ctx["specs"]:
        missing.append({"condition": None, "sample": None, "file": None, "kind": "필요 문서 없음", "detail": "장비 사양서"})
    return {"id_column": id_col, "replicate_column": rep_col, "found_samples": sorted(rows_of),
            "extra_samples": sorted(set(rows_of) - planned) if planned else [], "missing": missing}


# ── 실행 ────────────────────────────────────────────────────────────────
def run(rid: str, llm: LLM | None = None, parts=None, feedback: dict | None = None, from_confirm: bool = False) -> dict:
    store.require(rid, "ingest")
    if not from_confirm and store.stage_status(rid, "confirm"):
        raise ValueError("3 CONFIRM 을 시작한 실행 — 고칠 내용은 CONFIRM 답변(아니오 + 수정 내용)으로 보냄")
    if store.state(rid)["stages"]["ingest"].get("blocked"):
        raise ValueError("1 INGEST 에서 막힘(RAW·연구 계획서 없음) — 파일을 다시 넣어 새 실행")
    llm = llm or LLM()
    parts = set(parts or PARTS)
    exdir = store.out_dir(rid) / "extract"
    prev_summary = store.read(rid, "extract/summary.json") or {}
    rnd = (prev_summary.get("round") or 0) + 1
    ctx = _inputs(rid)
    if exdir.exists():   # 이전 회차 보관
        hist = exdir / "history" / f"round{rnd - 1}"
        hist.mkdir(parents=True, exist_ok=True)
        for f in exdir.glob("*.*"):
            shutil.copy2(f, hist / f.name)
    store.mark(rid, "extract", "running", round=rnd)
    res = {k: store.read(rid, f"extract/{v}") for k, v in FILES.items()}
    res["2-1b"] = ctx["equations"]           # 2-1b [PY] 는 결정적 — 매번 다시 변환해도 같은 결과
    steps = {k: v for k, v in (prev_summary.get("steps") or {}).items()}
    steps["2-1b"] = {"status": "ok", "seconds": 0, "round": rnd, "equations": len(ctx["equations"]["equations"]),
                     "failed": len(ctx["equations"]["failed"])}

    def timed(key, fn):
        t0 = time.time()
        try:
            res[key] = fn()
            steps[key] = {"status": "ok", "seconds": round(time.time() - t0, 1), "round": rnd}
        except Exception as e:
            res[key] = None
            steps[key] = {"status": "error", "seconds": round(time.time() - t0, 1), "round": rnd,
                          "error": f"{type(e).__name__}: {e}"[:1000]}

    def skip(key, reason):
        res[key] = None
        steps[key] = {"status": "skipped", "round": rnd, "reason": reason}

    def chain_21():
        timed("2-1a", lambda: _part_a(ctx, llm, _feedback(feedback, "2-1")))
        if res["2-1a"]:
            timed("2-1c", lambda: _part_c(ctx, res["2-1a"], llm, _feedback(feedback, "2-1")))
        else:
            skip("2-1c", "2-1a 실패")
        if res["2-1a"] and res["2-1c"]:
            timed("2-1c-code", lambda: _part_code(ctx, res["2-1a"], res["2-1c"], llm, _feedback(feedback, "2-1")))
        else:
            skip("2-1c-code", "2-1a 또는 2-1c 실패")

    jobs = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        if "2-1" in parts:
            jobs.append(pool.submit(chain_21))
        if "2-2" in parts:
            jobs.append(pool.submit(timed, "2-2", lambda: _part_s(ctx, llm, _feedback(feedback, "2-2"))))
        m_llm = pool.submit(_part_m_llm, ctx, llm, _feedback(feedback, "2-4")) if "2-4" in parts else None
        for j in jobs:
            j.result()
    if m_llm is not None:
        def m_all():
            req = m_llm.result()
            if not res.get("2-1a"):
                raise ValueError("2-1a 가 없어 대조하지 못함")
            return {"required": req, **_part_m_check(ctx, res["2-1a"], req)}
        timed("2-4", m_all)
    elif "2-1" in parts and res.get("2-1a") and (res.get("2-4") or {}).get("required"):
        required = res["2-4"]["required"]
        timed("2-4", lambda: {"required": required, **_part_m_check(ctx, res["2-1a"], required)})
    elif "2-1" in parts and not res.get("2-1a"):
        skip("2-4", "2-1a 실패")
    if res.get("2-1a") and res.get("2-1c"):
        timed("2-3", lambda: _part_structure(ctx, res["2-1a"], res["2-1c"], res.get("2-2") or {"ranges": []}))
    elif "2-1" in parts:
        skip("2-3", "2-1a 또는 2-1c 실패")
    if not ctx["specs"]:
        res["2-2"] = {"files": [], "ranges": [], "overflow_values": [], "note": "장비 사양서 없음"}
        steps["2-2"] = {"status": "ok", "seconds": 0, "round": rnd, "note": "사양서 없음"}

    written = {}
    for key, fname in FILES.items():
        if res.get(key) is not None:
            written[key] = write_json(exdir / fname, res[key])
        else:
            (exdir / fname).unlink(missing_ok=True)
    if res.get("2-1c-code"):
        (exdir / "code_draft.py").write_text(res["2-1c-code"]["code"], encoding="utf-8")
    else:
        (exdir / "code_draft.py").unlink(missing_ok=True)
    questions = [{"source": "2-1b", "text": n} for n in ctx["equations"]["notes"]]
    for g in (res.get("2-1a") or {}).get("groups", []):
        questions += [{"source": f"2-1a {g['group_id']}", "text": q} for q in g["analysis"].get("questions", [])]
    questions += [{"source": "2-1c", "text": q} for q in (res.get("2-1c") or {}).get("questions", [])]
    questions += [{"source": "2-1c 코드", "text": q} for q in (res.get("2-1c-code") or {}).get("assumptions", [])]
    for f in (res.get("2-2") or {}).get("files", []):
        questions += [{"source": f"2-2 {f['file']}", "text": q} for q in f.get("questions", [])]
    questions += [{"source": f"2-2 {u['file']}", "text": f"장비 사양서를 읽지 못함({u['error']}) — 사양 범위 이탈(E02) 검사를 하지 않습니다. "
                                                        "글자를 뽑을 수 있는 PDF 로 다시 올려 주세요."}
                  for u in (res.get("2-2") or {}).get("unreadable", [])]
    questions += [{"source": "2-4", "text": q} for q in ((res.get("2-4") or {}).get("required") or {}).get("questions", [])]
    errors = {k: v["error"] for k, v in steps.items() if v.get("status") == "error"}
    summary = {"stage": "2 EXTRACT", "run_id": rid, "round": rnd, "finished_at": now(), "steps": steps,
               "llm": {**llm.status(), **llm.stats}, "questions": questions, "errors": errors,
               "feedback": feedback or {}, "parts_run": sorted(parts),
               "blind": f"최종 보고서 초안 {ctx['reports_not_opened']}개는 열지 않음"}
    summary["hash"] = sha_obj({k: res.get(k) for k in FILES})
    write_json(exdir / "summary.json", summary)
    ingest_hash = ctx["ingest"]["input_hash"]
    for key, p in written.items():
        if key == "2-1b":                    # 파이썬 변환 — 입력은 계획서 해시, 코드는 docx_equations
            plan_hash = sha_text(canonical([(f["file"], f["plan_sha256"]) for f in ctx["equations"]["files"]]))
            lineage.record("2 EXTRACT 2-1b equations", rid, plan_hash, lineage.code_version(docx_equations),
                           {"converter": ctx["equations"]["converter"], "dwml": ctx["equations"]["dwml"]}, [p])
        else:
            lineage.record(f"2 EXTRACT {key} {p.stem}", rid, ingest_hash, lineage.code_version(sys.modules[__name__], readers, units),
                           {"model": llm.model, "round": rnd, "feedback": sha_obj(feedback or {})}, [p])
    store.mark(rid, "extract", "error" if errors else "done", round=rnd, errors=len(errors))
    return view(rid)


def view(rid: str) -> dict:
    out = {"summary": store.read(rid, "extract/summary.json")}
    for key, fname in FILES.items():
        out[key] = store.read(rid, f"extract/{fname}")
    return out
