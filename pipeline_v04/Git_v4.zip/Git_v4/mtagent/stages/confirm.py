"""3 CONFIRM — 사람이 확정한다. [USER] 승인값 반영은 파이썬. 보고서 수치는 어떤 질문에도 나오지 않는다(아직 열지 않음).

3-1 데이터 해석 승인   2-1(데이터 내용·LaTeX 식·가공 방법·설계·검정·매칭표·계산 코드) + 2-4(누락 — E03)
                       매칭표는 도식(Mermaid·글, confirm/relation_diagram.md)으로도. 승인한 코드는 해시를 떠서 고정(R1).
                       변환 실패한 식은 원문을 보고 LaTeX 로 직접 입력. 틀린 해석 → 고칠 내용을 받아 EXTRACT 2-1 다시.
3-2 장비 사양 확인     2-2(측정 범위·오차·범위 밖 표시값·동작 조건). 고쳐지지 않으면 2-3 의 잠정 이상치 확정, 고쳐지면 2-2·2-3 다시.
3-3 데이터 이상 확인   2-3 — 단위 누락·모호(E01) → 제안 중 고르거나 직접 입력 / 결측·이상치(E02) → 재측정(파일을 고쳐 1 INGEST 부터
                       새 실행, 원본은 지우지 않음) 또는 그대로 진행(결정을 기록).
피드백 루프: 최대 3회, 바뀐 항목만 다시 묻는다. 모든 답변은 내용·응답자·시각과 함께 기록하고 회차마다 제안 해시를 남긴다.
3회 뒤에도 미확정인 항목에 의존하는 주장은 5-2 에서 Unsupported — 단위는 E01, 데이터 이상은 E02, 나머지는 E06(미확정).
"""
from __future__ import annotations

import os
import stat
import sys

from mtagent import config, lineage, store, units
from mtagent.llm import LLM
from mtagent.stages import extract
from mtagent.util import now, sha_obj, sha_text, write_json

YES = {"value": "yes", "label": "맞음"}
NO = {"value": "no", "label": "수정 필요 — 고칠 내용을 적어 주세요", "needs_text": True}
MANUAL_EQ = {"value": "manual", "label": "직접 입력 — 원문의 식을 LaTeX 로 적어 주세요", "needs_text": True}
FAILED_LATEX = "(변환 실패 — 원문 확인 필요)"
DATA_ISSUE_LABEL = {"missing_value": "결측치", "non_numeric": "숫자가 아닌 값", "out_of_spec": "이상치 (장비 사양 범위 밖)",
                    "overflow": "장비의 범위 밖 표시값"}


def _item(iid, group, title, question, proposal, choices, required=True, target="*", part=None) -> dict:
    return {"id": iid, "group": group, "title": title, "question": question, "proposal": proposal,
            "proposal_hash": sha_obj(proposal)[:16], "choices": choices, "required": required, "target": target,
            "part": part, "status": "pending", "answer": None, "history": []}


def _label(text, limit: int = 60) -> str:
    t = " ".join(str(text or "—").split()).replace('"', "'")
    return t if len(t) <= limit else t[:limit - 1] + "…"


def relation_diagram(research: dict) -> dict:
    """실험 ↔ 데이터 ↔ 식 ↔ 장비 → 결과 — Mermaid 흐름도와 글 도식."""
    lines, text = ["flowchart LR"], []
    for k, m in enumerate(research.get("matching") or [], 1):
        cols = ", ".join(m.get("data_columns") or []) or "—"
        eqs = ", ".join(m.get("equation_ids") or []) or "—"
        inst = " · ".join(x for x in (m.get("instrument"), m.get("instrument_range")) if x) or "—"
        lines += [f'  X{k}["실험: {_label(m.get("experiment"))}"] --> D{k}["데이터: {_label(cols)}"]',
                  f'  I{k}["장비: {_label(inst)}"] -. 측정 .-> D{k}',
                  f'  D{k} --> E{k}["식: {_label(eqs)}"]',
                  f'  E{k} --> R{k}["결과: {_label(m.get("results"))}"]']
        text.append(f"[{k}] 실험 「{m.get('experiment') or '—'}」\n"
                    f"     ├─ 장비  {inst}\n"
                    f"     ├─ 데이터 {cols}\n"
                    f"     ├─ 식    {eqs}\n"
                    f"     └─ 결과  {m.get('results') or '—'}")
    return {"mermaid": "\n".join(lines), "text": "\n".join(text)}


def _write_diagram(rid: str, items: list[dict]) -> None:
    it = next((i for i in items if i["id"] == "3-1:matching"), None)
    d = it["proposal"]["diagram"] if it else relation_diagram({})
    md = ("# 실험 ↔ 데이터 ↔ 식 ↔ 장비\n\n3 CONFIRM 3-1 에서 확인할 관계 (2-1c 추출 결과, 확인 전).\n\n"
          "```mermaid\n" + d["mermaid"] + "\n```\n\n```\n" + d["text"] + "\n```\n")
    path = store.out_dir(rid) / "confirm" / "relation_diagram.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(md, encoding="utf-8")


def _equations_with_manual(equations: list[dict], manual: dict[str, str]) -> list[dict]:
    """변환 실패한 식에 연구자가 3-1 에서 적은 LaTeX 를 넣는다 (latex_source 로 출처 표시)."""
    out = []
    for e in equations:
        if e["id"] in manual:
            e = {**e, "latex": manual[e["id"]], "status": "manual", "latex_source": "researcher"}
        elif e.get("latex") is not None:
            e = {**e, "latex_source": e.get("converter") or "converter"}
        out.append(e)
    return out


def unit_key(x: dict) -> str:
    """단위 결정의 열쇠 — 같은 열 이름이 여러 묶음(G1 · G2)에 있어도 따로 묻고 따로 적는다."""
    return f"{x.get('group_id') or '-'}:{x['column']}"


def _parts(v: dict) -> tuple:
    """(2-1a 데이터 내용, 2-1c 연구 내용, 2-1c 계산 코드, 2-2 사양, 2-3 구조화, 2-4 누락)."""
    return tuple(v.get(k) or {} for k in ("2-1a", "2-1c", "2-1c-code", "2-2", "2-3", "2-4"))


def build_items(rid: str) -> list[dict]:
    v = extract.view(rid)
    a, b, c, sp, st, m = _parts(v)
    items = []
    # 3-1 데이터 해석 승인
    for g in a.get("groups", []):
        items.append(_item(f"3-1:data:{g['group_id']}", "3-1", f"데이터 내용 {g['group_id']} ({len(g['files'])}개 파일)",
                           "이 데이터 파일들이 이런 내용이 맞나요?",
                           {"summary": g["analysis"]["summary"], "files": g["files"][:10], "n_files": len(g["files"]),
                            "columns": g["analysis"]["columns"]}, [YES, NO], part="2-1"))
    for e in b.get("equations", []):
        prop = {k: e.get(k) for k in ("latex", "context", "meaning", "role", "variables")}
        if e.get("status") == "failed":        # Word 수식 → LaTeX 변환 실패 (2-1b, docx_equations)
            prop.update(latex=FAILED_LATEX, status="failed", error=e.get("error"))
            items.append(_item(f"3-1:eq:{e['id']}", "3-1", f"식 {e['id']} — 변환 실패",
                               f"이 식은 Word 수식을 LaTeX 로 바꾸지 못했습니다({e.get('error')}). "
                               "계획서 원문을 보고 LaTeX 로 직접 적어 주세요.", prop, [MANUAL_EQ],
                               target=f"eq:{e['id']}", part="2-1"))
            continue
        items.append(_item(f"3-1:eq:{e['id']}", "3-1", f"식 {e['id']}", "이 수식을 이렇게 읽고, 이 뜻으로 계산에 쓰는 게 맞나요?",
                           prop, [YES, NO], target=f"eq:{e['id']}", part="2-1"))
    if b:
        steps = b.get("steps") or []
        items.append(_item("3-1:steps", "3-1", "가공 방법 (raw → 계산 입력값 → 보고값)",
                           "RAW 를 이 방법으로 가공·계산하는 게 맞나요?" if steps else
                           "LLM 이 가공 방법을 뽑지 못했습니다(빈 목록) — 계획서의 가공·계산 순서를 적어 주세요.",
                           {"steps": steps}, [YES, NO] if steps else [NO], part="2-1"))
        items.append(_item("3-1:design", "3-1", "실험 설계 · 검정 방법",
                           "조건·시료·독립 단위·반복 수와 검정 방법을 이렇게 읽었습니다. 맞나요?",
                           {"design": b.get("design"), "test": b.get("test"), "outputs": b.get("outputs")}, [YES, NO], part="2-1"))
        matching = b.get("matching") or []
        items.append(_item("3-1:matching", "3-1", "실험 — 데이터 — 식 — 장비",
                           "이 실험에서 이 장비로 이 측정값을 확인했고, 이 식으로 계산하는 게 맞나요? "
                           "(관계 도식: confirm/relation_diagram.md)" if matching else
                           "LLM 이 실험 — 데이터 — 식 — 장비 연결을 뽑지 못했습니다(빈 목록) — 어떤 실험에서 어떤 장비로 "
                           "어떤 열을 재고 어떤 식으로 계산하는지 적어 주세요.",
                           {"matching": matching, "diagram": relation_diagram(b)}, [YES, NO] if matching else [NO],
                           part="2-1"))
    if c:
        items.append(_item("3-1:code", "3-1", "계산 코드", "위 식·가공 방법을 이 코드로 계산합니다. 승인하면 코드 해시를 고정하고 "
                           "4 RECOMPUTE 에서만 격리 실행합니다.",
                           {"sha256": c.get("sha256"), "code": c.get("code"), "explanation": c.get("explanation"),
                            "assumptions": c.get("assumptions"), "static_problems": c.get("static_problems")},
                           [YES, NO] if not c.get("static_problems") else [NO], target="code", part="2-1"))
    if m:
        miss = m.get("missing") or []
        prop = {"required": {k: (m.get("required") or {}).get(k) for k in ("conditions", "replicates", "points_per_replicate",
                                                                         "rows_per_file", "file_rule")},
                "missing": miss, "extra_samples": m.get("extra_samples")}
        if miss:
            items.append(_item("3-1:missing", "3-1", f"누락 데이터 {len(miss)}건",
                               "계획서가 요구하는 데이터 중 빠진 것이 있습니다. 어떻게 할까요?", prop,
                               [{"value": "proceed", "label": "그대로 진행 — 누락을 기록하고, 이 데이터에 기대는 주장은 E03"},
                                {"value": "reupload", "label": "파일을 보완해 다시 올리기 (1 INGEST 부터 새 실행)"},
                                {"value": "no", "label": "누락 판단이 틀림 — 고칠 내용을 적어 주세요", "needs_text": True}], part="2-4"))
        else:
            items.append(_item("3-1:missing", "3-1", "누락 점검", "계획서가 요구하는 데이터가 모두 있습니다. 맞나요?", prop,
                               [YES, NO], part="2-4"))
    # 3-2 장비 사양 확인
    for f in sp.get("files", []):
        for r in f.get("ranges", []):
            items.append(_item(f"3-2:{r['id']}", "3-2", f"{r['quantity']} · {r.get('range_name') or ''}".strip(" ·"),
                               f"장비 사양서 {r['page']}쪽을 읽어 보니 이 범위의 유효 판독값은 {r.get('min')} ~ {r.get('max')} "
                               f"{r['unit']}, 정확도 {r.get('accuracy') or '—'} 입니다. 맞나요?",
                               {**{k: r.get(k) for k in ("quantity", "range_name", "min", "max", "unit", "accuracy", "resolution",
                                                         "page", "quote", "verified", "problems")}, "file": f["file"]},
                               [YES, NO], target="spec", part="2-2"))
        for cd in f.get("conditions", []):
            items.append(_item(f"3-2:{cd.get('id') or cd['name']}", "3-2", f"측정 조건 · {cd['name']}",
                               f"장비 사양서 {cd.get('page')}쪽을 읽어 보니 측정 조건 '{cd['name']}' 은 {cd.get('value')} 입니다. 맞나요?",
                               {**{k: cd.get(k) for k in ("name", "value", "page", "quote", "verified", "problems")},
                                "file": f["file"]}, [YES, NO], target="spec", part="2-2"))
        if f.get("overflow_value") is not None:
            items.append(_item(f"3-2:overflow:{f['file']}", "3-2", f"범위 밖 표시값 {f['overflow_value']:g}",
                               "범위 밖 측정은 이 값으로 기록된다고 읽었습니다. 맞나요?",
                               {"value": f["overflow_value"], "quote": f.get("overflow_quote"), "verified": f.get("overflow_verified"),
                                "file": f["file"]}, [YES, NO], target="spec", part="2-2"))
    # 3-3 데이터 이상 확인
    cols = [x for x in st.get("columns", []) if x.get("unit_status")]
    if cols:
        items.append(_item("3-3:definition", "3-3", "측정 정의 (열의 역할·단위)",
                           "측정값·독립변수 열의 뜻과 단위를 이렇게 정의해 고정합니다. 맞나요? (단위 누락·모호는 아래에서 따로 고릅니다)",
                           {"columns": [{k: x.get(k) for k in ("group_id", "category", "column", "role", "unit", "unit_status",
                                                                "header_unit", "spec_range", "spec_note")} for x in cols]},
                           [YES, NO], part="2-1"))
    for x in cols:
        if x["unit_status"] != "ok":
            opts = [{"value": f"unit:{u}", "label": f"{u}"} for u in x.get("suggestions") or []]
            opts.append({"value": "other", "label": "기타 — 단위를 직접 입력", "needs_text": True})
            key = unit_key(x)
            items.append(_item(f"3-3:unit:{key}", "3-3",
                               f"단위 {'누락' if x['unit_status'] == 'missing' else '모호'}: {x['column']} ({x['group_id']})",
                               "이 열의 단위를 골라 주세요.", {k: x.get(k) for k in ("group_id", "column", "header_unit", "llm_unit",
                                                                                   "llm_unit_source", "suggestions")},
                               opts, target=f"unit:{key}"))
    for iss in st.get("issues", []):
        if iss["kind"] in DATA_ISSUE_LABEL:
            items.append(_item(f"3-3:data:{iss['id']}", "3-3", f"{DATA_ISSUE_LABEL[iss['kind']]}: {iss['file']} · {iss['column']}",
                               f"{iss['file']} 의 {iss['column']} 열에서 {iss['detail']} — 줄 번호와 값을 확인해 주세요. 어떻게 할까요?",
                               iss, [{"value": "proceed", "label": "충분히 나올 수 있는 값 — 그대로 진행 (결정을 기록: E02)"},
                                     {"value": "reupload", "label": "재측정 — 파일을 고쳐 다시 올리기 (1 INGEST 부터 새 실행, 원본은 지우지 않음)"}],
                               target=f"data:{iss['file']}"))
    # 참고 질문 (선택) — 같은 출처·같은 글은 한 번만 (id 가 겹치면 한쪽에 답할 수 없음)
    seen = set()
    for i, q in enumerate((v.get("summary") or {}).get("questions", [])):
        qid = f"Q:{sha_text(q['source'] + q['text'])[:10]}"
        if qid in seen:
            continue
        seen.add(qid)
        part = "2-2" if q["source"].startswith("2-2") else "2-4" if q["source"].startswith("2-4") else "2-1"
        items.append(_item(qid, "Q", q["source"], q["text"], {"question": q},
                           [{"value": "skip", "label": "넘어가기"},
                            {"value": "answer", "label": "답하고 반영 (해당 추출을 다시 함)", "needs_text": True}],
                           required=False, part=part))
    return items


def _state_path(rid: str):
    return store.out_dir(rid) / "confirm" / "confirm_state.json"


def load(rid: str) -> dict:
    s = store.read(rid, "confirm/confirm_state.json")
    if s is None:
        raise ValueError("3 CONFIRM 을 시작하지 않음")
    return s


def _save(rid: str, s: dict) -> dict:
    write_json(_state_path(rid), s)
    return s


def start(rid: str) -> dict:
    store.require(rid, "extract")
    if store.stage_status(rid, "confirm"):
        return view(rid)
    summary = store.read(rid, "extract/summary.json") or {}
    if summary.get("errors"):
        raise ValueError(f"2 EXTRACT 에 실패한 과업이 있음 {list(summary['errors'])} — 2 EXTRACT 를 다시 실행")
    s = {"run_id": rid, "round": 1, "status": "open", "started_at": now(), "items": build_items(rid),
         "feedback": {}, "overrides": {"units": {}}, "log": []}
    _write_diagram(rid, s["items"])
    _save(rid, s)
    store.mark(rid, "confirm", "open", round=1)
    return view(rid)


def view(rid: str) -> dict:
    s = load(rid)
    items = s["items"]
    pending = [i for i in items if i["required"] and i["status"] == "pending"]
    return {**s, "counts": {"total": len(items), "pending_required": len(pending),
                            "by_status": {st: sum(1 for i in items if i["status"] == st) for st in
                                          {i["status"] for i in items}}},
            "max_rounds": config.CONFIRM_MAX_ROUNDS, "confirmed": store.read(rid, "confirm/confirmed.json")}


def _validate(item: dict, ans: dict) -> str | None:
    if not isinstance(ans, dict):
        return f"{item['title']}: 답변은 객체여야 함"
    choice = ans.get("choice")
    opt = next((c for c in item["choices"] if c["value"] == choice), None)
    if opt is None:
        return f"{item['title']}: 고를 수 없는 답 {choice!r}"
    if ans.get("text") is not None and not isinstance(ans["text"], str):
        return f"{item['title']}: 내용은 문자열이어야 함"
    text = (ans.get("text") or "").strip()
    if opt.get("needs_text") and not text:
        return f"{item['title']}: 내용을 적어야 함"
    if item["id"].startswith("3-3:unit:") and choice == "other" and units.parse(text) is None:
        return f"{item['title']}: 단위 '{text}' 를 해석할 수 없음 (예: A, nA, V, nS)"
    return None


def submit(rid: str, respondent: str, answers: dict, llm: LLM | None = None) -> dict:
    if not isinstance(respondent, str):
        raise ValueError("확인한 사람 이름은 문자열이어야 함")
    respondent = respondent.strip()
    if not respondent:
        raise ValueError("확인한 사람 이름이 필요함")
    if not isinstance(answers, dict):
        raise ValueError("답변은 항목 ID를 키로 하는 객체여야 함")
    s = load(rid)
    if s["status"] != "open":
        raise ValueError(f"CONFIRM 이 이미 끝남 ({s['status']})")
    by_id = {i["id"]: i for i in s["items"]}
    errors = []
    for iid, ans in (answers or {}).items():
        it = by_id.get(iid)
        if it is None or it["status"] not in ("pending",):
            continue
        err = _validate(it, ans)
        if err:
            errors.append(err)
    if errors:
        raise ValueError("; ".join(errors))
    at = now()
    for iid, ans in (answers or {}).items():
        it = by_id.get(iid)
        if it is None or it["status"] != "pending":
            continue
        choice, text = ans["choice"], (ans.get("text") or "").strip()
        it["answer"] = {"choice": choice, "text": text, "respondent": respondent, "at": at, "round": s["round"]}
        it["history"].append(it["answer"])
        if choice in ("yes", "skip"):
            it["status"] = "approved"
        elif choice == "proceed":
            it["status"] = "decided"
        elif choice == "reupload":
            it["status"] = "reupload"
        elif choice in ("no", "answer"):
            it["status"] = "rejected" if choice == "no" else "answered"
        elif choice.startswith("unit:") or choice == "other":
            unit = choice[5:] if choice.startswith("unit:") else units.normalize(text)
            s["overrides"]["units"][unit_key(it["proposal"])] = unit
            it["status"] = "decided"
        elif choice == "manual":              # 변환 실패한 식 — 연구자가 적은 LaTeX 로 확정
            eid = it["id"].split(":", 2)[2]
            s["overrides"].setdefault("equations", {})[eid] = text
            s["feedback"].setdefault("2-1", []).append(f"[식 {eid}] 변환에 실패해 연구자가 원문을 보고 적은 식: {text}")
            it["status"] = "decided"
    s["log"].append({"at": at, "respondent": respondent, "round": s["round"], "answered": sorted(answers or {})})
    if any(i["status"] == "reupload" for i in s["items"]):
        s["status"] = "restart_required"
        s["restart_reason"] = [i["title"] for i in s["items"] if i["status"] == "reupload"]
        _save(rid, s)
        store.mark(rid, "confirm", "restart_required")
        return view(rid)
    if any(i["required"] and i["status"] == "pending" for i in s["items"]):
        _save(rid, s)
        return view(rid)
    to_fix = [i for i in s["items"] if i["status"] in ("rejected", "answered")]
    if to_fix and s["round"] < config.CONFIRM_MAX_ROUNDS:
        return _next_round(rid, s, to_fix, llm)
    for i in to_fix:            # 3회 뒤에도 '아니오' → 미확정
        if i["status"] == "rejected":
            i["status"] = "unresolved"
        else:
            i["status"] = "approved"
    return _complete(rid, s, respondent)


def _next_round(rid: str, s: dict, to_fix: list[dict], llm: LLM | None) -> dict:
    parts = set()
    for i in to_fix:
        part = i.get("part") or "2-1"
        parts.add(part)
        s["feedback"].setdefault(part, []).append(f"[{i['title']}] {i['answer']['text']}")
    run_parts = set(parts)
    if "2-1" in run_parts or "2-2" in run_parts:
        run_parts.add("2-3")
    extracted = extract.run(rid, llm, parts=run_parts, feedback=s["feedback"], from_confirm=True)
    errs = (extracted.get("summary") or {}).get("errors") or {}
    if errs:
        raise ValueError(f"2 EXTRACT 재실행 실패 {list(errs)} — CONFIRM 회차를 진행하지 않음")
    old = {i["id"]: i for i in s["items"]}
    new_items = build_items(rid)
    for it in new_items:
        o = old.get(it["id"])
        if o is None:
            continue
        it["history"] = o["history"]
        if (o["proposal_hash"] == it["proposal_hash"] and o["status"] in ("approved", "decided")
                and not ("2-1" in run_parts and it["id"] == "3-1:code")):
            it["status"], it["answer"] = o["status"], o["answer"]
            it["carried"] = True
        elif o["proposal_hash"] != it["proposal_hash"]:
            it["changed_from"] = o["proposal_hash"]
        elif o["status"] in ("rejected", "answered") and it["group"] == "Q":
            it["status"], it["answer"] = "approved", o["answer"]
    s["items"] = new_items
    s["round"] += 1
    _write_diagram(rid, new_items)
    s["log"].append({"at": now(), "event": f"{s['round']}회차 — 2 EXTRACT {sorted(run_parts)} 다시 실행",
                     "feedback_parts": sorted(parts)})
    _save(rid, s)
    store.mark(rid, "confirm", "open", round=s["round"])
    return view(rid)


def _complete(rid: str, s: dict, respondent: str) -> dict:
    v = extract.view(rid)
    a, b, c, sp, st, m = _parts(v)
    items = {i["id"]: i for i in s["items"]}
    unresolved = [i for i in s["items"] if i["status"] == "unresolved"]
    cdir = store.out_dir(rid) / "confirm"
    code = None
    code_item = items.get("3-1:code")
    if code_item and code_item["status"] == "approved" and c.get("code"):
        path = cdir / "approved_code.py"
        if path.exists():
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
        path.write_text(c["code"], encoding="utf-8", newline="\n")
        os.chmod(path, stat.S_IREAD)
        code = {"path": "confirm/approved_code.py", "sha256": sha_text(c["code"]),
                "approved_by": code_item["answer"]["respondent"], "approved_at": code_item["answer"]["at"]}
    overrides = s["overrides"]["units"]
    registry = []
    for x in st.get("columns", []):
        registry.append({**{k: x.get(k) for k in ("group_id", "column", "role", "numeric", "spec_range")},
                         "unit": overrides.get(unit_key(x), x.get("unit")),
                         "unit_decided": unit_key(x) in overrides})
    spec_ok = [r for f in sp.get("files", []) for r in f.get("ranges", [])
               if items.get(f"3-2:{r['id']}", {}).get("status") == "approved"]
    data_flags = [{"code": "E02", **{k: i["proposal"][k] for k in ("kind", "file", "column", "count", "rows", "detail")},
                   "decision": "proceed", "decided_by": i["answer"]["respondent"]}
                  for i in s["items"] if i["id"].startswith("3-3:data:") and i["status"] == "decided"]
    missing = [{"code": "E03", **x} for x in (m.get("missing") or [])] \
        if items.get("3-1:missing", {}).get("status") in ("decided", "approved") else []
    conf = {"run_id": rid, "project": store.state(rid)["project"], "confirmed_at": now(), "round": s["round"],
            "respondents": sorted({l["respondent"] for l in s["log"] if l.get("respondent")}),
            "extract_hash": (v.get("summary") or {}).get("hash"),
            "columns": registry, "equations": _equations_with_manual(b.get("equations", []), s["overrides"].get("equations") or {}),
            "steps": b.get("steps", []),
            "design": b.get("design", {}), "test": b.get("test", {}), "matching": b.get("matching", []),
            "outputs": b.get("outputs", []), "code": code,
            "spec": {"ranges": spec_ok, "overflow_values": sp.get("overflow_values", []),
                     "conditions": [c for f in sp.get("files", []) for c in f.get("conditions", [])
                                    if items.get(f"3-2:{c.get('id') or c['name']}", {}).get("status") == "approved"]},
            "data_flags": data_flags, "missing": missing,
            "pending": [{"item": i["id"], "title": i["title"], "target": i["target"]} for i in unresolved],
            "notes": [{"q": i["question"], "a": i["answer"]["text"]} for i in s["items"]
                      if i["group"] == "Q" and i.get("answer") and i["answer"].get("text")]}
    if code is None and not any(p["target"] == "code" for p in conf["pending"]):
        conf["pending"].append({"item": "3-1:code", "title": "계산 코드가 승인되지 않음", "target": "code"})
    conf["hash"] = sha_obj(conf)
    path = write_json(cdir / "confirmed.json", conf)
    s["status"] = "complete"
    s["completed_at"] = conf["confirmed_at"]
    _save(rid, s)
    lineage.record("3 CONFIRM", rid, conf["extract_hash"] or "", lineage.code_version(sys.modules[__name__]),
                   {"round": s["round"], "respondent": respondent, "pending": len(conf["pending"])},
                   [path] + ([cdir / "approved_code.py"] if code else []))
    store.mark(rid, "confirm", "done", round=s["round"], pending=len(conf["pending"]))
    return view(rid)
