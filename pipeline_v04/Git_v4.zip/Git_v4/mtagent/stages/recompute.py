"""4 RECOMPUTE — 승인된 코드로 재계산한다. [PY]

4-1 수치 재계산  입력은 RAW 만. 승인된 가공 방법·식·코드(3-1 에서 해시 고정)로 raw → 중간값 → 최종값(R1·R3).
                 실행 전 확인: 승인 코드 해시 = 확정 해시 · 추출 결과가 확정 때와 같음 · RAW 사본 해시 = 1 INGEST 해시 · 정적 점검.
                 하나라도 어긋나면 실행하지 않고 이유를 남긴다. 실행은 격리 프로세스에서 한 번(R6). 보고서는 아직 열지 않음(R4).
4-2 계산 로그    사용한 데이터의 해시 2종 · 계산 과정 · 결과값 · 결과 해시 · 코드 해시 → recompute/calc_log.json.
                 다음 실행의 6-2 가 이 데이터 해시와 새 해시를 비교해 E07(데이터 버전 변경)을 기록한다.
"""
from __future__ import annotations

import sys
from importlib import metadata

from mtagent import config, design, lineage, sandbox, store
from mtagent.util import canonical, now, sha_file, sha_obj, sha_text, write_json


def _versions() -> dict:
    out = {"python": sys.version.split()[0]}
    for pkg in ("numpy", "scipy", "pandas"):
        try:
            out[pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            out[pkg] = None
    return out


def raw_files(ing: dict) -> list[dict]:
    """1 INGEST 기록 중 계산에 들어가는 데이터 — RAW 만."""
    return [x for x in ing["files"] if x["zone"] == "data" and x["category"] == "raw"]


def data_hashes(files: list[dict]) -> dict:
    """사용한 데이터의 해시 2종 — 파일마다 원본 바이트·내용 정규화, 그리고 묶음 해시 두 개."""
    inputs = [{"path": x["path"], "sha256": x["sha256"], "content_hash": x["content_hash"]} for x in files]
    return {"files": inputs,
            "byte_hash": sha_text(canonical([(x["path"], x["sha256"]) for x in inputs])),
            "content_hash": sha_text(canonical([(x["path"], x["content_hash"]) for x in inputs]))}


def run(rid: str) -> dict:
    store.require(rid, "confirm")
    conf = store.read(rid, "confirm/confirmed.json")
    ing = store.read(rid, "ingest.json")
    raw = raw_files(ing)
    base = store.in_dir(rid) / "data"
    started = now()
    hashes = data_hashes(raw)
    code_sha = (conf.get("code") or {}).get("sha256")
    log = {"stage": "4 RECOMPUTE", "run_id": rid, "project": conf["project"], "started_at": started,
           "inputs": hashes["files"], "input_hash": hashes["byte_hash"], "content_input_hash": hashes["content_hash"],
           "confirmed_hash": conf["hash"], "code": conf.get("code"), "code_sha256": code_sha, "env": _versions(),
           "results": [], "intermediate": {}, "checks": []}
    checks = log["checks"]

    def check(name, ok, detail=""):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        return ok

    ok = check("확정 기록 해시", conf.get("hash") == sha_obj({k: v for k, v in conf.items() if k != "hash"}))
    if ok:
        ok = check("계산 코드 승인", conf.get("code"), "3-1 에서 승인한 코드" if conf.get("code") else
                   "승인된 코드 없음(미확정) — 계산하지 않고 막힌 채 기록, 5-2 에서 수치 주장은 E06(미확정)")
    code_path = store.out_dir(rid) / "confirm" / "approved_code.py"
    if ok:
        ok = check("승인 코드 해시", code_path.exists() and sha_file(code_path) == code_sha, f"확정 해시 {code_sha[:12]}")
    if ok:
        now_hash = (store.read(rid, "extract/summary.json") or {}).get("hash")
        ok = check("추출 결과가 확정 때와 같음", now_hash == conf.get("extract_hash"), f"{(now_hash or '')[:12]}")
    if ok:
        bad = [x["path"] for x in raw if sha_file(base / x["path"]) != x["sha256"]]
        ok = check("RAW 사본이 1 INGEST 해시와 같음", not bad, ", ".join(bad[:5]) or f"RAW {len(raw)}개 같음")
    if ok:
        problems = sandbox.static_check(code_path.read_text(encoding="utf-8"))
        ok = check("정적 점검", not problems, "; ".join(problems[:5]) or "금지 항목 없음")
    if not ok:
        log.update(status="blocked", reason=next(c for c in checks if not c["ok"])["check"] + " 실패")
    else:
        files = {x["path"]: str((base / x["path"]).resolve()) for x in raw}
        res = sandbox.run(code_path, code_sha, files, config.SANDBOX_TIMEOUT)
        log["sandbox"] = {"seconds": res.get("seconds"), "blocked": res.get("blocked", []), "stdout": res.get("stdout", ""),
                          "timeout": config.SANDBOX_TIMEOUT,
                          "isolation": "별도 프로세스(python -I -B) + 감사 훅 · 최소 환경 변수 · 빈 임시 폴더 — 컨테이너·VM 아님"}
        check("격리 실행", res.get("status") == "ok", res.get("error") or "완료")
        if res.get("status") == "ok":
            conds = (conf.get("design") or {}).get("conditions") or []
            for r in res["results"]:
                r["group"] = design.match_condition(r.get("condition"), conds) if r.get("condition") else None
            log.update(status="ok", results=res["results"], intermediate=res.get("intermediate") or {},
                       result_hash=sandbox.result_hash(res["results"]))
        else:
            log.update(status="error", reason=res.get("error"), traceback=res.get("traceback"))
    log["finished_at"] = now()
    log["commit"] = {                        # 4-2 계산 로그의 핵심 — 데이터 해시 2종 · 계산 과정 · 결과값 · 결과 해시 · 코드 해시
        "data": hashes,
        "process": {"confirmed_hash": conf["hash"], "extract_hash": conf.get("extract_hash"),
                    "equations": [{"id": e["id"], "latex": e.get("latex"), "latex_source": e.get("latex_source")}
                                  for e in conf.get("equations", [])],
                    "steps": conf.get("steps"), "intermediate_hash": sha_obj(log["intermediate"]) if log["intermediate"] else None,
                    "env": log["env"]},
        "code_sha256": code_sha,
        "results": [{k: r.get(k) for k in ("id", "name", "value", "unit", "condition", "kind", "equation_id")}
                    for r in log["results"]],
        "result_hash": log.get("result_hash")}
    rdir = store.out_dir(rid) / "recompute"
    path = write_json(rdir / "calc_log.json", log)
    write_json(rdir / "history" / f"calc_{log['finished_at'][:19].replace(':', '').replace('-', '')}.json", log)
    lineage.record("4 RECOMPUTE", rid, hashes["byte_hash"], sha_text((code_sha or "") + conf["hash"]),
                   {"confirmed": conf["hash"][:16], "status": log["status"], "code_sha256": (code_sha or "")[:16],
                    "content_input_hash": hashes["content_hash"][:16]}, [path])
    store.mark(rid, "recompute", "done" if log["status"] == "ok" else log["status"])
    return log
