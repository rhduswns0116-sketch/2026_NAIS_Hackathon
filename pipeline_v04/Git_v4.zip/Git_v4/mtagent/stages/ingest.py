"""1 INGEST — 격리하고 지문을 고정한다. [PY]

1-1 입력 격리·분류    입력은 사본으로 받아 읽기 전용으로 잠그고, 산출물은 입력 밖(outputs/<실행>/)에 쓴다(R5).
                      최종 보고서 초안은 report/ 로 따로 받고 5-1 전까지 열지 않는다(원본 해시만 — R4).
                      분류: RAW · 연구 계획서 · 장비 사양서 · 보고서. PROCESSED·그림·스크립트·메모는 쓰지 않고 목록에만 남긴다
                      (PROCESSED 는 연구자의 숫자로 연구자의 숫자를 검증하는 순환이 되므로, 스크립트는 실행하지 않음 — R6).
1-2 해시 2종          원본 바이트 + 내용 정규화. 바이트만 다르면 '형식만 변경'. 표는 행별 해시를 저장해 다음 실행과 행·열 차이를 비교한다.
1-3 산출물 이력 장부  (입력 해시, 코드 해시, 파라미터) → 출력 해시 를 lineage.jsonl 에 한 줄.
측정 시각은 검사 규칙의 입력으로 쓰지 않는다.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

from mtagent import hashing, lineage, readers, store
from mtagent.util import canonical, now, sha_text, write_json

CATEGORIES = {"raw": "RAW 데이터", "plan": "연구 계획서", "spec": "장비 사양서", "report": "최종 보고서 초안",
              "processed": "PROCESSED 데이터 (사용 안 함)", "script": "스크립트 (실행 안 함)", "figure": "그림 (사용 안 함)",
              "meta": "메모·기타 문서 (사용 안 함)", "unknown": "미분류 (확인 필요)"}
SCRIPT_EXT = {".py", ".r", ".m", ".ipynb", ".jl", ".sh", ".bat", ".ps1", ".mat", ".sas", ".do"}
FIGURE_EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".svg", ".gif", ".bmp", ".eps"}
REPORT_EXT = {".docx", ".pdf", ".txt", ".md"}
REQUIRED = (("RAW_DATA", "raw"), ("연구 계획서 (.docx)", "plan"), ("장비 사양서", "spec"), ("최종 보고서 초안", "report"))
_PROCESSED = re.compile(r"process|summary|result|analy[sz]ed|derived|가공|요약|결과|통계", re.I)
_RAW = re.compile(r"(^|/)raw|원시|측정", re.I)
_SPEC = re.compile(r"spec|datasheet|manual|사양|매뉴얼|accuracy|resolution", re.I)
_PLAN = re.compile(r"plan|protocol|proposal|계획|실험\s*설계|연구\s*목적|method", re.I)


_RAW_DIR = re.compile(r"^(raw|raw[_\- ]?data|원시|원시\s*데이터|측정|측정\s*데이터)$", re.I)
_PROCESSED_DIR = re.compile(r"^(processed|processed[_\- ]?data|summary|results?|analy[sz]ed|derived|가공|가공\s*데이터|요약|결과|통계)$", re.I)


def _folder_kind(rel: str) -> str | None:
    """경로의 폴더 이름으로 정한 표 종류 — 가장 안쪽 폴더부터. 파일 이름의 'result'·'summary' 보다 먼저 본다
    (raw/S01_results.csv 는 RAW). 폴더로 정하지 못하면 None."""
    for part in reversed(rel.replace("\\", "/").split("/")[:-1]):
        if _RAW_DIR.match(part.strip()):
            return "raw"
        if _PROCESSED_DIR.match(part.strip()):
            return "processed"
    return None


def classify(zone: str, rel: str, path: Path) -> tuple[str, float, str]:
    """(분류, 확신도, 근거). 내용을 읽지 못하는 파일은 멈추지 않고 '미분류'로 남긴다."""
    try:
        return _classify(zone, rel, path)
    except Exception as e:                   # 깨진 PDF·docx 등 — INGEST 전체를 멈추지 않는다
        return "unknown", 0.2, f"읽을 수 없는 {path.suffix.lower() or '확장자 없는'} 파일 — {type(e).__name__}: {e}"[:300]


def _classify(zone: str, rel: str, path: Path) -> tuple[str, float, str]:
    ext = path.suffix.lower()
    name = rel.lower()
    if zone == "report":
        if ext in REPORT_EXT:
            return "report", 1.0, "최종 보고서 칸으로 받음"
        return "unknown", 0.3, f"보고서 칸이지만 읽을 수 없는 형식({ext})"
    if ext in SCRIPT_EXT:
        return "script", 1.0, f"스크립트 확장자 {ext} — 실행하지 않음"
    if ext in FIGURE_EXT:
        return "figure", 0.95, f"그림 확장자 {ext} — 그림은 판정하지 않음"
    if ext == ".pdf":
        if _SPEC.search(name):
            return "spec", 0.9, "파일 이름에 사양·spec 표현"
        if _PLAN.search(name):
            return "plan", 0.85, "파일 이름에 계획·plan 표현"
        head = readers.normalize_space(" ".join(readers.read_pdf_pages(path)[:1]))[:2000]
        if _SPEC.search(head):
            return "spec", 0.7, "첫 쪽에 사양 표현(accuracy·range 등)"
        if _PLAN.search(head):
            return "plan", 0.6, "첫 쪽에 계획 표현"
        return "unknown", 0.3, "PDF 이지만 사양서·계획서 표현을 찾지 못함"
    if ext in (".docx", ".md", ".hwp", ".doc"):
        if _PLAN.search(name):
            return "plan", 0.9, "파일 이름에 계획·plan 표현"
        if ext == ".docx" and _PLAN.search(readers.read_docx(path)["text"][:3000]):
            return "plan", 0.7, "본문에 계획·설계 표현"
        return "meta", 0.5, "문서 — 계획서 표현 없음"
    if ext in readers.TABLE_EXT:
        table = readers.read_table(path)
        if table:
            numeric = sum(1 for c in range(len(table["columns"]))
                          if all(readers.to_float(r[c]) is not None for r in table["rows"][:30] if c < len(r) and r[c]))
            shape = f"표 {len(table['columns'])}열 × {len(table['rows'])}행"
            if table.get("comments") or table.get("notes"):
                shape += f" (머리말 {len(table.get('comments') or [])}줄 · 표 밖 설명 {len(table.get('notes') or [])}줄은 행에서 뺌)"
            folder = _folder_kind(rel)
            if folder == "raw":
                return "raw", 0.9, f"raw 폴더 · {shape}"
            if folder == "processed":
                return "processed", 0.85, "가공·요약 폴더 — PROCESSED 는 쓰지 않음(순환 검증 방지)"
            if _PROCESSED.search(name):
                return "processed", 0.7, "파일 이름에 가공·요약 표현 — PROCESSED 는 쓰지 않음(순환 검증 방지, RAW 라면 raw 폴더에 넣기)"
            if _RAW.search(name):
                return "raw", 0.85, f"파일 이름에 raw 표현 · {shape}"
            if numeric:
                return "raw", 0.6, f"숫자 열 {numeric}개인 {shape} — RAW 후보"
            return "unknown", 0.3, "숫자 열이 없는 표"
        if ext in (".txt", ".dat"):
            return "meta", 0.5, "표가 아닌 글 파일"
        return "unknown", 0.3, "표로 읽지 못함 — 빈 파일이거나 머리글만 있음(데이터 행 없음)"
    return "unknown", 0.2, f"알 수 없는 형식({ext or '확장자 없음'})"


def run(rid: str) -> dict:
    s = store.state(rid)
    if store.stage_status(rid, "ingest") == "done":
        raise ValueError("이미 1 INGEST 를 마친 실행 — 입력을 바꾸려면 새 실행")
    files = store.input_files(rid)
    if not files:
        raise ValueError("넣은 파일이 없음")
    store.mark(rid, "ingest", "running")     # 여기서 봉인 — 이후 업로드 거부
    started = now()
    locked = store.lock_readonly(store.in_dir(rid))
    records = []
    for zone, rel, path in files:            # 1-1 분류 · 1-2 해시 2종 (보고서는 열지 않고 바이트 해시만)
        cat, conf, reason = classify(zone, rel, path)
        records.append({"zone": zone, "path": rel, "category": cat, "category_ko": CATEGORIES[cat], "confidence": conf,
                        "reason": reason, **hashing.fingerprint(path, open_content=zone != "report")})
    # 처리 중 입력 불변 — 끝에 다시 해시
    after = {f"{z}/{r}": hashing.fingerprint(p, open_content=False)["sha256"] for z, r, p in files}
    unchanged = all(after[f"{x['zone']}/{x['path']}"] == x["sha256"] for x in records)
    counts: dict[str, int] = {}
    for x in records:
        counts[x["category"]] = counts.get(x["category"], 0) + 1
    checks = [
        {"check": "원본 보호", "ok": True, "detail": "사본으로 받음 — 연구자 PC 의 원본은 건드리지 않음"},
        {"check": "입력 사본 읽기 전용", "ok": locked == len(files), "detail": f"사본 {locked}개 잠금"},
        {"check": "산출물은 입력 밖", "ok": True, "detail": f"산출물 폴더 outputs/{rid}"},
        {"check": "보고서 별도 경로", "ok": True,
         "detail": f"보고서 {counts.get('report', 0)}개를 report/ 로 따로 받음 — 5-1 전까지 열지 않음(원본 해시만)"},
        {"check": "스크립트 실행 안 함", "ok": True, "detail": f"스크립트 {counts.get('script', 0)}개 — 목록에만 남김"},
        {"check": "처리 중 입력 불변", "ok": unchanged, "detail": "끝에 다시 해시 — " + ("모두 같음" if unchanged else "달라진 파일 있음")},
    ]
    findings = []
    if not counts.get("raw"):
        findings.append({"level": "막힘", "text": "RAW 데이터로 분류된 파일이 없음 — 다음 단계를 진행할 수 없음"})
    if not counts.get("plan"):
        findings.append({"level": "막힘", "text": "연구 계획서로 분류된 파일이 없음 — 계산식을 뽑을 수 없음"})
    for x in records:
        if x["category"] == "plan" and not x["path"].lower().endswith(".docx"):
            findings.append({"level": "확인", "text": f"{x['path']}: 연구 계획서가 Word(.docx)가 아님 — 계산식을 Word 수식에서 "
                                                      "읽을 수 없어 수치 주장이 E06(식 없음)이 될 수 있음"})
    if not counts.get("spec"):
        findings.append({"level": "확인", "text": "장비 사양서가 없음 — 사양 범위 이탈(E02) 검사는 하지 않음"})
    if not counts.get("report"):
        findings.append({"level": "확인", "text": "최종 보고서 초안이 없음 — 5 VALIDATE 를 할 수 없음"})
    if counts.get("processed"):
        findings.append({"level": "확인", "text": f"PROCESSED 데이터 {counts['processed']}개 — 사용하지 않음(RAW 에서 계획서의 "
                                                  "가공 방법으로 직접 계산)"})
    for x in records:
        if x["category"] == "unknown":
            findings.append({"level": "확인", "text": f"{x['path']}: 미분류 — {x['reason']}"})
    required = [{"file": name, "category": cat, "count": counts.get(cat, 0)} for name, cat in REQUIRED]
    prev = store.previous_run(rid, "ingest")
    changes = None
    if prev:
        old = {f"{x['zone']}/{x['path']}": x for x in (store.read(prev, "ingest.json") or {}).get("files", [])}
        new = {f"{x['zone']}/{x['path']}": x for x in records}
        changes = hashing.compare_sets(old, new)
    input_hash = sha_text(canonical(sorted((f"{x['zone']}/{x['path']}", x["sha256"]) for x in records)))
    out = {"stage": "1 INGEST", "run_id": rid, "project": s["project"], "started_at": started, "finished_at": now(),
           "normalization": hashing.NORM_VERSION, "input_hash": input_hash, "checks": checks, "findings": findings,
           "counts": counts, "required": required, "previous_run": prev, "changes": changes, "files": records}
    path = write_json(store.out_dir(rid) / "ingest.json", out)
    out["lineage"] = lineage.record("1 INGEST", rid, input_hash, lineage.code_version(sys.modules[__name__], hashing, readers),
                                    {"project": s["project"], "normalization": hashing.NORM_VERSION,
                                     "previous_run": prev}, [path])
    blocked = any(f["level"] == "막힘" for f in findings) or any(not c["ok"] for c in checks)
    store.mark(rid, "ingest", "done", blocked=blocked, files=len(records))
    return out
