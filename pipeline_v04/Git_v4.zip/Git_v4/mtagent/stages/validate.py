"""5 VALIDATE — 보고서를 처음 열고 대조한다.

블라인드(R4): 보고서는 4 RECOMPUTE 계산이 끝난 뒤 여기서 처음 연다 — 계산 로그 시각 < 보고서 열람 시각을 기록, 1 INGEST 해시 대조.
5-1 주장 추출·분류 [LLM]  문장마다 쪽·문장 번호를 붙여 보내고, 분류와 검사할 주장을 받는다. 재계산 항목 목록은 이름·단위·조건만 —
                          재계산 값은 보내지 않는다(LLM 이 값에 끌려가지 않게). 계획서에 있지만 재계산되지 않은 항목도 목록에 넣는다.
5-2 재계산값과 비교 [PY]  수치: 재계산값을 보고서 수치의 유효 자릿수로 반올림해 비교 · 단위 환산 · 방향: 차이 부호 ·
                          유의성: 계획서 검정의 재계산 p 값 · n·자유도: 재계산값 또는 계획서 설계. 대응하는 재계산값이 없으면 E06.
5-3 오류 코드 분류 [PY]   비교 결과 + 앞 단계 기록(미확정 E01·E02·E06, 누락 E03, 진행 결정 E02 기록)을 주장이 쓰는 항목 기준으로 붙인다.
                          E07(데이터 버전 변경)은 6-2 에서 이전 실행과 비교해 기록한다.
검사 대상 아님: 문헌 인용(인용 번호·참고문헌 원문·위치만 기록) · 정성 문장. 혼합 문장은 자기 값만 검사하고 문헌값은 기록.
"""
from __future__ import annotations

import json
import re
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path

from mtagent import codes, design, lineage, readers, store, units
from mtagent.codes import code
from mtagent.llm import LLM, arr, boolean, num, obj, s
from mtagent.util import is_finite_number, now, sha_file, write_json

CATEGORIES = ["numeric", "direction", "significance", "degree", "mixed", "qualitative", "citation", "none"]
CATEGORY_KO = {"numeric": "자기 데이터 수치", "direction": "방향", "significance": "유의성", "degree": "정도 표현",
               "mixed": "혼합(자기 값 + 문헌값)", "qualitative": "정성 서술", "citation": "문헌 인용", "none": "주장 아님"}
SCHEMA = obj({"sentences": arr(obj({
    "sid": s(), "category": s(enum=CATEGORIES),
    "claims": arr(obj({
        "type": s(enum=["value", "n", "direction", "significance"]),
        "text": s("문장 안의 해당 부분을 글자 그대로"),
        "value": num("적힌 수치 그대로"), "unit": s("적힌 단위 그대로, 없으면 null", nullable=True),
        "output_id": s("재계산 항목 id, 목록에 없으면 null", nullable=True),
        "lhs": s(nullable=True), "rhs": s(nullable=True), "relation": s(nullable=True, enum=["greater", "less", "equal"]),
        "p_value": num(), "p_comparator": s(nullable=True, enum=["<", "<=", "=", ">", ">="]),
        "significant": boolean(nullable=True), "df": num(), "literature": boolean()}))}))})
SYSTEM = """너는 연구 재현성 감사 도구 MeasureTrace 의 주장 추출 담당이다. 한국어로 답한다.
과업 5-1 주장 추출·분류: 최종 보고서 초안의 문장(쪽·문장 번호가 붙은 목록)마다 분류하고, 재계산 결과와 대조할 수 있는 주장을 뽑는다.
계산하거나 맞는지 판단하지 않는다 — 대조는 파이썬이 한다.
- category: numeric(자기 데이터 수치) · direction(크다/작다/증가) · significance(유의성·검정) · degree(정도 표현: 크게, 약간)
  · mixed(자기 값과 문헌값이 섞임) · qualitative(수치·계획서 지표와 연결되지 않는 서술) · citation(문헌 인용) · none(제목·설명·참고문헌 목록 등)
- claims — 문장마다 0개 이상:
  value: 보고한 수치 하나마다(평균, 표준편차 ±, 통계량, 증가율 등). value 는 적힌 그대로, unit 은 적힌 그대로, output_id 는 재계산 항목 목록에서 고른다.
  n: 표본 수. "각 n = 10" 처럼 여러 조건에 걸리면 조건마다 하나씩.
  direction: lhs·rhs 에 비교하는 두 재계산 항목 id, relation 은 lhs 가 rhs 보다 greater/less/equal.
  significance: output_id 는 p값 항목, p_value·p_comparator 는 적힌 그대로(p < 0.001 → 0.001, "<"), significant 는 유의하다고 주장하면 true,
                자유도가 적혀 있으면 df. 비교 방향이 있으면 lhs·rhs·relation 도 적는다. 검정 통계량 값(t = 6.05 등)은 따로 value 주장으로.
- 문헌값(인용한 남의 값)은 literature=true 로 표시하고 output_id 는 null. 자기 값과 섞인 문장은 자기 값만 literature=false.
- 재계산 항목 목록에 맞는 항목이 없으면 output_id 는 null 로 둔다(지어내지 않는다). recomputed=false 인 항목도 고를 수 있다. 해당 없는 필드는 null.
- 연구자가 정해 둔 실험 방법·설정값(인가 전압 범위, 측정 온도, 시간 간격 등)은 결과가 아니므로 value 주장으로 뽑지 않는다.
  시료 수·반복 수·측정점 수처럼 셀 수 있는 값은 n 으로 뽑는다(output_id 가 없으면 파이썬이 계획서의 수와 비교)."""
_CITE = re.compile(r"\[(\d+(?:\s*[,\-–]\s*\d+)*)\]")
_REF_LINE = re.compile(r"^\s*\[(\d+)\]\s*(.+)$")


def split_sentences(par: str) -> list[str]:
    parts = re.split(r"(?<=[.!?。])(?<!\d\.)\s+(?=\S)", par.strip())
    return [p.strip() for p in parts if p.strip()]


def _precision(claim_text: str, value: float) -> tuple[int, float]:
    """보고서의 숫자 표기에서 소수 표시 자릿수와 반올림 허용폭(유효 자릿수 기준)을 얻는다."""
    for tok in re.findall(r"(?<![\w.])\d[\d,]*(?:\.\d+)?(?:[eE][+-]?\d+)?", claim_text or ""):
        try:
            number = Decimal(tok.replace(",", ""))
        except InvalidOperation:
            continue
        if abs(float(number) - abs(value)) <= max(1e-300, 1e-9 * abs(value)):
            exp = number.as_tuple().exponent
            return max(0, -exp), float(Decimal("0.5").scaleb(exp))
    t = repr(float(value))
    d = 0 if t.endswith(".0") else len(t.split(".")[1]) if "." in t and "e" not in t else 3
    return d, 0.5 * 10 ** (-d)


def planned_ids(conf: dict) -> dict[str, dict]:
    """계획서(확정)의 보고값 id — per=condition 이면 조건마다 '<id>__<조건>'."""
    conds = [c["name"] for c in (conf.get("design") or {}).get("conditions") or []]
    out = {}
    for o in conf.get("outputs") or []:
        ids = [f"{o['id']}__{c}" for c in conds] if o.get("per") == "condition" and conds else [o["id"]]
        for i in ids:
            out[i] = o
    return out


def _catalog(results: list[dict], conf: dict) -> list[dict]:
    conds = (conf.get("design") or {}).get("conditions") or []
    label = {c["name"]: c.get("label") or c["name"] for c in conds}
    have = {r["id"] for r in results}
    cat = [{"id": r["id"], "name": r.get("name"), "unit": r.get("unit"), "kind": r.get("kind"),
            "condition": label.get(r.get("group"), r.get("condition")), "recomputed": True} for r in results]
    cat += [{"id": i, "name": o.get("name"), "unit": o.get("unit"), "kind": o.get("kind"),
             "condition": label.get(i.split("__", 1)[1]) if "__" in i else None, "recomputed": False}
            for i, o in planned_ids(conf).items() if i not in have]
    return cat


def _no_value(ref: str | None, conf: dict, what: str) -> dict:
    """대응하는 재계산값이 없음 — 계획서의 보고값인데 재계산되지 않았으면 '데이터 없음', 계획서에 없으면 '식 없음'."""
    if ref and ref in planned_ids(conf):
        return code("E06", f"{what}: 계획서의 보고값 {ref} 가 재계산되지 않음", reason="데이터 없음")
    return code("E06", f"{what}: 계획서에 대응하는 식·보고값이 없음 (output_id={ref})", reason="식 없음")


def _direction(cl: dict, outs: dict[str, dict], conf: dict, rec: dict) -> list[dict]:
    a, b = outs.get(cl.get("lhs") or ""), outs.get(cl.get("rhs") or "")
    if not cl.get("relation") or not a or not b:
        missing = cl.get("lhs") if not a else cl.get("rhs")
        return [_no_value(missing, conf, "방향 주장의 비교 항목")]
    rec["outputs_used"] += [a["id"], b["id"]]
    ua, ub = a.get("unit"), b.get("unit")
    da, db = units.dimension(ua), units.dimension(ub)
    if da is None or db is None or da != db:
        return [code("E01", f"방향 비교 단위 불일치 — {a['id']} {ua or '단위 없음'} · {b['id']} {ub or '단위 없음'}")]
    bv = units.convert(float(b["value"]), ub, ua)
    diff = float(a["value"]) - bv
    ok = {"greater": diff > 0, "less": diff < 0,
          "equal": abs(diff) <= 1e-9 * max(abs(float(a["value"])), abs(bv), 1e-300)}[cl["relation"]]
    rec.update(reported=f"{a['id']} {'>' if cl['relation'] == 'greater' else '<' if cl['relation'] == 'less' else '='} {b['id']}",
               recomputed=diff, shown=f"차이 {diff:.6g} {ua or ''}".strip(), compared=True)
    return [] if ok else [code("E05", f"방향 불일치 — 재계산 차이 {diff:.6g}")]


def _compare(cl: dict, outs: dict[str, dict], conf: dict) -> tuple[dict, list[dict]]:
    """5-2 → (비교 기록, 오류 코드). 비교 기록: {outputs_used, reported, recomputed, shown, compared, note}."""
    t = cl["type"]
    rec = {"outputs_used": [], "reported": None, "recomputed": None, "shown": None, "compared": False, "note": ""}
    found = []
    if t in ("value", "n"):
        o = outs.get(cl.get("output_id") or "")
        if t == "n" and o is None and not cl.get("output_id"):
            counts = design_counts(conf)
            if counts and is_finite_number(cl.get("value")):
                v = float(cl["value"])
                hit = [label for label, n in counts if v == n]
                listed = ", ".join(f"{label} {n}" for label, n in counts)
                rec.update(reported=cl["value"], recomputed=v if hit else None, shown=f"{v:g} ({hit[0]})" if hit else listed,
                           compared=True, note="재계산 항목이 없어 계획서 설계의 수(" + listed + ")와 비교")
                if not hit:
                    found.append(code("E04", f"보고 {v:g} — 계획서 설계의 어떤 수와도 맞지 않음 ({listed})"))
                return rec, found
        if o is None:
            return rec, [_no_value(cl.get("output_id"), conf, f"'{cl.get('text')}'")]
        rec["outputs_used"] = [o["id"]]
        if not is_finite_number(cl.get("value")):
            return rec, [code("E06", f"'{cl.get('text')}': 보고한 수치를 읽지 못해 비교할 값이 없음", reason="데이터 없음")]
        val, rv = float(cl["value"]), float(o["value"])
        if t == "n" or o.get("kind") in ("n", "df"):
            rec.update(reported=val, recomputed=rv, shown=f"{rv:g}", compared=True)
            if val != rv or not val.is_integer() or not rv.is_integer():
                found.append(code("E04", f"보고 {val:g} · 재계산 {rv:g}"))
            return rec, found
        uo, uc = o.get("unit"), cl.get("unit")
        do, dc = units.dimension(uo), units.dimension(uc)
        if uo and do not in (None, "none") and not uc:
            found.append(code("E01", f"단위 누락 — 재계산 단위는 {uo}"))
            conv = rv
        elif uc and dc is None:
            return rec, [code("E01", f"보고 단위 '{uc}' 를 해석할 수 없음")]
        elif uc and do not in (None,) and dc != do and not (dc == "none" and do == "none"):
            return rec, [code("E01", f"단위 불일치 — 보고 {uc}({dc}) · 재계산 {uo}({do})")]
        else:
            conv = units.convert(rv, uo, uc) if uc and uo and do == dc else rv
        d, tolerance = _precision(cl.get("text") or "", val)
        shown = f"{conv:.{d}f}"
        rec.update(reported=f"{val:.{d}f}" + (f" {uc}" if uc else ""), recomputed=rv, shown=shown + (f" {uc}" if uc else ""),
                   compared=True, note=f"보고 유효 자릿수({d})로 반올림해 비교" + (f" · {uo}→{uc} 환산" if uc and uo and uc != uo else ""))
        if abs(conv - val) > tolerance * (1 + 1e-9) + 1e-15 * max(abs(conv), abs(val), tolerance):
            found.append(code("E05", f"보고 {val:g} · 재계산 {shown} (원값 {rv:.6g})"))
        return rec, found
    if t == "direction":
        return rec, _direction(cl, outs, conf, rec)
    if t == "significance":
        if not (conf.get("test") or {}).get("present"):     # 계획서에 검정 없음 → 방향만 검사 + E06
            found = [code("E06", "유의성 주장인데 계획서에 검정 방법이 없음 — 방향만 검사", reason="검정 방법 없음")]
            if cl.get("lhs") and cl.get("rhs") and cl.get("relation"):
                found += _direction(cl, outs, conf, rec)
            return rec, found
        output_id = cl.get("output_id")
        candidates = [o for o in outs.values() if o.get("kind") == "p_value"]
        p = outs.get(output_id) if output_id else candidates[0] if len(candidates) == 1 else None
        if p is not None and p.get("kind") != "p_value":
            p = None
        if p is None:
            if not output_id and len(candidates) > 1:
                return rec, [code("E06", "p값 재계산 항목이 여러 개라 주장의 항목을 특정할 수 없음", reason="미확정")]
            planned_p = [i for i, o in planned_ids(conf).items() if o.get("kind") == "p_value"]
            return rec, [_no_value(output_id or (planned_p[0] if planned_p else None), conf, "p값 재계산 항목")]
        alpha = ((conf.get("test") or {}).get("alpha")) or 0.05
        pv = float(p["value"])
        rec.update(outputs_used=[p["id"]], reported=" ".join(str(x) for x in (cl.get("p_comparator"), cl.get("p_value")) if x is not None)
                   or ("유의" if cl.get("significant") else "유의하지 않음"), recomputed=pv,
                   shown=f"p = {pv:.3g} (α={alpha})", compared=True)
        if cl.get("significant") is not None and bool(cl["significant"]) != (pv < alpha):
            found.append(code("E05", f"유의성 불일치 — 재계산 p = {pv:.3g}, α = {alpha}"))
        if is_finite_number(cl.get("p_value")) and cl.get("p_comparator"):
            x = float(cl["p_value"])
            op = cl["p_comparator"]
            ok = {"<": pv < x, "<=": pv <= x, ">": pv > x, ">=": pv >= x,
                  "=": abs(pv - x) <= _precision(cl.get("text") or "", x)[1]}[op]
            if not ok:
                found.append(code("E05", f"p 표현 불일치 — 보고 p {op} {x:g} · 재계산 p = {pv:.3g}"))
        if is_finite_number(cl.get("df")):
            dfs = [o for o in outs.values() if o.get("kind") == "df"
                   and (o.get("group") == p.get("group") or o.get("condition") == p.get("condition"))]
            dfo = dfs[0] if len(dfs) == 1 else None
            if dfo:
                rec["outputs_used"].append(dfo["id"])
                if float(cl["df"]) != float(dfo["value"]):
                    found.append(code("E04", f"자유도 불일치 — 보고 {cl['df']:g} · 재계산 {dfo['value']:g}"))
            else:
                if len(dfs) > 1:
                    found.append(code("E06", "자유도 재계산 항목이 여러 개라 주장의 항목을 특정할 수 없음", reason="미확정"))
                else:
                    planned_df = [i for i, o in planned_ids(conf).items() if o.get("kind") == "df"]
                    found.append(_no_value(planned_df[0] if planned_df else None, conf, "자유도 재계산 항목"))
        return rec, found
    return rec, [code("E06", f"알 수 없는 주장 종류 {t}", reason="식 없음")]


def design_counts(conf: dict) -> list[tuple[str, int]]:
    """계획서(확정 설계)의 셀 수 있는 값 — 조건별 시료 수 · 시료당 반복 수 · 반복당 측정점 수."""
    d = conf.get("design") or {}
    out = []
    sizes = sorted({len(c.get("samples") or []) for c in d.get("conditions") or [] if c.get("samples")})
    out += [("조건별 시료 수", n) for n in sizes]
    if is_finite_number(d.get("replicates_per_unit")):
        out.append((f"시료당 {d.get('replicate') or '반복'} 수", int(d["replicates_per_unit"])))
    if is_finite_number(d.get("points_per_replicate")):
        out.append(("반복당 측정점 수", int(d["points_per_replicate"])))
    return out


def _dependency_codes(used: list[str], outs: dict[str, dict], conf: dict) -> list[dict]:
    """5-3 주장이 쓰는 재계산 항목에 걸린 앞 단계 기록 — 미확정(E01·E02·E06) · 누락(E03) · 진행 결정(E02 기록)."""
    found = []
    conds = (conf.get("design") or {}).get("conditions") or []
    used_o = [outs[u] for u in used if u in outs]
    groups = {o.get("group") for o in used_o}

    def touches(group):       # 이 집단의 데이터를 쓰는가 — 집단 없는 항목(합동·비교)은 모든 집단을 쓴다
        return group is None or None in groups or group in groups

    for p in conf.get("pending", []):                 # 3회 뒤에도 미확정
        tg = p.get("target") or "*"
        if tg.startswith("unit:"):
            found.append(code("E01", f"CONFIRM 3회 뒤에도 단위 미확정: {p['title']}", [p["item"]]))
        elif tg.startswith("data:"):
            if touches(design.match_condition(None, conds, Path(tg[5:]).stem)):
                found.append(code("E02", f"CONFIRM 3회 뒤에도 미결정: {p['title']}", [p["item"]], effect="Unsupported"))
        elif tg in ("*", "code") or (tg.startswith("eq:") and any(o.get("equation_id") == tg[3:] for o in used_o)):
            found.append(code("E06", f"CONFIRM 3회 뒤에도 미확정: {p['title']}", [p["item"]], reason="미확정"))
    for m in conf.get("missing", []):
        if m.get("kind") == "필요 문서 없음":
            continue
        g = design.match_condition(m.get("condition"), conds, m.get("sample"))
        if touches(g):
            found.append(code("E03", f"{m['kind']}: {m['detail']}", [m.get("file") or ""]))
    for f in conf.get("data_flags", []):
        g = design.match_condition(None, conds, Path(f["file"]).stem)
        if touches(g):
            found.append(code("E02", f"{f['file']} {f['column']}: {f['detail']} — 연구자가 그대로 진행하기로 결정 "
                                     f"({f.get('decided_by')})", [f"{f['file']}:{r['line']}" for r in f.get("rows") or []]))
    return found


def _blocked_code(calc: dict) -> dict:
    """재계산을 하지 못했을 때 — 승인된 코드·근거 문제면 '미확정', RAW 사본 문제면 '데이터 없음'."""
    reason = calc.get("reason") or ""
    why = "데이터 없음" if "RAW" in reason else "미확정"
    return code("E06", f"4 RECOMPUTE 가 계산하지 않음({calc.get('status')} — {reason})", reason=why)


def _references(pages: list[list[str]]) -> dict[str, str]:
    """보고서 안의 참고문헌 목록 — '[n] 원문' 문단."""
    refs = {}
    for paras in pages:
        for par in paras:
            m = _REF_LINE.match(par)
            if m:
                refs.setdefault(m.group(1), m.group(2).strip())
    return refs


def _citations(text: str, refs: dict[str, str]) -> list[dict]:
    out = []
    for m in _CITE.finditer(text):
        nums = []
        for part in re.split(r"\s*,\s*", m.group(1)):
            a, _, b = part.replace("–", "-").partition("-")
            nums += [str(i) for i in range(int(a), int(b) + 1)] if b else [a.strip()]
        out += [{"number": n, "reference": refs.get(n)} for n in nums]
    return out


def run(rid: str, llm: LLM | None = None, report: str | None = None) -> dict:
    store.require(rid, "recompute", ok=("done", "blocked", "error"))
    calc = store.read(rid, "recompute/calc_log.json")
    conf = store.read(rid, "confirm/confirmed.json")
    ing = store.read(rid, "ingest.json")
    reports = [x for x in ing["files"] if x["zone"] == "report" and x["category"] == "report"]
    if not reports:
        raise ValueError("최종 보고서 초안이 없음 — 1 INGEST 의 '최종 보고서 초안' 칸에 넣은 실행이어야 함")
    rep = next((x for x in reports if x["path"] == report), None) if report else reports[0]
    if rep is None:
        raise ValueError(f"보고서 {report!r} 는 이 실행의 보고서가 아님")
    path = store.in_dir(rid) / "report" / rep["path"]
    if sha_file(path) != rep["sha256"]:
        raise ValueError("보고서가 1 INGEST 이후 바뀜 — 새 실행")
    opened = now()
    blind = {"calc_finished_at": calc.get("finished_at"), "report_opened_at": opened,
             "ok": bool(calc.get("finished_at")) and calc["finished_at"] < opened, "report": rep["path"], "sha256": rep["sha256"]}
    llm = llm or LLM()
    pages = readers.document_pages(path)
    refs = _references(pages)
    sentences = []
    for pi, paras in enumerate(pages, 1):
        no = 0
        for par in paras:
            # 참고문헌 목록의 한 항목('[1] H. Kim et al., …')은 약어 마침표에서 자르지 않고 한 문장으로
            for sent in [par.strip()] if _REF_LINE.match(par) else split_sentences(par):
                no += 1
                sentences.append({"sid": f"S{len(sentences) + 1:03d}", "page": pi, "no": no, "text": sent})
    results = calc.get("results") or []
    outs = {r["id"]: r for r in results}
    conds = (conf.get("design") or {}).get("conditions") or []
    catalog = _catalog(results, conf)
    user = ("[재계산 항목 목록 — 값은 보내지 않음. recomputed=false 는 계획서에 있으나 재계산되지 않은 항목]\n"
            + json.dumps(catalog, ensure_ascii=False, indent=1)
            + "\n\n[설계]\n" + json.dumps({"conditions": [{k: c.get(k) for k in ("name", "label")} for c in conds],
                                           "test": conf.get("test")}, ensure_ascii=False)
            + "\n\n[보고서 문장]\n" + json.dumps([{k: x[k] for k in ("sid", "page", "no", "text")} for x in sentences],
                                                ensure_ascii=False, indent=1) + "\n[끝]")
    got = llm.json("5-1", SYSTEM, user, SCHEMA, effort="high")
    replies = got.get("sentences")
    problem = None
    if not isinstance(replies, list):
        problem = "5-1 주장 추출 응답에 문장 목록이 없음"
    else:
        expected = {x["sid"] for x in sentences}
        ids = [x.get("sid") for x in replies if isinstance(x, dict)]
        missing = expected - set(ids)
        extra = set(ids) - expected
        if len(ids) != len(replies) or len(ids) != len(set(ids)) or missing or extra:
            problem = (f"5-1 주장 추출 문장 ID 불일치 — 누락 {sorted(missing)}, 예상 밖 {sorted(extra, key=str)}, "
                       f"중복 {len(ids) - len(set(ids))}")
    if problem:
        # 이 응답은 캐시에서 지운다 — 남겨 두면 다시 실행해도 같은 불완전한 답을 캐시에서 받아 영영 막힌다
        llm.forget("5-1", SYSTEM, user, SCHEMA, effort="high")
        raise ValueError(problem + " — 이 응답은 캐시에서 지웠으니 5 VALIDATE 를 다시 실행하면 LLM 에 다시 묻습니다")
    by_sid = {x["sid"]: x for x in replies}
    eq_latex = {e["id"]: e.get("latex") for e in conf.get("equations") or []}
    data_hash = {"byte": calc.get("input_hash"), "content": calc.get("content_input_hash")}
    claims, non_target, literature = [], [], []
    blocked = calc.get("status") != "ok"
    for sx in sentences:
        g = by_sid.get(sx["sid"]) or {"category": "none", "claims": []}
        sx["category"] = g["category"]
        lit = [c for c in g.get("claims", []) if c.get("literature")]
        literature += [{**{f: sx[f] for f in ("sid", "page", "no")}, "sentence": sx["text"],
                        **{k: c.get(k) for k in ("text", "value", "unit")}} for c in lit]
        own = [c for c in g.get("claims", []) if not c.get("literature")]
        if not own:
            entry = {**sx, "category_ko": CATEGORY_KO.get(g["category"], g["category"]), "literature_only": bool(lit)}
            if g["category"] == "citation" or lit or _CITE.search(sx["text"]):
                entry["citations"] = _citations(sx["text"], refs)
            non_target.append(entry)
            continue
        for k, cl in enumerate(own, 1):
            if blocked:
                rec, found = {"outputs_used": [], "compared": False, "note": "4 RECOMPUTE 가 계산하지 않음"}, [_blocked_code(calc)]
            else:
                rec, found = _compare(cl, outs, conf)
                found += _dependency_codes(rec["outputs_used"], outs, conf)
            verdict = "Unsupported" if any(c["effect"] == "Unsupported" for c in found) or not rec.get("compared") else "Supported"
            used = [outs[u] for u in rec.get("outputs_used", []) if u in outs]
            rec["groups"] = sorted({str(o.get("group")) for o in used})
            rec["equations_used"] = [{"id": i, "latex": eq_latex.get(i)}
                                     for i in dict.fromkeys(o["equation_id"] for o in used if o.get("equation_id"))]
            claims.append({"cid": f"{sx['sid']}-{k}", **{f: sx[f] for f in ("sid", "page", "no")}, "sentence": sx["text"],
                           "category": g["category"], "category_ko": CATEGORY_KO.get(g["category"], g["category"]),
                           "claim": cl, **rec, "data_hash": data_hash, "codes": found, "verdict": verdict,
                           "note": rec.get("note", "") + (" · '크게' 등 정도 표현은 판정 제외 — 방향만 검사" if g["category"] == "degree" else ""),
                           "literature_values": [{k2: c.get(k2) for k2 in ("text", "value", "unit")} for c in lit]})
    counts: dict[str, int] = {}
    for c in claims:
        for k in {x["code"] for x in c["codes"]}:
            counts[k] = counts.get(k, 0) + 1
    summary = {"Supported": sum(c["verdict"] == "Supported" for c in claims),
               "Unsupported": sum(c["verdict"] == "Unsupported" for c in claims),
               "not_checked": len(non_target), "codes": counts}
    out = {"stage": "5 VALIDATE", "run_id": rid, "at": now(), "blind": blind, "report": rep["path"],
           "sentences": sentences, "claims": claims, "non_target": non_target, "literature": literature,
           "references": refs, "summary": summary, "llm": {**llm.status(), **llm.stats}, "sent": user}
    p = write_json(store.out_dir(rid) / "validate.json", out)
    lineage.record("5 VALIDATE", rid, calc.get("result_hash") or calc.get("input_hash"), lineage.code_version(sys.modules[__name__], codes),
                   {"report": rep["path"], "report_sha256": rep["sha256"][:16], "model": llm.model}, [p])
    store.mark(rid, "validate", "done", **{k: summary[k] for k in ("Supported", "Unsupported")})
    return out
