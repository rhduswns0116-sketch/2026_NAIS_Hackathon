"""6 AUDIT — 결과를 내고, 고치면 다시 본다. [PY] (LLM 없음 — 숫자는 파이썬이 채운다)

6-1 결과 출력       Supported / Unsupported(+오류 코드·E06 사유) / 검사 대상 아님 목록. 주장마다 보고서 원문(쪽·문장) · 보고값 ·
                    재계산값 · 사용한 식 · 데이터 해시를 나란히. 문헌 인용은 인용 번호·참고문헌 원문, 혼합 문장의 문헌값은 기록.
6-2 수정 후 재평가  같은 프로젝트의 이전 실행과 주장별로 짝지어 수정 전·후 판정을 비교(고쳐짐·나빠짐·그대로·새 주장·사라짐).
                    이전 실행 계산 로그(4-2)의 데이터 해시 2종과 현재 해시(1-2)를 대조해 E07(데이터 버전 변경)을 기록 —
                    어떤 파일이 몇 행 바뀌었는지. 바이트 해시만 다르고 내용 해시가 같으면 '형식만 변경'.
판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것이다.
"""
from __future__ import annotations

import re
import sys

from mtagent import codes, hashing, lineage, store
from mtagent.codes import code
from mtagent.util import now, write_json

DISCLAIMER = ("판정은 과학적 진실이 아니라 '제출된 자료(RAW·연구 계획서·장비 사양서)가 이 주장을 지지하는가'에 대한 것이다. "
              "계산식의 과학적 타당성, 그림, 외부 문헌 수치, 첫 실행 이전의 데이터 변경, 데이터 조작 여부는 판정하지 않는다.")


def _key(c: dict) -> str:
    """주장 짝짓기 — 문장·주장 원문·종류·(조건별 주장이면) 집단. 재계산 항목 id 는 LLM 이 실행마다 다르게 지을 수 있어 쓰지 않는다."""
    norm = lambda x: re.sub(r"\s+", "", x or "")  # noqa: E731
    groups = ",".join(sorted(str(g) for g in c.get("groups") or []))
    return "|".join((norm(c["sentence"]), norm(c["claim"].get("text")), c["claim"].get("type") or "", groups))


def data_version(rid: str) -> dict:
    """6-2 E07 — 이전 실행 계산 로그(4-2)의 RAW 해시 2종 ↔ 현재 1-2 해시. 행 차이는 이전 실행의 행별 해시로."""
    prev = store.previous_run(rid, "recompute")
    if not prev:
        return {"previous_run": None, "changes": [], "codes": [], "note": "같은 프로젝트의 이전 계산 없음 — 비교하지 않음"}
    old_log = store.read(prev, "recompute/calc_log.json") or {}
    old_ing = {x["path"]: x for x in (store.read(prev, "ingest.json") or {}).get("files", []) if x["zone"] == "data"}
    old = {x["path"]: {**old_ing.get(x["path"], {}), **x} for x in old_log.get("inputs") or []}
    new = {x["path"]: x for x in (store.read(rid, "ingest.json") or {}).get("files", [])
           if x["zone"] == "data" and x["category"] == "raw"}
    changes = hashing.compare_sets(old, new)
    found = [code("E07", f"{ch['file']}: {ch['kind']} — {ch['detail']}", [prev, ch["file"]]) for ch in changes]
    return {"previous_run": prev, "previous_hashes": {"byte": old_log.get("input_hash"), "content": old_log.get("content_input_hash")},
            "changes": changes, "codes": found,
            "note": "기록만 — 판정은 바꾸지 않음" if changes else "이전 계산에 쓴 RAW 와 같음"}


def _reeval(rid: str, claims: list[dict]) -> dict:
    prev = store.previous_run(rid, "audit")
    version = data_version(rid)
    if not prev:
        return {"previous_run": None, "data_version": version,
                "note": "같은 프로젝트의 이전 감사 없음 — 보고서·데이터를 고쳐 같은 프로젝트 이름으로 다시 돌리면 수정 전·후를 비교"}
    old = {_key(c): c for c in (store.read(prev, "validate.json") or {}).get("claims", [])}
    new = {_key(c): c for c in claims}
    # 2차 짝짓기 — 원문 자른 범위만 다른 주장: 같은 문장·종류·집단에 남은 것이 하나씩이면 짝
    loose = lambda c: "|".join(_key(c).split("|")[i] for i in (0, 2, 3))  # noqa: E731
    lo, ln = {}, {}
    for k in [k for k in old if k not in new]:
        lo.setdefault(loose(old[k]), []).append(k)
    for k in [k for k in new if k not in old]:
        ln.setdefault(loose(new[k]), []).append(k)
    for lk, oks in lo.items():
        if len(oks) == 1 and len(ln.get(lk, [])) == 1:
            new[oks[0]] = new.pop(ln[lk][0])
    # 숫자를 고쳐 문장 원문까지 달라진 경우에는 같은 위치·종류·집단의 유일한 주장끼리 짝짓는다.
    def position(c):
        return (c.get("page"), c.get("no"), c["claim"].get("type"),
                tuple(sorted(str(g) for g in c.get("groups") or [])))

    old_at, new_at = {}, {}
    for k in old.keys() - new.keys():
        old_at.setdefault(position(old[k]), []).append(k)
    for k in new.keys() - old.keys():
        new_at.setdefault(position(new[k]), []).append(k)
    for pos, oks in old_at.items():
        if len(oks) == 1 and len(new_at.get(pos, [])) == 1:
            new[oks[0]] = new.pop(new_at[pos][0])
    rows = []
    for k in list(old) + [k for k in new if k not in old]:
        o, n = old.get(k), new.get(k)
        before, after = (o or {}).get("verdict"), (n or {}).get("verdict")
        change = ("새 주장" if o is None else "사라짐" if n is None else "그대로" if before == after
                  else "고쳐짐" if after == "Supported" else "나빠짐")
        c = n or o
        rows.append({"change": change, "sentence": c["sentence"], "page": c.get("page"), "no": c.get("no"),
                     "claim": c["claim"].get("text"), "before": before, "after": after,
                     "codes_before": sorted({x["code"] for x in (o or {}).get("codes", [])}),
                     "codes_after": sorted({x["code"] for x in (n or {}).get("codes", [])}),
                     "shown_before": (o or {}).get("shown"), "shown_after": (n or {}).get("shown")})
    counts = {}
    for r in rows:
        counts[r["change"]] = counts.get(r["change"], 0) + 1
    return {"previous_run": prev, "counts": counts, "rows": rows, "data_version": version}


def run(rid: str) -> dict:
    store.require(rid, "validate")
    v = store.read(rid, "validate.json")
    calc = store.read(rid, "recompute/calc_log.json")
    conf = store.read(rid, "confirm/confirmed.json")
    claims = v["claims"]
    out = {"stage": "6 AUDIT", "run_id": rid, "project": conf["project"], "at": now(), "disclaimer": DISCLAIMER,
           "summary": v["summary"], "blind": v["blind"], "report": v["report"],
           "supported": [c for c in claims if c["verdict"] == "Supported"],
           "unsupported": [c for c in claims if c["verdict"] == "Unsupported"],
           "not_checked": v["non_target"], "literature": v.get("literature") or [], "code_names": codes.NAMES,
           "recompute": {k: calc.get(k) for k in ("status", "reason", "result_hash", "input_hash", "content_input_hash",
                                                   "code_sha256", "finished_at", "env")}
           | {"results": [{k: r.get(k) for k in ("id", "name", "value", "unit", "condition", "kind", "equation_id")}
                          for r in calc.get("results") or []]},
           "equations": [{k: e.get(k) for k in ("id", "latex", "latex_source")} for e in conf.get("equations") or []],
           "confirm": {k: conf.get(k) for k in ("hash", "round", "respondents", "pending", "missing", "data_flags")},
           "reevaluation": _reeval(rid, claims)}
    out["report_md"] = "audit_report.md"
    p = write_json(store.out_dir(rid) / "audit.json", out)
    md = store.out_dir(rid) / "audit_report.md"
    md.write_text(markdown(out), encoding="utf-8")
    lineage.record("6 AUDIT", rid, (store.read(rid, "ingest.json") or {}).get("input_hash", ""),
                   lineage.code_version(sys.modules[__name__]), {"previous_run": out["reevaluation"]["previous_run"]}, [p, md])
    s = store.state(rid)
    s["summary"] = f"S{v['summary']['Supported']}·U{v['summary']['Unsupported']}"
    store.save_state(rid, s)
    store.mark(rid, "audit", "done")
    return out


def _esc(x) -> str:
    return str(x if x is not None else "—").replace("|", "\\|")


def _row(c: dict) -> str:
    cs = ", ".join(x["code"] + (f"({x['reason']})" if x.get("reason") else "") + ("·기록" if x["effect"] == "기록" else "")
                   for x in c["codes"]) or "—"
    eqs = ", ".join(e["id"] for e in c.get("equations_used") or []) or "—"
    data_hash = ((c.get("data_hash") or {}).get("content") or "")[:12]
    return (f"| p.{c['page']} 문장 {c['no']} | {_esc(c['claim'].get('text'))} | {_esc(c.get('reported'))} "
            f"| {_esc(c.get('shown'))} | {eqs} | `{data_hash}` | **{c['verdict']}** | {cs} |")


def markdown(a: dict) -> str:
    sm = a["summary"]
    rc = a["recompute"]
    lines = [f"# MeasureTrace 감사 리포트 — {a['project']}", "",
             f"- 실행 `{a['run_id']}` · 보고서 `{a['report']}` · 작성 {a['at']}",
             f"- 블라인드: 계산 완료 {a['blind']['calc_finished_at']} → 보고서 첫 열람 {a['blind']['report_opened_at']} "
             f"({'확인' if a['blind']['ok'] else '위반'})",
             f"- 재계산: {rc['status']} · 코드 해시 `{(rc.get('code_sha256') or '')[:16]}` · 결과 해시 `{(rc.get('result_hash') or '')[:16]}`",
             f"- 데이터 해시 — 원본 바이트 `{(rc.get('input_hash') or '')[:16]}` · 내용 정규화 `{(rc.get('content_input_hash') or '')[:16]}`",
             "", f"> {a['disclaimer']}", "",
             "| Supported | Unsupported | 검사 대상 아님 |", "|---|---|---|",
             f"| {sm['Supported']} | {sm['Unsupported']} | {sm['not_checked']} |", ""]
    if sm["codes"]:
        lines += ["오류 코드: " + ", ".join(f"{k} {a['code_names'][k]} ×{n}" for k, n in sorted(sm["codes"].items())), ""]
    head = ["| 위치 | 주장 | 보고값 | 재계산값 (보고 자릿수) | 사용한 식 | 데이터 해시 | 판정 | 오류 코드 |",
            "|---|---|---|---|---|---|---|---|"]
    lines += ["## 6-1 Unsupported", ""] + (head + [_row(c) for c in a["unsupported"]] if a["unsupported"] else ["없음"]) + [""]
    by_sentence: dict[str, list[dict]] = {}
    for c in a["unsupported"]:
        by_sentence.setdefault(c["sid"], []).append(c)
    for group in by_sentence.values():
        c = group[0]
        lines.append(f"- **p.{c['page']} 문장 {c['no']}** “{c['sentence']}”")
        seen = set()
        for x in (x for c in group for x in c["codes"]):
            if (x["code"], x["detail"]) not in seen:
                seen.add((x["code"], x["detail"]))
                why = f" · 사유: {x['reason']}" if x.get("reason") else ""
                lines.append(f"  - {x['code']} {x['name']} [{x['effect']}{why}] — {x['detail']}")
    lines += ["", "## 6-1 Supported", ""] + (head + [_row(c) for c in a["supported"]] if a["supported"] else ["없음"]) + [""]
    used = {e["id"] for c in a["supported"] + a["unsupported"] for e in c.get("equations_used") or []}
    if used:
        lines += ["### 사용한 식", ""] + [f"- {e['id']}: `{e['latex']}` ({e.get('latex_source') or '—'})"
                                         for e in a["equations"] if e["id"] in used] + [""]
    lines += ["## 6-1 검사 대상 아님", ""]
    for x in a["not_checked"]:
        cites = "; ".join(f"[{c['number']}] {c['reference'] or '(참고문헌 원문 없음)'}" for c in x.get("citations") or [])
        lines.append(f"- p.{x['page']} 문장 {x['no']} ({x['category_ko']}) {x['text']}" + (f" — 인용: {cites}" if cites else ""))
    if a["literature"]:
        lines += ["", "### 문헌값 (기록 — 검사하지 않음)", ""]
        lines += [f"- p.{x['page']} 문장 {x['no']}: {x.get('text')}" for x in a["literature"]]
    lines += ["", "## 재계산 결과 (4-2 계산 로그)", ""]
    if rc["results"]:
        lines += ["| id | 이름 | 조건 | 값 (반올림 전) | 단위 | 식 |", "|---|---|---|---|---|---|"]
        lines += [f"| {r['id']} | {r.get('name') or '—'} | {r.get('condition') or '—'} | {r['value']:.6g} | {r.get('unit') or '—'} "
                  f"| {r.get('equation_id') or '—'} |" for r in rc["results"]]
    else:
        lines.append(f"재계산 결과 없음 — {rc.get('reason') or rc['status']}")
    r = a["reevaluation"]
    dv = r["data_version"]
    lines += ["", "## 6-2 수정 후 재평가", ""]
    if not r.get("previous_run"):
        lines.append(r["note"])
    else:
        lines.append(f"이전 감사 `{r['previous_run']}` 와 비교: " + ", ".join(f"{k} {v}" for k, v in r["counts"].items()))
        lines += ["", "| 변화 | 위치 | 주장 | 이전 | 이번 | 이전 코드 | 이번 코드 |", "|---|---|---|---|---|---|---|"]
        for x in r["rows"]:
            lines.append(f"| {x['change']} | p.{x['page']} 문장 {x['no']} | {_esc(x['claim'])} | {x['before'] or '—'} | "
                         f"{x['after'] or '—'} | {', '.join(x['codes_before']) or '—'} | {', '.join(x['codes_after']) or '—'} |")
    lines += ["", "### E07 데이터 버전 변경 (기록)", ""]
    if not dv.get("previous_run"):
        lines.append(dv["note"])
    elif not dv["changes"]:
        lines.append(f"이전 계산 `{dv['previous_run']}` 에 쓴 RAW 와 같음")
    else:
        lines += [f"- E07 {x['detail']}" for x in dv["codes"]]
    return "\n".join(lines) + "\n"
