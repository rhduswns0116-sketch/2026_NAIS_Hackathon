"""오류 코드 E01–E07 — docs/MeasureTrace_오류코드_E01-E07_기술명세.md (확정).

판정은 Supported / Unsupported 두 가지이고, 오류 코드는 그 이유다. 코드 결과는 Unsupported(판정을 바꿈) 또는
기록(판정을 바꾸지 않고 리포트에 남김). 판정을 바꾸는 코드가 하나라도 있으면 Unsupported.
"""
from __future__ import annotations

NAMES = {
    "E01": "단위 누락·불일치",
    "E02": "측정값 이상 (사양 범위 이탈·결측)",
    "E03": "필요 데이터 누락",
    "E04": "반복 단위·표본 수 불일치",
    "E05": "주장 수치 불일치 (방향 포함)",
    "E06": "재계산 대응 없음",
    "E07": "데이터 버전 변경",
}
UNSUPPORTED = {"E01", "E03", "E04", "E05", "E06"}
RECORD = {"E02", "E07"}              # E02 는 3회 뒤에도 미결정이면 Unsupported (effect 로 지정)
E06_REASONS = ("식 없음", "데이터 없음", "미확정", "검정 방법 없음")


def code(c: str, detail: str, evidence: list[str] | None = None, *, effect: str | None = None,
         reason: str | None = None) -> dict:
    """오류 코드 한 건. effect 를 주면 기본 결과를 바꾼다(E02 미결정 → Unsupported). E06 은 reason(사유)이 필요하다."""
    if c == "E06" and reason not in E06_REASONS:
        raise ValueError(f"E06 사유는 {E06_REASONS} 중 하나: {reason!r}")
    out = {"code": c, "name": NAMES[c], "effect": effect or ("Unsupported" if c in UNSUPPORTED else "기록"),
           "detail": detail, "evidence": evidence or []}
    if reason:
        out["reason"] = reason
    return out
