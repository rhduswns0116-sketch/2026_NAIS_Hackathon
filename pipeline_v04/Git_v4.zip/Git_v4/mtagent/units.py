"""단위 — 접두어(f p n u m k M G) × 기본 단위. 표기 해석과 환산만 한다(외부 라이브러리 없이)."""
from __future__ import annotations

import re

PREFIX = {"f": 1e-15, "p": 1e-12, "n": 1e-9, "u": 1e-6, "m": 1e-3, "c": 1e-2, "k": 1e3, "M": 1e6, "G": 1e9}
BASE = {"A": "current", "V": "voltage", "S": "conductance", "Ω": "resistance", "ohm": "resistance",
        "s": "time", "Hz": "frequency", "W": "power", "F": "capacitance", "H": "inductance", "T": "magnetic_flux",
        "Pa": "pressure", "N": "force", "J": "energy", "g": "mass", "mol": "amount", "L": "volume",
        "m": "length", "K": "temperature", "C": "temperature", "cd": "luminous"}
NO_PREFIX = {"C", "K"}      # °C · K 는 접두어를 붙이지 않는다고 본다 (mC 같은 전하는 이 도구 범위 밖)
DIMENSIONLESS = {"", "-", "1", "무차원", "개", "count", "counts", "none", "dimensionless", "ea"}
PERCENT = {"%", "퍼센트", "percent"}


_SHEET = re.compile(r"(?:/(?:sq|square|□)|□)$")        # 면저항: ohm/sq · Ω/□ · Ω/sq · Ω□ — 같은 단위의 다른 표기 (E01 오탐 방지)


def normalize(u: str | None) -> str:
    u = (u or "").strip()
    u = u.replace("μ", "u").replace("µ", "u").replace("°C", "C").replace("℃", "C").replace("Ohm", "ohm")
    u = re.sub(r"\s+", "", u)
    u = re.sub(r"ohms\b", "ohm", u)
    return _SHEET.sub("/sq", u)                        # 면저항 표기는 '/sq' 로 모은다


def parse(u: str | None) -> tuple[float, str] | None:
    """단위 표기 → (SI 배수, 차원). 해석 못 하면 None."""
    n = normalize(u)
    if n.lower() in DIMENSIONLESS:
        return (1.0, "none")
    if n in PERCENT:
        return (1.0, "percent")
    if n.endswith("/sq"):                              # 면저항 (Ω/□) — 저항 단위 + /sq
        base = parse(n[:-3])
        return (base[0], "sheet_resistance") if base and base[1] == "resistance" else None
    if n in BASE:
        return (1.0, BASE[n])
    if len(n) > 1 and n[0] in PREFIX and n[1:] in BASE and n[1:] not in NO_PREFIX:
        return (PREFIX[n[0]], BASE[n[1:]])
    return None


def dimension(u: str | None) -> str | None:
    p = parse(u)
    return p[1] if p else None


def convert(value: float, frm: str | None, to: str | None) -> float:
    a, b = parse(frm), parse(to)
    if a is None or b is None:
        raise ValueError(f"단위를 해석할 수 없음: {frm!r} → {to!r}")
    if a[1] != b[1]:
        raise ValueError(f"차원이 다름: {frm}({a[1]}) → {to}({b[1]})")
    if a[1] == "temperature" and normalize(frm) != normalize(to):
        return value + 273.15 if normalize(frm) == "C" else value - 273.15
    return value * a[0] / b[0]


_HEADER = [re.compile(r"[\(\[]\s*([^\)\]]+?)\s*[\)\]]\s*$"),     # current (nA) · current [nA]
           re.compile(r"[_\s/]([A-Za-zΩμµ°%]{1,4})$")]           # current_A · voltage_V


def from_header(col: str) -> str | None:
    """열 이름에 적힌 단위. 알려진 단위일 때만 단위로 본다(sample_no 의 'no' 등 오인 방지)."""
    for pat in _HEADER:
        m = pat.search(col.strip())
        if m and parse(m.group(1)) is not None and normalize(m.group(1)).lower() not in DIMENSIONLESS:
            return normalize(m.group(1))
    return None
