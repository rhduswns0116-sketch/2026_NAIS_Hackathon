"""LLM 호출 — 구조화 출력(JSON 스키마) · 캐시 · 호출 기록.

- Claude API(anthropic SDK) 의 output_config.format(json_schema) 로 JSON 만 받는다.
- 같은 (모델, 과업, 지시문, 입력, 스키마, effort) 이면 캐시를 쓴다 → 같은 입력에 같은 답(재현성), 토큰 0.
- 서버 측 fallbacks("default") 로 거절 시 다른 모델이 이어받게 한다. 거절·출력 잘림은 실패로 기록.
- 키 값은 어디에도 출력하지 않는다.
- 이 모듈은 받은 글을 그대로 보낸다 — 측정값을 빼는 것은 부르는 쪽(stages/*)의 책임.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

from mtagent import config
from mtagent.util import canonical, now, sha_text

_lock = threading.Lock()


class LLMError(RuntimeError):
    pass


def obj(props: dict, required: list[str] | None = None) -> dict:
    """구조화 출력용 object 스키마 — 추가 키 금지, 기본은 모든 키 필수."""
    return {"type": "object", "properties": props, "required": list(props) if required is None else required,
            "additionalProperties": False}


def arr(items: dict) -> dict:
    return {"type": "array", "items": items}


def s(desc: str | None = None, nullable: bool = False, enum: list | None = None) -> dict:
    if enum is not None and nullable:   # API 는 null 을 섞은 enum 을 받지 않음 → anyOf
        out: dict = {"anyOf": [{"type": "string", "enum": enum}, {"type": "null"}]}
    else:
        out = {"type": ["string", "null"] if nullable else "string"}
        if enum is not None:
            out["enum"] = enum
    if desc:
        out["description"] = desc
    return out


def num(desc: str | None = None, nullable: bool = True, integer: bool = False) -> dict:
    t = "integer" if integer else "number"
    out: dict = {"type": [t, "null"] if nullable else t}
    if desc:
        out["description"] = desc
    return out


def boolean(nullable: bool = False) -> dict:
    return {"type": ["boolean", "null"] if nullable else "boolean"}


class LLM:
    """client 를 넘기면 그것을 쓴다(시험용 가짜 클라이언트). 없으면 설정에서 만든다."""

    def __init__(self, client=None, model: str | None = None, offline: bool | None = None):
        self.model = model or config.model()
        self.offline = config.offline() if offline is None else offline
        self.client = client
        if client is None and not self.offline and config.api_key():
            import anthropic
            self.client = anthropic.Anthropic(api_key=config.api_key(), max_retries=3, timeout=900)
        self.stats = {"calls": 0, "cache_hits": 0, "errors": 0, "input_tokens": 0, "output_tokens": 0}

    def status(self) -> dict:
        return {"available": self.client is not None or self.offline, "model": self.model, "offline": self.offline,
                "has_key": bool(config.api_key())}

    def _cache_path(self, task: str, system: str, user: str, schema: dict, effort: str) -> Path:
        key = sha_text(canonical([self.model, task, system, user, schema, effort]))
        return config.cache_dir() / f"{task}-{key[:24]}.json"

    def forget(self, task: str, system: str, user: str, schema: dict, effort: str = "high") -> bool:
        """이 입력의 캐시를 지운다 — JSON 형식은 맞지만 부르는 쪽의 내용 검사에 떨어진 응답이 다음 실행에서 또 쓰이지 않게."""
        cache = self._cache_path(task, system, user, schema, effort)
        if cache.exists():
            cache.unlink()
            self._log({"task": task, "event": "cache_forgotten", "cache": cache.name})
            return True
        return False

    def json(self, task: str, system: str, user: str, schema: dict, effort: str = "high",
             max_tokens: int = 64000) -> dict:
        cache = self._cache_path(task, system, user, schema, effort)
        if cache.exists():
            self.stats["cache_hits"] += 1
            self._log({"task": task, "event": "cache_hit", "cache": cache.name})
            return json.loads(cache.read_text(encoding="utf-8"))["output"]
        if self.offline or self.client is None:
            raise LLMError("LLM 을 쓸 수 없음 (API 키 없음 또는 오프라인) — 캐시에도 없는 입력")
        t0 = time.time()
        try:
            with self.client.beta.messages.stream(
                model=self.model, max_tokens=max_tokens, system=system,
                messages=[{"role": "user", "content": user}],
                output_config={"effort": effort, "format": {"type": "json_schema", "schema": schema}},
                betas=["server-side-fallback-2026-07-01"], fallbacks="default",
            ) as stream:
                msg = stream.get_final_message()
        except Exception as e:
            self.stats["errors"] += 1
            self._log({"task": task, "event": "error", "error": f"{type(e).__name__}: {e}"[:800]})
            raise LLMError(f"LLM 호출 실패: {type(e).__name__}: {e}") from e
        usage = getattr(msg, "usage", None)
        info = {"task": task, "event": "call", "model_reported": getattr(msg, "model", None),
                "stop_reason": msg.stop_reason, "request_id": getattr(msg, "_request_id", None),
                "input_tokens": getattr(usage, "input_tokens", 0), "output_tokens": getattr(usage, "output_tokens", 0),
                "seconds": round(time.time() - t0, 1)}
        self.stats["calls"] += 1
        self.stats["input_tokens"] += info["input_tokens"] or 0
        self.stats["output_tokens"] += info["output_tokens"] or 0
        if msg.stop_reason in ("refusal", "max_tokens"):
            self.stats["errors"] += 1
            self._log({**info, "event": "error"})
            raise LLMError("LLM 이 거절함" if msg.stop_reason == "refusal" else "LLM 출력이 잘림(max_tokens)")
        text = next((b.text for b in msg.content if getattr(b, "type", "") == "text"), "")
        try:
            out = json.loads(text)
        except json.JSONDecodeError as e:
            self.stats["errors"] += 1
            self._log({**info, "event": "error", "error": "JSON 해석 실패"})
            raise LLMError(f"LLM 응답이 JSON 이 아님: {e}") from e
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps({"task": task, "model": self.model, "at": now(), "output": out},
                                    ensure_ascii=False, indent=1), encoding="utf-8")
        self._log({**info, "cache": cache.name})
        return out

    def _log(self, event: dict) -> None:
        path = config.outputs_dir() / "llm_calls.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with _lock, path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"at": now(), "model": self.model, **event}, ensure_ascii=False, default=str) + "\n")
