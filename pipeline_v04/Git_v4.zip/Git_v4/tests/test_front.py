"""앞단(1 INGEST · 2 EXTRACT · 3 CONFIRM 시작) 입력 변형 시험 — 가짜 LLM, 토큰 0.

실제 장비 파일에서 흔한 모양: 머리말 줄 · 따옴표 안 쉼표 · 표 뒤 설명 줄 · raw 폴더 안의 'results' 이름 ·
깨진 PDF/docx · 한글(.hwp) 계획서 · 면저항 단위 표기 · 메모 열의 빈칸.

  python -m unittest tests.test_front -v
"""
from __future__ import annotations

import os
import re
import shutil
import stat
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]

from fake_llm import FakeClient  # noqa: E402
from mtagent import hashing, readers, store, units  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import confirm, extract, ingest  # noqa: E402

SAMPLES = ROOT / "samples"
TMP = Path(tempfile.mkdtemp(prefix="mt_front_"))
_OLD_WS = None


def setUpModule():            # 이 모듈만 자기 작업 폴더 — 다른 시험 모듈의 설정을 건드리지 않는다
    global _OLD_WS
    _OLD_WS = os.environ.get("MT_WORKSPACE")
    os.environ["MT_WORKSPACE"] = str(TMP / "ws")


def tearDownModule():
    if _OLD_WS is None:
        os.environ.pop("MT_WORKSPACE", None)
    else:
        os.environ["MT_WORKSPACE"] = _OLD_WS
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def generic_2_1a(user: str) -> dict:
    """열 이름으로 역할을 정하는 가짜 2-1a (샘플과 다른 열 이름에서도 2-3 을 보려고)."""
    cols = []
    for n in re.findall(r'"name": "([^"]+)"', user.split("[연구 계획서]")[0]):
        low = n.lower()
        role = ("id" if "sample" in low else "condition" if "condition" in low else "replicate" if "position" in low
                else "independent" if "volt" in low else "measured" if any(k in low for k in ("current", "rs")) else "other")
        cols.append({"name": n, "role": role, "quantity": None, "unit": None, "unit_source": "none", "meaning": n})
    return {"summary": "가짜", "layout": "long", "columns": cols, "questions": []}


def sample(name: str, change=None) -> str:
    """샘플을 복사해 change(폴더) 로 고친 뒤 새 실행 → 1 INGEST 까지."""
    d = TMP / name
    shutil.copytree(SAMPLES / "annealing_demo", d)
    for p in d.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    if change:
        change(d)
    rid = store.new_run(name)
    store.add_folder(rid, "data", d / "data")
    store.add_folder(rid, "report", d / "report")
    return rid


def each_raw(d: Path, fn):
    for f in (d / "data/raw").rglob("*.csv"):
        f.write_text(fn(f.read_text(encoding="utf-8")), encoding="utf-8")


def extract_fake(rid: str, tag: str):
    return extract.run(rid, LLM(client=FakeClient({"2-1a": generic_2_1a}), model=f"fake-front-{tag}"))


class Tables(unittest.TestCase):
    def write(self, name: str, text: str) -> Path:
        p = TMP / "tables" / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        return p

    def test_preamble_quoted_comma_and_footer(self):
        p = self.write("t.csv", "Instrument: MT-SMU 2400\nOperator: Kim\n\nid,label,value\nS1,\"batch A, run 1\",1.5\n"
                                "S2,plain,2.5\nS3,,3.5\nEnd of data\n")
        t = readers.read_table(p)
        self.assertEqual(t["columns"], ["id", "label", "value"])
        self.assertEqual(t["rows"], [["S1", "batch A, run 1", "1.5"], ["S2", "plain", "2.5"], ["S3", "", "3.5"]])
        self.assertEqual(t["lines"], [5, 6, 7])                              # 원본 줄 번호 유지
        self.assertEqual(t["comments"], ["Instrument: MT-SMU 2400", "Operator: Kim"])
        self.assertEqual(t["notes"], [{"line": 8, "text": "End of data"}])
        self.assertEqual(t["header_line"], 4)

    def test_semicolon_with_decimal_comma_prefers_semicolon(self):
        t = readers.read_table(self.write("eu.csv", "a;b;c\n1,5;2,5;x\n3,5;4,5;y\n"))
        self.assertEqual((t["delimiter"], t["columns"]), (";", ["a", "b", "c"]))

    def test_preamble_change_is_not_format_only(self):
        a = self.write("p1.csv", "Date: 2026-09-15\nid,v\nS1,1\nS2,2\n")
        b = self.write("p2.csv", "Date: 2026-09-16\nid,v\nS1,1\nS2,2\n")
        c = self.write("p3.csv", "Date: 2026-09-15\r\nid,v\r\nS1,1\r\nS2,2\r\n")
        fa, fb, fc = (hashing.fingerprint(x) for x in (a, b, c))
        self.assertNotEqual(fa["content_hash"], fb["content_hash"])
        self.assertEqual(fa["content_hash"], fc["content_hash"])            # 줄바꿈만 다름 → 형식만 변경


class Units(unittest.TestCase):
    def test_sheet_resistance_notations_are_one_unit(self):
        for u in ("ohm/sq", "Ω/□", "Ω/sq", "ohms/square", "Ω□"):
            self.assertEqual(units.parse(u), (1.0, "sheet_resistance"), u)
        self.assertEqual(units.parse("kΩ/□"), (1e3, "sheet_resistance"))
        self.assertAlmostEqual(units.convert(2.0, "kohm/sq", "Ω/□"), 2000.0)
        self.assertEqual(units.dimension("Ω"), "resistance")                   # 그냥 저항과는 다른 차원
        self.assertEqual(units.from_header("Rs (Ω/□)"), "Ω/sq")
        with self.assertRaises(ValueError):
            units.convert(1, "Ω", "Ω/□")


class Ingest(unittest.TestCase):
    def test_folder_decides_over_file_name(self):
        rid = sample("results_name", lambda d: (d / "data/raw/annealed/S01.csv").rename(d / "data/raw/annealed/S01_results.csv"))
        cats = {x["path"]: x["category"] for x in ingest.run(rid)["files"]}
        self.assertEqual(cats["raw/annealed/S01_results.csv"], "raw")
        self.assertEqual(cats["processed/summary_by_sample.csv"], "processed")

    def test_instrument_preamble_and_quoted_commas_still_raw(self):
        def change(d):
            each_raw(d, lambda t: "Instrument: MT-SMU 2400\nOperator: Kim\n\n"
                     + "\n".join(ln + ",note" if i == 0 else ln + (',"batch A, run 1"' if i == 1 else ",")
                                 for i, ln in enumerate(t.splitlines())) + "\nEnd of data\n")
        rid = sample("messy", change)
        out = ingest.run(rid)
        self.assertEqual(out["counts"].get("raw"), 20)
        self.assertFalse(store.state(rid)["stages"]["ingest"]["blocked"])
        ex = extract_fake(rid, "messy")
        self.assertEqual(ex["summary"]["errors"], {})
        self.assertEqual(ex["2-3"]["issues"], [])                            # 메모 열 빈칸·설명 줄은 결측이 아님
        self.assertEqual(ex["2-4"]["missing"], [])                            # 행 수도 그대로(설명 줄을 세지 않음)

    def test_broken_files_do_not_stop_ingest(self):
        def change(d):
            (d / "data/document.docx").write_bytes(b"not a zip")
            (d / "data/instrument_spec.pdf").write_bytes(b"%PDF-1.4 broken")
        rid = sample("broken", change)
        out = ingest.run(rid)
        f = {x["path"]: x for x in out["files"]}
        self.assertEqual(f["document.docx"]["category"], "unknown")
        self.assertIn("읽을 수 없는", f["document.docx"]["reason"])
        ex = extract_fake(rid, "broken")
        self.assertEqual(ex["summary"]["errors"], {})                        # 깨진 사양서가 EXTRACT 를 막지 않음
        self.assertEqual([u["file"] for u in ex["2-2"]["unreadable"]], ["instrument_spec.pdf"])
        self.assertTrue(any("instrument_spec.pdf" in q["text"] or "instrument_spec.pdf" in q["source"]
                            for q in ex["summary"]["questions"]))
        self.assertTrue(confirm.start(rid)["items"])

    def test_hwp_plan_text_is_not_sent_as_bytes(self):
        client = FakeClient({"2-1a": generic_2_1a})
        rid = sample("hwp", lambda d: (d / "data/research_plan.docx").rename(d / "data/research_plan.hwp"))
        out = ingest.run(rid)
        self.assertTrue(any("research_plan.hwp" in x["text"] and ".docx" in x["text"] for x in out["findings"]))
        extract.run(rid, LLM(client=client, model="fake-front-hwp"))
        sent = next(c for c in client.calls if c["task"] == "2-1a")["user"]
        self.assertIn("(이 계획서를 읽지 못함 — .hwp 는 .docx 로 다시 저장해 주세요)", sent)
        self.assertNotIn("PK\x03\x04", sent)

    def test_sheet_resistance_column_unit_is_ok(self):
        rid = sample("sheet", lambda d: each_raw(d, lambda t: t.replace("current_A", "Rs (Ω/□)", 1)))
        ingest.run(rid)
        cols = {c["column"]: c for c in extract_fake(rid, "sheet")["2-3"]["columns"]}
        self.assertEqual((cols["Rs (Ω/□)"]["unit"], cols["Rs (Ω/□)"]["unit_status"]), ("Ω/sq", "ok"))


if __name__ == "__main__":
    unittest.main()
