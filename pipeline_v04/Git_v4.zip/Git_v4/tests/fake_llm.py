"""가짜 LLM 클라이언트 — 샘플(annealing_demo)에 맞춘 답을 돌려준다. 토큰 0.

anthropic.Anthropic().beta.messages.stream(...) 모양만 흉내 낸다. 과업은 지시문의 '과업 2-1a' 같은 표시로 고른다.
calls 에 받은 요청을 남긴다(피드백 반영·블라인드 확인 시험용).
"""
from __future__ import annotations

import json
import re
from types import SimpleNamespace

REFERENCE_CODE = '''import csv
import math
from collections import defaultdict
from scipy import stats


def _slope(points):
    """EQ01: 전압-전류 최소제곱 기울기."""
    n = len(points)
    vbar = sum(v for v, _ in points) / n
    ibar = sum(i for _, i in points) / n
    num = sum((v - vbar) * (i - ibar) for v, i in points)
    den = sum((v - vbar) ** 2 for v, _ in points)
    return num / den


def compute(files):
    data = defaultdict(lambda: defaultdict(list))
    cond_of = {}
    skipped = []
    for rel in sorted(files):
        with open(files[rel], newline="", encoding="utf-8-sig") as fh:
            for line, row in enumerate(csv.DictReader(fh), start=2):
                try:
                    v, i = float(row["voltage_V"]), float(row["current_A"])
                except (TypeError, ValueError):
                    skipped.append([rel, line, "숫자 아님"])
                    continue
                data[row["sample_id"]][row["position"]].append((v, i))
                cond_of[row["sample_id"]] = row["condition"]
    g_pos = {s: {p: _slope(pts) for p, pts in sorted(pos.items())} for s, pos in data.items()}
    g_sample = {s: sum(v.values()) / len(v) for s, v in g_pos.items()}          # EQ03
    groups = defaultdict(list)
    for s in sorted(g_sample):
        groups[cond_of[s]].append(g_sample[s])
    ns = 1e9
    results = []
    stat = {}
    for c in sorted(groups):
        xs = groups[c]
        n = len(xs)
        m = sum(xs) / n                                                       # EQ04
        sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (n - 1))              # EQ05
        stat[c] = (m, sd, n)
        results += [
            {"id": f"G_mean__{c}", "name": "조건 평균 전도도", "value": m * ns, "unit": "nS", "condition": c, "kind": "value", "equation_id": "EQ04"},
            {"id": f"G_sd__{c}", "name": "조건 표준편차", "value": sd * ns, "unit": "nS", "condition": c, "kind": "value", "equation_id": "EQ05"},
            {"id": f"n__{c}", "name": "시료 수", "value": float(n), "unit": None, "condition": c, "kind": "n", "equation_id": None},
        ]
    (ma, sa, na), (mc, sc, nc) = stat["annealed"], stat["control"]
    sp = math.sqrt(((na - 1) * sa ** 2 + (nc - 1) * sc ** 2) / (na + nc - 2))   # EQ06
    t = (ma - mc) / (sp * math.sqrt(1 / na + 1 / nc))                          # EQ07
    df = na + nc - 2
    p = 2 * stats.t.sf(abs(t), df)
    results += [
        {"id": "s_p", "name": "합동 표준편차", "value": sp * ns, "unit": "nS", "condition": None, "kind": "value", "equation_id": "EQ06"},
        {"id": "t", "name": "t 통계량", "value": t, "unit": None, "condition": None, "kind": "test_statistic", "equation_id": "EQ07"},
        {"id": "df", "name": "자유도", "value": float(df), "unit": None, "condition": None, "kind": "df", "equation_id": "EQ07"},
        {"id": "p", "name": "p값 (양측)", "value": float(p), "unit": None, "condition": None, "kind": "p_value", "equation_id": "EQ07"},
        {"id": "dG", "name": "전도도 증가율", "value": (ma - mc) / mc * 100, "unit": "%", "condition": None, "kind": "percent_change", "equation_id": "EQ08"},
    ]
    return {"results": results, "intermediate": {"G_sample_nS": {s: g * ns for s, g in g_sample.items()},
                                                 "G_position_nS": {s: {p: g * ns for p, g in v.items()} for s, v in g_pos.items()},
                                                 "skipped_rows": skipped}}
'''

EQ_MEANING = {
    "EQ01": "위치별 전도도 = I–V 11점 최소제곱 기울기", "EQ02": "저항 = 전도도의 역수 (참고용)",
    "EQ03": "시료 전도도 = 위치 7개 평균", "EQ04": "조건 평균 전도도", "EQ05": "조건 표본 표준편차",
    "EQ06": "합동 표준편차", "EQ07": "독립 2표본 t 통계량", "EQ08": "전도도 증가율(%)"}


def answer(task: str, user: str) -> dict:
    if task == "2-1a":
        return {"summary": "시료 20개 × 위치 7개에서 전압을 바꿔 가며 전류를 잰 I–V 데이터", "layout": "long",
                "columns": [
                    {"name": "sample_id", "role": "id", "quantity": None, "unit": None, "unit_source": "none", "meaning": "시료 ID"},
                    {"name": "condition", "role": "condition", "quantity": None, "unit": None, "unit_source": "none", "meaning": "처리 조건"},
                    {"name": "position", "role": "replicate", "quantity": None, "unit": None, "unit_source": "none", "meaning": "측정 위치 P1–P7"},
                    {"name": "voltage_V", "role": "independent", "quantity": "전압", "unit": "V", "unit_source": "header", "meaning": "인가 전압"},
                    {"name": "current_A", "role": "measured", "quantity": "전류", "unit": "A", "unit_source": "header", "meaning": "측정 전류"}],
                "questions": ["전압 스윕이 단방향입니까?"]}
    if task in ("2-1c", "2-1c2"):   # 두 호출 모두 전체를 돌려줌 — 부르는 쪽이 필요한 키만 씀
        ids = re.findall(r'"id": "(EQ\d+)"', user)
        return {"purpose": "어닐링이 박막 전도도를 높이는지 확인",
                "equations": [{"id": i, "meaning": EQ_MEANING.get(i, "?"), "role": "계산",
                               "variables": [{"symbol": "V_k", "meaning": "전압", "unit": "V", "column": "voltage_V"},
                                             {"symbol": "I_ijk", "meaning": "전류", "unit": "A", "column": "current_A"}]
                               if i == "EQ01" else []} for i in dict.fromkeys(ids)],
                "steps": [{"order": 1, "description": "위치별 I–V 기울기로 G_ij", "inputs": "voltage_V, current_A", "outputs": "G_ij", "equation_ids": ["EQ01"]},
                          {"order": 2, "description": "위치 7개 평균으로 시료 전도도", "inputs": "G_ij", "outputs": "G_i", "equation_ids": ["EQ03"]},
                          {"order": 3, "description": "조건별 평균·표준편차, t 검정, 증가율", "inputs": "G_i", "outputs": "보고값",
                           "equation_ids": ["EQ04", "EQ05", "EQ06", "EQ07", "EQ08"]}],
                "design": {"conditions": [{"name": "annealed", "label": "어닐링 (A)", "samples": ["S01–S10"]},
                                          {"name": "control", "label": "대조 (C)", "samples": ["S11–S20"]}],
                           "independent_unit": "시료", "id_column": "sample_id", "condition_column": "condition",
                           "replicate": "위치 P1–P7", "replicates_per_unit": 7, "points_per_replicate": 11,
                           "degrees_of_freedom": 18, "quote": "독립 단위는 시료이다."},
                "test": {"present": True, "method": "독립 2표본 t 검정(등분산 가정)", "alternative": "two-sided", "alpha": 0.05,
                         "equation_ids": ["EQ06", "EQ07"], "quote": "유의수준은 0.05이다."},
                "matching": [{"experiment": "어닐링/대조 박막 I–V 측정", "data_columns": ["voltage_V", "current_A"],
                              "equation_ids": ["EQ01", "EQ03", "EQ04"], "instrument": "MT-SMU 2400", "instrument_range": "10 nA",
                              "results": "조건 평균 전도도"}],
                "outputs": [
                    {"id": "G_mean", "name": "조건 평균 전도도", "symbol": "G_c", "unit": "nS", "equation_id": "EQ04", "per": "condition", "kind": "value"},
                    {"id": "G_sd", "name": "조건 표준편차", "symbol": "s_c", "unit": "nS", "equation_id": "EQ05", "per": "condition", "kind": "value"},
                    {"id": "n", "name": "시료 수", "symbol": "n", "unit": None, "equation_id": None, "per": "condition", "kind": "n"},
                    {"id": "s_p", "name": "합동 표준편차", "symbol": "s_p", "unit": "nS", "equation_id": "EQ06", "per": "overall", "kind": "value"},
                    {"id": "t", "name": "t 통계량", "symbol": "t", "unit": None, "equation_id": "EQ07", "per": "comparison", "kind": "test_statistic"},
                    {"id": "df", "name": "자유도", "symbol": "df", "unit": None, "equation_id": "EQ07", "per": "comparison", "kind": "df"},
                    {"id": "p", "name": "p값", "symbol": "p", "unit": None, "equation_id": "EQ07", "per": "comparison", "kind": "p_value"},
                    {"id": "dG", "name": "전도도 증가율", "symbol": "ΔG", "unit": "%", "equation_id": "EQ08", "per": "comparison", "kind": "percent_change"}],
                "reporting": "nS, 평균 ± 표준편차", "questions": []}
    if task == "2-1c3":
        return {"code": REFERENCE_CODE, "explanation": "계획서 식 1·3~8 을 그대로 구현", "assumptions": []}
    if task == "2-2":
        return {"instrument": "MT-SMU 2400",
                "ranges": [{"quantity": "전류 측정", "dimension": "current", "range_name": "10 nA", "min": -10.5, "max": 10.5, "unit": "nA",
                            "accuracy": "0.10 % + 50 pA", "resolution": "10 fA", "page": 2,
                            "quote": "Valid current readings on the 10 nA range: -10.5 nA to +10.5 nA."},
                           {"quantity": "전류 측정", "dimension": "current", "range_name": "100 nA", "min": None, "max": 105, "unit": "nA",
                            "accuracy": "0.06 % + 100 pA", "resolution": "100 fA", "page": 1, "quote": "100 nA 100 fA 0.06 % + 100 pA 105 nA"}],
                "overflow_value": 9.9e37, "overflow_quote": "Out-of-range readings are reported as the overflow value 9.9E37.",
                "conditions": [{"name": "동작 온도", "value": "18–28 C", "page": 2, "quote": "Temperature: 18 C to 28 C, humidity below 70 % RH."}],
                "questions": []}
    if task == "2-4":
        return {"conditions": [{"name": "어닐링 (A)", "samples": ["S01–S10"]}, {"name": "대조 (C)", "samples": ["S11–S20"]}],
                "replicates": ["P1–P7"], "points_per_replicate": 11, "rows_per_file": 77, "file_rule": "raw/<조건>/<시료>.csv",
                "required_documents": ["plan", "spec", "raw"], "quote": "파일 하나에 위치 7개 × 11점 = 77행이 있다.", "questions": []}
    if task == "5-1":
        return claims_for(user)
    raise ValueError(f"가짜 LLM: 모르는 과업 {task}")


def _claim(**kw) -> dict:
    base = {"type": "value", "text": "", "value": None, "unit": None, "output_id": None, "lhs": None, "rhs": None,
            "relation": None, "p_value": None, "p_comparator": None, "significant": None, "df": None, "literature": False}
    base.update(kw)
    return base


def claims_for(user: str) -> dict:
    sents = json.loads(user.split("[보고서 문장]", 1)[1].split("[끝]", 1)[0])
    out = []
    for x in sents:
        t = x["text"]
        claims, cat = [], "none"
        m = re.search(r"어닐링 시료의 평균 전도도는 ([\d.]+) ± ([\d.]+) nS, 대조 시료는 ([\d.]+) ± ([\d.]+) nS", t)
        if m:
            cat = "numeric"
            claims = [_claim(text=f"{m.group(1)} nS", value=float(m.group(1)), unit="nS", output_id="G_mean__annealed"),
                      _claim(text=f"± {m.group(2)} nS", value=float(m.group(2)), unit="nS", output_id="G_sd__annealed"),
                      _claim(text=f"{m.group(3)} nS", value=float(m.group(3)), unit="nS", output_id="G_mean__control"),
                      _claim(text=f"± {m.group(4)} nS", value=float(m.group(4)), unit="nS", output_id="G_sd__control")]
            if "n = 10" in t:
                claims += [_claim(type="n", text="각 n = 10", value=10, output_id="n__annealed"),
                           _claim(type="n", text="각 n = 10", value=10, output_id="n__control")]
        elif "높았다" in t:
            cat = "numeric"
            v = re.search(r"([\d.]+) %", t)
            claims = [_claim(type="direction", text=t, lhs="G_mean__annealed", rhs="G_mean__control", relation="greater")]
            if v:
                claims.append(_claim(text=f"{v.group(1)} %", value=float(v.group(1)), unit="%", output_id="dG"))
        elif "유의" in t and "t(" in t:
            cat = "significance"
            tm = re.search(r"t\((\d+)\) = ([\d.]+)", t)
            claims = [_claim(type="significance", text=t, output_id="p", p_value=0.001, p_comparator="<", significant=True,
                             df=float(tm.group(1)) if tm else None)]
            if tm:
                claims.append(_claim(text=f"t({tm.group(1)}) = {tm.group(2)}", value=float(tm.group(2)), output_id="t"))
        elif "문헌값" in t:
            cat = "mixed"
            v = re.search(r"값 ([\d.]+) nS", t)
            lit = re.search(r"문헌값 ([\d.]+) nS", t)
            claims = [_claim(text=f"{v.group(1)} nS", value=float(v.group(1)), unit="nS", output_id="G_mean__annealed")] if v else []
            if lit:     # 문헌값은 literature=true — 검사하지 않고 기록만
                claims.append(_claim(text=f"문헌값 {lit.group(1)} nS", value=float(lit.group(1)), unit="nS", literature=True))
        elif "크게 증가" in t:
            cat = "degree"
            claims = [_claim(type="direction", text=t, lhs="G_mean__annealed", rhs="G_mean__control", relation="greater")]
        elif re.search(r"\[\d+\]", t):
            cat = "citation"
        out.append({"sid": x["sid"], "category": cat, "claims": claims})
    return {"sentences": out}


class _Stream:
    def __init__(self, msg):
        self.msg = msg

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def get_final_message(self):
        return self.msg


class FakeClient:
    def __init__(self, overrides: dict | None = None):
        self.calls = []
        self.overrides = overrides or {}
        self.beta = SimpleNamespace(messages=SimpleNamespace(stream=self._stream))

    def _stream(self, **kw):
        system = kw["system"]
        task = re.search(r"과업 (\d-\d[a-c]?\d?)", system).group(1)
        user = kw["messages"][0]["content"]
        self.calls.append({"task": task, "system": system, "user": user, "kw": kw})
        out = self.overrides[task](user) if task in self.overrides else answer(task, user)
        msg = SimpleNamespace(content=[SimpleNamespace(type="text", text=json.dumps(out, ensure_ascii=False))],
                              stop_reason="end_turn", model="fake", usage=SimpleNamespace(input_tokens=0, output_tokens=0))
        return _Stream(msg)
