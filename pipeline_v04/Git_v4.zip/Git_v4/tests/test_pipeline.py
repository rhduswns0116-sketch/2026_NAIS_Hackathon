"""MeasureTrace Git_v4 시험 — 가짜 LLM(토큰 0), 임시 작업 폴더.

  python -m unittest discover -s tests -v

기준 문서: docs/MeasureTrace_파이프라인_v4_기술명세.md · docs/MeasureTrace_오류코드_E01-E07_기술명세.md
"""
from __future__ import annotations

import json
import os
import re
import shutil
import stat
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
TMP = Path(tempfile.mkdtemp(prefix="mt_test_"))
os.environ["MT_WORKSPACE"] = str(TMP / "ws")
os.environ.pop("LLM_API_KEY", None)
os.environ.pop("ANTHROPIC_API_KEY", None)

from fake_llm import REFERENCE_CODE, FakeClient, answer  # noqa: E402
from mtagent import codes, design, hashing, lineage, sandbox, store, units  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import audit, confirm, extract, ingest, recompute, validate  # noqa: E402
from mtagent.util import sha_file  # noqa: E402

SAMPLES = ROOT / "samples"
KEY = json.loads((SAMPLES / "annealing_demo_answer_key.json").read_text(encoding="utf-8"))


def tearDownModule():
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def fake(client=None, tag: str = "") -> LLM:
    """가짜 LLM. tag 를 주면 캐시를 다른 시험과 나누지 않는다(같은 입력에 다른 가짜 답을 줄 때)."""
    return LLM(client=client or FakeClient(), model=f"fake{'-' + tag if tag else ''}")


def new_run(project: str, folder: Path) -> str:
    rid = store.new_run(project)
    store.add_folder(rid, "data", folder / "data")
    if (folder / "report").exists():
        store.add_folder(rid, "report", folder / "report")
    time.sleep(0.01)
    return rid


def approve_all(rid: str, who="tester", extra: dict | None = None):
    v = confirm.view(rid)
    ans = {}
    for i in v["items"]:
        if i["required"] and i["status"] == "pending":
            vals = [c["value"] for c in i["choices"]]
            ans[i["id"]] = {"choice": next(x for x in ("yes", "proceed") if x in vals) if {"yes", "proceed"} & set(vals)
                            else vals[0]}
    ans.update(extra or {})
    return confirm.submit(rid, who, ans)


def full(rid: str, client=None, tag: str = ""):
    ingest.run(rid)
    extract.run(rid, fake(client, tag))
    confirm.start(rid)
    approve_all(rid)
    recompute.run(rid)
    validate.run(rid, fake(client, tag))
    return audit.run(rid)


def copy_sample(name: str) -> Path:
    src = TMP / name
    shutil.copytree(SAMPLES / "annealing_demo", src)
    for p in src.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    return src


class UnitsHashing(unittest.TestCase):
    def test_units(self):
        self.assertAlmostEqual(units.convert(1.2e-8, "A", "nA"), 12.0)
        self.assertEqual(units.dimension("nS"), "conductance")
        self.assertEqual(units.dimension("μA"), "current")
        self.assertIsNone(units.parse("furlong"))
        self.assertEqual(units.from_header("current_A"), "A")
        self.assertEqual(units.from_header("Current (nA)"), "nA")
        self.assertIsNone(units.from_header("sample_id"))
        with self.assertRaises(ValueError):
            units.convert(1, "A", "V")

    def test_format_only_and_row_diff(self):
        d = TMP / "h"
        d.mkdir(exist_ok=True)
        rows = "a,b\n1,2\n3,4\n5,6\n"
        (d / "x.csv").write_text(rows, encoding="utf-8")
        (d / "y.csv").write_bytes(("\ufeff" + rows.replace("\n", "  \r\n")).encode("utf-8"))
        (d / "z.csv").write_text("a,b\n1,2\n5,6\n", encoding="utf-8")
        x, y, z = (hashing.fingerprint(d / n) for n in ("x.csv", "y.csv", "z.csv"))
        self.assertNotEqual(x["sha256"], y["sha256"])
        self.assertEqual(x["content_hash"], y["content_hash"])
        ch = hashing.compare_sets({"x": x}, {"x": z})
        self.assertEqual(ch[0]["table"]["removed"], 1)
        self.assertEqual(ch[0]["table"]["spans"], [{"kind": "빠짐", "where": "옛 파일 3줄"}])

    def test_condition_matching(self):
        conds = [{"name": "annealed", "label": "어닐링 (A)", "samples": ["S01", "S02"]},
                 {"name": "control", "label": "대조 (C)", "samples": ["S11"]}]
        self.assertEqual(design.match_condition("어닐링 (A)", conds), "annealed")
        self.assertEqual(design.match_condition("annealed (A)", conds), "annealed")
        self.assertEqual(design.match_condition("A 조건", conds, "s02"), "annealed")
        self.assertIsNone(design.match_condition("제3 조건", conds, "S99"))
        self.assertEqual(design.expand_samples(["S01–S03", "X"]), ["S01", "S02", "S03", "X"])


class Schemas(unittest.TestCase):
    def test_structured_output_limits(self):
        """Claude API 구조화 출력 제약: null 허용(유니언) 항목 16개 이하, null 섞인 enum 금지, 모든 object 에 additionalProperties=false."""
        def walk(x, acc):
            if isinstance(x, dict):
                if isinstance(x.get("type"), list) or "anyOf" in x:
                    acc["unions"] += 1
                if isinstance(x.get("type"), list) and "enum" in x:
                    acc["bad_enum"] += 1
                if x.get("type") == "object" and x.get("additionalProperties") is not False:
                    acc["open_obj"] += 1
                for y in x.values():
                    walk(y, acc)
            elif isinstance(x, list):
                for y in x:
                    walk(y, acc)
            return acc
        schemas = [getattr(extract, n) for n in ("SCHEMA_A", "SCHEMA_C", "SCHEMA_C2", "SCHEMA_CODE", "SCHEMA_S", "SCHEMA_M")]
        for sch in schemas + [validate.SCHEMA]:
            acc = walk(sch, {"unions": 0, "bad_enum": 0, "open_obj": 0})
            self.assertLessEqual(acc["unions"], 16)
            self.assertEqual((acc["bad_enum"], acc["open_obj"]), (0, 0))


class Sandbox(unittest.TestCase):
    def test_static_check_and_signature(self):
        bad = "import os\nimport socket\ndef compute(files):\n    eval('1')\n    open('a', 'w')\n    return {}\n"
        self.assertEqual(len(sandbox.static_check(bad)), 4)
        self.assertIn("compute(files) 함수가 없음", sandbox.static_check("x = 1\n"))
        for ok in ("def compute(files):\n    return {}\n", "def compute(files, /):\n    return {}\n",
                   "def compute(files, opts=None):\n    return {}\n",
                   "class H:\n    def compute(self, a, b):\n        return 1\n\ndef compute(files):\n    return {}\n"):
            self.assertEqual(sandbox.static_check(ok), [], ok)
        self.assertTrue(any("인자 하나" in p for p in sandbox.static_check("def compute(raw, processed):\n    return {}\n")))

    def test_runtime_blocks_write_and_foreign_read(self):
        d = TMP / "sb"
        d.mkdir(exist_ok=True)
        target = d / "leak.txt"
        for body, word in ((f"open(r'{target}', 'w').write('x')", "쓰기"), ("import socket", "import")):
            p = d / "code.py"
            p.write_text("def compute(files):\n    " + body + "\n    return {'results': []}\n", encoding="utf-8")
            r = sandbox.run(p, sha_file(p), {}, 60)
            self.assertEqual(r["status"], "error")
            self.assertIn(word, r["error"])
        self.assertFalse(target.exists())


class Codes(unittest.TestCase):
    def test_names_effects_and_e06_reasons(self):
        self.assertEqual(codes.NAMES["E06"], "재계산 대응 없음")
        self.assertEqual(codes.code("E02", "x")["effect"], "기록")
        self.assertEqual(codes.code("E02", "x", effect="Unsupported")["effect"], "Unsupported")
        self.assertEqual(codes.code("E07", "x")["effect"], "기록")
        self.assertEqual(codes.code("E06", "x", reason="검정 방법 없음")["reason"], "검정 방법 없음")
        with self.assertRaises(ValueError):
            codes.code("E06", "사유 없음")


class Pipeline(unittest.TestCase):
    def test_ingest_blocks_failed_input_lock(self):
        rid = new_run("unlocked-input", SAMPLES / "annealing_demo")
        with patch.object(store, "lock_readonly", return_value=0):
            result = ingest.run(rid)
        self.assertFalse(next(c for c in result["checks"] if c["check"] == "입력 사본 읽기 전용")["ok"])
        self.assertTrue(store.state(rid)["stages"]["ingest"]["blocked"])
        with self.assertRaises(ValueError):
            extract.run(rid, fake(tag="unlocked-input"))

    def test_recompute_blocks_tampered_confirmation(self):
        rid = new_run("tampered-confirm", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(tag="tampered-confirm"))
        confirm.start(rid)
        approve_all(rid)
        path = store.out_dir(rid) / "confirm" / "confirmed.json"
        confirmed = json.loads(path.read_text(encoding="utf-8"))
        confirmed["notes"].append({"q": "changed", "a": "after approval"})
        path.write_text(json.dumps(confirmed, ensure_ascii=False), encoding="utf-8")

        with patch.object(sandbox, "run", side_effect=AssertionError("sandbox must not run")):
            log = recompute.run(rid)
        self.assertEqual(log["status"], "blocked")
        self.assertEqual(log["checks"][0]["check"], "확정 기록 해시")
        self.assertFalse(log["checks"][0]["ok"])

    def test_demo_end_to_end(self):
        client = FakeClient()
        rid = new_run("demo", SAMPLES / "annealing_demo")
        a = full(rid, client, tag="e2e")          # 다른 시험의 캐시를 쓰지 않도록 — 모든 LLM 호출을 client 로 확인
        ing = store.read(rid, "ingest.json")
        # 1 INGEST — PROCESSED 는 분류만 하고 쓰지 않음, 측정 시각 없음, 필요 파일 4종
        cats = {x["path"]: x["category"] for x in ing["files"]}
        self.assertEqual(cats["processed/summary_by_sample.csv"], "processed")
        self.assertEqual([r["file"] for r in ing["required"]], ["RAW_DATA", "연구 계획서 (.docx)", "장비 사양서", "최종 보고서 초안"])
        self.assertTrue(all(r["count"] for r in ing["required"]))
        self.assertFalse(any("measured_at" in x or "times" in x for x in ing["files"]))
        # 2 EXTRACT — 2-1b 파이썬 수식 변환, 2-1a 는 RAW 묶음만
        eq = store.read(rid, "extract/equations.json")
        self.assertEqual((len(eq["equations"]), eq["failed"], eq["converter"]), (8, [], "dwml.omml.oMath2Latex"))
        self.assertEqual([g["group_id"] for g in store.read(rid, "extract/data_content.json")["groups"]], ["G1"])
        self.assertEqual({c["task"] for c in client.calls}, {"2-1a", "2-1c", "2-1c2", "2-1c3", "2-2", "2-4", "5-1"})
        # 4 RECOMPUTE — RAW 만, 정답 대비(상대 오차 ≤ 1e-6), 코드 해시
        log = store.read(rid, "recompute/calc_log.json")
        self.assertEqual(len(log["inputs"]), 20)
        self.assertTrue(all(x["path"].startswith("raw/") for x in log["inputs"]))
        self.assertEqual(log["commit"]["code_sha256"], log["code"]["sha256"])
        res = {r["id"]: r["value"] for r in log["results"]}
        exp = {"G_mean__annealed": KEY["conditions"]["annealed"]["mean_nS"], "G_sd__control": KEY["conditions"]["control"]["sd_nS"],
               "t": KEY["t_test"]["t"], "p": KEY["t_test"]["p_two_sided"], "dG": KEY["increase_percent"], "df": 18}
        for k, v in exp.items():
            self.assertLessEqual(abs(res[k] - v) / abs(v), 1e-6, k)
        # 5·6
        self.assertEqual((a["summary"]["Supported"], a["summary"]["Unsupported"]), (12, 0))
        self.assertTrue(a["blind"]["ok"])
        claim = a["supported"][0]
        self.assertEqual(claim["data_hash"]["content"], log["content_input_hash"])
        self.assertTrue(any(c.get("equations_used") for c in a["supported"]))
        # 측정값·보고서 수치는 LLM 에 가지 않음 / 5-1 요청에 재계산 값 없음
        s01 = (SAMPLES / "annealing_demo/data/raw/annealed/S01.csv").read_text(encoding="utf-8").splitlines()[1].split(",")[-1]
        for call in client.calls:
            if call["task"].startswith("2-"):
                self.assertNotIn(s01, call["user"])
                self.assertNotIn("12.1 ± 0.7", call["user"])
                self.assertNotIn("G_mean_nS", call["user"])          # PROCESSED 열도 보내지 않음
        catalog = next(c for c in client.calls if c["task"] == "5-1")["user"].split("[보고서 문장]")[0]
        self.assertNotIn("12.1016", catalog)
        self.assertNotIn("6.0494", catalog)
        # 문헌 인용·문헌값은 기록만
        cites = [x for x in a["not_checked"] if x.get("citations")]
        self.assertEqual(cites[0]["citations"], [{"number": "1", "reference": "H. Kim et al., Journal of Thin Film Tests 12, 34 (2024). (가상 문헌)"}])
        self.assertEqual([x["text"] for x in a["literature"]], ["문헌값 11.5 nS"])                 # 혼합 문장의 문헌값은 기록만
        mixed = next(c for c in a["supported"] if c["category"] == "mixed")
        self.assertEqual(mixed["literature_values"][0]["value"], 11.5)
        # 확정 코드 읽기 전용, 장부(1-3)에 단계가 모두 있음, 입력 봉인
        code = store.out_dir(rid) / "confirm" / "approved_code.py"
        self.assertFalse(os.access(code, os.W_OK))
        stages = {" ".join(e["stage"].split(" ")[:2]) for e in lineage.entries(rid)}
        for s in ("1 INGEST", "2 EXTRACT", "3 CONFIRM", "4 RECOMPUTE", "5 VALIDATE", "6 AUDIT"):
            self.assertIn(s, stages)
        self.assertIn("2 EXTRACT 2-1b equations", {e["stage"] for e in lineage.entries(rid)})
        with self.assertRaises(ValueError), open(code, "rb") as f:
            store.save_upload(rid, "data", "x.csv", f, 1)

    def test_rerun_e03_scope_and_e07_at_6_2(self):
        full(new_run("re", SAMPLES / "annealing_demo"))
        rid = new_run("re", SAMPLES / "annealing_demo_rerun")
        a = full(rid)
        ch = {c["file"]: c for c in store.read(rid, "ingest.json")["changes"]}
        self.assertEqual(ch["data/raw/annealed/S07.csv"]["table"]["spans"], [{"kind": "빠짐", "where": "옛 파일 31–33줄"}])
        self.assertEqual(ch["data/raw/control/S12.csv"]["kind"], "형식만 변경")
        self.assertEqual([m["detail"] for m in store.read(rid, "extract/missing.json")["missing"]], ["S07 position=P3: 8/11점"])
        by = {}
        for c in store.read(rid, "validate.json")["claims"]:
            by.setdefault(c["claim"].get("output_id") or c["claim"].get("lhs"), []).append(c)
        for oid in ("G_mean__annealed", "G_sd__annealed", "dG", "t", "p"):
            for c in by[oid]:
                self.assertEqual(c["verdict"], "Unsupported", oid)
                self.assertIn("E03", {x["code"] for x in c["codes"]})
        for oid in ("G_mean__control", "G_sd__control", "n__control"):
            for c in by[oid]:
                self.assertEqual(c["verdict"], "Supported", oid)
            self.assertFalse(any(x["code"] == "E07" for c in by[oid] for x in c["codes"]))   # E07 은 주장에 붙이지 않음
        self.assertEqual(a["reevaluation"]["counts"], {"나빠짐": 9, "그대로": 3})
        dv = a["reevaluation"]["data_version"]
        self.assertEqual({c["file"]: c["kind"] for c in dv["changes"]},
                         {"raw/annealed/S07.csv": "내용 변경", "raw/control/S12.csv": "형식만 변경"})
        self.assertTrue(all(x["code"] == "E07" and x["effect"] == "기록" for x in dv["codes"]))
        self.assertIn("빠짐 3", next(x["detail"] for x in dv["codes"] if "S07" in x["detail"]))

    def test_confirm_no_reruns_extract_with_feedback(self):
        client = FakeClient()
        rid = new_run("fb", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client))
        v = confirm.start(rid)
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans["3-1:eq:EQ05"] = {"choice": "no", "text": "표준편차는 n-1 로 나누는 표본 표준편차임"}
        before = len(client.calls)
        v = confirm.submit(rid, "tester", ans, llm=fake(client))
        self.assertEqual((v["round"], v["status"]), (2, "open"))
        again = [c for c in client.calls[before:] if c["task"] == "2-1c"]
        self.assertTrue(again and "n-1 로 나누는" in again[0]["user"])
        self.assertTrue(any(i.get("carried") for i in v["items"]))
        code = next(i for i in v["items"] if i["id"] == "3-1:code")
        self.assertEqual(code["status"], "pending")

    def test_max_rounds_unresolved_equation_is_e06_undecided(self):
        client = FakeClient()
        rid = new_run("mx", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client))
        confirm.start(rid)
        for _ in range(3):
            v = confirm.view(rid)
            ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and i["status"] == "pending"
                   and "yes" in [c["value"] for c in i["choices"]]}
            ans["3-1:eq:EQ04"] = {"choice": "no", "text": "조건 평균의 뜻이 틀림"}
            v = confirm.submit(rid, "tester", ans, llm=fake(client))
            if v["status"] == "complete":
                break
        v = confirm.view(rid)
        self.assertEqual(v["status"], "complete")
        self.assertEqual([p["target"] for p in v["confirmed"]["pending"]], ["eq:EQ04"])
        recompute.run(rid)
        out = validate.run(rid, fake(client))
        g = [c for c in out["claims"] if c["claim"].get("output_id") == "G_mean__annealed"]
        self.assertTrue(g and all({"code": "E06", "reason": "미확정"}.items() <= next(x for x in c["codes"] if x["code"] == "E06").items()
                                  for c in g))
        sd = [c for c in out["claims"] if c["claim"].get("output_id") == "G_sd__annealed"]
        self.assertTrue(sd and all(c["verdict"] == "Supported" for c in sd))

    def test_out_of_spec_is_tentative_e02_and_reupload_restarts(self):
        src = copy_sample("oos")
        f = src / "data/raw/control/S15.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        lines[5] = ",".join(lines[5].split(",")[:-1] + ["5.0e-08"])     # 50 nA — 10 nA 범위(±10.5 nA) 밖
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("oos", src)
        ingest.run(rid)
        extract.run(rid, fake())
        issue = next(i for i in store.read(rid, "extract/structure.json")["issues"] if i["kind"] == "out_of_spec")
        self.assertEqual((issue["code"], issue["tentative"]), ("E02", True))
        v = confirm.start(rid)
        item = next(i for i in v["items"] if i["id"].startswith("3-3:data:out_of_spec"))
        self.assertEqual(item["proposal"]["rows"], [{"line": 6, "value": "5.0e-08"}])
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans[item["id"]] = {"choice": "reupload"}
        v = confirm.submit(rid, "tester", ans)
        self.assertEqual(v["status"], "restart_required")
        with self.assertRaises(ValueError):
            recompute.run(rid)

    def test_proceed_is_e02_record_only(self):
        src = copy_sample("proceed")
        f = src / "data/raw/control/S15.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        lines[5] = ",".join(lines[5].split(",")[:-1] + ["1.2e-08"])     # 12 nA — 사양 밖이지만 연구자가 진행
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        a = full(new_run("proceed", src), tag="proceed")
        e02 = [x for c in a["supported"] + a["unsupported"] for x in c["codes"] if x["code"] == "E02"]
        self.assertTrue(e02 and all(x["effect"] == "기록" for x in e02))
        self.assertTrue(any("S15.csv:6" in e for x in e02 for e in x["evidence"]))

    def test_text_value_none_is_not_missing_but_numeric_na_is(self):
        src = copy_sample("na")
        for f in (src / "data/raw/control").glob("*.csv"):
            f.write_text(f.read_text(encoding="utf-8").replace(",control,", ",none,"), encoding="utf-8")
        f = src / "data/raw/annealed/S03.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        lines[4] = ",".join(lines[4].split(",")[:-1] + ["NA"])
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("na", src)
        ingest.run(rid)
        extract.run(rid, fake())
        issues = store.read(rid, "extract/structure.json")["issues"]
        self.assertEqual([(i["kind"], i["code"], i["file"], i["column"], i["rows"]) for i in issues],
                         [("missing_value", "E02", "raw/annealed/S03.csv", "current_A", [{"line": 5, "value": "NA"}])])

    def test_report_is_not_opened_before_validate(self):
        rid = new_run("bl", SAMPLES / "annealing_demo")
        out = ingest.run(rid)
        self.assertEqual(next(x for x in out["files"] if x["zone"] == "report")["kind"], "bytes (열지 않음)")
        with self.assertRaises(ValueError):
            validate.run(rid, fake())


class ErrorCodes(unittest.TestCase):
    """확정 오류 코드 규칙 — E01·E02 미확정, E04 가짜 반복, E06 사유 네 가지."""

    CONF = {"design": {"conditions": [{"name": "a", "samples": ["S1", "S2"]}, {"name": "b", "samples": ["S3", "S4"]}],
                       "replicate": "위치", "replicates_per_unit": 7, "points_per_replicate": 11},
            "test": {"present": True, "alpha": 0.05},
            "outputs": [{"id": "G", "per": "condition", "kind": "value"}, {"id": "p", "per": "comparison", "kind": "p_value"},
                        {"id": "df", "per": "comparison", "kind": "df"}]}

    def test_unresolved_unit_is_e01_and_unresolved_data_is_e02_unsupported(self):
        conf = {**self.CONF, "pending": [{"item": "3-3:unit:G1:current", "title": "단위", "target": "unit:G1:current"},
                                         {"item": "3-3:data:x", "title": "이상치", "target": "data:raw/S1.csv"},
                                         {"item": "3-1:steps", "title": "가공 방법", "target": "*"}]}
        outs = {"G__a": {"id": "G__a", "group": "a", "equation_id": None}}       # 시료 S1 이 속한 조건 a 의 값을 쓰는 주장
        found = validate._dependency_codes(["G__a"], outs, conf)
        got = {(x["code"], x["effect"], x.get("reason")) for x in found}
        self.assertFalse(any(x["code"] == "E02" for x in validate._dependency_codes(
            ["G__b"], {"G__b": {"id": "G__b", "group": "b"}}, conf)))           # 다른 조건만 쓰면 E02 안 붙음
        self.assertEqual(got, {("E01", "Unsupported", None), ("E02", "Unsupported", None), ("E06", "Unsupported", "미확정")})

    def test_pseudoreplication_df_is_e04(self):
        outs = {"p": {"id": "p", "kind": "p_value", "value": 1e-5, "group": None, "condition": None},
                "df": {"id": "df", "kind": "df", "value": 18.0, "group": None, "condition": None}}
        rec, found = validate._compare({"type": "significance", "text": "t(138) = 4.21, p < 0.001", "output_id": "p",
                                        "p_value": 0.001, "p_comparator": "<", "significant": True, "df": 138}, outs, self.CONF)
        self.assertEqual([x["code"] for x in found], ["E04"])
        for value, bad in ((7, False), (11, False), (2, False), (140, True)):     # 계획서 설계의 수와 비교
            _, found = validate._compare({"type": "n", "text": f"{value}개", "value": value, "output_id": None}, {}, self.CONF)
            self.assertEqual(any(x["code"] == "E04" for x in found), bad, value)

    def test_e06_reasons(self):
        outs = {"G__a": {"id": "G__a", "kind": "value", "value": 1.0, "unit": "nS", "group": "a"}}
        _, f = validate._compare({"type": "value", "text": "12 %", "value": 12, "unit": "%", "output_id": None}, outs, self.CONF)
        self.assertEqual((f[0]["code"], f[0]["reason"]), ("E06", "식 없음"))
        _, f = validate._compare({"type": "value", "text": "1.0 nS", "value": 1.0, "unit": "nS", "output_id": "G__b"}, outs, self.CONF)
        self.assertEqual((f[0]["code"], f[0]["reason"]), ("E06", "데이터 없음"))          # 계획서에 있으나 재계산 안 됨
        no_test = {**self.CONF, "test": {"present": False}}
        outs2 = {**outs, "G__b": {"id": "G__b", "kind": "value", "value": 0.5, "unit": "nS", "group": "b"}}
        _, f = validate._compare({"type": "significance", "text": "유의하게 높았다", "significant": True,
                                  "lhs": "G__a", "rhs": "G__b", "relation": "greater"}, outs2, no_test)
        self.assertEqual([(x["code"], x.get("reason")) for x in f], [("E06", "검정 방법 없음")])   # 방향은 맞음 → E05 없음
        _, f = validate._compare({"type": "significance", "text": "유의하게 낮았다", "significant": True,
                                  "lhs": "G__a", "rhs": "G__b", "relation": "less"}, outs2, no_test)
        self.assertEqual({x["code"] for x in f}, {"E06", "E05"})                               # 방향도 따로 검사
        self.assertEqual(validate._blocked_code({"status": "blocked", "reason": "계산 코드 승인 실패"})["reason"], "미확정")
        self.assertEqual(validate._blocked_code({"status": "blocked", "reason": "RAW 사본이 1 INGEST 해시와 같음 실패"})["reason"],
                         "데이터 없음")

    def test_no_test_method_end_to_end(self):
        client = FakeClient({"2-1c2": lambda u: {**answer("2-1c2", u), "test": {"present": False, "method": None,
                                                                             "alternative": None, "alpha": None,
                                                                             "equation_ids": [], "quote": None}}})
        a = full(new_run("notest", SAMPLES / "annealing_demo"), client, tag="notest")
        sig = [c for c in a["unsupported"] if c["claim"]["type"] == "significance"]
        self.assertTrue(sig and all(any(x.get("reason") == "검정 방법 없음" for x in c["codes"]) for c in sig))

    def test_planned_output_not_recomputed_is_e06_no_data(self):
        dropped = REFERENCE_CODE.replace('        {"id": "dG",', '        # dG 를 계산하지 않음\n        {"id": "dG_unused",')
        client = FakeClient({"2-1c3": lambda u: {"code": dropped, "explanation": "dG 빠짐", "assumptions": []}})
        a = full(new_run("nodg", SAMPLES / "annealing_demo"), client, tag="nodg")
        catalog = next(c for c in client.calls if c["task"] == "5-1")["user"]
        self.assertIn('"id": "dG"', catalog)
        self.assertIn('"recomputed": false', catalog)
        dg = [c for c in a["unsupported"] if c["claim"].get("output_id") == "dG"]
        self.assertTrue(dg and all(any(x.get("reason") == "데이터 없음" for x in c["codes"]) for c in dg))


class ValidateAuditReview(unittest.TestCase):
    def test_tiny_direction_difference_is_not_equal(self):
        outs = {"a": {"id": "a", "value": 0.0, "unit": "A"},
                "b": {"id": "b", "value": 1e-10, "unit": "A"}}
        _, found = validate._compare({"type": "direction", "lhs": "a", "rhs": "b", "relation": "equal"}, outs, {})
        self.assertIn("E05", {x["code"] for x in found})

    def test_multiple_p_values_without_output_id_are_ambiguous(self):
        outs = {"p1": {"id": "p1", "value": 0.01, "kind": "p_value"},
                "p2": {"id": "p2", "value": 0.8, "kind": "p_value"}}
        conf = {"test": {"present": True, "alpha": 0.05},
                "outputs": [{"id": "p1", "kind": "p_value"}, {"id": "p2", "kind": "p_value"}]}
        _, found = validate._compare({"type": "significance", "significant": True, "output_id": None}, outs, conf)
        self.assertEqual((found[0]["code"], found[0]["reason"]), ("E06", "미확정"))

    def test_tiny_reported_value_is_not_accepted_by_fixed_absolute_tolerance(self):
        outs = {"x": {"id": "x", "kind": "value", "value": 2e-15, "unit": "A"}}
        _, found = validate._compare({"type": "value", "text": "1.0e-15 A", "value": 1e-15,
                                      "unit": "A", "output_id": "x"}, outs, {})
        self.assertIn("E05", {x["code"] for x in found})

    def test_missing_sentence_id_stops_validation(self):
        rid = new_run("validate-gap", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(tag="validate-gap"))
        confirm.start(rid)
        approve_all(rid)
        recompute.run(rid)
        client = FakeClient({"5-1": lambda user: {"sentences": []}})
        with self.assertRaisesRegex(ValueError, "문장 ID 불일치"):
            validate.run(rid, fake(client, "validate-gap"))
        self.assertIsNone(store.read(rid, "validate.json"))

    def test_corrected_numeric_sentence_is_paired_with_previous_audit(self):
        old = {"sentence": "값은 12.1이다.", "page": 1, "no": 2,
               "claim": {"type": "value", "text": "12.1"}, "groups": ["a"],
               "verdict": "Unsupported", "codes": [{"code": "E05"}]}
        new = {**old, "sentence": "값은 12.0이다.", "claim": {"type": "value", "text": "12.0"},
               "verdict": "Supported", "codes": []}
        with patch.object(audit.store, "previous_run", return_value="prior"), \
             patch.object(audit.store, "read", return_value={"claims": [old]}), \
             patch.object(audit, "data_version", return_value={}):
            result = audit._reeval("current", [new])
        self.assertEqual(result["counts"], {"고쳐짐": 1})


class Confirm(unittest.TestCase):
    def test_same_column_name_in_two_groups_gets_separate_unit_questions(self):
        src = copy_sample("dup")
        for f in (src / "data/raw").rglob("*.csv"):
            text = f.read_text(encoding="utf-8").replace("current_A", "current", 1)
            if "control" in f.parts:                                  # 대조 파일만 열 하나 더 → 다른 묶음(G2)
                text = "\n".join(ln + (",note" if i == 0 else ",") for i, ln in enumerate(text.splitlines())) + "\n"
            f.write_text(text, encoding="utf-8")
        roles = {"sample_id": ("id", None), "condition": ("condition", None), "position": ("replicate", None),
                 "voltage_V": ("independent", "V"), "note": ("other", None)}

        def columns(user):
            cols = []
            for n in re.findall(r'"name": "([^"]+)"', user.split("[연구 계획서]")[0]):
                role, unit = roles.get(n, ("measured", None))
                cols.append({"name": n, "role": role, "quantity": None, "unit": unit,
                             "unit_source": "header" if unit else "none", "meaning": n})
            return {"summary": "단위 없는 current 열", "layout": "long", "columns": cols, "questions": []}
        rid = new_run("dup", src)
        ingest.run(rid)
        extract.run(rid, fake(FakeClient({"2-1a": columns}), "dup"))
        v = confirm.start(rid)
        ids = sorted(i["id"] for i in v["items"] if i["id"].startswith("3-3:unit:"))
        self.assertEqual(ids, ["3-3:unit:G1:current", "3-3:unit:G2:current"])
        v = approve_all(rid, extra={"3-3:unit:G1:current": {"choice": "other", "text": "A"},
                                    "3-3:unit:G2:current": {"choice": "other", "text": "nA"}})
        self.assertEqual(v["status"], "complete")
        reg = {(c["group_id"], c["column"]): c["unit"] for c in v["confirmed"]["columns"]}
        self.assertEqual((reg[("G1", "current")], reg[("G2", "current")]), ("A", "nA"))

    def test_empty_processing_method_is_asked_again_then_cannot_be_approved(self):
        def once_empty(user):
            out = answer("2-1c", user)
            return out if "[다시 요청]" in user else {**out, "steps": [], "matching": []}
        client = FakeClient({"2-1c": once_empty})
        rid = new_run("empty1", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client, "empty1"))
        b = store.read(rid, "extract/research.json")
        self.assertTrue(b["steps"] and b["matching"])
        self.assertEqual(sum(c["task"] == "2-1c" for c in client.calls), 2)
        always = FakeClient({"2-1c": lambda u: {**answer("2-1c", u), "steps": [], "matching": []}})
        rid = new_run("empty2", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(always, "empty2"))
        items = {i["id"]: i for i in confirm.start(rid)["items"]}
        for k in ("3-1:steps", "3-1:matching"):
            self.assertEqual([c["value"] for c in items[k]["choices"]], ["no"], k)
        self.assertIn("가공 방법", items["3-1:steps"]["title"])

    def test_confirm_groups_and_no_measurement_time(self):
        rid = new_run("groups", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake())
        items = confirm.start(rid)["items"]
        self.assertFalse(any(i["id"] == "3-3:times" for i in items))
        self.assertTrue(any(i["id"].startswith("3-2:cond") for i in items))
        self.assertIn("flowchart LR", next(i for i in items if i["id"] == "3-1:matching")["proposal"]["diagram"]["mermaid"])


class Server(unittest.TestCase):
    def test_host_origin_and_write_header(self):
        from http.server import ThreadingHTTPServer
        from web import server
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        server.Handler.port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{server.Handler.port}"

        def req(method, path, body=None, headers=None):
            r = urllib.request.Request(base + path, data=json.dumps(body).encode() if body is not None else None,
                                       method=method, headers={"Content-Type": "application/json", **(headers or {})})
            try:
                with urllib.request.urlopen(r, timeout=10) as resp:
                    return resp.status, json.loads(resp.read() or b"null") if "json" in resp.headers.get("Content-Type", "") else None
            except urllib.error.HTTPError as e:
                return e.code, None
        try:
            self.assertEqual(req("GET", "/api/status")[0], 200)
            self.assertEqual(req("POST", "/api/runs", {"project": "s"})[0], 403)
            self.assertEqual(req("POST", "/api/runs", {"project": "s"}, {"X-MeasureTrace": "1", "Origin": "http://evil.example"})[0], 403)
            code, body = req("POST", "/api/runs", {"project": "s"}, {"X-MeasureTrace": "1"})
            self.assertEqual(code, 200)
            self.assertEqual(req("GET", f"/api/runs/{body['run_id']}")[0], 200)
            self.assertEqual(req("PUT", f"/api/runs/{body['run_id']}/files?zone=data&path=../x.csv", {}, {"X-MeasureTrace": "1"})[0], 400)
        finally:
            httpd.shutdown()


class Cli(unittest.TestCase):
    def test_cli_ingest_and_status(self):
        import io
        from contextlib import redirect_stdout
        import cli
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.assertEqual(cli.main(["new", "cli", "--data", str(SAMPLES / "annealing_demo" / "data")]), 0)
            self.assertEqual(cli.main(["status"]), 0)
        self.assertIn("RAW_DATA: 20개", buf.getvalue())
        self.assertIn("최종 보고서 초안: 0개", buf.getvalue())
        self.assertIn("PROCESSED 데이터 1개 — 사용하지 않음", buf.getvalue())


if __name__ == "__main__":
    unittest.main()
