"""계획서 수식(2-1b, docx_equations) ↔ 파이프라인 연결 시험 — 가짜 LLM(토큰 0).

2 EXTRACT 2-1b 가 Word 계획서의 수식을 LaTeX 로 바꿔 extract/equations.json 에 남기고(파이썬, LLM 없음),
2-1a·2-1c 는 식 자리에 LaTeX 가 들어간 계획서 글을 받으며, 변환 실패한 식은 3-1 에서 연구자가 직접 적는다.

  python -m unittest tests.test_equations_pipeline -v
"""
from __future__ import annotations

import os
import shutil
import stat
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]

import make_eq_docx as mk  # noqa: E402
from fake_llm import FakeClient  # noqa: E402
from mtagent import lineage, store  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import confirm, extract, ingest  # noqa: E402

SAMPLES = ROOT / "samples"
TMP = Path(tempfile.mkdtemp(prefix="mt_eqpipe_"))
_OLD_WS = None


def setUpModule():            # 이 모듈만 자기 작업 폴더 — 다른 시험 모듈의 설정을 건드리지 않는다
    global _OLD_WS
    _OLD_WS = os.environ.get("MT_WORKSPACE")
    os.environ["MT_WORKSPACE"] = str(TMP / "ws")


def tearDownModule():
    if _OLD_WS is None:
        os.environ.pop("MT_WORKSPACE", None)
    else:
        os.environ["MT_WORKSPACE"] = _OLD_WS
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def llm(tag: str, client=None) -> LLM:
    return LLM(client=client or FakeClient(), model=f"fake-eqpipe-{tag}")


def new_run(project: str, folder: Path) -> str:
    rid = store.new_run(project)
    store.add_folder(rid, "data", folder / "data")
    if (folder / "report").exists():
        store.add_folder(rid, "report", folder / "report")
    return rid


def copy_sample(name: str) -> Path:
    src = TMP / name
    shutil.copytree(SAMPLES / "annealing_demo", src)
    for p in src.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    return src


class Equations(unittest.TestCase):
    def test_2_1b_converts_plan_equations_with_python(self):
        client = FakeClient()
        rid = new_run("eq", SAMPLES / "annealing_demo")
        ing = ingest.run(rid)
        self.assertNotIn("equations", ing)                                      # 1 INGEST 는 수식을 다루지 않음
        extract.run(rid, llm("eq", client))
        eq = store.read(rid, "extract/equations.json")
        plan = next(x for x in ing["files"] if x["path"] == "research_plan.docx")
        self.assertEqual((eq["converter"], eq["failed"]), ("dwml.omml.oMath2Latex", []))
        self.assertEqual([e["id"] for e in eq["equations"]], [f"EQ{i:02d}" for i in range(1, 9)])
        self.assertTrue(all(e["plan_sha256"] == plan["sha256"] for e in eq["equations"]))  # 계획서 해시와 함께
        self.assertTrue(eq["equations"][0]["latex"].startswith(r"G_{ij}=\frac{\sum_{k=1}^{11}"))
        self.assertTrue(all(e["omml_sha256"] and e["context"] for e in eq["equations"]))
        b = store.read(rid, "extract/research.json")                             # 2-1c 는 2-1b 의 LaTeX 를 그대로
        self.assertEqual([(e["id"], e["latex"]) for e in b["equations"]], [(e["id"], e["latex"]) for e in eq["equations"]])
        a = next(c for c in client.calls if c["task"] == "2-1a")
        self.assertIn("[EQ01] $ G_{ij}=", a["user"])
        self.assertFalse(any(c["task"] == "2-1b" for c in client.calls))         # 2-1b 는 LLM 을 부르지 않음
        self.assertIn("2 EXTRACT 2-1b equations", {e["stage"] for e in lineage.entries(rid)})

    def test_non_docx_plan_is_noted(self):
        src = copy_sample("txtplan")
        (src / "data/research_plan.docx").unlink()
        (src / "data/research_plan.md").write_text("# 연구 계획\n실험 설계와 계산식\n", encoding="utf-8")
        rid = new_run("txt", src)
        out = ingest.run(rid)
        self.assertTrue(any("research_plan.md" in x["text"] and "E06(식 없음)" in x["text"] for x in out["findings"]))
        extract.run(rid, llm("txt"))
        eq = store.read(rid, "extract/equations.json")
        self.assertEqual(eq["equations"], [])
        self.assertTrue(any("research_plan.md" in n for n in eq["notes"]))

    def test_failed_equation_is_asked_and_researcher_latex_is_confirmed(self):
        src = copy_sample("broken")
        eqs = mk.equations()
        eqs[1] = (eqs[1][0], mk.omath(mk.sub(mk.r("R"), mk.r("ij")), mk.r("="),
                                      mk.frac(mk.r("1"), mk.sub(mk.r("G"), mk.r("ij")), pr=False)))   # m:fPr 없음
        mk.write_docx(src / "data/research_plan.docx", mk.default_paragraphs(eqs))
        rid = new_run("broken", src)
        ingest.run(rid)
        extract.run(rid, llm("broken"))
        eq = store.read(rid, "extract/equations.json")
        self.assertEqual(eq["failed"], ["EQ02"])
        b = {e["id"]: e for e in store.read(rid, "extract/research.json")["equations"]}
        self.assertEqual((b["EQ02"]["status"], b["EQ02"]["latex"]), ("failed", None))
        self.assertTrue(b["EQ02"]["error"].startswith("KeyError"))

        v = confirm.start(rid)
        item = next(i for i in v["items"] if i["id"] == "3-1:eq:EQ02")
        self.assertEqual([c["value"] for c in item["choices"]], ["manual"])
        self.assertEqual(item["proposal"]["latex"], "(변환 실패 — 원문 확인 필요)")
        ans = {}
        for i in v["items"]:
            if i["required"] and i["status"] == "pending":
                vals = [c["value"] for c in i["choices"]]
                ans[i["id"]] = {"choice": "yes" if "yes" in vals else "proceed" if "proceed" in vals else vals[0]}
        ans["3-1:eq:EQ02"] = {"choice": "manual", "text": r"R_{ij}=\frac{1}{G_{ij}}"}
        v = confirm.submit(rid, "tester", ans)
        self.assertEqual(v["status"], "complete")
        eq = {e["id"]: e for e in v["confirmed"]["equations"]}
        self.assertEqual((eq["EQ02"]["latex"], eq["EQ02"]["status"], eq["EQ02"]["latex_source"]),
                         (r"R_{ij}=\frac{1}{G_{ij}}", "manual", "researcher"))
        self.assertEqual(eq["EQ01"]["latex_source"], "dwml.omml.oMath2Latex")
        self.assertTrue(any("EQ02" in x for x in confirm.load(rid)["feedback"]["2-1"]))


if __name__ == "__main__":
    unittest.main()
