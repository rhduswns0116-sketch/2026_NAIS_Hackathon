"""뒷단(4 RECOMPUTE · 5 VALIDATE · 6 AUDIT) 재점검 시험 — 가짜 LLM, 토큰 0.

  python -m unittest tests.test_back_review -v
"""
from __future__ import annotations

import os
import shutil
import stat
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]

from fake_llm import FakeClient  # noqa: E402
from mtagent import store  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import audit, confirm, extract, ingest, recompute, validate  # noqa: E402

SAMPLES = ROOT / "samples"
TMP = Path(tempfile.mkdtemp(prefix="mt_back_"))
_OLD_WS = None


def setUpModule():            # 이 모듈만 자기 작업 폴더 — 다른 시험 모듈의 설정을 건드리지 않는다
    global _OLD_WS
    _OLD_WS = os.environ.get("MT_WORKSPACE")
    os.environ["MT_WORKSPACE"] = str(TMP / "ws")


def tearDownModule():
    if _OLD_WS is None:
        os.environ.pop("MT_WORKSPACE", None)
    else:
        os.environ["MT_WORKSPACE"] = _OLD_WS
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def until_recompute(project: str, tag: str) -> str:
    rid = store.new_run(project)
    store.add_folder(rid, "data", SAMPLES / "annealing_demo" / "data")
    store.add_folder(rid, "report", SAMPLES / "annealing_demo" / "report")
    ingest.run(rid)
    extract.run(rid, LLM(client=FakeClient(), model=f"fake-back-{tag}"))
    v = confirm.start(rid)
    ans = {}
    for i in v["items"]:
        if i["required"]:
            vals = [c["value"] for c in i["choices"]]
            ans[i["id"]] = {"choice": "yes" if "yes" in vals else "proceed" if "proceed" in vals else vals[0]}
    confirm.submit(rid, "tester", ans)
    recompute.run(rid)
    return rid


class ValidateCache(unittest.TestCase):
    def test_rejected_5_1_reply_is_not_reused_from_cache(self):
        """문장 ID 가 빠진 5-1 응답으로 멈춘 뒤, 다시 실행하면 캐시가 아니라 LLM 에 다시 묻는다(영영 막히지 않음)."""
        rid = until_recompute("cache-gap", "cache")
        bad = FakeClient({"5-1": lambda user: {"sentences": []}})
        with self.assertRaisesRegex(ValueError, "문장 ID 불일치.*캐시에서 지웠"):
            validate.run(rid, LLM(client=bad, model="fake-back-cache"))
        good = FakeClient()
        out = validate.run(rid, LLM(client=good, model="fake-back-cache"))       # 같은 모델 이름 — 같은 캐시 열쇠
        self.assertEqual([c["task"] for c in good.calls], ["5-1"])                # 캐시가 아니라 다시 물음
        self.assertEqual((out["summary"]["Supported"], out["summary"]["Unsupported"]), (12, 0))
        self.assertTrue(audit.run(rid)["supported"])


if __name__ == "__main__":
    unittest.main()
