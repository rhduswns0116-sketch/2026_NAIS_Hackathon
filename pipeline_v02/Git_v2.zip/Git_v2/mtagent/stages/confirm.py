"""3 CONFIRM — LLM 이 잘 읽었는지 사람이 확인하는 단계. 승인값 반영은 파이썬.

3-1 데이터 해석 승인   2-1(RAW·PROCESSED 데이터 내용·식·가공 순서·설계·검정·매칭·계산 코드) + 2-4(누락)
                       실험 ↔ 데이터 ↔ 식 ↔ 장비 관계는 도식(Mermaid·글)으로도 보여 준다(confirm/relation_diagram.md)
                       아니오 → 고칠 내용을 받아 2 EXTRACT 2-1(a부터) 다시 → 제안이 바뀐 항목만 다시 물음
3-2 분석 범위 확정     2-2 장비 사양(범위·정확도·범위 밖 표시값·동작 조건)   아니오 → 고칠 내용을 받아 2-2(와 2-3) 다시
3-3 측정 기준 승인     측정 정의(열 역할·단위) 고정 · 단위 누락/모호 → 제안 중 고르거나 직접 입력 · 측정 시각(장비 기록 우선)
                       결측치/이상치 → 맞음(그대로 진행, 기록) 또는 아니오 → 파일을 고쳐 다시 올림(1 INGEST 부터 새 실행)
피드백은 최대 3회 — 그 뒤에도 '아니오'인 항목은 미확정으로 넘기고, 그 항목에 기대는 주장은 5단계에서 E06.
"""
from __future__ import annotations

import os
import stat
import sys

from mtagent import config, lineage, store, units
from mtagent.llm import LLM
from mtagent.stages import extract
from mtagent.util import now, sha_obj, sha_text, write_json

YES = {"value": "yes", "label": "맞음"}
NO = {"value": "no", "label": "수정 필요 — 고칠 내용을 적어 주세요", "needs_text": True}
DATA_ISSUE_LABEL = {"missing_value": "결측치", "non_numeric": "숫자가 아닌 값", "out_of_spec": "이상치 (장비 사양 범위 밖)",
                    "overflow": "장비의 범위 밖 표시값"}


def _item(iid, group, title, question, proposal, choices, required=True, target="*", part=None) -> dict:
    return {"id": iid, "group": group, "title": title, "question": question, "proposal": proposal,
            "proposal_hash": sha_obj(proposal)[:16], "choices": choices, "required": required, "target": target,
            "part": part, "status": "pending", "answer": None, "history": []}


def _label(text, limit: int = 60) -> str:
    t = " ".join(str(text or "—").split()).replace('"', "'")
    return t if len(t) <= limit else t[:limit - 1] + "…"


def relation_diagram(research: dict) -> dict:
    """실험 ↔ 데이터 ↔ 식 ↔ 장비 → 결과 — Mermaid 흐름도와 글 도식."""
    lines, text = ["flowchart LR"], []
    for k, m in enumerate(research.get("matching") or [], 1):
        cols = ", ".join(m.get("data_columns") or []) or "—"
        eqs = ", ".join(m.get("equation_ids") or []) or "—"
        inst = " · ".join(x for x in (m.get("instrument"), m.get("instrument_range")) if x) or "—"
        lines += [f'  X{k}["실험: {_label(m.get("experiment"))}"] --> D{k}["데이터: {_label(cols)}"]',
                  f'  I{k}["장비: {_label(inst)}"] -. 측정 .-> D{k}',
                  f'  D{k} --> E{k}["식: {_label(eqs)}"]',
                  f'  E{k} --> R{k}["결과: {_label(m.get("results"))}"]']
        text.append(f"[{k}] 실험 「{m.get('experiment') or '—'}」\n"
                    f"     ├─ 장비  {inst}\n"
                    f"     ├─ 데이터 {cols}\n"
                    f"     ├─ 식    {eqs}\n"
                    f"     └─ 결과  {m.get('results') or '—'}")
    return {"mermaid": "\n".join(lines), "text": "\n".join(text)}


def _write_diagram(rid: str) -> None:
    b = extract.view(rid).get("2-1b") or {}
    d = relation_diagram(b)
    md = ("# 실험 ↔ 데이터 ↔ 식 ↔ 장비\n\n3 CONFIRM 3-1 에서 확인할 관계 (2-1b 추출 결과, 확인 전).\n\n"
          "```mermaid\n" + d["mermaid"] + "\n```\n\n```\n" + d["text"] + "\n```\n")
    path = store.out_dir(rid) / "confirm" / "relation_diagram.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(md, encoding="utf-8")


def build_items(rid: str) -> list[dict]:
    v = extract.view(rid)
    a, b, c, sp, st, m = (v.get(k) or {} for k in ("2-1a", "2-1b", "2-1c", "2-2", "2-3", "2-4"))
    items = []
    # 3-1 데이터 해석 승인
    for g in a.get("groups", []):
        kind = "RAW" if g.get("category", "raw") == "raw" else "PROCESSED"
        items.append(_item(f"3-1:data:{g['group_id']}", "3-1", f"{kind} 데이터 내용 {g['group_id']} ({len(g['files'])}개 파일)",
                           "이 데이터 파일들이 이런 내용이 맞나요?",
                           {"summary": g["analysis"]["summary"], "files": g["files"][:10], "n_files": len(g["files"]),
                            "columns": g["analysis"]["columns"]}, [YES, NO], part="2-1"))
    for e in b.get("equations", []):
        items.append(_item(f"3-1:eq:{e['id']}", "3-1", f"식 {e['id']}", "이 수식을 이렇게 읽고, 이 뜻으로 계산에 쓰는 게 맞나요?",
                           {k: e.get(k) for k in ("latex", "context", "meaning", "role", "variables")}, [YES, NO],
                           target=f"eq:{e['id']}", part="2-1"))
    if b:
        items.append(_item("3-1:steps", "3-1", "계산 과정 (raw → 보고값)", "RAW 를 이 순서로 가공·계산하는 게 맞나요?",
                           {"steps": b.get("steps", [])}, [YES, NO], part="2-1"))
        items.append(_item("3-1:design", "3-1", "실험 설계 · 검정 방법",
                           "조건·시료·독립 단위·반복 수와 검정 방법을 이렇게 읽었습니다. 맞나요?",
                           {"design": b.get("design"), "test": b.get("test"), "outputs": b.get("outputs")}, [YES, NO], part="2-1"))
        items.append(_item("3-1:matching", "3-1", "실험 — 데이터 — 식 — 장비",
                           "이 실험에서 이 장비로 이 측정값을 확인했고, 이 식으로 계산하는 게 맞나요? "
                           "(관계 도식: confirm/relation_diagram.md)",
                           {"matching": b.get("matching", []), "diagram": relation_diagram(b)}, [YES, NO], part="2-1"))
    if c:
        items.append(_item("3-1:code", "3-1", "계산 코드", "위 식·계산 과정을 이 코드로 계산합니다. 승인하면 코드 해시를 고정하고 "
                           "4 RECOMPUTE 에서만 격리 실행합니다.",
                           {"sha256": c.get("sha256"), "code": c.get("code"), "explanation": c.get("explanation"),
                            "assumptions": c.get("assumptions"), "static_problems": c.get("static_problems")},
                           [YES, NO] if not c.get("static_problems") else [NO], target="code", part="2-1"))
    if m:
        miss = m.get("missing") or []
        prop = {"required": {k: (m.get("required") or {}).get(k) for k in ("conditions", "replicates", "points_per_replicate",
                                                                         "rows_per_file", "file_rule")},
                "missing": miss, "extra_samples": m.get("extra_samples")}
        if miss:
            items.append(_item("3-1:missing", "3-1", f"누락 데이터 {len(miss)}건",
                               "계획서가 요구하는 데이터 중 빠진 것이 있습니다. 어떻게 할까요?", prop,
                               [{"value": "proceed", "label": "그대로 진행 — 누락을 기록하고, 이 데이터에 기대는 주장은 E03"},
                                {"value": "reupload", "label": "파일을 보완해 다시 올리기 (1 INGEST 부터 새 실행)"},
                                {"value": "no", "label": "누락 판단이 틀림 — 고칠 내용을 적어 주세요", "needs_text": True}], part="2-4"))
        else:
            items.append(_item("3-1:missing", "3-1", "누락 점검", "계획서가 요구하는 데이터가 모두 있습니다. 맞나요?", prop,
                               [YES, NO], part="2-4"))
    # 3-2 분석 범위 확정
    for f in sp.get("files", []):
        for r in f.get("ranges", []):
            items.append(_item(f"3-2:{r['id']}", "3-2", f"{r['quantity']} · {r.get('range_name') or ''}".strip(" ·"),
                               f"장비 사양서 {r['page']}쪽을 읽어 보니 이 범위의 유효 판독값은 {r.get('min')} ~ {r.get('max')} "
                               f"{r['unit']}, 정확도 {r.get('accuracy') or '—'} 입니다. 맞나요?",
                               {**{k: r.get(k) for k in ("quantity", "range_name", "min", "max", "unit", "accuracy", "resolution",
                                                         "page", "quote", "verified", "problems")}, "file": f["file"]},
                               [YES, NO], target="spec", part="2-2"))
        for c in f.get("conditions", []):
            items.append(_item(f"3-2:{c.get('id') or c['name']}", "3-2", f"측정 조건 · {c['name']}",
                               f"장비 사양서 {c.get('page')}쪽을 읽어 보니 측정 조건 '{c['name']}' 은 {c.get('value')} 입니다. 맞나요?",
                               {**{k: c.get(k) for k in ("name", "value", "page", "quote", "verified", "problems")},
                                "file": f["file"]}, [YES, NO], target="spec", part="2-2"))
        if f.get("overflow_value") is not None:
            items.append(_item(f"3-2:overflow:{f['file']}", "3-2", f"범위 밖 표시값 {f['overflow_value']:g}",
                               "범위 밖 측정은 이 값으로 기록된다고 읽었습니다. 맞나요?",
                               {"value": f["overflow_value"], "quote": f.get("overflow_quote"), "verified": f.get("overflow_verified"),
                                "file": f["file"]}, [YES, NO], target="spec", part="2-2"))
    # 3-3 측정 기준 승인
    cols = [x for x in st.get("columns", []) if x.get("unit_status")]
    if cols:
        items.append(_item("3-3:definition", "3-3", "측정 정의 (열의 역할·단위)",
                           "측정값·독립변수 열의 뜻과 단위를 이렇게 정의해 고정합니다. 맞나요? (단위 누락·모호는 아래에서 따로 고릅니다)",
                           {"columns": [{k: x.get(k) for k in ("column", "role", "unit", "unit_status", "header_unit",
                                                                "spec_range", "spec_note")} for x in cols]},
                           [YES, NO], part="2-1"))
    for x in cols:
        if x["unit_status"] != "ok":
            opts = [{"value": f"unit:{u}", "label": f"{u}"} for u in x.get("suggestions") or []]
            opts.append({"value": "other", "label": "기타 — 단위를 직접 입력", "needs_text": True})
            items.append(_item(f"3-3:unit:{x['column']}", "3-3",
                               f"단위 {'누락' if x['unit_status'] == 'missing' else '모호'}: {x['column']}",
                               "이 열의 단위를 골라 주세요.", {k: x.get(k) for k in ("column", "header_unit", "llm_unit",
                                                                                   "llm_unit_source", "suggestions")},
                               opts, target=f"unit:{x['column']}"))
    for iss in st.get("issues", []):
        if iss["kind"] in DATA_ISSUE_LABEL:
            items.append(_item(f"3-3:data:{iss['id']}", "3-3", f"{DATA_ISSUE_LABEL[iss['kind']]}: {iss['file']} · {iss['column']}",
                               f"{iss['file']} 의 {iss['column']} 열에서 {iss['detail']} — 줄 번호와 값을 확인해 주세요. 이 값이 맞나요?",
                               iss, [{"value": "proceed", "label": "값이 맞음 — 그대로 진행 (기록: E02)"},
                                     {"value": "reupload", "label": "아니오 — 파일을 고쳐 다시 올리기 (1 INGEST 부터 새 실행)"}],
                               target=f"data:{iss['file']}"))
    times = [(x["path"], x["measured_at"], (x.get("times") or {}).get("file_mtime"))
             for x in (store.read(rid, "ingest.json") or {}).get("files", [])
             if x.get("measured_at") and x["zone"] == "data"]
    if times:
        items.append(_item("3-3:times", "3-3", "측정 시각",
                           "파일마다 측정 시각을 이렇게 정했습니다 — 장비가 기록한 시각을 우선하고, 없으면 파일 수정 시각"
                           "(복사만 해도 바뀔 수 있음)을 썼습니다. 맞나요?",
                           {"files": [{"file": f, **t, "file_mtime": m and m["value"]} for f, t, m in times]},
                           [YES, NO], required=True, part=None))
    # 참고 질문 (선택)
    for i, q in enumerate((v.get("summary") or {}).get("questions", [])):
        part = "2-2" if q["source"].startswith("2-2") else "2-4" if q["source"].startswith("2-4") else "2-1"
        items.append(_item(f"Q:{sha_text(q['source'] + q['text'])[:10]}", "Q", q["source"], q["text"], {"question": q},
                           [{"value": "skip", "label": "넘어가기"},
                            {"value": "answer", "label": "답하고 반영 (해당 추출을 다시 함)", "needs_text": True}],
                           required=False, part=part))
    return items


def _state_path(rid: str):
    return store.out_dir(rid) / "confirm" / "confirm_state.json"


def load(rid: str) -> dict:
    s = store.read(rid, "confirm/confirm_state.json")
    if s is None:
        raise ValueError("3 CONFIRM 을 시작하지 않음")
    return s


def _save(rid: str, s: dict) -> dict:
    write_json(_state_path(rid), s)
    return s


def start(rid: str) -> dict:
    store.require(rid, "extract")
    if store.stage_status(rid, "confirm"):
        return view(rid)
    summary = store.read(rid, "extract/summary.json") or {}
    if summary.get("errors"):
        raise ValueError(f"2 EXTRACT 에 실패한 과업이 있음 {list(summary['errors'])} — 2 EXTRACT 를 다시 실행")
    s = {"run_id": rid, "round": 1, "status": "open", "started_at": now(), "items": build_items(rid),
         "feedback": {}, "overrides": {"units": {}}, "log": []}
    _write_diagram(rid)
    _save(rid, s)
    store.mark(rid, "confirm", "open", round=1)
    return view(rid)


def view(rid: str) -> dict:
    s = load(rid)
    items = s["items"]
    pending = [i for i in items if i["required"] and i["status"] == "pending"]
    return {**s, "counts": {"total": len(items), "pending_required": len(pending),
                            "by_status": {st: sum(1 for i in items if i["status"] == st) for st in
                                          {i["status"] for i in items}}},
            "max_rounds": config.CONFIRM_MAX_ROUNDS, "confirmed": store.read(rid, "confirm/confirmed.json")}


def _validate(item: dict, ans: dict) -> str | None:
    choice = (ans or {}).get("choice")
    opt = next((c for c in item["choices"] if c["value"] == choice), None)
    if opt is None:
        return f"{item['title']}: 고를 수 없는 답 {choice!r}"
    text = (ans.get("text") or "").strip()
    if opt.get("needs_text") and not text:
        return f"{item['title']}: 내용을 적어야 함"
    if item["id"].startswith("3-3:unit:") and choice == "other" and units.parse(text) is None:
        return f"{item['title']}: 단위 '{text}' 를 해석할 수 없음 (예: A, nA, V, nS)"
    return None


def submit(rid: str, respondent: str, answers: dict, llm: LLM | None = None) -> dict:
    respondent = (respondent or "").strip()
    if not respondent:
        raise ValueError("확인한 사람 이름이 필요함")
    s = load(rid)
    if s["status"] != "open":
        raise ValueError(f"CONFIRM 이 이미 끝남 ({s['status']})")
    by_id = {i["id"]: i for i in s["items"]}
    errors = []
    for iid, ans in (answers or {}).items():
        it = by_id.get(iid)
        if it is None or it["status"] not in ("pending",):
            continue
        err = _validate(it, ans)
        if err:
            errors.append(err)
    if errors:
        raise ValueError("; ".join(errors))
    at = now()
    for iid, ans in (answers or {}).items():
        it = by_id.get(iid)
        if it is None or it["status"] != "pending":
            continue
        choice, text = ans["choice"], (ans.get("text") or "").strip()
        it["answer"] = {"choice": choice, "text": text, "respondent": respondent, "at": at, "round": s["round"]}
        it["history"].append(it["answer"])
        if choice in ("yes", "skip"):
            it["status"] = "approved"
        elif choice == "proceed":
            it["status"] = "decided"
        elif choice == "reupload":
            it["status"] = "reupload"
        elif choice in ("no", "answer"):
            it["status"] = "rejected" if choice == "no" else "answered"
        elif choice.startswith("unit:") or choice == "other":
            unit = choice[5:] if choice.startswith("unit:") else units.normalize(text)
            s["overrides"]["units"][it["proposal"]["column"]] = unit
            it["status"] = "decided"
    s["log"].append({"at": at, "respondent": respondent, "round": s["round"], "answered": sorted(answers or {})})
    if any(i["status"] == "reupload" for i in s["items"]):
        s["status"] = "restart_required"
        s["restart_reason"] = [i["title"] for i in s["items"] if i["status"] == "reupload"]
        _save(rid, s)
        store.mark(rid, "confirm", "restart_required")
        return view(rid)
    if any(i["required"] and i["status"] == "pending" for i in s["items"]):
        _save(rid, s)
        return view(rid)
    to_fix = [i for i in s["items"] if i["status"] in ("rejected", "answered")]
    if to_fix and s["round"] < config.CONFIRM_MAX_ROUNDS:
        return _next_round(rid, s, to_fix, llm)
    for i in to_fix:            # 3회 뒤에도 '아니오' → 미확정
        if i["status"] == "rejected":
            i["status"] = "unresolved"
        else:
            i["status"] = "approved"
    return _complete(rid, s, respondent)


def _next_round(rid: str, s: dict, to_fix: list[dict], llm: LLM | None) -> dict:
    parts = set()
    for i in to_fix:
        part = i.get("part") or "2-1"
        parts.add(part)
        s["feedback"].setdefault(part, []).append(f"[{i['title']}] {i['answer']['text']}")
    run_parts = set(parts)
    if "2-1" in run_parts or "2-2" in run_parts:
        run_parts.add("2-3")
    extract.run(rid, llm, parts=run_parts, feedback=s["feedback"], from_confirm=True)
    old = {i["id"]: i for i in s["items"]}
    new_items = build_items(rid)
    for it in new_items:
        o = old.get(it["id"])
        if o is None:
            continue
        it["history"] = o["history"]
        if o["proposal_hash"] == it["proposal_hash"] and o["status"] in ("approved", "decided"):
            it["status"], it["answer"] = o["status"], o["answer"]
            it["carried"] = True
        elif o["proposal_hash"] != it["proposal_hash"]:
            it["changed_from"] = o["proposal_hash"]
        elif o["status"] in ("rejected", "answered") and it["group"] == "Q":
            it["status"], it["answer"] = "approved", o["answer"]
    s["items"] = new_items
    s["round"] += 1
    _write_diagram(rid)
    s["log"].append({"at": now(), "event": f"{s['round']}회차 — 2 EXTRACT {sorted(run_parts)} 다시 실행",
                     "feedback_parts": sorted(parts)})
    errs = (store.read(rid, "extract/summary.json") or {}).get("errors")
    if errs:
        s["extract_errors"] = errs
    _save(rid, s)
    store.mark(rid, "confirm", "open", round=s["round"])
    return view(rid)


def _complete(rid: str, s: dict, respondent: str) -> dict:
    v = extract.view(rid)
    a, b, c, sp, st, m = (v.get(k) or {} for k in ("2-1a", "2-1b", "2-1c", "2-2", "2-3", "2-4"))
    items = {i["id"]: i for i in s["items"]}
    unresolved = [i for i in s["items"] if i["status"] == "unresolved"]
    cdir = store.out_dir(rid) / "confirm"
    code = None
    code_item = items.get("3-1:code")
    if code_item and code_item["status"] == "approved" and c.get("code"):
        path = cdir / "approved_code.py"
        if path.exists():
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
        path.write_text(c["code"], encoding="utf-8", newline="\n")
        os.chmod(path, stat.S_IREAD)
        code = {"path": "confirm/approved_code.py", "sha256": sha_text(c["code"]),
                "approved_by": code_item["answer"]["respondent"], "approved_at": code_item["answer"]["at"]}
    overrides = s["overrides"]["units"]
    registry = []
    for x in st.get("columns", []):
        registry.append({**{k: x.get(k) for k in ("group_id", "column", "role", "numeric", "spec_range")},
                         "unit": overrides.get(x["column"], x.get("unit")),
                         "unit_decided": x["column"] in overrides})
    spec_ok = [r for f in sp.get("files", []) for r in f.get("ranges", [])
               if items.get(f"3-2:{r['id']}", {}).get("status") == "approved"]
    data_flags = [{"code": "E02", **{k: i["proposal"][k] for k in ("kind", "file", "column", "count", "rows", "detail")},
                   "decision": "proceed", "decided_by": i["answer"]["respondent"]}
                  for i in s["items"] if i["id"].startswith("3-3:data:") and i["status"] == "decided"]
    missing = [{"code": "E03", **x} for x in (m.get("missing") or [])] \
        if items.get("3-1:missing", {}).get("status") in ("decided", "approved") else []
    conf = {"run_id": rid, "project": store.state(rid)["project"], "confirmed_at": now(), "round": s["round"],
            "respondents": sorted({l["respondent"] for l in s["log"] if l.get("respondent")}),
            "extract_hash": (v.get("summary") or {}).get("hash"),
            "columns": registry, "equations": b.get("equations", []), "steps": b.get("steps", []),
            "design": b.get("design", {}), "test": b.get("test", {}), "matching": b.get("matching", []),
            "outputs": b.get("outputs", []), "code": code,
            "spec": {"ranges": spec_ok, "overflow_values": sp.get("overflow_values", []),
                     "conditions": [c for f in sp.get("files", []) for c in f.get("conditions", [])
                                    if items.get(f"3-2:{c.get('id') or c['name']}", {}).get("status") == "approved"]},
            "data_flags": data_flags, "missing": missing,
            "measurement_times": items.get("3-3:times", {}).get("proposal") if items.get("3-3:times", {}).get("status") == "approved" else None,
            "pending": [{"item": i["id"], "title": i["title"], "target": i["target"]} for i in unresolved],
            "notes": [{"q": i["question"], "a": i["answer"]["text"]} for i in s["items"]
                      if i["group"] == "Q" and i.get("answer") and i["answer"].get("text")]}
    if code is None and not any(p["target"] == "code" for p in conf["pending"]):
        conf["pending"].append({"item": "3-1:code", "title": "계산 코드가 승인되지 않음", "target": "code"})
    conf["hash"] = sha_obj(conf)
    path = write_json(cdir / "confirmed.json", conf)
    s["status"] = "complete"
    s["completed_at"] = conf["confirmed_at"]
    _save(rid, s)
    lineage.record("3 CONFIRM", rid, conf["extract_hash"] or "", lineage.code_version(sys.modules[__name__]),
                   {"round": s["round"], "respondent": respondent, "pending": len(conf["pending"])},
                   [path] + ([cdir / "approved_code.py"] if code else []))
    store.mark(rid, "confirm", "done", round=s["round"], pending=len(conf["pending"]))
    return view(rid)
