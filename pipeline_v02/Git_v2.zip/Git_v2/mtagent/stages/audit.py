"""6 AUDIT — 처리는 앞에서 끝났고, 여기서는 결과를 모아 보여 준다(LLM 없음).

6-1 Validate 결과 출력   Supported · Unsupported 주장마다 보고서 문장(쪽·문장 번호)과 재계산 비교, 오류 코드와 근거
                         + 재계산 결과·계산 로그 요약(데이터 해시 2종·결과 해시)·PROCESSED 대조
6-3 수정 후 재평가       같은 프로젝트의 이전 감사와 주장별로 짝지어 수정 전·후 판정을 비교(고쳐짐·나빠짐·그대로·새 주장·사라짐)
판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것이다.
"""
from __future__ import annotations

import re
import sys

from mtagent import codes, lineage, store
from mtagent.util import now, write_json

DISCLAIMER = ("판정은 과학적 진실이 아니라 '제출된 자료(RAW·PROCESSED·계획서·사양서)가 이 주장을 지지하는가'에 대한 것이다. "
              "계산식의 과학적 타당성, 그림, 외부 문헌 수치, 데이터 조작 여부는 판정하지 않는다.")


def _key(c: dict) -> str:
    """주장 짝짓기 — 문장·주장 원문·종류·(조건별 주장이면) 집단. 재계산 항목 id 는 LLM 이 실행마다 다르게 지을 수 있어 쓰지 않는다."""
    norm = lambda x: re.sub(r"\s+", "", x or "")  # noqa: E731
    groups = ",".join(sorted(str(g) for g in c.get("groups") or []))
    return "|".join((norm(c["sentence"]), norm(c["claim"].get("text")), c["claim"].get("type") or "", groups))


def _reeval(rid: str, claims: list[dict]) -> dict:
    prev = store.previous_run(rid, "audit")
    if not prev:
        return {"previous_run": None, "note": "같은 프로젝트의 이전 감사 없음 — 보고서를 고쳐 같은 프로젝트 이름으로 다시 돌리면 수정 전·후를 비교"}
    old = {_key(c): c for c in (store.read(prev, "validate.json") or {}).get("claims", [])}
    new = {_key(c): c for c in claims}
    # 2차 짝짓기 — 원문 자른 범위만 다른 주장: 같은 문장·종류·집단에 남은 것이 하나씩이면 짝
    loose = lambda c: "|".join(_key(c).split("|")[i] for i in (0, 2, 3))  # noqa: E731
    lo = {}
    for k in [k for k in old if k not in new]:
        lo.setdefault(loose(old[k]), []).append(k)
    ln = {}
    for k in [k for k in new if k not in old]:
        ln.setdefault(loose(new[k]), []).append(k)
    for lk, oks in lo.items():
        if len(oks) == 1 and len(ln.get(lk, [])) == 1:
            new[oks[0]] = new.pop(ln[lk][0])
    rows = []
    for k in list(old) + [k for k in new if k not in old]:
        o, n = old.get(k), new.get(k)
        before, after = (o or {}).get("verdict"), (n or {}).get("verdict")
        change = ("새 주장" if o is None else "사라짐" if n is None else "그대로" if before == after
                  else "고쳐짐" if after == "Supported" else "나빠짐")
        c = n or o
        rows.append({"change": change, "sentence": c["sentence"], "claim": c["claim"].get("text"), "before": before,
                     "after": after, "codes_before": sorted({x["code"] for x in (o or {}).get("codes", [])}),
                     "codes_after": sorted({x["code"] for x in (n or {}).get("codes", [])}),
                     "shown_before": (o or {}).get("shown"), "shown_after": (n or {}).get("shown")})
    counts = {}
    for r in rows:
        counts[r["change"]] = counts.get(r["change"], 0) + 1
    calc = store.read(rid, "recompute/calc_log.json") or {}
    return {"previous_run": prev, "counts": counts, "rows": rows,
            "data_changes": (calc.get("e07") or {}).get("changes") if (calc.get("e07") or {}).get("compared_with") == prev else None}


def run(rid: str) -> dict:
    store.require(rid, "validate")
    v = store.read(rid, "validate.json")
    calc = store.read(rid, "recompute/calc_log.json")
    conf = store.read(rid, "confirm/confirmed.json")
    claims = v["claims"]
    out = {"stage": "6 AUDIT", "run_id": rid, "project": conf["project"], "at": now(), "disclaimer": DISCLAIMER,
           "summary": v["summary"], "blind": v["blind"], "report": v["report"],
           "supported": [c for c in claims if c["verdict"] == "Supported"],
           "unsupported": [c for c in claims if c["verdict"] == "Unsupported"],
           "not_checked": v["non_target"], "code_names": codes.NAMES,
           "recompute": {k: calc.get(k) for k in ("status", "reason", "result_hash", "input_hash", "content_input_hash",
                                                   "finished_at", "env", "processed_check")}
           | {"results": [{k: r.get(k) for k in ("id", "name", "value", "unit", "condition", "kind", "equation_id")}
                          for r in calc.get("results") or []]},
           "confirm": {k: conf.get(k) for k in ("hash", "round", "respondents", "pending", "missing", "data_flags")},
           "reevaluation": _reeval(rid, claims)}
    out["report_md"] = "audit_report.md"
    p = write_json(store.out_dir(rid) / "audit.json", out)
    md = store.out_dir(rid) / "audit_report.md"
    md.write_text(markdown(out), encoding="utf-8")
    lineage.record("6 AUDIT", rid, (store.read(rid, "ingest.json") or {}).get("input_hash", ""),
                   lineage.code_version(sys.modules[__name__]), {"previous_run": out["reevaluation"]["previous_run"]}, [p, md])
    s = store.state(rid)
    s["summary"] = f"S{v['summary']['Supported']}·U{v['summary']['Unsupported']}"
    store.save_state(rid, s)
    store.mark(rid, "audit", "done")
    return out


def _row(c: dict) -> str:
    cs = ", ".join(f"{x['code']}" + ("(기록)" if x["effect"] == "기록" else "") for x in c["codes"]) or "—"
    esc = lambda x: str(x if x is not None else "—").replace("|", "\\|")  # noqa: E731
    return (f"| p.{c['page']} 문장 {c['no']} | {esc(c['claim'].get('text'))} | {esc(c.get('reported'))} "
            f"| {esc(c.get('shown'))} | **{c['verdict']}** | {cs} |")


def markdown(a: dict) -> str:
    sm = a["summary"]
    lines = [f"# MeasureTrace 감사 리포트 — {a['project']}", "",
             f"- 실행 `{a['run_id']}` · 보고서 `{a['report']}` · 작성 {a['at']}",
             f"- 블라인드: 계산 완료 {a['blind']['calc_finished_at']} → 보고서 첫 열람 {a['blind']['report_opened_at']} "
             f"({'확인' if a['blind']['ok'] else '위반'})",
             f"- 재계산: {a['recompute']['status']} · 결과 해시 `{(a['recompute'].get('result_hash') or '')[:16]}`",
             "", f"> {a['disclaimer']}", "",
             "| Supported | Unsupported | 검사 대상 아님 |", "|---|---|---|",
             f"| {sm['Supported']} | {sm['Unsupported']} | {sm['not_checked']} |", ""]
    if sm["codes"]:
        lines += ["오류 코드: " + ", ".join(f"{k} {a['code_names'][k]} ×{n}" for k, n in sorted(sm["codes"].items())), ""]
    head = ["| 위치 | 주장 | 보고값 | 재계산 (보고 자릿수) | 판정 | 오류 코드 |", "|---|---|---|---|---|---|"]
    lines += ["## Unsupported", ""] + (head + [_row(c) for c in a["unsupported"]] if a["unsupported"] else ["없음"]) + [""]
    by_sentence: dict[str, list[dict]] = {}
    for c in a["unsupported"]:
        by_sentence.setdefault(c["sid"], []).append(c)
    for group in by_sentence.values():
        c = group[0]
        lines.append(f"- **p.{c['page']} 문장 {c['no']}** “{c['sentence']}”")
        seen = set()
        for x in (x for c in group for x in c["codes"]):
            if (x["code"], x["detail"]) not in seen:
                seen.add((x["code"], x["detail"]))
                lines.append(f"  - {x['code']} {x['name']} [{x['effect']}] — {x['detail']}")
    lines += ["", "## Supported", ""] + (head + [_row(c) for c in a["supported"]] if a["supported"] else ["없음"]) + [""]
    lines += ["## 검사 대상 아님", ""] + [f"- p.{x['page']} 문장 {x['no']} ({x['category_ko']}) {x['text']}" for x in a["not_checked"]]
    rc = a["recompute"]
    lines += ["", "## 재계산 결과 (4 RECOMPUTE 계산 로그)", "",
              f"- 데이터 해시 — 원본 바이트 `{(rc.get('input_hash') or '')[:16]}` · 내용 정규화 `{(rc.get('content_input_hash') or '')[:16]}`",
              f"- 결과 해시 `{(rc.get('result_hash') or '')[:16]}` · 계산 완료 {rc.get('finished_at')}", ""]
    if rc["results"]:
        lines += ["| id | 이름 | 조건 | 값 (반올림 전) | 단위 | 식 |", "|---|---|---|---|---|---|"]
        lines += [f"| {r['id']} | {r.get('name') or '—'} | {r.get('condition') or '—'} | {r['value']:.6g} | {r.get('unit') or '—'} "
                  f"| {r.get('equation_id') or '—'} |" for r in rc["results"]]
    pc = rc.get("processed_check") or {}
    if pc.get("checked") or pc.get("problems"):
        lines += ["", "### PROCESSED 데이터 대조 (기록)", "",
                  f"가공 파일 값 {pc['checked']}개 중 {pc['matched']}개가 RAW 재계산 값과 같음 (적힌 자릿수 기준)."]
        for m in pc.get("mismatches") or []:
            lines.append(f"- 불일치: {m['file']} {m.get('line')}줄 {m.get('column')} — 적힌 값 {m['reported']} · 재계산 {m['recomputed']:.6g}")
        for x in pc.get("problems") or []:
            lines.append(f"- 대조 못 함: {x}")
    r = a["reevaluation"]
    lines += ["", "## 수정 후 재평가", ""]
    if not r.get("previous_run"):
        lines.append(r["note"])
    else:
        lines.append(f"이전 감사 `{r['previous_run']}` 와 비교: " + ", ".join(f"{k} {v}" for k, v in r["counts"].items()))
        lines += ["", "| 변화 | 주장 | 이전 | 이번 | 이전 코드 | 이번 코드 |", "|---|---|---|---|---|---|"]
        for x in r["rows"]:
            lines.append(f"| {x['change']} | {x['claim']} | {x['before'] or '—'} | {x['after'] or '—'} | "
                         f"{', '.join(x['codes_before']) or '—'} | {', '.join(x['codes_after']) or '—'} |")
        for ch in r.get("data_changes") or []:
            lines.append(f"- 데이터 변경: {ch['file']} — {ch['kind']} ({ch['detail']})")
    return "\n".join(lines) + "\n"
