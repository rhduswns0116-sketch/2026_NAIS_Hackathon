"""MeasureTrace GIT_v2 명령줄 — 웹 화면 없이 단계별로 실행한다.

  python cli.py new <프로젝트> --data <연구 자료 폴더> [--report <보고서 폴더>]   1 INGEST 까지 (원본은 읽기만, 사본을 받음)
  python cli.py extract <실행 ID>                        2 EXTRACT                       [LLM — 토큰 사용]
  python cli.py confirm <실행 ID>                        3 CONFIRM 시작 · 질문과 답 양식 파일을 씀
  python cli.py answer <실행 ID> <답.json> --who <이름>  3 CONFIRM 답 제출 ('아니오'가 있으면 2 EXTRACT 를 다시 함 [LLM])
  python cli.py recompute <실행 ID>                      4 RECOMPUTE (격리 실행)
  python cli.py validate <실행 ID>                       5 VALIDATE + 6 AUDIT            [LLM — 토큰 사용]
  python cli.py freshness <실행 ID> <새 연구 자료 폴더>  계산에 쓴 데이터 해시와 대조 — 최신 파일인지
  python cli.py status [실행 ID]                         실행 목록 · 단계 상태

MT_OFFLINE=1 이면 LLM 캐시만 쓴다(토큰 0).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from mtagent import store
from mtagent.stages import audit, confirm, extract, ingest, recompute, validate
from mtagent.util import write_json


def _out(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=1, default=str))


def cmd_new(a) -> None:
    rid = store.new_run(a.project)
    n = store.add_folder(rid, "data", Path(a.data))
    if a.report:
        n += store.add_folder(rid, "report", Path(a.report))
    out = ingest.run(rid)
    print(f"실행 {rid} — 파일 {n}개 사본, 1 INGEST 완료")
    for r in out["required"]:
        print(f"  {'✓' if r['count'] else '✗'} {r['file']}: {r['count']}개")
    for f in out["findings"]:
        print(f"  [{f['level']}] {f['text']}")
    for c in out["changes"] or []:
        print(f"  변경 {c['file']}: {c['kind']} — {c['detail']}")


def cmd_extract(a) -> None:
    v = extract.run(a.run)
    sm = v["summary"]
    print(f"2 EXTRACT {sm['round']}회차 — " + ", ".join(f"{k}:{x['status']}" for k, x in sorted(sm["steps"].items())))
    for k, e in (sm.get("errors") or {}).items():
        print(f"  오류 {k}: {e}")


def cmd_confirm(a) -> None:
    v = confirm.start(a.run)
    cdir = store.out_dir(a.run) / "confirm"
    pending = [i for i in v["items"] if i["status"] == "pending"]
    write_json(cdir / "questions.json", pending)
    template = {i["id"]: {"choice": None, "text": "", "_title": i["title"], "_question": i["question"],
                          "_choices": {c["value"]: c["label"] for c in i["choices"]}} for i in pending}
    write_json(cdir / "answers_template.json", template)
    print(f"3 CONFIRM {v['round']}회차 · 상태 {v['status']} · 남은 필수 {v['counts']['pending_required']}")
    for i in pending:
        print(f"  [{i['group']}] {i['id']} — {i['title']}: {i['question']}")
    diagram = cdir / "relation_diagram.md"
    if diagram.exists():
        print("\n" + diagram.read_text(encoding="utf-8"))
    print(f"질문 전체: {cdir / 'questions.json'}\n답 양식: {cdir / 'answers_template.json'} "
          f"(choice 를 채우고 python cli.py answer {a.run} <파일> --who <이름>)")


def cmd_answer(a) -> None:
    raw = json.loads(Path(a.file).read_text(encoding="utf-8"))
    answers = {k: {"choice": x["choice"], "text": x.get("text") or ""} for k, x in raw.items()
               if isinstance(x, dict) and x.get("choice")}
    v = confirm.submit(a.run, a.who, answers)
    print(f"3 CONFIRM 상태 {v['status']} · {v['round']}회차 · 남은 필수 {v['counts']['pending_required']}")
    if v["status"] == "restart_required":
        print("  파일을 고쳐 새 실행(1 INGEST 부터)으로: " + ", ".join(v.get("restart_reason") or []))
    elif v["status"] == "open":
        print(f"  다음: python cli.py confirm {a.run}  (바뀐 항목만 다시 물음)")


def cmd_recompute(a) -> None:
    log = recompute.run(a.run)
    print(f"4 RECOMPUTE {log['status']}" + (f" — {log.get('reason')}" if log.get("reason") else ""))
    c = log["commit"]
    print(f"  ① 데이터 {len(c['data']['files'])}개 · 원본 해시 {c['data']['byte_hash'][:16]} · 내용 해시 {c['data']['content_hash'][:16]}")
    print(f"  ② 계산 과정 · 확정 {c['process']['confirmed_hash'][:16]} · 코드 {(c['process']['code_sha256'] or '—')[:16]}")
    for r in c["results"]:
        print(f"  ③ {r['id']:<22} {r['value']!r} {r.get('unit') or ''}")
    print(f"  ④ 결과 해시 {(c['result_hash'] or '—')[:16]}")
    pc = log.get("processed_check") or {}
    if pc.get("checked") or pc.get("problems"):
        print(f"  PROCESSED 대조 {pc['matched']}/{pc['checked']} 같음 · 불일치 {len(pc['mismatches'])} · 대조 못 함 {len(pc['problems'])}")


def cmd_validate(a) -> None:
    validate.run(a.run)
    out = audit.run(a.run)
    sm = out["summary"]
    print(f"6 AUDIT — Supported {sm['Supported']} · Unsupported {sm['Unsupported']} · 검사 대상 아님 {sm['not_checked']}")
    for c in out["unsupported"]:
        print(f"  ✗ p.{c['page']} 문장 {c['no']}: {c['claim'].get('text')} — " + ", ".join(x["code"] for x in c["codes"]))
    print(f"  리포트: {store.out_dir(a.run) / 'audit_report.md'}")


def cmd_freshness(a) -> None:
    r = recompute.freshness(a.run, Path(a.folder))
    print(("최신 — " if r["fresh"] else "바뀜 — ") + r["note"])
    for c in r["changes"]:
        print(f"  {c['file']}: {c['kind']} — {c['detail']}")


def cmd_status(a) -> None:
    if a.run:
        _out(store.state(a.run))
    else:
        for r in store.list_runs():
            print(f"{r['run_id']}  {r['project']:<20} " + " ".join(f"{k}:{v}" for k, v in r["stages"].items()))


def main(argv: list[str]) -> int:
    for stream in (sys.stdout, sys.stderr):      # Windows 콘솔에서도 한글·기호 출력
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    p = argparse.ArgumentParser(prog="cli.py", description="MeasureTrace GIT_v2 명령줄")
    sub = p.add_subparsers(dest="cmd", required=True)
    x = sub.add_parser("new", help="새 실행 + 1 INGEST")
    x.add_argument("project"), x.add_argument("--data", required=True), x.add_argument("--report")
    for name in ("extract", "confirm", "recompute", "validate"):
        sub.add_parser(name).add_argument("run")
    x = sub.add_parser("answer")
    x.add_argument("run"), x.add_argument("file"), x.add_argument("--who", required=True)
    x = sub.add_parser("freshness")
    x.add_argument("run"), x.add_argument("folder")
    sub.add_parser("status").add_argument("run", nargs="?")
    a = p.parse_args(argv)
    try:
        globals()[f"cmd_{a.cmd}"](a)
    except ValueError as e:
        print(f"오류: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
