# MeasureTrace 과업 2-1c: 어닐링/대조 박막 전도도 재계산 코드
# 계산 순서(계획서): EQ01 위치별 I-V 최소제곱 기울기 -> EQ03 시료별 위치 7개 평균(독립 단위 값)
# -> EQ04/EQ05 조건별 평균·표본 표준편차 -> EQ06/EQ07 합동 표준편차·등분산 독립 2표본 t 검정(양측)
# -> EQ08 증가율(%). EQ02(저항)는 보고에 쓰지 않으므로 intermediate 에 참고값으로만 둔다.
# 보고값은 모두 RAW 에서 다시 계산한다. PROCESSED 파일은 processed_check 대조용으로만 읽는다.
import csv
import math
from collections import OrderedDict

from scipy import stats

CONDITIONS = [
    ('annealed', ['S01', 'S02', 'S03', 'S04', 'S05', 'S06', 'S07', 'S08', 'S09', 'S10']),
    ('control', ['S11', 'S12', 'S13', 'S14', 'S15', 'S16', 'S17', 'S18', 'S19', 'S20']),
]
RAW_PREFIX = 'raw/'
PROCESSED_PREFIX = 'processed/'
PROCESSED_VALUE_COLUMN = 'G_mean_nS'
RAW_COLUMNS = ['sample_id', 'condition', 'position', 'voltage_V', 'current_A']
ENCODING = 'utf-8-sig'
S_TO_NS = 1e9
PLAN_POSITIONS = 7
PLAN_POINTS = 11
PLAN_DF = 18
PLAN_VOLTAGES = [round(-0.5 + 0.1 * k, 9) for k in range(11)]


def _parse_float(text):
    if text is None:
        return None, '값 없음(열 수 부족)'
    s = text.strip()
    if s == '':
        return None, '빈 값'
    try:
        v = float(s)
    except ValueError:
        return None, '숫자로 바꿀 수 없음: ' + repr(s)
    if not math.isfinite(v):
        # ASSUMPTION: nan/inf 는 계산에 쓸 수 없는 값으로 보고 skipped_rows 에 남긴다.
        return None, '유한한 수가 아님: ' + repr(s)
    return v, None


def _natural_key(text):
    digits = ''.join(ch for ch in text if ch.isdigit())
    return (int(digits) if digits else 10 ** 12, text)


def _ls_slope(volts, currents):
    # EQ01: 절편을 포함한 최소제곱 직선의 기울기 (단위 A/V = S)
    n = len(volts)
    v_bar = math.fsum(volts) / n
    i_bar = math.fsum(currents) / n
    sxx = math.fsum((v - v_bar) ** 2 for v in volts)
    sxy = math.fsum((v - v_bar) * (c - i_bar) for v, c in zip(volts, currents))
    if sxx == 0.0:
        return None
    return sxy / sxx


def _mean(values):
    return math.fsum(values) / len(values)


def _sd(values):
    # EQ05: 표본 표준편차(분모 n-1)
    m = _mean(values)
    return math.sqrt(math.fsum((x - m) ** 2 for x in values) / (len(values) - 1))


def compute(files: dict) -> dict:
    skipped_rows = []
    warnings = []

    sample_to_condition = {}
    for cond_name, samples in CONDITIONS:
        for s in samples:
            sample_to_condition[s] = cond_name

    raw_keys = sorted(k for k in files if k.startswith(RAW_PREFIX))
    processed_keys = sorted(k for k in files if k.startswith(PROCESSED_PREFIX))
    if not raw_keys:
        raise ValueError('RAW 파일(raw/...)이 files 에 없다')

    # ---------- RAW 읽기 ----------
    points = OrderedDict()  # (sample_id, position) -> {'V': [...], 'I': [...]}
    sample_files = {}
    sample_condition_values = {}
    rows_read = {}

    for key in raw_keys:
        n_rows = 0
        with open(files[key], 'r', encoding=ENCODING, newline='') as fh:
            reader = csv.DictReader(fh, delimiter=',')
            header = reader.fieldnames or []
            missing = [c for c in RAW_COLUMNS if c not in header]
            if missing:
                raise ValueError(key + ' 에 필요한 열이 없다: ' + ', '.join(missing))
            for row in reader:
                n_rows += 1
                line = reader.line_num  # 머리글이 1줄
                sample = (row.get('sample_id') or '').strip()
                position = (row.get('position') or '').strip()
                reasons = []
                if sample == '':
                    reasons.append('sample_id 빈 값')
                if position == '':
                    reasons.append('position 빈 값')
                v, why_v = _parse_float(row.get('voltage_V'))
                if why_v is not None:
                    reasons.append('voltage_V ' + why_v)
                c, why_c = _parse_float(row.get('current_A'))
                if why_c is not None:
                    reasons.append('current_A ' + why_c)
                if reasons:
                    skipped_rows.append({'file': key, 'line': line, 'reason': '; '.join(reasons)})
                    continue
                # ASSUMPTION: 같은 (sample_id, position) 행은 파일이 달라도 하나의 위치로 합친다.
                d = points.setdefault((sample, position), {'V': [], 'I': []})
                d['V'].append(v)
                d['I'].append(c)
                fl = sample_files.setdefault(sample, [])
                if key not in fl:
                    fl.append(key)
                cond_val = (row.get('condition') or '').strip()
                cl = sample_condition_values.setdefault(sample, [])
                if cond_val not in cl:
                    cl.append(cond_val)
        rows_read[key] = n_rows

    # 폴더 이름과 설계 조건이 어긋나는지 기록(배정에는 쓰지 않음)
    for sample, fl in sample_files.items():
        design_cond = sample_to_condition.get(sample)
        for key in fl:
            parts = key.split('/')
            folder = parts[1] if len(parts) > 2 else None
            if design_cond is not None and folder is not None and folder != design_cond:
                warnings.append(sample + ': 파일 폴더(' + folder + ')와 설계 조건(' + design_cond + ')이 다르다 (' + key + ')')

    # ---------- EQ01 위치별 전도도, EQ02 참고 저항 ----------
    position_values = OrderedDict()
    skipped_positions = []
    samples_seen = sorted({s for (s, _) in points}, key=_natural_key)
    for sample in samples_seen:
        positions = sorted([p for (s, p) in points if s == sample], key=_natural_key)
        pv = OrderedDict()
        for position in positions:
            d = points[(sample, position)]
            n_pts = len(d['V'])
            if n_pts != PLAN_POINTS:
                # ASSUMPTION: 점 수가 계획(11)과 달라도 있는 점으로 기울기를 계산하고 경고만 남긴다.
                warnings.append(sample + ' ' + position + ': I-V 점 수 ' + str(n_pts) + ' (계획 ' + str(PLAN_POINTS) + ')')
            if sorted(round(v, 9) for v in d['V']) != PLAN_VOLTAGES:
                warnings.append(sample + ' ' + position + ': 전압 값이 계획(-0.5~0.5 V, 0.1 V 간격 11점)과 다르다')
            slope = _ls_slope(d['V'], d['I']) if n_pts >= 2 else None
            if slope is None:
                skipped_positions.append({'sample_id': sample, 'position': position,
                                          'reason': '기울기를 정의할 수 없음(점 부족 또는 전압이 모두 같음)'})
                continue
            pv[position] = {
                'n_points': n_pts,
                'G_S': slope,
                'G_nS': slope * S_TO_NS,
                'R_ohm_reference_EQ02': (1.0 / slope) if slope != 0.0 else None,
            }
        position_values[sample] = pv

    # ---------- EQ03 시료별 전도도(위치 평균) ----------
    sample_G_nS = OrderedDict()
    for sample, pv in position_values.items():
        g_list = [x['G_nS'] for x in pv.values()]
        if len(g_list) != PLAN_POSITIONS:
            # ASSUMPTION: 위치 수가 계획(7)과 달라도 있는 위치의 평균을 시료 값으로 쓰고 경고만 남긴다.
            warnings.append(sample + ': 위치 수 ' + str(len(g_list)) + ' (계획 ' + str(PLAN_POSITIONS) + ')')
        if not g_list:
            warnings.append(sample + ': 유효한 위치가 없어 시료 값을 계산하지 못했다')
            continue
        sample_G_nS[sample] = _mean(g_list)

    unassigned = [s for s in sample_G_nS if s not in sample_to_condition]
    for s in unassigned:
        warnings.append(s + ': 설계의 시료 목록에 없어 조건 통계에서 제외했다')

    # ---------- EQ04/EQ05 조건별 평균·표본 표준편차 ----------
    # ASSUMPTION: 조건 배정은 설계의 시료 목록(sample_id) 기준. raw 의 condition 열 값은 기록만 한다.
    cond_values = OrderedDict()
    cond_stats = OrderedDict()
    for cond_name, samples in CONDITIONS:
        present = [s for s in samples if s in sample_G_nS]
        absent = [s for s in samples if s not in sample_G_nS]
        if absent:
            warnings.append(cond_name + ': 값이 없는 시료 ' + ', '.join(absent))
        vals = [sample_G_nS[s] for s in present]
        if len(vals) < 2:
            raise ValueError(cond_name + ' 조건의 시료 값이 2개 미만이라 표준편차·t 검정을 계산할 수 없다')
        cond_values[cond_name] = OrderedDict((s, sample_G_nS[s]) for s in present)
        cond_stats[cond_name] = {'n': len(vals), 'mean_nS': _mean(vals), 'sd_nS': _sd(vals)}

    a = cond_stats['annealed']
    c = cond_stats['control']
    n_a, n_c = a['n'], c['n']

    # ---------- EQ06 합동 표준편차 ----------
    df = n_a + n_c - 2
    if df != PLAN_DF:
        warnings.append('자유도 ' + str(df) + ' (계획 ' + str(PLAN_DF) + ')')
    s_p = math.sqrt(((n_a - 1) * a['sd_nS'] ** 2 + (n_c - 1) * c['sd_nS'] ** 2) / df)

    # ---------- EQ07 t 통계량, 양측 p ----------
    diff = a['mean_nS'] - c['mean_nS']
    t_stat = diff / (s_p * math.sqrt(1.0 / n_a + 1.0 / n_c))
    p_value = float(2.0 * stats.t.sf(abs(t_stat), df))

    # 교차 확인용(보고값은 위 식으로 계산한 값)
    chk = stats.ttest_ind(list(cond_values['annealed'].values()),
                          list(cond_values['control'].values()), equal_var=True)

    # ---------- EQ08 증가율 ----------
    increase_pct = diff / c['mean_nS'] * 100.0

    # ---------- 결과 ----------
    results = []

    def add(rid, name, value, unit, condition, kind, eq):
        results.append({'id': rid, 'name': name, 'value': float(value), 'unit': unit,
                        'condition': condition, 'kind': kind, 'equation_id': eq})

    for cond_name, _ in CONDITIONS:
        st = cond_stats[cond_name]
        add('G_mean__' + cond_name, '조건별 평균 전도도', st['mean_nS'], 'nS', cond_name, 'value', 'EQ04')
    for cond_name, _ in CONDITIONS:
        st = cond_stats[cond_name]
        add('G_sd__' + cond_name, '조건별 전도도 표본 표준편차', st['sd_nS'], 'nS', cond_name, 'value', 'EQ05')
    for cond_name, _ in CONDITIONS:
        st = cond_stats[cond_name]
        add('n_samples__' + cond_name, '조건별 시료 수', st['n'], None, cond_name, 'n', None)
    add('G_diff', '조건 간 평균 전도도 차이(A − C)', diff, 'nS', None, 'difference', None)
    add('s_pooled', '합동 표준편차', s_p, 'nS', None, 'other', 'EQ06')
    add('t_stat', 't 검정 통계량', t_stat, None, None, 'test_statistic', 'EQ07')
    add('df', '자유도', df, None, None, 'df', 'EQ07')
    add('p_value', '양측 p값', p_value, None, None, 'p_value', 'EQ07')
    # ASSUMPTION: 증가율은 ×100 한 값이므로 단위를 outputs 의 '%' 로 적는다.
    add('G_increase_pct', '어닐링에 따른 전도도 증가율', increase_pct, '%', None, 'percent_change', 'EQ08')

    # ---------- PROCESSED 대조 목록 ----------
    processed_check = []
    processed_unmatched = []
    processed_condition_values = {}
    for key in processed_keys:
        with open(files[key], 'r', encoding=ENCODING, newline='') as fh:
            reader = csv.DictReader(fh, delimiter=',')
            header = reader.fieldnames or []
            if 'sample_id' not in header or PROCESSED_VALUE_COLUMN not in header:
                warnings.append(key + ': sample_id 또는 ' + PROCESSED_VALUE_COLUMN + ' 열이 없어 대조하지 않았다')
                continue
            for row in reader:
                line = reader.line_num
                sample = (row.get('sample_id') or '').strip()
                reported = row.get(PROCESSED_VALUE_COLUMN)
                if 'condition' in header:
                    processed_condition_values[sample] = row.get('condition')
                if sample in sample_G_nS and reported is not None:
                    # ASSUMPTION: G_mean_nS 는 EQ03 의 G_i 를 nS 로 적은 값이다.
                    processed_check.append({'file': key, 'line': line, 'column': PROCESSED_VALUE_COLUMN,
                                            'reported': reported, 'recomputed': float(sample_G_nS[sample])})
                else:
                    processed_unmatched.append({'file': key, 'line': line, 'sample_id': sample,
                                                'reason': 'RAW 에서 다시 계산한 시료 값이 없거나 값 칸이 없다'})

    intermediate = {
        'skipped_rows': skipped_rows,
        'processed_check': processed_check,
        'processed_unmatched': processed_unmatched,
        'warnings': warnings,
        'raw_rows_read': rows_read,
        'skipped_positions': skipped_positions,
        'position_conductance': {s: {p: dict(v) for p, v in pv.items()} for s, pv in position_values.items()},
        'sample_G_nS': {s: float(v) for s, v in sample_G_nS.items()},
        'sample_assigned_condition': {s: sample_to_condition.get(s) for s in sample_G_nS},
        'raw_condition_column_values': sample_condition_values,
        'processed_condition_column_values': processed_condition_values,
        'sample_files': sample_files,
        'unassigned_samples': unassigned,
        'condition_samples_G_nS': {k: {s: float(x) for s, x in v.items()} for k, v in cond_values.items()},
        'condition_stats': {k: {'n': v['n'], 'mean_nS': float(v['mean_nS']), 'sd_nS': float(v['sd_nS'])} for k, v in cond_stats.items()},
        'scipy_ttest_ind_crosscheck': {'statistic': float(chk.statistic), 'pvalue': float(chk.pvalue)},
        'plan': {'positions_per_sample': PLAN_POSITIONS, 'points_per_position': PLAN_POINTS, 'df': PLAN_DF,
                 'alternative': 'two-sided', 'alpha': 0.05},
    }
    return {'results': results, 'intermediate': intermediate}
