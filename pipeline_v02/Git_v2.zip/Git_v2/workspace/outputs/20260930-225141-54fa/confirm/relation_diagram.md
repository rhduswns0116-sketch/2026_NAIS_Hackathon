# 실험 ↔ 데이터 ↔ 식 ↔ 장비

3 CONFIRM 3-1 에서 확인할 관계 (2-1b 추출 결과, 확인 전).

```mermaid
flowchart LR
```

```

```
