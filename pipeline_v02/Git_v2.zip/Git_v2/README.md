# MeasureTrace GIT_v2

보고서의 수치 주장이 **제출된 데이터(RAW·PROCESSED)로 지지되는지** 다시 계산해 확인하는 Agent AI.
파이프라인(1 INGEST → 2 EXTRACT → 3 CONFIRM → 4 RECOMPUTE → 5 VALIDATE → 6 AUDIT)은 `docs/PIPELINE_v2.md` 를 따른다.
Git_v1(친구 구현)을 바탕으로 이어서 만들었다 — 바뀐 점은 아래 **v1 → v2** 참고.
LLM 은 **읽기**(데이터 뜻·계획서·사양서·보고서 문장)만 하고, **계산·비교·판정은 파이썬**이 한다. 사람은 3 CONFIRM 에서 LLM 이 잘 읽었는지 확인한다.

## 연구자가 가져올 파일

RAW_DATA · PROCESSED_DATA · 연구 계획서 · 장비 사양 보고서 (연구 자료 폴더) + 최종 보고서 초안 (다른 폴더로 따로).
1 INGEST 가 다섯 가지가 있는지 점검표(`ingest.json` 의 `required`)로 남긴다.

## 실행

```powershell
pip install -r requirements.txt
Copy-Item .env.example .env      # LLM_API_KEY 넣기 (.env 는 커밋 금지 — .gitignore 에 있음)
```

**웹 화면** (Git_v1 과 같음 — 이번 단계에서 검증·수정하지 않음):
`python run.py` → http://127.0.0.1:8765

**명령줄** (v2 추가 — 웹 없이 단계별로):

```powershell
python cli.py new 데모 --data samples\annealing_demo\data --report samples\annealing_demo\report   # 1 INGEST
python cli.py extract <실행 ID>        # 2 EXTRACT            ← LLM 호출 (토큰 사용)
python cli.py confirm <실행 ID>        # 3 CONFIRM 질문 + 관계 도식 + 답 양식(answers_template.json)
python cli.py answer <실행 ID> 답.json --who 홍길동   # '아니오'가 있으면 2 EXTRACT 다시 ← LLM
python cli.py recompute <실행 ID>      # 4 RECOMPUTE (격리 실행, LLM 없음)
python cli.py validate <실행 ID>       # 5 VALIDATE + 6 AUDIT ← LLM 호출 (토큰 사용)
python cli.py freshness <실행 ID> <새 연구 자료 폴더>   # 계산에 쓴 데이터 해시와 대조 — 최신 파일인지
python cli.py status
```

`MT_OFFLINE=1` 이면 LLM 캐시만 쓴다(토큰 0). 시험: `python -m unittest discover -s tests -v` (가짜 LLM, 토큰 0).

샘플: `samples/annealing_demo`(연구 자료 `data/`, 보고서 `report/`) — 정답 `samples/annealing_demo_answer_key.json`(업로드하지 않음).
`samples/annealing_demo_rerun` 은 S07 에서 3행이 빠지고 S12 의 형식만 바뀐 재실행본.

## v1 → v2 (파이프라인 문서 반영)

| 단계 | Git_v1 | GIT_v2 |
|---|---|---|
| 1-1 유형 분류 | 가공 데이터는 '사용 안 함' | **PROCESSED 데이터를 입력으로 사용**. 연구자가 가져올 5종 점검표(`required`) |
| 1-2 측정 시각 | 파일 안의 기록만 | **(1) 파일 수정 시각 (2) 장비 기록 시각 둘 다 기록, 장비 기록 우선**. 명령줄로 넣으면 원본 수정 시각을 사본에 옮김(`upload_meta.json`), 웹 업로드는 원본 시각이 없어 '업로드 시각'으로 표시하고 측정 시각으로 쓰지 않음. 파일 수정이 장비 기록보다 이르면 확인 요청 |
| 2-1a 데이터 내용 | RAW 묶음만 | RAW(G1…) + **PROCESSED(P1…) 묶음**, 열 역할에 `derived`(계산된 값) 추가 |
| 2-1c 계산 코드 | RAW 만 입력 | RAW + PROCESSED 입력(원칙은 RAW 에서 계산, RAW 없는 단계만 PROCESSED), **processed_check**(가공값 ↔ RAW 재계산값) 목록 |
| 2-2 측정 조건 | 범위·정확도·범위 밖 표시값 | + 동작 조건 인용도 원문 대조 |
| 2-3 데이터 구조화 | RAW | RAW + PROCESSED 의 단위·결측·숫자 아닌 값 (사양 범위 이상치는 장비가 낸 RAW 측정값에만) |
| 3-1 데이터 해석 승인 | 매칭 표 | + **실험 ↔ 데이터 ↔ 식 ↔ 장비 도식**(Mermaid·글, `confirm/relation_diagram.md`, 항목 proposal 의 `diagram`) |
| 3-2 분석 범위 확정 | 범위·범위 밖 표시값 | + **측정 조건**(동작 온도 등) 항목, 승인분은 `confirmed.json` 의 `spec.conditions` |
| 3-3 측정 시각 | 파일 안 기록 | 장비 기록/파일 수정 시각 중 무엇을 썼는지(`basis`) 함께 확인 |
| 4 계산 로그 | 사용한 RAW 해시 | **`commit` = ① 데이터 해시 2종(파일별 + 묶음 원본·내용 해시, RAW·PROCESSED) ② 계산 과정(확정 식 LaTeX·단계·코드 해시·중간값 해시·환경) ③ 결과값 ④ 결과 해시** |
| 4 최신 여부 | 이전 실행과 E07 | + **`freshness`** — 새 데이터 폴더를 계산에 쓴 해시와 대조. E07 은 PROCESSED 변경도 포함 |
| 4 PROCESSED 대조 | — | 가공 파일 값을 **적힌 자릿수로** RAW 재계산값과 비교, 불일치는 파일·줄·열로 기록(판정은 바꾸지 않음) |
| 6 리포트 | 주장 판정·재평가 | + 재계산 결과 표·데이터/결과 해시·PROCESSED 대조 |

웹 화면(`web/`)은 Git_v1 그대로다. v2 가 더한 값(도식·동작 조건·commit·PROCESSED 대조)은 산출물 JSON·리포트·명령줄에는 나오지만 화면에는 아직 그리지 않는다 — 화면 반영은 다음 단계.

## 단계별 구현

| 단계 | 과업 | 주체 | 구현 |
|---|---|---|---|
| 1 INGEST | 1-1 입력 격리·분류 | PY | 사본을 `workspace/inputs/<실행>/data`·`/report` 에 받고 **읽기 전용**으로 잠금. 산출물은 `workspace/outputs/<실행>/`(입력 밖). 보고서는 따로 받고 5단계 전까지 열지 않음(원본 해시만). 규칙으로 분류: RAW · PROCESSED · 연구 계획서 · 장비 사양서 · 스크립트(실행 안 함) · 그림 · 메모 · 미분류 | `stages/ingest.py` |
| | 1-2 지문·시각 | PY | 해시 2종(원본 바이트 + 내용 정규화: 인코딩·BOM·줄바꿈·공백·구분자 무시). 표는 행별 해시 → 이전 실행과 **바뀜·추가·빠짐과 줄 번호**. 측정 시각 2종(장비 기록 우선) | `hashing.py` |
| | 1-3 파생 이력 | PY | `(입력 해시, 코드 버전, 파라미터) → 출력 해시` 를 `workspace/outputs/lineage.jsonl` 에 단계마다 한 줄. 연구자가 가져온 PROCESSED 는 파이프라인 밖에서 만든 것이라 파생 기록이 없음(입력 해시로만 등장) | `lineage.py` |
| 2 EXTRACT | 2-1a 데이터 내용 파악 | LLM | 같은 열 구성의 RAW·PROCESSED 묶음마다 **열 이름·문자 값만** 보내(숫자 값 없음) 역할·단위·뜻 | `stages/extract.py` |
| | 2-1b 연구 내용 추출 | LLM | Word 수식(OMML)은 **파이썬이 LaTeX 로 변환**(id 고정), LLM 은 식의 뜻·변수↔데이터 열, 계산 과정, 설계·검정, 실험—데이터—식—장비 매칭, 보고할 값 목록 | `readers.py` |
| | 2-1c 계산 코드 | LLM | 계획서대로 계산하는 `compute(files)` 초안. **실행하지 않음**, 정적 점검만 | |
| | 2-2 측정 조건 | LLM→PY | 장비 사양서의 유효 판독 범위·정확도·범위 밖 표시값·동작 조건. 인용이 원문에 있는지 파이썬이 확인 | |
| | 2-3 데이터 구조화 | PY | 단위 누락·모호, 결측, 숫자 아닌 값, 사양 범위 밖(이상치), 범위 밖 표시값 — 파일·열·**줄 번호·값** | |
| | 2-4 누락 점검 | LLM→PY | LLM 은 계획서만 읽고 필요한 시료·반복·측정점 수를 뽑고, 파이썬이 RAW 와 대조 | |
| 3 CONFIRM | 3-1 데이터 해석 승인 | 사람 | 데이터 내용·식·계산 과정·설계·매칭(도식)·코드·누락. **아니오 + 고칠 내용 → 2-1 을 a 부터 다시** → 제안이 바뀐 항목만 다시 물음 | `stages/confirm.py` |
| | 3-2 분석 범위 확정 | 사람 | 장비 사양(범위·정확도·범위 밖 표시값·측정 조건). **아니오 → 2-2 다시** | |
| | 3-3 측정 기준 승인 | 사람 | 측정 정의(열 역할·단위) 고정. 단위 누락·모호 → 제안 중 고르거나 **기타 직접 입력**. 결측·이상치 → **'아니오 → 파일을 고쳐 1 INGEST 부터 새 실행'** 또는 '값이 맞음(진행, E02 기록)' | |
| | 승인값 반영 | PY | 피드백 최대 3회 — 그 뒤에도 아니오면 미확정(관련 주장 E06). 확정 기록 `confirmed.json`, 승인 코드는 해시 고정·읽기 전용 | |
| 4 RECOMPUTE | 4-1 수치 재계산 | PY | 실행 전 확인(승인 코드 해시 · 추출 결과 불변 · 데이터 해시 · 정적 점검) → **격리 실행**(`python -I -B` 별도 프로세스, 감사 훅으로 쓰기·허용 밖 읽기·네트워크·하위 프로세스 차단, 시간 제한) · PROCESSED 대조 | `stages/recompute.py`, `sandbox.py`, `sandbox_runner.py` |
| | 4-2 계산 로그 | PY | `commit` 4요소(위 표) + 같은 프로젝트의 이전 계산과 비교해 E07 · `freshness()` | |
| 5 VALIDATE | 5-1 주장 추출 | LLM | 보고서를 **이때 처음 열고**(열람 시각 > 계산 완료 시각 확인), 문장마다 **몇 쪽 몇 번째 문장** 번호 | `stages/validate.py` |
| | 5-2 비교 · 5-3 오류 코드 | PY | 보고 자릿수로 반올림 비교 · 단위 환산 · 방향 · 유의성(α) · n·자유도 | `codes.py`, `design.py` |
| 6 AUDIT | 6-1 결과 출력 · 6-2 재평가 | PY | Supported / Unsupported 주장마다 문장·보고값·재계산값·오류 코드·근거. 이전 감사와 주장별 수정 전·후. `audit_report.md` | `stages/audit.py` |

## 오류 코드

| 코드 | 뜻 | 판정 |
|---|---|---|
| E01 | 단위 불일치 (누락 포함) | Unsupported |
| E02 | 측정값 이상 — 장비 사양 범위 밖 값을 연구자가 확인하고 진행 | 기록 |
| E03 | 필요 데이터 누락 (계획서 대비) — 그 집단을 쓰는 주장에만 | Unsupported |
| E04 | 표본 수·자유도 불일치 | Unsupported |
| E05 | 수치·방향·유의성 불일치 | Unsupported |
| E06 | 재계산 근거 없음·미확정 | Unsupported |
| E07 | 데이터 버전 변경 (이전 실행 대비, RAW·PROCESSED) | 기록 |

판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것이다. 계산식의 과학적 타당성, 그림, 외부 문헌 수치, 데이터 조작 여부는 판정하지 않는다.
파이프라인 문서의 5-3 '오류 코드 분류 — 수정하기' 는 아직 열려 있어 Git_v1 의 E01~E07 을 그대로 쓴다.

## 파일

```
run.py                 웹 화면 실행 (Git_v1 그대로)
cli.py                 명령줄 실행 (v2)
docs/PIPELINE_v2.md    파이프라인 문서 + 단계 ↔ 코드 대응
mtagent/
  config.py            경로·모델·키 (.env)          llm.py       구조화 출력·캐시·호출 기록
  store.py             실행 폴더·상태·업로드(원본 수정 시각)   lineage.py   1-3 파생 이력
  readers.py           표·Word(글+수식→LaTeX)·PDF     hashing.py   해시 2종·행 차이·측정 시각 2종
  units.py             단위 해석·환산                design.py    조건 이름 맞추기
  sandbox.py · sandbox_runner.py  정적 점검·격리 실행    codes.py     오류 코드
  stages/ ingest · extract · confirm · recompute · validate · audit
web/                   표준 라이브러리 HTTP 서버 + 화면 (Git_v1 그대로)
tests/                 test_pipeline.py · fake_llm.py (가짜 LLM)
samples/               시험 자료 (생성형 AI 로 만든 가상 자료)
workspace/             실행하면 생김 — inputs · outputs · llm_cache (.gitignore)
```

## 설정

`.env`: `LLM_API_KEY`(또는 `ANTHROPIC_API_KEY`) · `LLM_MODEL`(기본 `claude-opus-5-5`) · `MT_OFFLINE=1`(캐시만, 토큰 0) · `MT_WORKSPACE`(작업 폴더).
LLM 응답은 `workspace/llm_cache/` 에 캐시된다 — 같은 입력이면 토큰 0 으로 같은 답(재현성). 호출 기록은 `workspace/outputs/llm_calls.jsonl`.
