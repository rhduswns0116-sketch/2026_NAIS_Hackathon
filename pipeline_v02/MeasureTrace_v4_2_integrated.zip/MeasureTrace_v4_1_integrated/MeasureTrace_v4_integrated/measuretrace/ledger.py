"""1-3 산출물 이력 장부 (lineage) — 파이프라인이 입력을 가공해 만든 산출물마다
(입력 해시, 코드 해시, 파라미터) → 출력 해시 를 JSON Lines 로 한 줄씩 추가한다. 지우거나 고치지 않는다.

연구자가 가져온 파일(입력 사본 포함)은 파이프라인이 만든 것이 아니므로 여기에 적지 않는다.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

from measuretrace.paths import LEDGER_PATH, ROOT, rel


def code_hash(*modules_or_dirs: Path) -> dict:
    """실행한 코드의 해시 — 파일(상대 경로 + 바이트)을 정렬해 묶는다. 코드가 한 글자라도 바뀌면 달라진다."""
    files: list[Path] = []
    for p in modules_or_dirs:
        p = Path(p)
        files += sorted(p.rglob("*.py")) if p.is_dir() else [p]
    digest = hashlib.sha256()
    for f in sorted(set(files)):
        digest.update(f.relative_to(ROOT).as_posix().encode("utf-8") + b"\0")
        digest.update(f.read_bytes() + b"\0")
    return {"sha256": digest.hexdigest(), "files": [f.relative_to(ROOT).as_posix() for f in sorted(set(files))]}


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(step: str, run_id: str, input_hash: str, code: dict, params: dict, outputs: list[Path]) -> dict:
    entry = {
        "ts": datetime.now().astimezone().isoformat(timespec="seconds"),
        "step": step, "run_id": run_id,
        "input_hash": input_hash, "code_hash": code["sha256"], "code_files": code["files"],
        "params": params,
        "outputs": [{"path": rel(p), "sha256": _sha256(p)} for p in outputs],
    }
    LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)
    with LEDGER_PATH.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return entry


def entries(run_id: str) -> list[dict]:
    """이 실행의 장부 줄 전부 (기록 순)."""
    if not LEDGER_PATH.exists():
        return []
    out = []
    for line in LEDGER_PATH.read_text(encoding="utf-8").splitlines():
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if e.get("run_id") == run_id:
            out.append(e)
    return out


def find(run_id: str, step: str) -> dict | None:
    """이 실행에서 step 과 이름이 같은 마지막 장부 줄."""
    hits = [e for e in entries(run_id) if e.get("step") == step]
    return hits[-1] if hits else None


def recent(n: int = 10) -> list[dict]:
    if not LEDGER_PATH.exists():
        return []
    lines = [l for l in LEDGER_PATH.read_text(encoding="utf-8").splitlines() if l.strip()][-n:]
    out = []
    for line in reversed(lines):
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out
