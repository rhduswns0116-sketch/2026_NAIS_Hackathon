"""경로 상수 — 모든 경로는 여기서만 정한다.

  workspace/inputs/<실행 ID>/data/     연구 자료 사본 (RAW·연구 계획서·장비 사양서) — 읽기 전용으로 잠금
  workspace/inputs/<실행 ID>/report/   최종 보고서 초안 사본 — 별도 경로, 5-1 전까지 열지 않음
  workspace/outputs/<프로젝트>/<실행 ID>/   산출물 — 입력 밖
  workspace/outputs/lineage.jsonl     1-3 산출물 이력 장부
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # practice_v4/
PACKAGE_DIR = ROOT / "measuretrace"
WORKSPACE = Path(os.environ.get("MEASURETRACE_WORKSPACE") or ROOT / "workspace")   # 시험·리허설은 다른 폴더로
INPUTS_DIR = WORKSPACE / "inputs"
OUTPUTS_DIR = WORKSPACE / "outputs"
LEDGER_PATH = OUTPUTS_DIR / "lineage.jsonl"


def rel(path) -> str:
    """practice_v4 기준 상대 경로 (밖이면 절대 경로) — 기록·화면 표시용."""
    path = Path(path).resolve()
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return path.as_posix()
