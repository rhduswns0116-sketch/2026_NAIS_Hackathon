"""MeasureTrace v4 — 기준 문서: MeasureTrace_파이프라인_v4_확정.md · MeasureTrace_오류코드_v4.md"""
