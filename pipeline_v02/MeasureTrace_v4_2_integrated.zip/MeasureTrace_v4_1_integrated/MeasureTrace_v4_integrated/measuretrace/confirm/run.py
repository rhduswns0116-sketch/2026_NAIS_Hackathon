"""3 CONFIRM — 사람이 확정한다 [USER]. 파이프라인 v4 확정본 §4-3.

  start(run_id)                    2 EXTRACT 결과로 확인 항목을 만든다. 같은 프로젝트의 이전 실행에서 확정한 항목은
                                   제안 해시가 같으면 이어받고(다시 묻지 않음), 다르면 '이전과 달라짐'을 기록한다.
  submit(run_id, respondent, answers)   한 번 제출 = 피드백 1회(최대 3회). 답변은 answers.jsonl 에 추가만 한다.
      3-1 수정 → 수정 내용을 붙여 EXTRACT 재실행(LLM) → 제안이 바뀐 항목만 다시 묻는다
      3-2 수정 · 3-3 단위 확정 → 2-3 을 다시 계산(PY) → 새로 드러난 이상값은 새 항목
      3회 뒤에도 남은 필수 항목 → 미확정(unresolved) — 그 항목에 의존하는 주장은 5단계에서 Unsupported(E06 '미확정')
  모든 필수 항목이 끝나면 confirmed.json(승인된 식·가공·설계·검정·매칭·사양·단위·결정) + 승인 코드(해시 고정)를 쓴다.

보고서는 열지 않는다. 계산 코드는 여기서도 실행하지 않는다(4-1 에서만).
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import stat
from datetime import datetime
from pathlib import Path

from measuretrace import ledger
from measuretrace.confirm import items as I
from measuretrace.extract import datacheck
from measuretrace.extract.run import find_snapshot, run_extract
from measuretrace.extract.units import parse_unit
from measuretrace.ingest import workspace
from measuretrace.paths import OUTPUTS_DIR, PACKAGE_DIR, rel

MAX_ROUNDS = 3
FINAL = {"approved", "decided", "corrected_applied", "answered", "skipped", "unresolved", "remeasure"}
CONFIRM_CODE = [PACKAGE_DIR / "confirm", PACKAGE_DIR / "extract", PACKAGE_DIR / "ledger.py"]
REGISTRY = "approved_code_registry.jsonl"
EXTRACT_FILES = {"equations": "equations.json", "headers": "headers.json", "spec": "spec_conditions.json",
                 "plan": "plan_extraction.json", "checks": "data_checks.json", "missing": "missing_check.json",
                 "summary": "extract_summary.json"}


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _paths(run_id: str) -> dict:
    snap = find_snapshot(run_id)
    base = snap.parent
    return {"snapshot": snap, "base": base, "extract": base / "extract", "confirm": base / "confirm",
            "state": base / "confirm" / "confirm_state.json", "answers": base / "confirm" / "answers.jsonl"}


def load_extract(extract_dir: Path) -> dict:
    if not (extract_dir / "extract_summary.json").exists():
        raise ValueError("이 실행의 2 EXTRACT 결과가 없음 — 먼저 EXTRACT 를 실행")
    out = {}
    for key, name in EXTRACT_FILES.items():
        p = extract_dir / name
        out[key] = json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
    return out


def _save(p: dict, state: dict) -> None:
    p["confirm"].mkdir(parents=True, exist_ok=True)
    p["state"].write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def _code_key(snap: dict, ex: dict) -> str:
    """같은 입력이면 같은 코드 — 계획서 해시 + 추출 결과(코드 제외) + RAW 열 구성."""
    plan = copy.deepcopy(((ex.get("plan") or {}).get("analysis")) or {})
    plan.pop("code", None)
    cols = sorted({tuple(g["columns"]) for g in (ex.get("headers") or {}).get("groups", [])})
    plan_sha = (ex.get("equations") or {}).get("plan_sha256", "")
    return I.phash([plan_sha, plan, cols])


def _registry_lookup(key: str) -> dict | None:
    path = OUTPUTS_DIR / REGISTRY
    if not path.exists():
        return None
    hit = None
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if e.get("key") == key:
            hit = e
    return hit


def _previous_state(project: str, run_id: str) -> dict | None:
    base = OUTPUTS_DIR / project
    cands = [d / "confirm" / "confirm_state.json" for d in base.iterdir()
             if d.is_dir() and d.name != run_id and (d / "confirm" / "confirm_state.json").exists()] if base.is_dir() else []
    if not cands:
        return None
    return json.loads(max(cands, key=lambda x: x.stat().st_mtime_ns).read_text(encoding="utf-8"))


def _unit_evidence(snap: dict, files: list[str], header_unit) -> dict:
    """확정 단위의 근거 — 그 열이 든 RAW 파일의 내용 해시와 헤더 표기. 같은 열 이름이라도 파일 내용이 바뀌면
    (다른 장비·배율로 다시 측정) 단위가 달라질 수 있으므로, 다음 실행은 이 근거가 같을 때만 단위를 이어받는다."""
    hashes = {f["path"]: f.get("content_hash") or f.get("sha256") for f in snap["files"]}
    return {"files": {f: hashes.get(f) for f in sorted(set(files or []))}, "header_unit": header_unit}


def _carry_units(prev: dict, ex: dict, snap: dict) -> tuple[dict, dict, list[str]]:
    """이전 실행의 확정 단위 중 근거가 지금 입력과 같은 것만 (단위, 근거, 다시 묻는 열 안내)."""
    now = {e["column"]: _unit_evidence(snap, e.get("files"), e.get("header_unit"))
           for e in ((ex.get("checks") or {}).get("e01") or [])}
    old_units = (prev.get("overrides") or {}).get("units") or {}
    old_ev = (prev.get("overrides") or {}).get("unit_evidence") or {}
    units, evidence, notes = {}, {}, []
    for col, unit in old_units.items():
        if col not in now:
            continue   # 이번 입력에서는 단위를 물을 필요가 없는 열(헤더에 단위가 생김·열 없음) — 이어받지 않음
        if old_ev.get(col) == now[col]:
            units[col], evidence[col] = unit, now[col]
        else:
            why = "이전 기록에 근거가 없음" if col not in old_ev else "그 열이 든 RAW 파일 내용이 바뀜"
            notes.append(f"열 '{col}': 이전 실행 확정 단위 '{unit}' — {why}, 다시 확인")
    return units, evidence, notes


def _fresh(item: dict, event: str | None = None, rnd: int = 0) -> dict:
    item.update(status="pending", answer=None, history=[], changed=True)
    if event:
        item["history"].append({"round": rnd, "at": _now(), "event": event})
    return item


def _merge(old_items: list[dict], new_items: list[dict], rnd: int, reset_ids: set[str]) -> tuple[list[dict], list[dict]]:
    """제안 해시가 같으면 앞선 상태 유지, 다르면 다시 묻는다. reset_ids 는 해시와 상관없이 다시 묻는다(3-1 수정 항목)."""
    old = {i["id"]: i for i in old_items}
    merged = []
    for n in new_items:
        o = old.get(n["id"])
        if o is None:
            merged.append(_fresh(n, "새 항목", rnd))
        elif o["proposal_hash"] != n["proposal_hash"] or n["id"] in reset_ids:
            f = _fresh(n, None, rnd)
            f["history"] = o.get("history", []) + [{
                "round": rnd, "at": _now(),
                "event": "제안이 바뀜 — 다시 확인" if o["proposal_hash"] != n["proposal_hash"] else "수정 요청 후 재추출 결과 — 다시 확인",
                "old_hash": o["proposal_hash"][:12], "new_hash": n["proposal_hash"][:12]}]
            f["previous_answer"] = o.get("answer")
            merged.append(f)
        else:
            keep = {k: o.get(k) for k in ("status", "answer", "history", "carried_from")}
            merged.append({**n, **keep, "changed": False})
    removed = [o for o in old_items if o["id"] not in {n["id"] for n in new_items}]
    return merged, removed


def _raw_paths(run_id: str, snap: dict) -> list[tuple[str, Path]]:
    root = workspace.run_dir(run_id) / "data"
    return [(f["path"], root / f["path"]) for f in snap["files"] if f["zone"] == "data" and f["category"] == "raw"]


def _corrected_spec(ex: dict, overrides: dict) -> list[dict]:
    items = copy.deepcopy((ex.get("spec") or {}).get("items", []))
    for sp in items:
        for e in ((sp.get("analysis") or {}).get("entries") or []):
            fix = overrides.get(I.spec_entry_id(sp["file"], e))
            if fix:
                for k in ("min", "max"):
                    if fix.get(k) not in (None, ""):
                        e[k] = float(fix[k])
                if fix.get("unit"):
                    e["unit"] = fix["unit"]
                e["user_corrected"] = fix
    return items


def _recompute_checks(p: dict, run_id: str, snap: dict, state: dict) -> dict:
    """2-3 을 확정 단위·수정된 사양으로 다시 계산(PY)."""
    ex = load_extract(p["extract"])
    checks = datacheck.check(_raw_paths(run_id, snap), (ex.get("headers") or {}).get("groups", []),
                             _corrected_spec(ex, state["overrides"]["spec"]), ex.get("plan"), state["overrides"]["units"])
    checks["recomputed_in_confirm"] = {"round": state["round"], "units": state["overrides"]["units"],
                                       "spec_corrections": list(state["overrides"]["spec"])}
    (p["extract"] / "data_checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding="utf-8")
    return checks


def _view(state: dict) -> dict:
    items = state["items"]
    counts = {s: sum(1 for i in items if i["status"] == s) for s in
              ("pending", "approved", "corrected", "corrected_applied", "decided", "answered", "skipped", "unresolved", "remeasure")}
    counts["required_open"] = sum(1 for i in items if i["required"] and i["status"] not in FINAL)
    return {**state, "counts": counts, "sections": I.SECTION_TITLES, "max_rounds": MAX_ROUNDS}


def get(run_id: str) -> dict:
    p = _paths(run_id)
    if not p["state"].exists():
        raise ValueError("아직 3 CONFIRM 을 시작하지 않음")
    return _view(json.loads(p["state"].read_text(encoding="utf-8")))


def start(run_id: str) -> dict:
    p = _paths(run_id)
    if p["state"].exists():
        return get(run_id)
    snap = json.loads(p["snapshot"].read_text(encoding="utf-8"))
    ex = load_extract(p["extract"])
    state = {"run_id": run_id, "project": snap["project"], "created_at": _now(), "round": 0, "status": "open",
             "overrides": {"units": {}, "spec": {}, "corrections": []}, "rounds": [], "messages": [],
             "spec_settled": False, "code_key": _code_key(snap, ex), "removed_items": []}
    reuse = _registry_lookup(state["code_key"])
    if reuse:
        state["code_reuse"] = {k: reuse.get(k) for k in ("sha256", "run_id", "approved_by", "at", "path")}
    prev = _previous_state(snap["project"], run_id)
    if prev:   # 이전 실행에서 확정한 단위·사양 수정 — 사양 항목의 제안이 같을 때만 이어받고, 2-3 을 그 값으로 다시 계산
        old_items = {i["id"]: i for i in prev["items"]}
        spec_now = {i["id"]: i["proposal_hash"] for i in I.build(ex, state) if i["section"] == "3-2"}
        state["overrides"]["spec"] = {k: v for k, v in prev.get("overrides", {}).get("spec", {}).items()
                                      if k in spec_now and old_items.get(k, {}).get("proposal_hash") == spec_now[k]}
        # 단위는 근거(그 열이 든 RAW 파일 내용·헤더)가 지금 입력과 같을 때만 이어받는다 — 열 이름만 같다고 옮기지 않음
        units, evidence, unit_notes = _carry_units(prev, ex, snap)
        state["overrides"]["units"], state["overrides"]["unit_evidence"] = units, evidence
        state["messages"] += unit_notes
        if state["overrides"]["spec"] or state["overrides"]["units"]:
            _recompute_checks(p, run_id, snap, state)
            ex = load_extract(p["extract"])
            state["messages"].append("이전 실행에서 확정한 단위·사양 수정으로 2-3 을 다시 계산함")
    items = [_fresh(i) for i in I.build(ex, state)]
    for i in items:
        i["changed"] = False
    if prev:   # 재실행: 같은 항목·같은 제안 해시면 이어받고, 다르면 해시 차이를 기록
        old = {i["id"]: i for i in prev["items"]}
        for i in items:
            o = old.get(i["id"])
            if o is None:
                continue
            if i["kind"] == "unit" and i["proposal"].get("column") not in state["overrides"]["units"]:
                # 단위 답은 근거(파일 내용)가 같아 _carry_units 가 이어받은 것만 — 질문 문구가 같아도 답을 옮기지 않음
                if o.get("answer"):
                    i["previous_answer"] = o.get("answer")
                continue
            if o["proposal_hash"] == i["proposal_hash"] and o["status"] in FINAL - {"unresolved", "remeasure"}:
                i.update(status=o["status"], answer=o.get("answer"), carried_from=prev["run_id"])
                i["history"].append({"round": 0, "at": _now(), "event": f"이전 실행 {prev['run_id']} 에서 확정 — 제안 해시 같음, 다시 묻지 않음"})
            elif o["proposal_hash"] != i["proposal_hash"]:
                i["history"].append({"round": 0, "at": _now(), "event": f"이전 실행 {prev['run_id']} 과 제안이 다름",
                                     "old_hash": o["proposal_hash"][:12], "new_hash": i["proposal_hash"][:12]})
        state["messages"].append(f"같은 프로젝트의 이전 실행 {prev['run_id']} 의 확인 결과를 대조함")
    for i in items:   # 같은 입력으로 승인된 코드 재사용 (지금 규칙의 정적 점검을 통과할 때만)
        if i["id"] == "3-1:code" and reuse and i["proposal"].get("sha256") == reuse["sha256"] and i["status"] == "pending" \
                and not i["proposal"].get("static_problems"):
            i.update(status="approved", answer={"choice": "approve", "respondent": reuse.get("approved_by"),
                                                "at": reuse.get("at"), "note": "같은 입력으로 승인된 코드 재사용"},
                     carried_from=reuse.get("run_id"))
            i["history"].append({"round": 0, "at": _now(), "event": f"승인된 코드 재사용 (해시 {reuse['sha256'][:12]})"})
    state["items"] = items
    state["spec_settled"] = _spec_settled(items)
    _save(p, state)
    if prev and not any(i["required"] and i["status"] not in FINAL for i in items):
        # 같은 입력의 재실행 — 필수 항목을 모두 이전 실행에서 이어받아 물을 것이 없다. 확정은 제출 때만 하던 탓에
        # (빈 제출은 거절) 여기서 끝낼 방법이 없었다 → 이어받은 답으로 바로 확정한다 (2026-09-30 실제 API 확인에서 발견)
        state["messages"].append(f"필수 항목을 모두 이전 실행 {prev['run_id']} 에서 이어받아 바로 확정함")
        state["confirmed"] = finalize(p, state, ex, snap)
        state["status"] = "complete"
        _save(p, state)
    return _view(state)


def _spec_settled(items: list[dict]) -> bool:
    spec = [i for i in items if i["section"] == "3-2"]
    return bool(spec) and all(i["status"] in ("approved", "corrected_applied") for i in spec)


def _validate(item: dict, a: dict) -> str | None:
    choice = a.get("choice")
    if choice not in item["inputs"]:
        return f"{item['title']}: 고를 수 없는 답 '{choice}'"
    if item["kind"] == "code" and choice == "approve" and item["proposal"].get("static_problems"):
        return (f"{item['title']}: 격리 실행 규칙을 어기는 코드는 승인할 수 없음 "
                f"({'; '.join(item['proposal']['static_problems'][:3])}) — '거부'로 다시 작성을 요청")
    if choice in ("correct", "reject", "answer") and not (a.get("text") or "").strip() and not a.get("fields"):
        return f"{item['title']}: 수정 내용(글)을 적어 주세요"
    if choice == "value":
        v = (a.get("value") or "").strip()
        if not v or parse_unit(v) is None:
            return f"{item['title']}: 단위 '{v}' 를 해석할 수 없음 (예: A, mA, V, nS, ohm)"
    if item["kind"] == "spec" and choice == "correct":
        f = a.get("fields") or {}
        for k in ("min", "max"):
            if f.get(k) not in (None, ""):
                try:
                    float(f[k])
                except (TypeError, ValueError):
                    return f"{item['title']}: {k} 는 숫자여야 함"
        if f.get("unit") and parse_unit(f["unit"]) is None:
            return f"{item['title']}: 단위 '{f['unit']}' 를 해석할 수 없음"
    return None


def submit(run_id: str, respondent: str, answers: dict, llm=None) -> dict:
    p = _paths(run_id)
    state = json.loads(p["state"].read_text(encoding="utf-8")) if p["state"].exists() else None
    if state is None:
        raise ValueError("먼저 3 CONFIRM 을 시작")
    if state["status"] != "open":
        raise ValueError(f"이미 끝난 확인 단계 (상태: {state['status']})")
    respondent = (respondent or "").strip()
    if not respondent:
        raise ValueError("응답자 이름을 적어 주세요 (모든 답변은 응답자·시각과 함께 기록)")
    by_id = {i["id"]: i for i in state["items"]}
    errors = [f"없는 항목 {k}" for k in answers if k not in by_id]
    errors += [e for k, a in answers.items() if k in by_id and (e := _validate(by_id[k], a))]
    if errors:
        raise ValueError(" / ".join(errors))
    if not answers:
        raise ValueError("제출할 답이 없음")

    rnd = state["round"] + 1
    at = _now()
    p["confirm"].mkdir(parents=True, exist_ok=True)
    corrected_31, spec_changed, units_changed = [], False, False
    with p["answers"].open("a", encoding="utf-8") as log:
        for k, a in answers.items():
            item = by_id[k]
            rec = {"choice": a["choice"], "text": (a.get("text") or "").strip(), "value": (a.get("value") or "").strip(),
                   "fields": a.get("fields") or {}, "respondent": respondent, "at": at, "round": rnd}
            log.write(json.dumps({"run_id": run_id, "item_id": k, "proposal_hash": item["proposal_hash"], **rec},
                                 ensure_ascii=False) + "\n")
            item["answer"] = rec
            item["history"].append({"round": rnd, "at": at, "event": f"답변: {a['choice']}", "respondent": respondent})
            c = a["choice"]
            if c == "approve":
                item["status"] = "approved"
            elif c in ("correct", "reject"):
                if item["section"] == "3-2":
                    item["status"] = "corrected_applied"
                    state["overrides"]["spec"][k] = {**(a.get("fields") or {}), "note": rec["text"], "round": rnd}
                    spec_changed = True
                else:
                    item["status"] = "corrected"
                    corrected_31.append(item)
                    state["overrides"]["corrections"].append({"item_id": k, "title": item["title"], "text": rec["text"],
                                                              "round": rnd, "respondent": respondent})
            elif c == "proceed":
                item["status"] = "decided"
            elif c in ("upload", "remeasure"):
                item["status"] = "remeasure"
            elif c == "value":
                item["status"] = "decided"
                col = item["proposal"]["column"]
                state["overrides"]["units"][col] = rec["value"]
                ev = state["overrides"].setdefault("unit_evidence", {})
                if item["proposal"].get("files") is not None:   # 3-3 질문 항목 — 지금 입력을 근거로 기록
                    ev[col] = _unit_evidence(json.loads(p["snapshot"].read_text(encoding="utf-8")),
                                             item["proposal"]["files"], item["proposal"].get("header_unit"))
                units_changed = True
            elif c == "answer":
                item["status"] = "answered"
            elif c == "skip":
                item["status"] = "skipped"

    messages = []
    if corrected_31:   # 3-1 수정 → EXTRACT 재실행 (2-1a·2-2 는 캐시, 2-1c·2-4 는 수정 반영)
        shutil.copytree(p["extract"], p["confirm"] / "rounds" / f"r{rnd}_extract_before", dirs_exist_ok=True)
        lines = [f"- [{c['title']}] {c['text']}" for c in state["overrides"]["corrections"]]
        lines += [f"- [질문 {i['proposal']['from']}] {i['proposal']['q']} → 답: {i['answer']['text']}"
                  for i in state["items"] if i["status"] == "answered"]
        result = run_extract(run_id, llm, corrections="\n".join(lines), units=state["overrides"]["units"],
                             during_confirm=True)
        failed = {k: v for k, v in result["steps"].items() if v["status"] == "error"}
        messages.append(f"3-1 수정 {len(corrected_31)}건을 반영해 2 EXTRACT 를 다시 실행함"
                        + (f" — 실패: {', '.join(failed)}" if failed else ""))
    snap = json.loads(p["snapshot"].read_text(encoding="utf-8"))
    if spec_changed or units_changed or state["overrides"]["spec"] or corrected_31:
        if spec_changed or units_changed or state["overrides"]["spec"]:
            _recompute_checks(p, run_id, snap, state)
            messages.append("확정 단위·수정된 사양으로 2-3 을 다시 계산함")

    ex = load_extract(p["extract"])
    state["round"] = rnd
    state["code_key"] = _code_key(snap, ex)
    state["spec_settled"] = _spec_settled(state["items"])
    new_items = I.build(ex, state)
    merged, removed = _merge(state["items"], new_items, rnd, {c["id"] for c in corrected_31})
    for m in merged:   # 확정 단위 기록 항목 — 제안이 '확정값'으로 바뀌어도 다시 묻지 않는다
        if m.get("settled"):
            m.update(status="decided", changed=False,
                     answer=m.get("answer") or m.get("previous_answer") or {"value": m["proposal"]["confirmed"]})
    state["items"] = merged
    state["removed_items"] += [{"id": r["id"], "title": r["title"], "round": rnd, "last_status": r["status"]} for r in removed]
    state["spec_settled"] = _spec_settled(merged)
    changed = [i["id"] for i in merged if i.get("changed")]
    if changed:
        messages.append(f"다시 확인할 항목 {len(changed)}개 (새로 생기거나 제안이 바뀜)")
    if rnd >= MAX_ROUNDS:
        left = [i for i in merged if i["required"] and i["status"] not in FINAL]
        for i in left:
            i["status"] = "unresolved"
            i["history"].append({"round": rnd, "at": _now(), "event": f"피드백 {MAX_ROUNDS}회 뒤에도 미확정"})
        state["status"] = "closed"
        if left:
            messages.append(f"피드백 {MAX_ROUNDS}회 소진 — 미확정 {len(left)}개 (의존하는 주장은 Unsupported, E06 '미확정')")
    state["rounds"].append({"round": rnd, "at": at, "respondent": respondent, "answers": len(answers),
                            "corrections_3_1": len(corrected_31), "extract_rerun": bool(corrected_31),
                            "checks_recomputed": bool(spec_changed or units_changed), "changed_items": changed,
                            "messages": messages})
    state["messages"] = messages
    if not any(i["required"] and i["status"] not in FINAL for i in merged):
        state["confirmed"] = finalize(p, state, ex, snap)
        state["status"] = "complete" if state["status"] == "open" else state["status"]
    _save(p, state)
    return _view(state)


def finalize(p: dict, state: dict, ex: dict, snap: dict) -> dict:
    """confirmed.json + 승인 코드(해시 고정·읽기 전용) + 코드 등록부 + 1-3 장부."""
    plan = ((ex.get("plan") or {}).get("analysis")) or {}
    by_id = {i["id"]: i for i in state["items"]}
    code_item = by_id.get("3-1:code")
    code = None
    if code_item and code_item["status"] == "approved":
        body = code_item["proposal"]["code"]
        sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
        path = p["confirm"] / "approved_code.py"
        if path.exists():
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
        path.write_text(f"# MeasureTrace 승인된 계산 코드 — 3-1 승인 · 해시 고정 · 4-1 에서만 실행\n"
                        f"# sha256(본문) = {sha}\n# 승인: {code_item['answer'].get('respondent')} · {code_item['answer'].get('at')}\n\n"
                        + body, encoding="utf-8")
        os.chmod(path, stat.S_IREAD)
        code = {"sha256": sha, "path": rel(path), "approved_by": code_item["answer"].get("respondent"),
                "approved_at": code_item["answer"].get("at"), "reused_from": code_item.get("carried_from")}
        store = OUTPUTS_DIR / "approved_code"
        store.mkdir(parents=True, exist_ok=True)
        if not (store / f"{sha}.py").exists():
            (store / f"{sha}.py").write_text(body, encoding="utf-8")
            os.chmod(store / f"{sha}.py", stat.S_IREAD)
        if not code_item.get("carried_from"):
            with (OUTPUTS_DIR / REGISTRY).open("a", encoding="utf-8") as reg:
                reg.write(json.dumps({"key": state["code_key"], "sha256": sha, "path": rel(store / f"{sha}.py"),
                                      "run_id": state["run_id"], "approved_by": code["approved_by"], "at": code["approved_at"]},
                                     ensure_ascii=False) + "\n")
    spec_items = _corrected_spec(ex, state["overrides"]["spec"])
    decisions = [{"id": i["id"], "title": i["title"], "file": i["proposal"].get("file"), "column": i["proposal"].get("column"),
                  "kind": i["proposal"].get("kind"), "count": i["proposal"].get("count"), "decision": i["status"],
                  "answer": i.get("answer")} for i in state["items"] if i["kind"] == "anomaly"]
    confirmed = {
        "step": "3 CONFIRM", "run_id": state["run_id"], "project": state["project"], "confirmed_at": _now(),
        "rounds": state["round"], "status": "미확정 포함" if any(i["status"] == "unresolved" for i in state["items"]) else "확정",
        "plan_file": (ex.get("equations") or {}).get("plan_file"), "plan_sha256": (ex.get("equations") or {}).get("plan_sha256"),
        "equations": [{"id": e["id"], "latex": e.get("latex"), "status": by_id.get(f"3-1:eq:{e['id']}", {}).get("status")}
                      for e in (ex.get("equations") or {}).get("equations", [])],
        "formulas": plan.get("formulas"), "processing": plan.get("processing"), "design": plan.get("design"),
        "test": plan.get("test"), "matching": plan.get("matching"), "reported_quantities": plan.get("reported_quantities"),
        "code": code,
        "spec": [{"file": sp["file"], "entries": (sp.get("analysis") or {}).get("entries", []),
                  "overflow_values": (sp.get("analysis") or {}).get("overflow_values", [])} for sp in spec_items],
        "units": state["overrides"]["units"], "corrections": state["overrides"]["corrections"],
        "data_decisions": decisions,
        "missing": {"e03": ((ex.get("missing") or {}).get("comparison") or {}).get("e03", []),
                    "decision": by_id.get("3-1:missing", {}).get("status")},
        "unresolved": [{"id": i["id"], "section": i["section"], "title": i["title"]} for i in state["items"] if i["status"] == "unresolved"],
        "remeasure": [{"id": i["id"], "title": i["title"]} for i in state["items"] if i["status"] == "remeasure"],
        "answers_log_sha256": hashlib.sha256(p["answers"].read_bytes()).hexdigest() if p["answers"].exists() else None,
        "extract_hashes": {n: hashlib.sha256((p["extract"] / f).read_bytes()).hexdigest()
                           for n, f in EXTRACT_FILES.items() if (p["extract"] / f).exists()},
    }
    out = p["confirm"] / "confirmed.json"
    out.write_text(json.dumps(confirmed, ensure_ascii=False, indent=2), encoding="utf-8")
    written = [out] + ([p["confirm"] / "approved_code.py"] if code else [])
    entry = ledger.record("3 CONFIRM", state["run_id"], I.phash(confirmed["extract_hashes"]) , ledger.code_hash(*CONFIRM_CODE),
                          {"rounds": state["round"], "code_sha256": code and code["sha256"],
                           "unresolved": len(confirmed["unresolved"])}, written)
    return {"path": rel(out), "status": confirmed["status"], "code": code, "unresolved": confirmed["unresolved"],
            "remeasure": confirmed["remeasure"], "lineage": entry}
