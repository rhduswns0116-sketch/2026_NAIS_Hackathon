"""3 CONFIRM 질문 만들기 [PY] — 2 EXTRACT 결과에서 규칙으로 확인 항목을 만든다(LLM 없음).

항목마다 proposal(도구가 읽은 것)과 그 해시를 둔다. 라운드가 바뀌어도 해시가 같으면 앞선 답을 유지하고(다시 묻지 않음),
해시가 달라지면 다시 묻는다 — v4 "바뀐 항목만 다시 묻는다". 보고서 수치는 어떤 질문에도 나오지 않는다(보고서 미개봉).

항목 종류(kind)와 받을 수 있는 답(input)
  3-1  equation · processing · design · test · matching   approve | correct(글)
       code                                              approve | reject(이유)
       missing                                           proceed(누락 인정) | upload(추가 업로드 — 새 실행) | approve(누락 없음)
  3-2  spec · overflow                                   approve | correct(min·max·unit·글)
  3-3  unit (E01)                                        value(단위 표기)
       anomaly (E02 묶음)                                proceed(그대로 진행) | remeasure(재측정 — 새 실행)
  Q    question (2단계 LLM 질문, 선택)                    answer(글) | skip
"""
from __future__ import annotations

import hashlib
import json

from measuretrace.recompute import sandbox

SECTION_TITLES = {"3-1": "데이터 해석 승인", "3-2": "장비 사양 확인", "3-3": "데이터 이상 확인", "Q": "추가 확인 (선택)"}
MAX_ROWS_SHOWN = 50


def phash(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()


def _sid(*parts) -> str:
    return hashlib.sha256("\x1f".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:8]


def spec_entry_id(file: str, e: dict) -> str:
    return "3-2:spec:" + _sid(file, e.get("quantity"), e.get("range_label"), e.get("page"))


def _item(id_, section, kind, title, question, proposal, inputs, required=True, **extra) -> dict:
    return {"id": id_, "section": section, "kind": kind, "title": title, "question": question,
            "proposal": proposal, "proposal_hash": phash(proposal), "inputs": inputs, "required": required, **extra}


def build(ex: dict, state: dict) -> list[dict]:
    """ex: load_extract() 결과. state: 현재 확인 상태(확정 단위·사양 수정 반영 여부 표시용)."""
    items: list[dict] = []
    plan = ((ex.get("plan") or {}).get("analysis")) or {}
    formulas = {f["eq_id"]: f for f in plan.get("formulas", [])}

    # ── 3-1 데이터 해석 승인 ─────────────────────────────────────────────
    for e in (ex.get("equations") or {}).get("equations", []):
        f = formulas.get(e["id"], {})
        prop = {"latex": e.get("latex"), "sentence": e.get("sentence"), "purpose": f.get("purpose", ""),
                "role": f.get("role", ""), "variables": f.get("variables", []), "omml_sha256": e.get("omml_sha256")}
        if e.get("status") == "ok":
            items.append(_item(f"3-1:eq:{e['id']}", "3-1", "equation", f"{e['id']} 식",
                               f"수식 {e['id']} 를 이렇게 읽고, 이 뜻으로 계산에 쓰는 게 맞나요?", prop, ["approve", "correct"]))
        else:
            items.append(_item(f"3-1:eq:{e['id']}", "3-1", "equation", f"{e['id']} 식 (변환 실패)",
                               f"계획서의 수식 {e['id']} 를 읽지 못했습니다({e.get('error')}). 식을 직접 적어 주세요.",
                               prop, ["correct"]))
    if plan:
        items.append(_item("3-1:processing", "3-1", "processing", "가공 방법 (raw → 계산 입력값)",
                           "RAW 를 이 순서로 가공해 계산 입력값을 만드는 게 맞나요?", {"steps": plan.get("processing", [])},
                           ["approve", "correct"]))
        items.append(_item("3-1:design", "3-1", "design", "실험 설계 (독립 단위·반복 수)",
                           "설계를 이렇게 읽었습니다. 독립 단위와 반복 수가 맞나요? (보고서의 n·자유도 대조 E04 에 씀)",
                           plan.get("design", {}), ["approve", "correct"]))
        items.append(_item("3-1:test", "3-1", "test", "검정 방법", "계획서의 검정 방법을 이렇게 읽었습니다. 맞나요?",
                           plan.get("test", {}), ["approve", "correct"]))
        items.append(_item("3-1:matching", "3-1", "matching", "실험 ↔ 데이터 ↔ 식 ↔ 장비",
                           "이 실험을 이 데이터 열·식·장비(범위)로 계산하는 게 맞나요?", {"rows": plan.get("matching", [])},
                           ["approve", "correct"]))
        code = plan.get("code") or {}
        if code.get("code"):
            reuse = state.get("code_reuse")
            items.append(_item("3-1:code", "3-1", "code", "계산 코드",
                               "위 식·가공 방법을 이 코드로 계산합니다. 승인하면 코드 해시를 고정하고 4-1 에서만 실행합니다.",
                               {"code": code["code"], "explanation": code.get("explanation", ""),
                                "sha256": hashlib.sha256(code["code"].encode("utf-8")).hexdigest(),
                                "static_problems": sandbox.static_check(code["code"])},   # 4-1 과 같은 검사
                               ["approve", "reject"], reuse=reuse))
        else:   # 코드 초안이 없으면 확정할 수 없다 — 다시 작성 요청만 받는다 (없는 채로 '완료'되지 않게)
            items.append(_item("3-1:code", "3-1", "code", "계산 코드 (없음)",
                               "계산 코드 초안을 만들지 못했습니다. '거부 — 다시 작성'으로 다시 만들기를 요청하세요.",
                               {"code": None, "error": (ex.get("plan") or {}).get("code_error") or "코드 초안 없음"},
                               ["reject"]))
    elif ex.get("equations"):   # 계획서는 있는데 2-1c 가 실패 — 식·설계·코드를 확인할 수 없다
        items.append(_item("3-1:plan", "3-1", "plan_missing", "연구 내용 추출 (실패)",
                           "2-1c 연구 내용 추출에 실패해 식·가공 방법·설계·코드를 확인할 수 없습니다. '거부 — 다시 작성'으로 다시 추출을 요청하세요.",
                           {"error": (ex.get("plan") or {}).get("error") or "추출 결과 없음"}, ["reject"]))
    miss = (ex.get("missing") or {}).get("comparison")
    if miss is not None:
        e03 = miss.get("e03", [])
        if e03:
            items.append(_item("3-1:missing", "3-1", "missing", f"E03 필요 데이터 누락 {len(e03)}건",
                               "계획서가 요구하는데 입력에 없는 데이터입니다. 추가로 올리시겠어요, 아니면 누락을 인정하고 진행할까요? "
                               "(누락 데이터가 필요한 주장은 Unsupported)",
                               {"e03": e03, "unlisted_raw_files": miss.get("unlisted_raw_files", [])}, ["proceed", "upload"]))
        else:
            items.append(_item("3-1:missing", "3-1", "missing", "누락 점검 결과",
                               f"계획서가 요구하는 시료 {miss.get('required_samples')}개와 측정이 모두 있습니다. 이 목록이 맞나요?",
                               {"e03": [], "required_samples": miss.get("required_samples"),
                                "unlisted_raw_files": miss.get("unlisted_raw_files", [])}, ["approve", "correct"]))

    # ── 3-2 장비 사양 확인 ───────────────────────────────────────────────
    for sp in (ex.get("spec") or {}).get("items", []):
        a = sp.get("analysis") or {}
        for e in a.get("entries", []):
            prop = {k: e.get(k) for k in ("quantity", "dimension", "range_label", "min", "max", "unit", "accuracy",
                                          "resolution", "condition", "page", "quote", "verified", "verify_notes")}
            lim = f"{e.get('min') if e.get('min') is not None else '—'} ~ {e.get('max') if e.get('max') is not None else '—'} {e.get('unit')}"
            items.append(_item(spec_entry_id(sp["file"], e), "3-2", "spec", f"{e.get('quantity')} · {e.get('range_label')}",
                               f"사양서 {e.get('page')}쪽을 읽어 보니 {e.get('range_label')} 범위의 측정 한계는 {lim}"
                               f"{', 정확도 ' + e['accuracy'] if e.get('accuracy') else ''} 입니다. 맞게 읽었나요?",
                               prop, ["approve", "correct"], file=sp["file"]))
        for o in a.get("overflow_values", []):
            items.append(_item("3-2:overflow:" + _sid(sp["file"], o.get("value"), o.get("page")), "3-2", "overflow",
                               f"오버플로 표시값 {o.get('value')}",
                               f"사양서 {o.get('page')}쪽: 범위 밖 측정은 {o.get('value')} 로 기록된다고 읽었습니다. 맞나요?",
                               o, ["approve", "correct"], file=sp["file"]))

    # ── 3-3 데이터 이상 확인 ─────────────────────────────────────────────
    checks = ex.get("checks") or {}
    confirmed_units = state.get("overrides", {}).get("units", {})
    for e in checks.get("e01", []):
        items.append(_item(f"3-3:unit:{e['column']}", "3-3", "unit", f"E01 {e['kind']} — {e['column']}",
                           f"열 '{e['column']}' 의 단위가 {'없습니다' if e['kind'] == '단위 없음' else '모호합니다(' + str(e['header_unit']) + ')'}."
                           f"{' 제안: ' + e['suggestion'] + '.' if e.get('suggestion') else ''} 단위를 적어 주세요.",
                           {"column": e["column"], "header_unit": e.get("header_unit"), "suggestion": e.get("suggestion"),
                            "files": e["files"]}, ["value"]))
    for col, unit in confirmed_units.items():   # 확정된 단위는 기록으로 남김(다시 묻지 않음)
        if not any(i["id"] == f"3-3:unit:{col}" for i in items):
            items.append(_item(f"3-3:unit:{col}", "3-3", "unit", f"E01 단위 확정 — {col}", f"열 '{col}' 의 단위",
                               {"column": col, "confirmed": unit}, ["value"], required=False, settled=True))
    spec_ok = state.get("spec_settled", False)
    groups: dict[tuple, list] = {}
    for f in checks.get("e02", []):
        groups.setdefault((f["file"], f["column"], f["kind"]), []).append(f)
    totals = {(g["file"], g["column"], g["kind"]): g["count"] for g in checks.get("e02_groups", [])}
    for (file, column, kind), rows in groups.items():
        provisional = kind in ("사양 범위 밖", "오버플로 표시값")
        status = ("확정 (사양 확인됨)" if spec_ok else "잠정 (사양 확인 전)") if provisional else "탐지"
        count = totals.get((file, column, kind), len(rows))
        prop = {"file": file, "column": column, "kind": kind, "count": count, "state": status,
                "rows": [{"line": r["line"], "value": r["value"], "limit": r.get("limit"),
                          "spec_ref": r.get("spec_ref")} for r in rows[:MAX_ROWS_SHOWN]]}
        items.append(_item(f"3-3:e02:{_sid(file, column, kind)}", "3-3", "anomaly", f"E02 {kind} — {file} · {column} ({count}건)",
                           "이 값들을 어떻게 할까요? 재측정하면 파일을 다시 올려 1단계부터 새로 실행합니다(원본은 지우지 않음). "
                           "그대로 진행하면 결정을 기록하고 판정은 바꾸지 않습니다.",
                           {**prop, "rows": prop["rows"]}, ["proceed", "remeasure"]))

    # ── Q 추가 확인 (2단계 LLM 질문) ───────────────────────────────────────
    for q in (ex.get("summary") or {}).get("questions", []):
        items.append(_item("Q:" + _sid(q["from"], q["q"]), "Q", "question", f"[{q['from']}]", q["q"],
                           {"from": q["from"], "q": q["q"]}, ["answer", "skip"], required=False))
    return items
