"""1-1 입력 격리 — 웹 화면에서 올린 파일을 실행마다 새 입력 폴더에 사본으로 받고 읽기 전용으로 잠근다.

연구자 PC 의 원본은 브라우저가 읽어 보내기만 하므로 건드리지 않는다. 사본은 지우지 않는다(R5 원본 보존).
연구 자료(data)와 보고서(report)는 서로 다른 폴더로 받는다.
"""
from __future__ import annotations

import os
import re
import secrets
import stat
from datetime import datetime
from pathlib import Path, PurePosixPath

from measuretrace.paths import INPUTS_DIR, OUTPUTS_DIR

ZONES = ("data", "report")
_RUN_ID = re.compile(r"^\d{8}-\d{6}-[0-9a-f]{4}$")
_PROJECT = re.compile(r"[^0-9A-Za-z가-힣_.-]+")


def new_run() -> str:
    run_id = f"{datetime.now():%Y%m%d-%H%M%S}-{secrets.token_hex(2)}"
    for zone in ZONES:
        (INPUTS_DIR / run_id / zone).mkdir(parents=True, exist_ok=False)
    return run_id


def run_dir(run_id: str) -> Path:
    if not _RUN_ID.match(run_id or ""):
        raise ValueError("실행 ID 형식 오류")
    path = INPUTS_DIR / run_id
    if not path.is_dir():
        raise ValueError("없는 실행 ID")
    return path


def project_name(text: str | None) -> str:
    name = _PROJECT.sub("_", (text or "").strip()).strip("._") or "default"
    return name[:60]


def safe_relpath(text: str) -> PurePosixPath:
    """브라우저가 보낸 상대 경로(폴더/파일) — 절대 경로·'..'·드라이브 문자는 거부."""
    parts = [p for p in text.replace("\\", "/").split("/") if p not in ("", ".")]
    if not parts or any(p == ".." or ":" in p for p in parts):
        raise ValueError(f"허용하지 않는 경로: {text!r}")
    return PurePosixPath(*parts)


SEAL = ".ingested"   # 1 INGEST 를 마치면 입력 폴더에 남기는 표시 — 이후 입력은 바뀌지 않는다


def is_sealed(run_id: str) -> bool:
    return (run_dir(run_id) / SEAL).exists()


def seal(run_id: str, project: str) -> None:
    (run_dir(run_id) / SEAL).write_text(project, encoding="utf-8")


def save_upload(run_id: str, zone: str, rel: str, stream, length: int) -> dict:
    if zone not in ZONES:
        raise ValueError("zone 은 data 또는 report")
    if is_sealed(run_id):
        raise ValueError("1 INGEST 를 마친 실행에는 파일을 더할 수 없음 — 파일을 바꾸려면 새로 시작(새 실행)")
    root = run_dir(run_id) / zone
    rel_path = safe_relpath(rel)
    target = root.joinpath(*rel_path.parts)
    if target.exists():
        raise ValueError(f"같은 경로의 파일이 이미 있음: {rel_path}")
    target.parent.mkdir(parents=True, exist_ok=True)
    remaining = length
    with target.open("wb") as out:
        while remaining > 0:
            chunk = stream.read(min(1024 * 1024, remaining))
            if not chunk:
                break
            out.write(chunk)
            remaining -= len(chunk)
    if remaining:
        target.unlink(missing_ok=True)
        raise ValueError("업로드가 중간에 끊김")
    os.chmod(target, stat.S_IREAD)   # 사본을 읽기 전용으로 잠금
    return {"path": rel_path.as_posix(), "bytes": length}


def list_inputs(run_id: str) -> list[tuple[str, str, Path]]:
    """(zone, 상대 경로, 실제 경로) — 경로 순."""
    root = run_dir(run_id)
    out = []
    for zone in ZONES:
        base = root / zone
        for path in sorted(base.rglob("*")):
            if path.is_file():
                out.append((zone, path.relative_to(base).as_posix(), path))
    return out


def output_dir(project: str, run_id: str) -> Path:
    path = OUTPUTS_DIR / project / run_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def previous_snapshot_path(project: str, run_id: str) -> Path | None:
    """같은 프로젝트에서 가장 최근에 끝난 다른 실행의 스냅샷 (스냅샷 저장 시각 기준)."""
    base = OUTPUTS_DIR / project
    if not base.is_dir():
        return None
    snaps = [d / "ingest_snapshot.json" for d in base.iterdir()
             if d.is_dir() and d.name != run_id and (d / "ingest_snapshot.json").exists()]
    return max(snaps, key=lambda x: x.stat().st_mtime_ns) if snaps else None
