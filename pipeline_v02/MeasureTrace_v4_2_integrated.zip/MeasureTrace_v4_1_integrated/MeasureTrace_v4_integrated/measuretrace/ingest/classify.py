"""1-1 유형 분류 — 규칙만 쓴다(LLM 없음). 결과는 분류 후보와 근거이며 확정은 3 CONFIRM.

v4 §3 입력: RAW_DATA · 연구 계획서(.docx, Word 수식) · 장비 사양서(PDF) · 최종 보고서 초안(별도 경로)
사용하지 않음: PROCESSED_DATA(순환 검증 방지) · Figure — 목록에는 남기고 계산에서 뺀다.
"""
from __future__ import annotations

import re
from pathlib import Path

CATEGORIES = {
    "raw": "RAW 데이터",
    "plan": "연구 계획서",
    "spec": "장비 사양서",
    "report": "최종 보고서 초안",
    "processed": "가공 데이터 (사용 안 함)",
    "figure": "그림 (사용 안 함)",
    "script": "스크립트 (실행 안 함)",
    "system": "시스템·임시 파일 (제외)",
    "unknown": "미분류 (확인 필요)",
}
USED = {"raw", "plan", "spec", "report"}   # 다음 단계로 넘어가는 분류

SYSTEM_NAMES = {".ds_store", "thumbs.db", "desktop.ini"}
SCRIPT_SUFFIXES = {".py", ".ipynb", ".r", ".m", ".jl", ".sh", ".bat", ".cmd", ".ps1", ".js", ".vbs", ".exe", ".dll", ".jar"}
FIGURE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".svg", ".emf", ".wmf"}
REPORT_SUFFIXES = {".docx", ".pdf", ".md", ".txt", ".hwp", ".hwpx"}
PROCESSED_COLUMNS = {"mean", "avg", "average", "std", "stdev", "sd", "sem", "se", "median", "summary", "cv",
                     "평균", "표준편차", "중앙값", "요약"}
PROCESSED_NAME = re.compile(r"(processed|summary|result|stats|statistic|analy[sz]|평균|요약|결과|가공|분석|통계)", re.I)
REPORT_NAME = re.compile(r"(report|draft|manuscript|paper|보고서|초안|논문)", re.I)
SPEC_WORDS = ("specification", "datasheet", "data sheet", "accuracy", "measurement range", "resolution",
              "calibration", "사양", "정확도", "측정 범위", "측정범위", "분해능", "교정")
REPORT_WORDS = ("abstract", "introduction", "conclusion", "references", "초록", "서론", "결론", "참고문헌")


def classify(rel_path: str, zone: str, fp: dict) -> dict:
    """(분류, 확신도, 근거, 주의) — fp 는 hashing.fingerprint 결과(내용 요약 포함)."""
    name = Path(rel_path).name
    lower = name.lower()
    suffix = Path(rel_path).suffix.lower()
    content = fp.get("content") or {}

    def out(category: str, confidence: float, evidence: str, warning: str = "") -> dict:
        return {"category": category, "confidence": confidence, "evidence": evidence, "warning": warning}

    if lower in SYSTEM_NAMES or lower.startswith(("~$", "._")):
        return out("system", 1.0, "운영체제·편집기의 시스템·임시 파일")
    if zone == "report":
        warn = "" if suffix in REPORT_SUFFIXES else f"보고서로 흔하지 않은 형식({suffix or '확장자 없음'})"
        return out("report", 1.0, "보고서 칸으로 받음 — 5-1 전까지 열지 않고 원본 해시만 기록", warn)
    if suffix in SCRIPT_SUFFIXES:
        return out("script", 1.0, f"스크립트·실행 파일({suffix}) — 목록에만 남기고 실행하지 않음(R6)")
    if suffix in FIGURE_SUFFIXES:
        return out("figure", 0.95, "그림 파일 — v4 는 Figure 를 판정하지 않음")

    if suffix == ".docx":
        n_eq = content.get("equations")
        warn = "이름이 보고서처럼 보임 — 최종 보고서 초안이면 보고서 칸에 따로 넣어야 함" if REPORT_NAME.search(name) else ""
        if n_eq:
            return out("plan", 0.9, f"Word 문서, Word 수식 {n_eq}개 — 연구 계획서 후보", warn)
        if n_eq == 0:
            return out("plan", 0.6, "Word 문서이나 Word 수식이 없음 — 계산식이 글자로만 있으면 2-1b 수식 변환 불가",
                       warn or "Word 수식(삽입 → 수식)으로 식을 넣었는지 확인")
        return out("plan", 0.5, "Word 문서 (내용을 읽지 못함)", fp.get("read_error", ""))
    if suffix == ".doc":
        return out("unknown", 0.3, "구형 Word(.doc) — .docx 로 저장해야 수식을 읽을 수 있음")
    if suffix in (".hwp", ".hwpx"):
        return out("unknown", 0.3, "한글 문서 — v4 계획서 형식은 .docx (Word 수식)")

    if suffix == ".pdf":
        first = (content.get("first_page") or "").lower()
        spec_hits = [w for w in SPEC_WORDS if w in first]
        report_hits = [w for w in REPORT_WORDS if w in first]
        if spec_hits and not report_hits:
            return out("spec", 0.9, f"PDF 첫 쪽의 사양 표현: {', '.join(spec_hits[:4])}")
        if report_hits and not spec_hits:
            return out("unknown", 0.4, f"PDF 첫 쪽이 논문·보고서 형식({', '.join(report_hits[:3])}) — 사양서가 아닐 수 있음",
                       "최종 보고서 초안이면 보고서 칸에, 참고 문헌이면 빼 주세요")
        if not first:
            return out("spec", 0.5, "PDF — 글자를 읽지 못해 내용 근거 없음(스캔본일 수 있음), 형식으로만 사양서 후보")
        return out("spec", 0.6, "PDF — 사양 표현을 찾지 못함, 형식으로만 사양서 후보")

    if suffix == ".xlsx":
        sheets = content.get("sheets") or []
        return out("raw", 0.5, f"엑셀 통합 문서(시트 {len(sheets)}개) — 원자료 후보, 시트 구조는 2-1 에서 확인",
                   "가공된 요약 시트가 섞여 있으면 RAW 가 아님")

    table = content.get("table")
    if suffix in (".csv", ".tsv", ".txt", ".dat", ".md"):
        if fp.get("read_error"):
            return out("unknown", 0.0, f"읽기 실패: {fp['read_error']}")
        if not table:
            return out("unknown", 0.3, "텍스트 문서 — 구분자로 나뉜 표가 아님 (메모·설명일 수 있음)")
        tokens = {t for c in table["columns"] for t in re.split(r"[^0-9a-zA-Z가-힣]+", c.lower()) if t}
        stat_cols = sorted(tokens & PROCESSED_COLUMNS)
        name_hit = PROCESSED_NAME.search(Path(rel_path).stem)
        n_num = len(table.get("numeric_columns") or [])
        shape = f"{len(table['columns'])}열 × {table['n_rows']}행, 숫자 열 {n_num}개"
        if stat_cols:
            return out("processed", 0.7, f"통계 열({', '.join(stat_cols)}) — 가공 데이터로 보임 · {shape} — RAW 라면 3 CONFIRM 에서 바로잡기")
        if name_hit:
            return out("processed", 0.55, f"파일 이름의 가공 단서('{name_hit.group(0)}') · {shape} — RAW 라면 3 CONFIRM 에서 바로잡기")
        if n_num >= 2:
            return out("raw", 0.85, f"측정값 표 · {shape} ({', '.join(table['numeric_columns'][:4])})")
        if n_num == 1:
            return out("raw", 0.6, f"숫자 열이 하나뿐인 표 · {shape}", "측정값 표인지 확인")
        return out("raw", 0.4, f"숫자 열이 없는 표 · {shape}", "측정값 표인지 확인")
    return out("unknown", 0.2, f"v4 입력 형식이 아님({suffix or '확장자 없음'})")
