"""1 INGEST — 격리하고 지문을 고정한다 [PY]. (파이프라인 v4 확정본 §4-1)

  1-1 입력 격리·분류   workspace(사본·읽기 전용·보고서 별도) · classify
  1-2 해시 2종         hashing.fingerprint · 이전 실행과 비교(형식만 변경 / 내용 변경 + 행·열 차이)
  1-3 산출물 이력 장부 ledger.record — (입력 해시, 코드 해시, 파라미터) → 출력 해시

LLM 을 쓰지 않는다. 보고서는 열지 않는다(원본 해시만, R4). 측정 시각은 모으지 않는다(v4 결정 15).
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

from measuretrace import ledger
from measuretrace.ingest import workspace
from measuretrace.ingest.classify import CATEGORIES, USED, classify
from measuretrace.ingest.hashing import NORMALIZATION_VERSION, fingerprint, row_diff, sha256_file
from measuretrace.paths import PACKAGE_DIR, rel as rel_path

INGEST_CODE = [PACKAGE_DIR / "ingest", PACKAGE_DIR / "ledger.py", PACKAGE_DIR / "paths.py"]


def input_hash(files: list[dict]) -> str:
    """입력 전체의 해시 — (구역/상대 경로, 원본 해시) 목록을 정렬해 묶는다."""
    lines = sorted(f"{f['zone']}/{f['path']}\t{f['sha256']}" for f in files)
    return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()


def compare(previous: dict | None, files: list[dict]) -> list[dict]:
    """1-2 이전 실행과 비교. 해시만으로는 '달라졌다'까지 — 표는 저장해 둔 행별 해시로 행·열 차이를 본다."""
    if not previous:
        return []
    old = {f"{f['zone']}/{f['path']}": f for f in previous["files"]}
    new = {f"{f['zone']}/{f['path']}": f for f in files}
    gone = {k: f for k, f in old.items() if k not in new}
    gone_by_hash: dict[str, list[str]] = {}
    for k, f in gone.items():
        gone_by_hash.setdefault(f["sha256"], []).append(k)
    out, moved = [], set()
    for key, f in new.items():
        o = old.get(key)
        if o is None:
            src = [k for k in gone_by_hash.get(f["sha256"], []) if k not in moved]
            if src:
                moved.add(src[0])
                out.append({"kind": "경로 변경", "file": key, "detail": f"{src[0]} → {key} (내용 같음)"})
            else:
                out.append({"kind": "추가", "file": key, "detail": CATEGORIES[f["category"]]})
            continue
        if o["sha256"] == f["sha256"]:
            continue
        if o["normalization"] != f["normalization"]:
            out.append({"kind": "바이트 변경", "file": key,
                        "detail": f"정규화 방법이 달라 내용 비교 불가 ({o['normalization']} → {f['normalization']})"})
        elif o["content_hash"] == f["content_hash"] and not f["normalization"].startswith("none"):
            out.append({"kind": "형식만 변경", "file": key, "detail": "원본 바이트는 다르지만 정규화한 내용은 같음"})
        elif f["normalization"].startswith("none"):
            out.append({"kind": "바이트 변경", "file": key, "detail": "원본 해시가 다름 (이 형식은 내용 비교 안 함)"})
        else:
            item = {"kind": "내용 변경", "file": key, "detail": "정규화한 내용이 다름"}
            diff = row_diff((o.get("content") or {}).get("table"), (f.get("content") or {}).get("table"))
            if diff:
                item["table"] = diff
                bits = []
                if diff["columns_added"]:
                    bits.append(f"열 추가 {diff['columns_added']}")
                if diff["columns_removed"]:
                    bits.append(f"열 삭제 {diff['columns_removed']}")
                if diff.get("columns_reordered"):
                    bits.append("열 순서 바뀜")
                if "rows_changed" in diff:
                    bits.append(f"행 바뀜 {diff['rows_changed']} · 추가 {diff['rows_added']} · 빠짐 {diff['rows_removed']}")
                bits.append(f"행 수 {diff['rows_before']} → {diff['rows_after']}")
                if not (diff["columns_added"] or diff["columns_removed"] or diff.get("columns_reordered")
                        or diff.get("rows_changed") or diff.get("rows_added") or diff.get("rows_removed")):
                    bits = ["표의 열·행은 같음 — 머리글 앞 줄·구분 표기 등 표 밖의 글자가 다름"]
                item["detail"] = " · ".join(bits)
            out.append(item)
    for key in gone:
        if key not in moved:
            out.append({"kind": "삭제", "file": key, "detail": "이전 실행에 있던 파일이 없음"})
    return out


def findings(files: list[dict]) -> list[dict]:
    """1-1 점검 — 멈추지 않고 모두 모은다. level: 'bad'(다음 단계 불가) · 'warn'(확인) · 'info'."""
    by = Counter(f["category"] for f in files)
    out = []

    def add(level: str, title: str, items: list[str] | None = None) -> None:
        out.append({"level": level, "title": title, "items": items or []})

    if not by["raw"]:
        add("bad", "RAW 데이터가 없음 — 재계산할 데이터가 없음")
    if not by["plan"]:
        add("bad", "연구 계획서(.docx)가 없음 — 계산식·가공 방법·설계를 가져올 곳이 없음")
    elif by["plan"] > 1:
        add("warn", f"연구 계획서 후보가 {by['plan']}개 — 어느 것이 계획서인지 3-1 에서 확인",
            [f["path"] for f in files if f["category"] == "plan"])
    if not by["spec"]:
        add("warn", "장비 사양서(PDF)가 없음 — 2-2 측정 범위·오차 확인(E02)을 할 수 없음")
    if not by["report"]:
        add("warn", "최종 보고서 초안이 없음 — 5 VALIDATE 에서 대조할 주장이 없음")
    for cat, title in (("processed", "가공 데이터는 사용하지 않음 (연구자 숫자로 연구자 숫자를 검증하는 순환 방지)"),
                       ("figure", "그림은 판정하지 않음 (v4 결정 12)"),
                       ("script", "스크립트는 실행하지 않음 (R6)"),
                       ("system", "시스템·임시 파일 제외"),
                       ("unknown", "미분류 — 역할 확인 필요")):
        items = [f"{f['zone']}/{f['path']} — {f['evidence']}" for f in files if f["category"] == cat]
        if items:
            add("warn" if cat == "unknown" else "info", title, items)
    warns = [f"{f['zone']}/{f['path']} — {f['warning']}" for f in files if f.get("warning")]
    if warns:
        add("warn", "분류 주의", warns)
    seen: dict[str, str] = {}
    dups = []
    for f in files:
        k = f"{f['zone']}/{f['path']}"
        if f["sha256"] in seen:
            dups.append(f"{k} = {seen[f['sha256']]}")
        else:
            seen[f["sha256"]] = k
    if dups:
        add("warn", "원본 바이트가 같은 파일 (복사본)", dups)
    return out


def run_ingest(run_id: str, project: str | None = None) -> dict:
    project = workspace.project_name(project)
    if workspace.is_sealed(run_id):
        raise ValueError("이미 1 INGEST 를 마친 실행 — 결과는 '이전 실행 열기'로 보고, 입력을 바꾸려면 새 실행으로")
    inputs = workspace.list_inputs(run_id)
    if not any(zone == "data" for zone, _, _ in inputs):
        raise ValueError("연구 자료가 하나도 없음")
    in_root = workspace.run_dir(run_id)
    out_dir = workspace.output_dir(project, run_id)
    started = datetime.now().astimezone().isoformat(timespec="seconds")

    # 1-2 해시 2종 → 1-1 분류 (분류가 내용 요약을 근거로 씀)
    files = []
    for zone, rel, path in inputs:
        fp = fingerprint(path, zone)
        cls = classify(rel, zone, fp)
        (fp.get("content") or {}).pop("first_page", None)     # 분류에만 쓰고 저장하지 않음
        files.append({"zone": zone, "path": rel, "bytes": path.stat().st_size, **cls,
                      "used": cls["category"] in USED, **fp})

    # 1-1 격리 점검
    checks = []
    def check(label: str, ok: bool | None, detail: str) -> None:
        checks.append({"label": label, "ok": ok, "detail": detail})

    check("원본 보호", True, "브라우저가 파일을 읽어 사본으로 보냄 — 연구자 PC 의 원본은 건드리지 않음")
    locked = all(not (p.stat().st_mode & 0o222) for _, _, p in inputs)
    check("입력 사본 읽기 전용", locked, f"입력 사본 {len(inputs)}개를 읽기 전용으로 잠금: {in_root}")
    check("산출물은 입력 밖", in_root not in out_dir.parents, f"산출물 폴더: {out_dir}")
    n_report = sum(1 for z, _, _ in inputs if z == "report")
    check("보고서 별도 경로", True if n_report else None,
          f"보고서 {n_report}개를 {in_root / 'report'} 에 따로 받음 — 5-1 전까지 열지 않음(원본 해시만)"
          if n_report else "보고서 초안을 넣지 않음")
    scripts = [f["path"] for f in files if f["category"] == "script"]
    check("스크립트 실행 안 함", True, f"스크립트 {len(scripts)}개 — 목록에만 남김" if scripts else "입력에 스크립트 없음")

    prev_path = workspace.previous_snapshot_path(project, run_id)
    previous = json.loads(prev_path.read_text(encoding="utf-8")) if prev_path else None
    changes = compare(previous, files)

    # 끝나기 전에 입력이 그대로인지 다시 해시 (읽기만 했다는 확인)
    changed = [f"{f['zone']}/{f['path']}" for f, (_, _, p) in zip(files, inputs) if sha256_file(p) != f["sha256"]]
    check("처리 중 입력 불변", not changed, "끝에 다시 해시 — 모두 같음" if not changed else f"바뀐 파일: {changed}")

    ihash = input_hash(files)
    snapshot = {
        "step": "1 INGEST", "run_id": run_id, "project": project, "started_at": started,
        "finished_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "normalization_version": NORMALIZATION_VERSION,
        "input_dir": str(in_root), "output_dir": str(out_dir), "input_hash": ihash,
        "previous_run_id": previous["run_id"] if previous else None,
        "checks": checks, "findings": findings(files), "changes": changes,
        "counts": dict(Counter(f["category"] for f in files)),
        "files": files,
    }
    snap_path = out_dir / "ingest_snapshot.json"
    snap_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
    workspace.seal(run_id, project)   # 이후 이 실행의 입력은 바뀌지 않는다

    # 1-3 산출물 이력 장부
    code = ledger.code_hash(*INGEST_CODE)
    entry = ledger.record("1 INGEST", run_id, ihash, code,
                          {"project": project, "normalization": NORMALIZATION_VERSION,
                           "previous_run_id": snapshot["previous_run_id"]}, [snap_path])
    return {**snapshot, "categories": CATEGORIES, "lineage": entry, "ledger_path": rel_path(ledger.LEDGER_PATH),
            "ledger_recent": ledger.recent(10)}


def ingest_view(run_id: str) -> dict:
    """저장된 스냅샷으로 1 INGEST 결과 화면을 다시 만든다(다시 실행하지 않음) — 페이지를 새로 열어도 이어서 보기."""
    from measuretrace.extract.run import find_snapshot
    snap = json.loads(find_snapshot(run_id).read_text(encoding="utf-8"))
    entry = ledger.find(run_id, "1 INGEST")
    return {**snap, "categories": CATEGORIES, "lineage": entry, "ledger_path": rel_path(ledger.LEDGER_PATH),
            "ledger_recent": ledger.recent(10)}


def list_runs() -> list[dict]:
    """작업 폴더의 실행 목록 — 새 것이 위. 단계별 진행 상태 포함."""
    out = []
    for snap in workspace.OUTPUTS_DIR.glob("*/*/ingest_snapshot.json"):
        base = snap.parent
        s = json.loads(snap.read_text(encoding="utf-8"))
        conf = base / "confirm" / "confirm_state.json"
        calc = base / "recompute" / "calc_log.json"
        audit = base / "audit" / "audit_view.json"
        summary = json.loads(audit.read_text(encoding="utf-8"))["result"]["summary"] if audit.exists() else None
        out.append({"run_id": s["run_id"], "project": s["project"], "started_at": s["started_at"],
                    "files": len(s["files"]), "extract": (base / "extract" / "extract_summary.json").exists(),
                    "confirm": json.loads(conf.read_text(encoding="utf-8"))["status"] if conf.exists() else None,
                    "recompute": json.loads(calc.read_text(encoding="utf-8"))["status"] if calc.exists() else None,
                    "audit": f"S{summary['Supported']}·U{summary['Unsupported']}" if summary else None})
    return sorted(out, key=lambda r: r["started_at"], reverse=True)
