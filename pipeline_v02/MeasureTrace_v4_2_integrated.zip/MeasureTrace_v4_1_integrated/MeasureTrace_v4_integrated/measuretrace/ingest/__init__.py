"""1 INGEST — 격리하고 지문을 고정한다. 진입점: run_ingest(run_id, project)."""
from measuretrace.ingest.run import run_ingest  # noqa: F401
