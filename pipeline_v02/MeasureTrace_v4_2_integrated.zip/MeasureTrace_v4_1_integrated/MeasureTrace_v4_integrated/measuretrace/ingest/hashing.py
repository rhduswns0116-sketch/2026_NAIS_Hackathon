"""1-2 해시 2종 — 원본 바이트 해시 + 내용 정규화 해시. 표는 행별 해시도 남겨 다음 실행에서 행·열 차이를 본다.

정규화 방법 (NORMALIZATION_VERSION 과 함께 기록 — 방법이 다르면 내용 해시끼리 비교하지 않는다)
  text-v2          CSV·TSV·TXT·DAT·MD : BOM 제거 → 개행 \\n 통일 → 줄 끝 공백 제거 → 빈 줄 제거
  docx-text-omml-v1  연구 계획서 : 문단 글자 + Word 수식(m:oMath) XML(정규형). zip 재압축·메타데이터 차이는 무시
  pdf-text-v1      장비 사양서 : 모든 쪽의 글자(쪽 경계 포함). 글자층이 없으면 원본 해시만
  xlsx-cells-v1    엑셀 : 시트별 칸 값·수식
  none             그 밖의 형식 · 보고서(5-1 전까지 열지 않음) : 원본 해시를 그대로 씀
"""
from __future__ import annotations

import csv
import difflib
import hashlib
import io
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

NORMALIZATION_VERSION = "norm-v4.2"
TEXT_SUFFIXES = {".csv", ".tsv", ".txt", ".dat", ".md"}
MAX_ROW_HASHES = 200_000      # 이보다 긴 표는 행 수만 남김 (행별 비교 불가 표시)
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def decode_text(data: bytes) -> tuple[str, str] | None:
    """(글자, 인코딩). BOM 이 있으면 그대로 따르고, 없으면 UTF-8 → CP949 순. 못 읽으면 None."""
    if data.startswith(b"\xef\xbb\xbf"):
        return data[3:].decode("utf-8", errors="strict"), "utf-8-sig"
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16"), "utf-16"
    for enc in ("utf-8", "cp949"):
        try:
            return data.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return None


def normalize_text(text: str) -> list[str]:
    """개행 통일 · 줄 끝 공백 제거 · 빈 줄 제거 (빈 줄은 표의 값이 아님)."""
    lines = (line.rstrip() for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"))
    return [line for line in lines if line]


def detect_delimiter(lines: list[str]) -> str | None:
    """앞쪽 줄들에서 칸 수가 가장 일정한 구분자. 표가 아니면 None."""
    sample = [l for l in lines[:50] if l.strip()]
    if len(sample) < 2:
        return None
    best, best_score = None, 0
    for d in (",", "\t", ";", "|"):
        counts = [len(next(csv.reader([l], delimiter=d))) for l in sample]
        top = max(set(counts), key=counts.count)
        if top < 2:
            continue
        score = counts.count(top) / len(counts)
        if score > best_score:
            best, best_score = d, score
    return best if best_score >= 0.6 else None


def table_info(lines: list[str]) -> dict | None:
    """구분자로 나뉜 표 — 첫 줄을 열 이름으로 보고, 데이터 행마다 해시(16자리)를 남긴다."""
    delim = detect_delimiter(lines)
    if delim is None:
        return None
    first = next(i for i, l in enumerate(lines) if l.strip())
    columns = [c.strip() for c in next(csv.reader([lines[first]], delimiter=delim))]
    rows = [(i + 1, l) for i, l in enumerate(lines[first + 1:], start=first + 1) if l.strip()]
    numeric = total = 0
    col_hits = [0] * len(columns)
    col_seen = [0] * len(columns)
    for _, line in rows[:50]:
        for c, cell in enumerate(next(csv.reader([line], delimiter=delim))):
            cell = cell.strip()
            if not cell:
                continue
            total += 1
            if c < len(columns):
                col_seen[c] += 1
            try:   # 쉼표: 구분자가 쉼표가 아닐 때 '정수,정수' 소수점만 숫자로 (천 단위 추측 안 함)
                float(cell.replace(",", ".") if delim != "," and cell.count(",") == 1 else cell)
                numeric += 1
                if c < len(columns):
                    col_hits[c] += 1
            except ValueError:
                pass
    numeric_columns = [columns[c] for c in range(len(columns)) if col_seen[c] and col_hits[c] / col_seen[c] >= 0.9]
    info = {"delimiter": delim, "header_line": first + 1, "columns": columns, "n_rows": len(rows),
            "numeric_ratio": round(numeric / total, 3) if total else 0.0, "numeric_columns": numeric_columns}
    if len(rows) <= MAX_ROW_HASHES:
        info["row_hashes"] = [sha256_bytes(l.encode("utf-8"))[:16] for _, l in rows]
        info["row_lines"] = [n for n, _ in rows]     # 파일 안의 줄 번호 (1부터)
    else:
        info["row_hashes_note"] = f"{len(rows)}행 — {MAX_ROW_HASHES}행 초과라 행별 해시를 남기지 않음"
    return info


def docx_content(data: bytes) -> tuple[bytes, dict]:
    """문단 글자 + Word 수식 XML. 수식 개수는 1-1 분류 근거로도 쓴다."""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    parts, n_math, n_par = [], 0, 0
    for p in root.iter(W + "p"):
        n_par += 1
        parts.append("".join(t.text or "" for t in p.iter(W + "t")).strip())
        for om in p.iter(M + "oMath"):
            n_math += 1
            parts.append(ET.canonicalize(ET.tostring(om, encoding="unicode"), strip_text=True))
    return "\n".join(parts).encode("utf-8"), {"paragraphs": n_par, "equations": n_math}


def pdf_pages(path: Path) -> list[str] | None:
    try:
        import pdfplumber
    except ImportError:
        return None
    with pdfplumber.open(path) as pdf:
        return [(page.extract_text() or "") for page in pdf.pages]


def xlsx_content(path: Path) -> tuple[bytes, dict]:
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=False)
    out, sheets = [], []
    for ws in wb.worksheets:
        n = 0
        out.append(f"#sheet {ws.title}")
        for row in ws.iter_rows(values_only=True):
            if any(v is not None for v in row):
                n += 1
                out.append("\t".join("" if v is None else repr(v) for v in row).rstrip())
        sheets.append({"name": ws.title, "n_rows": n})
    wb.close()
    return "\n".join(out).encode("utf-8"), {"sheets": sheets}


def fingerprint(path: Path, zone: str) -> dict:
    """파일 하나의 해시 2종과 내용 요약. 보고서(zone='report')는 5-1 전까지 열지 않으므로 원본 해시만."""
    raw = sha256_file(path)
    out = {"sha256": raw, "content_hash": raw, "normalization": "none", "content": {}}
    suffix = path.suffix.lower()
    if zone == "report":
        out["normalization"] = "none — 보고서는 5-1 전까지 열지 않음(R4), 원본 해시만"
        return out
    try:
        if suffix in TEXT_SUFFIXES:
            decoded = decode_text(path.read_bytes())
            if decoded is None:
                out["normalization"] = "none — 인코딩을 확정할 수 없음, 원본 해시만"
                out["read_error"] = "인코딩 판별 실패 (UTF-8·CP949·BOM 아님)"
                return out
            text, encoding = decoded
            lines = normalize_text(text)
            out["content_hash"] = sha256_bytes("\n".join(lines).encode("utf-8"))
            out["normalization"] = "text-v2"
            out["content"] = {"encoding": encoding, "n_lines": len(lines)}
            table = table_info(lines)
            if table:
                out["content"]["table"] = table
        elif suffix == ".docx":
            content, info = docx_content(path.read_bytes())
            out["content_hash"] = sha256_bytes(content)
            out["normalization"] = "docx-text-omml-v1"
            out["content"] = info
        elif suffix == ".pdf":
            pages = pdf_pages(path)
            if pages is None:
                out["normalization"] = "none — PDF 글자 읽기 라이브러리(pdfplumber) 없음, 원본 해시만"
            elif not any(p.strip() for p in pages):
                out["normalization"] = "none — PDF 글자층 없음(스캔본일 수 있음), 원본 해시만"
                out["content"] = {"pages": len(pages)}
            else:
                text = "\f".join("\n".join(normalize_text(p)) for p in pages)
                out["content_hash"] = sha256_bytes(text.encode("utf-8"))
                out["normalization"] = "pdf-text-v1"
                out["content"] = {"pages": len(pages), "first_page": pages[0][:2000]}
        elif suffix == ".xlsx":
            content, info = xlsx_content(path)
            out["content_hash"] = sha256_bytes(content)
            out["normalization"] = "xlsx-cells-v1"
            out["content"] = info
    except Exception as e:  # 읽기 실패는 기록만 하고 원본 해시로 진행
        out["content_hash"], out["normalization"] = raw, f"none — 내용 읽기 실패({type(e).__name__}), 원본 해시만"
        out["read_error"] = f"{type(e).__name__}: {e}"
    return out


def row_diff(old: dict, new: dict) -> dict | None:
    """두 표의 열·행 차이 — 행별 해시를 순서대로 맞춰 본다(difflib). 줄 번호는 새 파일 기준(삭제는 옛 파일 기준)."""
    if not old or not new:
        return None
    out = {"columns_added": [c for c in new["columns"] if c not in old["columns"]],
           "columns_removed": [c for c in old["columns"] if c not in new["columns"]],
           "columns_reordered": (old["columns"] != new["columns"]
                                 and sorted(old["columns"]) == sorted(new["columns"])),
           "rows_before": old["n_rows"], "rows_after": new["n_rows"]}
    if "row_hashes" not in old or "row_hashes" not in new:
        out["note"] = "행별 해시가 없어 행 단위 비교 불가 — 행 수만 비교"
        return out
    added = removed = changed = 0
    spans = []
    sm = difflib.SequenceMatcher(a=old["row_hashes"], b=new["row_hashes"], autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "replace":
            k = min(i2 - i1, j2 - j1)
            changed += k
            removed += (i2 - i1) - k
            added += (j2 - j1) - k
        elif tag == "delete":
            removed += i2 - i1
        elif tag == "insert":
            added += j2 - j1
        lines = (f"새 파일 {new['row_lines'][j1]}–{new['row_lines'][j2 - 1]}줄" if j2 > j1
                 else f"옛 파일 {old['row_lines'][i1]}–{old['row_lines'][i2 - 1]}줄")
        spans.append({"kind": {"replace": "바뀜", "delete": "빠짐", "insert": "추가"}[tag], "where": lines})
    out.update(rows_changed=changed, rows_added=added, rows_removed=removed, spans=spans[:30],
               spans_truncated=len(spans) > 30)
    return out
