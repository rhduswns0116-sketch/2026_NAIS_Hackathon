"""6-1 결과 출력 — audit_result.json + audit_report.md.

Supported / Unsupported(+오류 코드) / 검사 대상 아님 목록.
주장마다 보고서 원문(쪽·문장) · 보고값 · 재계산값 · 사용한 식 · 데이터 해시 · 코드 해시를 나란히 둔다.
판정은 과학적 진실이 아니라 "지금 제출된 자료가 이 주장을 지지하는가"에 대한 것이다.
"""
from __future__ import annotations

import json
import os
import tempfile
from collections import Counter
from pathlib import Path

from ..common.hashing import now_iso, sha256_bytes
from ..contract import Confirmed, refs_overlap
from ..validate.codes import CODE_NAMES, NOT_TARGET, SUPPORTED, UNSUPPORTED_V, dependencies
from .rerun import claim_key
from .storage import (AuditError, COMPLETE_FILE, REQUIRED_FILES, STAGE_VERSION,
                      json_object, output_path, validate_calc)


def _claim_record(item: dict, confirmed: Confirmed, calc: dict) -> dict:
    c, cmp = item["claim"], item["comparison"]
    deps = dependencies(confirmed, cmp["outputs_used"])
    eq_ids = list(dict.fromkeys(e for oid in cmp["outputs_used"] if confirmed.output(oid)
                                for e in confirmed.output(oid).equations))
    eqs = [{"id": e.id, "latex": e.latex, "context": e.context} for e in confirmed.equations if e.id in eq_ids]
    data = [{"path": d["path"], "sha256": d["sha256"], "content_hash": d["content_hash"]}
            for d in calc.get("data", []) if any(refs_overlap(x, d["id"]) for x in deps)]
    return {
        "claim_id": c["claim_id"], "key": claim_key(c), "sid": c["sid"], "page": c["page"],
        "no_in_page": c["no_in_page"], "sentence": c["sentence"], "source_text": c["source_text"],
        "category": c["category"], "category_ko": c["category_ko"], "claim_type": c["claim_type"],
        "statistic": c.get("statistic"), "output_id": c.get("output_id"), "test_id": c.get("test_id"),
        "lhs_output": c.get("lhs_output"), "rhs_output": c.get("rhs_output"),
        "n_scope": c.get("n_scope"), "n_group": c.get("n_group"),
        "reported": cmp["reported"], "recomputed": cmp["recomputed"], "outputs_used": cmp["outputs_used"],
        "equations": eqs, "data": data, "code_sha256": calc["code"]["sha256"],
        "verdict": item["verdict"], "codes": item["codes"], "checks": cmp["checks"], "notes": cmp["notes"],
        "degree_excluded": c.get("degree_word"), "literature_values": c.get("literature_values", []),
        "reference_texts": c.get("reference_texts", []),
        "extraction_notes": c.get("extraction_notes", []),
        "explanation": item.get("explanation"), "explanation_source": item.get("explanation_source"),
        "explanation_core": item.get("explanation_core"), "explanation_advice": item.get("explanation_advice"),
        "explanation_policy": item.get("explanation_policy"), "explanation_status": item.get("explanation_status"),
        "explanation_llm_rejected": item.get("explanation_llm_rejected"),
    }


def build_result(items: list[dict], claims_out: dict, calc: dict, confirmed: Confirmed,
                 rerun: dict | None) -> dict:
    records = [_claim_record(it, confirmed, calc) for it in items]
    verdicts = Counter(r["verdict"] for r in records)
    code_counts = Counter(k["code"] for r in records for k in r["codes"])
    records_only = [{"claim_id": r["claim_id"], **k} for r in records for k in r["codes"] if k["effect"] == "record"]
    return {
        "stage": "6-1 결과 출력",
        "stage_version": STAGE_VERSION,
        "generated_at": now_iso(),
        "project_id": confirmed.project_id,
        "run_id": calc["run_id"],
        "summary": {SUPPORTED: verdicts.get(SUPPORTED, 0), UNSUPPORTED_V: verdicts.get(UNSUPPORTED_V, 0),
                    NOT_TARGET: len(claims_out["non_target"]),
                    "구조화 실패": len(claims_out["unstructured"]),
                    "codes": dict(sorted(code_counts.items()))},
        "blind": claims_out["blind"],
        "recompute": {"status": calc["status"], "error": calc["error"], "code_sha256": calc["code"]["sha256"],
                      "results_sha256": calc["results_sha256"], "finished_at": calc["finished_at"],
                      "data": [{k: d[k] for k in ("id", "path", "sha256", "content_hash", "rows")}
                               for d in calc["data"]],
                      "outputs": calc["outputs"]},
        "claims": records,
        "records": records_only,
        "non_target": claims_out["non_target"],
        "references": claims_out.get("references", []),
        "unstructured": claims_out["unstructured"],
        "rejected_extractions": claims_out["rejected"],
        "llm_failures": claims_out["llm_failures"],
        "page_mode": claims_out["page_mode"],
        "rerun": rerun,
        "scope_note": "판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것. "
                      "계산식의 과학적 타당성, 그림, 외부 문헌 수치, 데이터 조작 여부는 판정하지 않음.",
    }


def _cell(s) -> str:
    return str(s if s is not None else "—").replace("|", "\\|").replace("\n", " ")


def _recomputed_text(r: dict) -> str:
    rec = r["recomputed"] or {}
    if "rounded" in rec:
        return f"{rec['rounded']} {rec.get('rounded_unit') or ''} (원값 {rec['raw']:.6g})".strip()
    if "difference" in rec:
        return f"차이 {rec['difference']:.6g} {rec.get('unit') or ''}".strip()
    if "p" in rec:
        return f"p = {rec['p']:.4g} ({'유의' if rec['significant'] else '비유의'}, α={rec['alpha']})"
    if "raw" in rec:
        return f"{rec['raw']:.6g}"
    return "—"


def render_markdown(result: dict) -> str:
    s, b, rc = result["summary"], result["blind"], result["recompute"]
    L = [f"# MeasureTrace 감사 리포트 — {result['project_id']}", "",
         f"실행 `{result['run_id']}` · 생성 {result['generated_at']}", "",
         f"> {result['scope_note']}", "",
         "## 요약", "",
         f"| Supported | Unsupported | 검사 대상 아님 | 구조화 실패 |", "|---|---|---|---|",
         f"| {s[SUPPORTED]} | {s[UNSUPPORTED_V]} | {s[NOT_TARGET]} | {s['구조화 실패']} |", ""]
    if s["codes"]:
        L += ["오류 코드: " + ", ".join(f"{c} {CODE_NAMES[c]} ×{n}" for c, n in s["codes"].items()), ""]
    L += ["## 블라인드 입증", "",
          f"- 계산 로그 완료 {b['calc_finished_at']} < 보고서 첫 열람 {b['report_opened_at']} → "
          f"{'확인' if b['blind_ok'] else '실패'}",
          f"- 보고서 해시 `{b['report_sha256'][:16]}` · 코드 해시 `{rc['code_sha256'][:16]}` · "
          f"결과 해시 `{rc['results_sha256'][:16]}`"]
    if b.get("note"):
        L.append(f"- 주의: {b['note']}")
    L += ["", "## 주장별 판정", "",
          "| 위치 | 원문 | 보고값 | 재계산값 | 판정 | 오류 코드 |", "|---|---|---|---|---|---|"]
    for r in result["claims"]:
        codes = ", ".join(f"{k['code']}{'(기록)' if k['effect'] == 'record' else ''}" for k in r["codes"]) or "—"
        L.append(f"| p.{r['page']} 문장 {r['no_in_page']} | {_cell(r['source_text'])} | {_cell(r['reported'])} | "
                 f"{_cell(_recomputed_text(r))} | **{r['verdict']}** | {codes} |")
    L += ["", "## 주장 상세", ""]
    for r in result["claims"]:
        source = ("핵심 Python · 안내 LLM" if r.get("explanation_policy") and r["explanation_source"] == "llm"
                  else "Python 템플릿" if r.get("explanation_policy") else r["explanation_source"])
        L += [f"### {r['claim_id']} · {r['verdict']} · p.{r['page']} 문장 {r['no_in_page']} ({r['category_ko']})", "",
              f"> {r['sentence']}", "", f"- 설명: {r['explanation']} _(작성: {source})_"]
        if r.get("explanation_llm_rejected"):
            L.append(f"- 설명 대체 사유: {_cell(r['explanation_llm_rejected'])}")
        for k in r["codes"]:
            tag = "기록" if k["effect"] == "record" else "Unsupported"
            rt = f" · 사유: {k['reason_type']}" if k.get("reason_type") else ""
            L.append(f"- **{k['code']} {k['name']}** [{tag}{rt}] {k['reason']}")
            L += [f"  - {e}" for e in k["evidence"]]
        if r["checks"]:
            L.append(f"- 수행한 검사: {', '.join(r['checks'])}")
        L += [f"- 참고: {n}" for n in r["notes"] + r["extraction_notes"]]
        if r["literature_values"]:
            L.append(f"- 문헌값(검사 안 함): {', '.join(r['literature_values'])}")
        L += [f"- 인용 {x['ref']}: {x['text'] or '참고문헌 목록에서 찾지 못함'}" for x in r["reference_texts"]]
        for e in r["equations"]:
            L.append(f"- 식 {e['id']}: `{e['latex']}`" + (f" — {e['context']}" if e["context"] else ""))
        for d in r["data"]:
            L.append(f"- 데이터 `{d['path']}` sha256 `{d['sha256'][:16]}` 내용 `{(d['content_hash'] or '—')[:16]}`")
        L.append("")
    if result["records"]:
        L += ["## 기록 (판정에 영향 없음)", ""]
        L += [f"- {x['claim_id']} {x['code']} {x['name']}: {x['reason']}" for x in result["records"]]
        L.append("")
    L += ["## 검사 대상 아님", ""]
    if not result["non_target"]:
        L.append("- 없음")
    for n in result["non_target"]:
        L.append(f"- p.{n['page']} 문장 {n['no_in_page']} [{n['category_ko']}]: {n['sentence']}")
        L += [f"  - 인용 {x['ref']}: {x['text'] or '참고문헌 목록에서 찾지 못함'}" for x in n.get("reference_texts", [])]
        if n.get("literature_values"):
            L.append(f"  - 문헌값(검사 안 함): {', '.join(n['literature_values'])}")
    L.append("")
    if result["unstructured"] or result["llm_failures"] or result["rejected_extractions"]:
        L += ["## 구조화 실패 (검사하지 못함 — 판정 아님)", ""]
        L += [f"- p.{u['page']} 문장 {u['no_in_page']}: {u['reason']} — {u['sentence']}" for u in result["unstructured"]]
        L += [f"- LLM 실패 {f['sids'][0]}~{f['sids'][-1]}: {f['error']}" for f in result["llm_failures"]]
        L += [f"- 거절된 주장 후보 p.{r['page']} 문장 {r['no_in_page']}: {r['reason']} — {r.get('source_text') or '원문 없음'}"
              for r in result["rejected_extractions"]]
        L.append("")
    rr = result.get("rerun")
    if rr:
        L += [f"## 수정 후 재평가 (이전 실행 `{rr['data']['previous_run']}` 대비)", "", "### E07 데이터 버전 변경 (기록)", ""]
        L += [f"- [{c['change']}] {c['summary']}" for c in rr["data"]["changes"]] or ["- 데이터 변경 없음"]
        if rr["data"]["code_changed"]:
            L.append("- 승인된 계산 코드가 바뀜 (코드 해시 다름)")
        L.append(f"- 한계: {rr['data']['limit']}")
        major = [v for v in rr["verdicts"] if v["change"] not in ("변화 없음", "기록 변화")]
        record_only = [v for v in rr["verdicts"] if v["change"] == "기록 변화"]
        unchanged = sum(v["change"] == "변화 없음" for v in rr["verdicts"])
        L += ["", "### 판정 변화", ""]
        if major:
            L += ["| 원문 | 이전 | 이번 | 변화 |", "|---|---|---|---|"]
            L += [f"| {_cell(v['source_text'])} | {_cell(v['before'])} {_cell(v['codes_before'])} | "
                  f"{_cell(v['after'])} {_cell(v['codes_after'])} | {v['change']} |" for v in major]
        else:
            L.append("- 판정이나 판정을 바꾸는 오류 코드가 달라진 주장 없음")
        L += ["", f"- 기록(E02 진행·E07 등)만 달라진 주장 {len(record_only)}건 · 변화 없는 주장 {unchanged}건"
                  " — 목록은 `audit_result.json` 의 `rerun.verdicts`"]
        L.append("")
    selection = result.get("previous_run_selection")
    if selection and selection.get("excluded"):
        L += ["## 재평가 기준 선택", "", "비교에서 제외한 실행:", ""]
        L += [f"- {_cell(item['run_id'])}: {_cell(item['reason'])}" for item in selection["excluded"]]
        L.append("")
    return "\n".join(L)


def write_outputs(result: dict, run_dir: Path, input_root: str | Path | None = None,
                  out_root: str | Path | None = None) -> tuple[Path, Path]:
    """경로를 확인하고 두 결과를 게시한 뒤 완료 표식을 마지막에 원자적으로 저장한다."""
    run_dir = Path(run_dir)
    if input_root is None and (run_dir / "confirmed_snapshot.json").is_file():
        input_root = json_object(run_dir / "confirmed_snapshot.json").get("input_root")
    if not input_root:
        raise AuditError("AUDIT RAW 경계 검사에는 input_root 또는 confirmed_snapshot.json이 필요함")
    raw_root = Path(input_root).resolve()
    boundary = Path(out_root) if out_root is not None else run_dir.absolute().parent.parent
    actual_dir = output_path(run_dir, boundary, raw_root)
    names = ("audit_result.json", "audit_report.md", COMPLETE_FILE)
    for name in names:
        target = output_path(run_dir / name, actual_dir, raw_root)
        if target.exists() and not target.is_file():
            raise AuditError(f"AUDIT 출력 대상이 일반 파일이 아님: {name}")
    if (actual_dir / COMPLETE_FILE).exists():
        raise AuditError("이미 완료된 AUDIT 실행에는 다시 쓸 수 없음 — 새 실행 id를 사용해야 함")
    calc = json_object(actual_dir / "calc_log.json")
    rows = json_object(actual_dir / "data_rows.json")
    validate_calc(calc, rows)
    if calc.get("project_id") != result.get("project_id") or calc.get("run_id") != result.get("run_id"):
        raise AuditError("AUDIT 출력과 계산 근거의 실행/프로젝트가 다름")
    published = dict(result, stage_version=STAGE_VERSION)
    payloads = {"audit_result.json": json.dumps(published, ensure_ascii=False, indent=2).encode("utf-8"),
                "audit_report.md": render_markdown(published).encode("utf-8")}
    hashes = {name: sha256_bytes(payloads[name] if name in payloads else (actual_dir / name).read_bytes())
              for name in REQUIRED_FILES}
    if (actual_dir / "confirmed_snapshot.json").is_file():
        hashes["confirmed_snapshot.json"] = sha256_bytes((actual_dir / "confirmed_snapshot.json").read_bytes())
    temporary = {}

    def stage_file(name, payload):
        fd, temp_name = tempfile.mkstemp(prefix=".audit-", suffix=".tmp", dir=actual_dir)
        temporary[name] = Path(temp_name)
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())

    try:
        # 렌더링·직렬화·임시 쓰기를 모두 끝낸 뒤 최종 파일을 교체한다.
        for name, payload in payloads.items():
            stage_file(name, payload)
        for name in ("audit_report.md", "audit_result.json"):
            target = output_path(run_dir / name, actual_dir, raw_root)
            os.replace(temporary[name], target)
        # 생성 시각과 게시 완료 시각을 분리해 병행 실행이 미완료 결과와 비교하지 않게 한다.
        marker = {"stage_version": STAGE_VERSION, "project_id": result["project_id"], "run_id": result["run_id"],
                  "completed_at": now_iso(), "files": hashes}
        stage_file(COMPLETE_FILE, json.dumps(marker, ensure_ascii=False, indent=2).encode("utf-8"))
        os.replace(temporary[COMPLETE_FILE], output_path(run_dir / COMPLETE_FILE, actual_dir, raw_root))
    finally:
        for path in temporary.values():
            path.unlink(missing_ok=True)
    return actual_dir / "audit_result.json", actual_dir / "audit_report.md"
