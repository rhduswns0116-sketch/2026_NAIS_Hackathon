"""6-1 설명 — 판정·숫자·사유는 Python, LLM은 검증된 안내 문구를 선택한다.

LLM 에 보내는 것: 주장 원문(보고서 문장), 판정, 오류 코드 이름·사유 종류, 쓸 수 있는 자리표시자 이름과 뜻.
LLM 에 보내지 않는 것: 재계산값·측정값·사유 문장(숫자가 들어 있음) (R2).
LLM 이 돌려주는 문장은 {자리표시자} 로만 수치를 가리켜야 한다. 파이썬이 검사한다
  - 문장에 숫자가 있으면 (자리표시자 밖) 거절
  - 정의되지 않은 자리표시자를 쓰면 거절
거절되거나 LLM 을 쓸 수 없으면 템플릿 문장을 쓴다. 어느 쪽이 쓰였는지 결과에 남긴다.
"""
from __future__ import annotations

import re

from ..common.llm import LLMLog, call_json
from ..validate.codes import SUPPORTED

ADVICE = (
    "보고서의 수치·단위와 승인된 계산 조건을 함께 확인하세요.",
    "입력 자료와 승인 기록을 함께 보관하세요.",
    "보고서의 표현과 승인된 항목의 대응 관계를 확인하세요.",
)
EXPLANATION_POLICY = "python-core-advice-v1"
SYSTEM_PROMPT = """너는 연구 데이터 감사 결과에 붙일 보조 안내를 선택하는 도구다.
판정·숫자·오류 코드·핵심 사유는 파이썬이 작성한다. 너는 주어진 안내 중 하나만 그대로 선택한다.
새 문장·수치·배수·오류 코드·과학적 판단을 추가하지 마라. 주장마다 claim_id와 선택한 text를 반환한다.
허용된 안내:\n""" + "\n".join(ADVICE)

SCHEMA = {
    "type": "object",
    "properties": {"explanations": {"type": "array", "items": {
        "type": "object",
        "properties": {"claim_id": {"type": "string"}, "text": {"type": "string", "enum": list(ADVICE)}},
        "required": ["claim_id", "text"], "additionalProperties": False}}},
    "required": ["explanations"],
    "additionalProperties": False,
}

_PH = re.compile(r"\{([^{}]+)\}")
_CODE = re.compile(r"(?<![A-Za-z0-9])E0[1-7](?![0-9])")
# 말로 쓴 수량 — LLM 이 "두 배" 처럼 파이썬이 채우지 않은 수치 관계를 지어내지 못하게 (R1)
_NUM_WORDS = re.compile(r"(한|두|세|네|다섯|여섯|일곱|여덟|아홉|열|백|천|만|수십|수백|수천|몇)\s?배|절반|반으로"
                        r"|\b(?:twice|double|doubled|triple|tripled|half|halved|thousand|million|hundred|dozen)\b"
                        r"|\b(?:one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:times|fold)\b", re.I)
# 판정과 설명의 방향이 맞는지 — Unsupported 인데 "일치합니다" 로만 쓰는 것을 막는다
_NEGATIVE = re.compile(r"않|불일치|어긋|다릅|다르|달라|없어|없습니다|없음|못|아닙|\bnot\b|mismatch|unsupported|inconsistent",
                       re.I)
_CONTRADICT_SUPPORTED = re.compile(r"지지(?:되지|하지)\s*(?:않|못)|일치하지 않|불일치|어긋|\bnot supported\b|unsupported|inconsistent",
                                   re.I)
_AFFIRM_SUPPORTED = re.compile(r"지지(?:합니다|됩니다|된다|한다)|\bsupported\b|일치합니다", re.I)
EXPLAIN_BATCH = 40


def _n(v) -> str:
    return f"{v:.6g}" if isinstance(v, (int, float)) and not isinstance(v, bool) else str(v)


def placeholders(item: dict) -> dict[str, tuple[str, str]]:
    """{이름: (값, 뜻)} — 값은 파이썬이 만든 문자열."""
    cmp, c = item["comparison"], item["claim"]
    rec = cmp.get("recomputed") or {}
    ph: dict[str, tuple[str, str]] = {}
    if cmp.get("reported"):
        ph["보고값"] = (cmp["reported"], "보고서에 적힌 값")
    if "rounded" in rec:
        ph["재계산값"] = (f"{rec['rounded']} {rec.get('rounded_unit') or ''}".strip(), "재계산값을 보고 자릿수로 반올림한 값")
        ph["재계산원값"] = (f"{_n(rec['raw'])} {rec.get('unit') or ''}".strip(), "반올림 전 재계산값")
    elif "raw" in rec:
        ph["재계산값"] = (f"{_n(rec['raw'])} {rec.get('unit') or ''}".strip(), "재계산값")
    if "difference" in rec:
        u = f" {rec['unit']}" if rec.get("unit") else ""
        ph["차이"] = (_n(rec["difference"]) + u, f"{c.get('lhs_output')} − {c.get('rhs_output')} 재계산 차이")
        ph["왼쪽값"] = (_n(rec["lhs"]) + u, f"{c.get('lhs_output')} 재계산값")
        ph["오른쪽값"] = (_n(rec["rhs"]) + u, f"{c.get('rhs_output')} 재계산값")
    if "p" in rec:
        ph["재계산p"] = (_n(rec["p"]), "계획서 검정으로 재계산한 p 값")
        ph["유의수준"] = (_n(rec["alpha"]), "계획서 유의수준")
    first = next((k for k in item["codes"] if k["effect"] == "unsupported"), None)
    if first:
        ph["상세"] = (first["reason"], "첫 번째 판정 사유 (숫자 포함 원문)")
    return ph


def template(item: dict) -> str:
    """LLM 없이 쓰는 설명 (자리표시자 형식)."""
    ph = placeholders(item)
    if item["verdict"] == SUPPORTED:
        if "재계산값" in ph:
            return "보고값 {보고값} 은(는) 승인된 계산으로 다시 구한 {재계산값} 과(와) 일치합니다."
        if "차이" in ph:
            return "보고된 방향이 재계산 차이 {차이} 의 부호와 일치합니다."
        if "재계산p" in ph:
            return "계획서 검정으로 재계산한 p 값 {재계산p} 이(가) 보고된 유의성 판단과 일치합니다."
        return "재계산 결과가 보고 내용과 일치합니다."
    names = ", ".join(dict.fromkeys(f"{k['code']} {k['name']}" for k in item["codes"] if k["effect"] == "unsupported"))
    return f"{names} 때문에 지지되지 않습니다. {{상세}}"


def fill(text: str, ph: dict[str, tuple[str, str]]) -> str:
    return _PH.sub(lambda m: ph[m.group(1)][0], text)


def check(text: str, ph: dict[str, tuple[str, str]], verdict: str | None = None) -> str | None:
    """문제가 있으면 이유. verdict 를 주면 설명이 판정과 반대 방향인지도 본다."""
    if not isinstance(text, str):
        return "설명 text가 문자열이 아님"
    names = _PH.findall(text)
    unknown = [n for n in names if n not in ph]
    if unknown:
        return f"정의되지 않은 자리표시자 {unknown}"
    bare = _CODE.sub("", _PH.sub("", text))    # 오류 코드 이름(E05)은 숫자로 보지 않음
    if any(char.isnumeric() for char in bare):
        return "자리표시자 밖에 숫자가 있음"
    if _NUM_WORDS.search(bare):
        return "자리표시자 밖에 말로 쓴 수량(배수·분수)이 있음"
    if not text.strip():
        return "빈 문장"
    if verdict == SUPPORTED and _CONTRADICT_SUPPORTED.search(bare):
        return "Supported 판정인데 지지되지 않는다는 표현이 있음"
    if verdict is not None and verdict != SUPPORTED and _AFFIRM_SUPPORTED.search(bare):
        return "Unsupported 판정인데 지지된다는 표현이 있음"
    if verdict is not None and verdict != SUPPORTED and not _NEGATIVE.search(bare):
        return "Unsupported 판정인데 지지되지 않는다는 표현이 없음"
    return None


def explain_all(items: list[dict], client, model: str, log: LLMLog, use_llm: bool = True) -> None:
    """Python 핵심 설명을 항상 유지하고, 검증된 보조 안내만 붙인다."""
    llm_texts: dict[str, str] = {}
    errors: dict[str, str] = {}          # claim_id → 그 묶음의 호출 오류
    call_errors: set[str] = set()
    if use_llm and client is not None and items:
        # 주장이 많으면 응답이 max_tokens 에서 잘려 전부 템플릿이 되므로 묶음으로 나눠 부른다
        for i in range(0, len(items), EXPLAIN_BATCH):
            chunk, blocks = items[i:i + EXPLAIN_BATCH], []
            for it in chunk:
                ph = placeholders(it)
                codes = "; ".join(f"{k['code']} {k['name']}" + (f"({k['reason_type']})" if k.get("reason_type") else "")
                                  + (" [기록]" if k["effect"] == "record" else "") for k in it["codes"]) or "없음"
                phs = ", ".join(f"{{{n}}}={meaning}" for n, (_, meaning) in ph.items()) or "없음"
                blocks.append(f"[{it['claim']['claim_id']}] 원문: {it['claim']['source_text']}\n"
                              f"  판정: {it['verdict']} / 오류 코드: {codes}\n  쓸 수 있는 자리표시자: {phs}")
            ids = {it["claim"]["claim_id"] for it in chunk}
            try:
                data = call_json("explanations", SYSTEM_PROMPT, SCHEMA, "\n".join(blocks), client, model, log)
            except Exception as e:
                errors.update({cid: f"{type(e).__name__}: {e}" for cid in ids})
                call_errors.update(ids)
                continue
            try:
                if not isinstance(data, dict) or not isinstance(data.get("explanations"), list):
                    raise ValueError("설명 응답에 explanations 목록이 없음")
                seen = set()
                for entry in data["explanations"]:
                    if not isinstance(entry, dict) or not isinstance(entry.get("claim_id"), str):
                        log.audit({"kind": "explanations", "event": "item_rejected", "error": "설명 항목/id 형식 오류"})
                        continue
                    cid = entry["claim_id"]
                    if cid not in ids:
                        log.audit({"kind": "explanations", "event": "item_rejected", "error": "알 수 없는 claim_id", "claim_id": cid})
                        continue
                    if cid in seen:
                        errors[cid] = "설명 응답의 claim_id가 중복됨"
                        llm_texts.pop(cid, None)
                        continue
                    seen.add(cid)
                    if not isinstance(entry.get("text"), str):
                        errors[cid] = "설명 text가 문자열이 아님"
                    else:
                        llm_texts[cid] = entry["text"]
            except Exception as e:
                errors.update({cid: f"{type(e).__name__}: {e}" for cid in ids})
    for it in items:
        ph = placeholders(it)
        cid = it["claim"]["claim_id"]
        text = llm_texts.get(cid)
        problem = (errors.get(cid) or check(text, ph) if text is not None else
                   errors.get(cid) or ("LLM 미사용" if not use_llm or client is None else "LLM 응답에 없음"))
        if problem is None and text not in ADVICE:
            problem = "허용된 보조 안내 문구가 아님"
        core = f"{it['verdict']}: " + fill(template(it), ph)
        it.update(explanation_core=core, explanation_advice=None, explanation_policy=EXPLANATION_POLICY,
                  explanation_llm_rejected=problem)
        if text is not None and problem is None:
            it["explanation"], it["explanation_source"] = core + " " + text, "llm"
            it["explanation_advice"], it["explanation_status"] = text, "llm_advice"
        else:
            it["explanation"], it["explanation_source"] = core, "template"
            it["explanation_status"] = ("not_requested" if not use_llm or client is None else
                                         "call_failed" if cid in call_errors else
                                         "invalid_response" if cid in errors else
                                         "missing_response" if text is None else "rejected")
