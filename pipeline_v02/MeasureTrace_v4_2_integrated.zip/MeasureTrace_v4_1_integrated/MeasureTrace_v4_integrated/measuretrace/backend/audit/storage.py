"""AUDIT 쓰기 경계·완료 표식·이전 실행의 비교 근거 검증."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from ..common.hashing import sha256_bytes

STAGE_VERSION = "audit-v4.1"
COMPLETE_FILE = "audit_complete.json"
REQUIRED_FILES = ("audit_result.json", "audit_report.md", "calc_log.json", "data_rows.json")


class AuditError(ValueError):
    """출력 보호 또는 완료 실행의 비교 근거 확인에 실패함."""


def timestamp(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, TypeError, ValueError) as exc:
        raise AuditError(f"실행 시각 형식이 잘못됨: {value!r}") from exc
    if parsed.tzinfo is None:
        raise AuditError(f"실행 시각에 시각대 정보가 없음: {value!r}")
    return parsed.astimezone(timezone.utc)


def _inside(path: Path, root: Path) -> bool:
    return path.resolve().is_relative_to(root.resolve())


def output_path(path: Path, root: Path, input_root: Path | None = None) -> Path:
    actual = path.resolve()
    if not _inside(actual, root) or (input_root is not None and _inside(actual, input_root)):
        raise AuditError(f"AUDIT 출력 경로가 산출물 밖 또는 RAW 안으로 연결됨: {path} (R5)")
    if path.is_symlink():
        raise AuditError(f"AUDIT 출력 대상이 symlink임: {path} (R5)")
    if actual.is_file() and actual.stat().st_nlink > 1:
        raise AuditError(f"AUDIT 출력 대상에 hard link가 있음: {path} (R5)")
    return actual


def json_object(path: Path, raw: bytes | None = None) -> dict:
    try:
        value = json.loads(path.read_bytes() if raw is None else raw)
    except (OSError, UnicodeError, ValueError) as exc:
        raise AuditError(f"실행 근거를 읽을 수 없음: {path.name}: {type(exc).__name__}") from exc
    if not isinstance(value, dict):
        raise AuditError(f"실행 근거가 JSON 객체가 아님: {path.name}")
    return value


def validate_calc(calc: dict, rows: dict) -> None:
    if not isinstance(calc.get("data"), list) or not isinstance(calc.get("code"), dict):
        raise AuditError("계산 로그에 data/code 근거가 없음")
    if not isinstance(calc["code"].get("sha256"), str):
        raise AuditError("계산 로그에 코드 해시가 없음")
    for data in calc["data"]:
        if not isinstance(data, dict) or any(not isinstance(data.get(key), str) for key in ("id", "path", "sha256")):
            raise AuditError("계산 로그의 데이터 근거 형식이 잘못됨")
        hashes = rows.get(data["id"])
        if data.get("content_hash") is not None and data["id"] not in rows:
            raise AuditError(f"데이터 행별 근거가 없음: {data['id']}")
        if hashes is not None and (not isinstance(hashes, list) or any(not isinstance(h, str) for h in hashes)):
            raise AuditError(f"데이터 행별 근거 형식이 잘못됨: {data['id']}")


def load_completed_run(run_dir: Path, project_id: str | None = None) -> dict:
    """새 실행은 완료 표식/해시를, 과거 실행은 필수 산출물과 내용 일관성을 확인한다."""
    run_dir = Path(run_dir)
    raw_files = {}

    def read(name):
        try:
            raw_files[name] = (run_dir / name).read_bytes()
        except OSError as exc:
            raise AuditError(f"실행 근거를 읽을 수 없음: {name}: {type(exc).__name__}") from exc
        return raw_files[name]

    result = json_object(run_dir / "audit_result.json", read("audit_result.json"))
    if project_id is not None and result.get("project_id") != project_id:
        raise AuditError("다른 프로젝트의 실행과 재평가할 수 없음")
    if not isinstance(result.get("project_id"), str) or result.get("run_id") != run_dir.name:
        raise AuditError("감사 결과의 project_id/run_id가 실행 폴더와 맞지 않음")
    timestamp(result.get("generated_at"))
    claims = result.get("claims")
    if not isinstance(claims, list):
        raise AuditError("감사 결과의 claims 목록이 없음")
    for claim in claims:
        if (not isinstance(claim, dict) or not isinstance(claim.get("source_text"), str)
                or claim.get("verdict") not in ("Supported", "Unsupported")
                or not isinstance(claim.get("codes"), list)
                or any(not isinstance(code, dict) or not isinstance(code.get("code"), str) for code in claim["codes"])):
            raise AuditError("감사 결과의 주장/판정 근거 형식이 잘못됨")
    calc = json_object(run_dir / "calc_log.json", read("calc_log.json"))
    rows = json_object(run_dir / "data_rows.json", read("data_rows.json"))
    validate_calc(calc, rows)
    if calc.get("run_id") != result["run_id"] or calc.get("project_id") != result["project_id"]:
        raise AuditError("계산 로그와 감사 결과의 실행/프로젝트가 다름")
    if not (run_dir / "audit_report.md").is_file():
        raise AuditError("감사 Markdown이 없어 완료 실행으로 비교할 수 없음")
    read("audit_report.md")
    recompute = result.get("recompute", {})
    if not isinstance(recompute, dict):
        raise AuditError("감사 결과의 재계산 근거 형식이 잘못됨")
    for result_key, calc_value in (("code_sha256", calc["code"]["sha256"]),
                                   ("results_sha256", calc.get("results_sha256"))):
        if result_key in recompute and recompute[result_key] != calc_value:
            raise AuditError(f"감사 결과와 계산 로그의 {result_key}가 다름")
    marker_path = run_dir / COMPLETE_FILE
    completed_at = result["generated_at"]
    if marker_path.exists():
        marker = json_object(marker_path)
        completed_at = marker.get("completed_at")
        timestamp(completed_at)
        hashes = marker.get("files")
        if (marker.get("stage_version") != STAGE_VERSION or marker.get("run_id") != result["run_id"]
                or marker.get("project_id") != result["project_id"] or not isinstance(hashes, dict)
                or not set(REQUIRED_FILES).issubset(hashes)
                or not set(hashes).issubset(set(REQUIRED_FILES) | {"confirmed_snapshot.json"})):
            raise AuditError("AUDIT 완료 표식의 실행/파일 근거가 잘못됨")
        for name, expected in hashes.items():
            try:
                actual = sha256_bytes(raw_files[name] if name in raw_files else read(name))
            except OSError as exc:
                raise AuditError(f"완료 표식의 파일이 없음: {name}") from exc
            if actual != expected:
                raise AuditError(f"완료 후 실행 근거가 변경됨: {name}")
    elif result.get("stage_version") not in (None, "audit-v4.0"):
        raise AuditError("AUDIT 완료 표식이 없어 미완료 실행임")
    return {"result": result, "calc": calc, "rows": rows, "completed_at": completed_at}
