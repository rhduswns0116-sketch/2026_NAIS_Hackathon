"""6-2 수정 후 재평가 — 이전 실행과 비교.

E07 데이터 버전 변경 (기록): 이전 실행 계산 로그(4-2)의 해시 2종과 이번 해시를 대조.
  - 바이트 해시만 다르고 내용 해시가 같으면 "형식만 변경"
  - 내용이 다르면 행별 해시로 추가·삭제 행 수를 센다 ("sample_07 파일 3행 감소")
  - 첫 실행 이전에 삭제된 데이터는 알 수 없다 (판정 범위 밖)
판정 변화: 항목·검정 중심 의미 키로 보고값이 수정된 주장도 연결하고, 반복 주장은 순서대로 대응한다.
"""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

from ..common.hashing import sha256_text
from ..validate.report_reader import normalize_text
from ..validate.claims import _NUMBER
from .storage import AuditError, json_object, load_completed_run, timestamp, validate_calc


def _load(path: Path) -> dict | None:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def find_previous_run(out_root: Path, current_run_id: str, project_id: str | None = None,
                      excluded: list[dict] | None = None) -> Path | None:
    """이번 실행 이전의, 감사 결과까지 끝난 가장 최근 실행 폴더."""
    current = json_object(out_root / "runs" / current_run_id / "calc_log.json")
    started = timestamp(current.get("started_at"))
    candidates = []
    for path in (out_root / "runs").glob("*"):
        if not path.is_dir() or path.name == current_run_id:
            continue
        try:
            completed = load_completed_run(path, project_id)
            generated = timestamp(completed["completed_at"])
            if generated >= started:
                raise AuditError("현재 계산 시작 전에 완료된 실행이 아님")
            candidates.append((generated, path.name, path))
        except (AuditError, OSError) as exc:
            if excluded is not None:
                excluded.append({"run_id": path.name, "reason": str(exc)})
    return max(candidates)[2] if candidates else None


def data_changes(prev_dir: Path, cur_dir: Path, previous: dict | None = None) -> dict:
    previous = previous if previous is not None else load_completed_run(prev_dir)
    prev, prev_rows = previous["calc"], previous["rows"]
    cur, cur_rows = json_object(cur_dir / "calc_log.json"), json_object(cur_dir / "data_rows.json")
    validate_calc(cur, cur_rows)
    before = {d["path"]: d for d in (prev or {}).get("data", [])}
    after = {d["path"]: d for d in (cur or {}).get("data", [])}
    changes, changed_ids = [], {}
    for path in sorted(set(before) | set(after)):
        b, a = before.get(path), after.get(path)
        if b is None:
            item = {"path": path, "data_id": a["id"], "change": "추가된 파일", "summary": f"{path} 파일 추가"}
        elif a is None:
            item = {"path": path, "data_id": b["id"], "change": "삭제된 파일", "summary": f"{path} 파일 삭제"}
        elif a["sha256"] == b["sha256"]:
            continue
        elif (a.get("content_hash") and a.get("content_hash") == b.get("content_hash")
              and a.get("content_hash_method") == b.get("content_hash_method")):
            item = {"path": path, "data_id": a["id"], "change": "형식만 변경",
                    "summary": f"{path} 형식만 변경 (바이트 해시만 다르고 내용 해시 같음)"}
        else:
            item = {"path": path, "data_id": a["id"], "change": "내용 변경"}
            rb, ra = prev_rows.get(b["id"]), cur_rows.get(a["id"])
            if rb is not None and ra is not None:
                added = sum((Counter(ra) - Counter(rb)).values())
                removed = sum((Counter(rb) - Counter(ra)).values())
                net = len(ra) - len(rb)
                trend = f"{abs(net)}행 {'증가' if net > 0 else '감소'}" if net else "행 수 같음"
                item.update(rows_before=len(rb), rows_after=len(ra), rows_added=added, rows_removed=removed,
                            summary=f"{path} 파일 {trend} (추가 {added}행, 삭제 {removed}행)")
            else:
                item["summary"] = f"{path} 내용 변경 (행 단위 비교 불가 — 텍스트 표가 아님)"
        item.update(sha256_before=b and b["sha256"], sha256_after=a and a["sha256"])
        changes.append(item)
        if item["change"] != "형식만 변경":
            changed_ids[item["data_id"]] = item["summary"]
    code_changed = bool(prev and cur and prev["code"]["sha256"] != cur["code"]["sha256"])
    return {"previous_run": prev_dir.name, "changes": changes, "changed_data_ids": changed_ids,
            "code_changed": code_changed,
            "code_sha256": {"before": prev and prev["code"]["sha256"], "after": cur and cur["code"]["sha256"]},
            "limit": "첫 실행 이전에 삭제·수정된 데이터는 알 수 없음 (판정 범위 밖)"}


def claim_key(claim: dict) -> str:
    """보고값과 분리한 의미 키. 반복된 같은 주장은 verdict_changes에서 순서대로 대응한다."""
    kind = claim.get("claim_type")
    outputs = claim.get("outputs_used") or []
    oid = claim.get("output_id") or (outputs[0] if kind == "numeric" and len(outputs) == 1 else None)
    if kind == "direction":
        pair = [claim.get("lhs_output"), claim.get("rhs_output")]
        pair = outputs if any(p is None for p in pair) else pair
        identity = sorted(pair)
    elif kind == "significance":
        test_id = claim.get("test_id") or (claim.get("recomputed") or {}).get("test")
        identity = [test_id] if test_id else outputs
    else:
        identity = [oid] if oid else []
    if not identity:
        source = normalize_text(claim.get("source_text") or "").lower()
        identity = [_NUMBER.sub("<number>", source)]
    body = [kind, identity, claim.get("n_scope"), claim.get("n_group")]
    return sha256_text(json.dumps(body, ensure_ascii=False, sort_keys=True))[:16]


def verdict_changes(prev_result: dict, cur_items: list[dict]) -> list[dict]:
    before, after = defaultdict(list), defaultdict(list)
    for c in prev_result.get("claims", []):
        before[claim_key(c)].append(c)
    for c in cur_items:
        after[claim_key(c)].append(c)
    def codes(c: dict, effect: str) -> list[str]:
        return sorted(k["code"] for k in c["codes"] if k.get("effect", "unsupported") == effect)

    out = []
    for key in list(dict.fromkeys(list(before) + list(after))):
        old, new = before.get(key, []), after.get(key, [])
        for index in range(max(len(old), len(new))):
            b = old[index] if index < len(old) else None
            a = new[index] if index < len(new) else None
            out.append({
                "key": f"{key}:{index + 1}",
                "source_text": (a or b)["source_text"],
                "source_text_before": b and b["source_text"], "source_text_after": a and a["source_text"],
                "before": b and b["verdict"], "after": a and a["verdict"],
                "codes_before": b and [k["code"] for k in b["codes"]],
                "codes_after": a and [k["code"] for k in a["codes"]],
                # 판정을 바꾸는 코드가 달라졌는지와, 기록(E02 진행·E07)만 달라졌는지를 나눈다 —
                # 데이터를 고치면 모든 주장에 E07 이 붙어 진짜 변화가 묻히기 때문
                "change": ("새 주장" if b is None else "사라진 주장" if a is None
                           else "판정 변화" if b["verdict"] != a["verdict"]
                           else "코드 변화" if codes(b, "unsupported") != codes(a, "unsupported")
                           else "기록 변화" if codes(b, "record") != codes(a, "record")
                           else "변화 없음"),
            })
    return out
