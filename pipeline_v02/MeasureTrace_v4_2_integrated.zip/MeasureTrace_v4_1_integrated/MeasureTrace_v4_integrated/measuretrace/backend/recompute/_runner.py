"""승인된 계산 코드를 실행하는 독립 스크립트 (별도 프로세스, python -I).

measuretrace 패키지를 import 하지 않는다. job.json 하나를 받아 result.json 하나를 쓴다.
  job = {code_path, entrypoint, params, data: [{id, path, read}], out_path}
  코드 규약: def compute(data: dict[str, DataFrame], params: dict) -> {"outputs": {id: number}, "steps": [...]}
"""
import ast
import hashlib
import io
import json
import math
import numbers
import os
import sys
import types
from pathlib import Path


def _load_verified_table(job: dict):
    """해시 검사와 pandas 입력은 같은 바이트를 사용한다."""
    import pandas as pd
    raw = Path(job["path"]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != job["sha256"]:
        raise ValueError(f"실행 데이터 사본이 바뀜: {job['id']}")
    read = dict(job.get("read") or {})
    suffix = Path(job["path"]).suffix.lower()
    stream = io.BytesIO(raw)
    if suffix in (".xlsx", ".xlsm", ".xls"):
        frame = pd.read_excel(stream, **read)
    else:
        if suffix == ".tsv" and "sep" not in read:
            read["sep"] = "\t"
        frame = pd.read_csv(stream, **read)
    # 앞단 승인 코드(compute(files) 규약)는 파일을 직접 읽는다 — 해시를 확인한 이 실행 사본의 경로만 알려 준다.
    frame.attrs["source_path"] = job["path"]
    return frame


BLOCKED_MODULES = {"ctypes", "cffi", "mmap", "pickle", "marshal", "gc", "inspect", "importlib",
                   "multiprocessing", "threading", "concurrent", "atexit"}
BLOCKED_NAMES = {"eval", "exec", "compile", "globals", "locals", "vars", "getattr", "setattr",
                 "delattr", "__import__", "breakpoint", "input"}
BLOCKED_ATTRS = {"modules", "f_globals", "f_locals", "gi_frame", "cr_frame", "tb_frame"}


def static_violations(source: str, filename: str = "approved_code.py") -> list[str]:
    """실행 전 코드 정적 검사 — 위반 목록(비면 통과). 앞단 3-1 승인 검사도 이 함수를 그대로 쓴다(규칙 한 곳)."""
    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError as exc:
        return [f"문법 오류: {exc.msg} ({exc.lineno}줄)"]
    problems = []
    for node in ast.walk(tree):
        line = getattr(node, "lineno", "?")
        modules = ([a.name.split(".")[0] for a in node.names] if isinstance(node, ast.Import) else
                   [node.module.split(".")[0]] if isinstance(node, ast.ImportFrom) and node.module else [])
        for m in modules:
            if m in BLOCKED_MODULES:
                problems.append(f"{line}줄: 런타임 접근 제한을 우회하는 모듈 {m} 금지")
        if isinstance(node, ast.ImportFrom):
            for imported in node.names:
                if imported.name == "*" or imported.name.startswith("_") \
                        or imported.name in BLOCKED_NAMES | BLOCKED_ATTRS | BLOCKED_MODULES:
                    problems.append(f"{line}줄: 허용하지 않는 import {imported.name}")
        if isinstance(node, ast.Name) and (node.id in BLOCKED_NAMES or node.id.startswith("__")):
            problems.append(f"{line}줄: 허용하지 않는 이름 {node.id}")
        if isinstance(node, ast.Attribute) and (node.attr.startswith("_")
                or node.attr in BLOCKED_ATTRS | BLOCKED_NAMES | BLOCKED_MODULES):
            problems.append(f"{line}줄: 허용하지 않는 내부 접근 .{node.attr}")
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name.startswith("__"):
            problems.append(f"{line}줄: 내부 프로토콜 재정의 {node.name} 금지")
    return problems


def _restrict_execution(source: str, job: dict):
    """승인 코드의 일반 Python 파일 접근·네트워크·프로세스 생성을 제한한다.

    네이티브 확장에 대한 OS 격리가 아니다. OS 컨테이너와 함께 사용할 수 있는 방어 계층이다.
    """
    problems = static_violations(source, job["code_path"])
    if problems:
        raise PermissionError("계산 코드 정적 검사 위반: " + "; ".join(problems[:5]))

    scratch = Path(job["out_path"]).parent / "scratch"
    out_path = Path(job["out_path"]).resolve()
    libraries = [Path(sys.base_prefix).resolve(), Path(sys.prefix).resolve()]
    read_files = {Path(job["code_path"]).resolve()} | {Path(d["path"]).resolve() for d in job["data"]}
    state = {"write_result": False}
    sys.dont_write_bytecode = True

    def inside(path: Path, root: Path) -> bool:
        return path == root or root in path.parents

    def resolved(value):
        if isinstance(value, int):
            raise PermissionError("계산 코드의 파일 디스크립터 직접 접근은 허용하지 않음")
        return Path(os.fsdecode(value)).resolve()

    def can_write(path: Path) -> bool:
        return inside(path, scratch) or (state["write_result"] and path == out_path)

    def audit(event, args):
        if event == "open":
            path = resolved(args[0])
            mode = args[1] or ""
            flags = args[2] if len(args) > 2 else 0
            writing = any(c in mode for c in "wax+") or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
            allowed = can_write(path) if writing else (path in read_files or inside(path, scratch)
                                                       or any(inside(path, root) for root in libraries))
            if not allowed:
                raise PermissionError("계산 환경 밖 파일 접근이 차단됨")
        elif event in {"os.remove", "os.rmdir", "os.mkdir", "os.rename", "os.link", "os.symlink", "os.truncate",
                       "os.chmod", "os.chown", "os.utime"}:
            paths = args[:2] if event in {"os.rename", "os.link", "os.symlink"} else args[:1]
            if any(not inside(resolved(p), scratch) for p in paths):
                raise PermissionError("계산 환경 밖 파일 변경이 차단됨")
        elif event in {"os.listdir", "os.scandir"}:
            path = resolved(args[0] or ".")
            if not inside(path, scratch) and not any(inside(path, root) for root in libraries):
                raise PermissionError("계산 환경 밖 폴더 탐색이 차단됨")
        elif event.startswith(("socket.", "subprocess.", "ctypes.", "winreg.", "os.exec", "os.spawn")) \
                or event in {"os.system", "os.fork", "os.startfile", "sys._getframe", "sys.settrace", "sys.setprofile"}:
            raise PermissionError("계산 코드의 네트워크·프로세스·네이티브/내부 접근이 차단됨")

    sys.addaudithook(audit)
    return state


def _plain(v):
    """JSON 으로 옮길 수 있는 값. numpy 수는 float 로, 유한하지 않으면 문자열 표시."""
    if isinstance(v, bool) or not isinstance(v, numbers.Real):
        return v if isinstance(v, (bool, str)) else {"non_numeric": str(v)}
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if not math.isfinite(f):
        return {"non_finite": str(f)}
    return int(v) if isinstance(v, numbers.Integral) else f


def _meta(value, depth: int = 0):
    """메타데이터를 JSON 으로 옮길 수 있는 모양으로 (깊이·개수 제한)."""
    if depth > 4:
        return None
    if isinstance(value, dict):
        return {str(k): _meta(v, depth + 1) for k, v in list(value.items())[:500]}
    if isinstance(value, (list, tuple)):
        return [_meta(v, depth + 1) for v in list(value)[:2000]]
    if value is None or isinstance(value, str):
        return value
    return _plain(value)


def main(job_path: str, expected_sha256: str) -> int:
    job_bytes = Path(job_path).read_bytes()
    if hashlib.sha256(job_bytes).hexdigest() != expected_sha256:
        raise ValueError("실행 작업 파일의 해시가 바뀜")
    job = json.loads(job_bytes.decode("utf-8"))
    out = {"ok": False}
    policy = None
    try:
        # 과학 라이브러리 초기화는 승인 코드에 제한을 적용하기 전에 끝낸다.
        import numpy
        import pandas
        import scipy.stats
        data = {d["id"]: _load_verified_table(d) for d in job["data"]}
        code_bytes = Path(job["code_path"]).read_bytes()
        if hashlib.sha256(code_bytes).hexdigest() != job["code_sha256"]:
            raise ValueError("실행 코드 사본의 해시가 바뀜")
        source = code_bytes.decode("utf-8-sig")
        policy = _restrict_execution(source, job)
        module = types.ModuleType("approved_code")
        exec(compile(source, job["code_path"], "exec"), module.__dict__)
        result = getattr(module, job["entrypoint"])(data, dict(job.get("params") or {}))
        if not isinstance(result, dict) or not isinstance(result.get("outputs"), dict):
            raise TypeError("compute() 는 {'outputs': {...}, 'steps': [...]} 를 돌려줘야 함")
        steps = []
        for s in result.get("steps") or []:
            if isinstance(s, dict):
                steps.append({str(k): _plain(v) if not isinstance(v, str) else v for k, v in s.items()})
            else:
                steps.append({"note": str(s)})
        out = {"ok": True,
               "outputs": {str(k): _plain(v) for k, v in result["outputs"].items()},
               "steps": steps,
               # 탐색 실행(discover)용 결과 메타데이터 — 이름·기호·단위·조건·식 (숫자는 outputs 에만 있다)
               "meta": _meta(result.get("meta")),
               "versions": {"python": sys.version.split()[0], "numpy": numpy.__version__,
                            "pandas": pandas.__version__, "scipy": scipy.__version__}}
    except BaseException as e:  # SystemExit를 포함해 실패도 현재 실행 결과 파일에 남긴다
        out = {"ok": False, "error": f"{type(e).__name__}: {e}",
               "traceback": ""}  # 제한 중 traceback 포맷은 추가 소스 파일을 열 수 있어 생략
    if policy is not None:
        policy["write_result"] = True
    Path(job["out_path"]).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    if policy is not None:
        policy["write_result"] = False
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
