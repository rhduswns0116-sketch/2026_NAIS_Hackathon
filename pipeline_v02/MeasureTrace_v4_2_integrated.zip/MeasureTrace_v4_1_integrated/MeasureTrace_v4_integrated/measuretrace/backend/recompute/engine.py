"""4 RECOMPUTE — 4-1 수치 재계산 · 4-2 계산 로그.

4-1 입력은 RAW 만. 승인된 코드(해시 고정)로 raw → 중간값 → 최종값. 보고서는 열지 않는다(블라인드, R4).
4-2 사용한 데이터의 해시 2종 · 계산 과정 · 결과값 · 결과 해시 · 코드 해시를 남긴다.

실행 방식 [판단]: 승인 코드는 별도 프로세스(python -I, 최소 환경변수, 시간 제한, 출력 폴더 안의 작업 폴더)에서
실행한다(R6). RAW는 해시를 확인한 실행별 사본만 제공하고 runner가 Python 파일·네트워크 접근을 제한한다.
이것은 운영체제 수준의 샌드박스가 아니므로 신뢰할 수 없는 네이티브 코드를 실행하는 용도로 쓰지 않는다.
"""
from __future__ import annotations

import json
import copy
import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from ..common.hashing import canonical_json, fingerprint_bytes, now_iso, sha256_bytes, sha256_text
from ..common.ledger import Ledger
from ..contract import Confirmed

STAGE_VERSION = "recompute-v4.2"
RUNNER = Path(__file__).with_name("_runner.py")
DEFAULT_TIMEOUT_S = 120
_ENV_KEEP = ("SYSTEMROOT", "WINDIR", "PATH", "TEMP", "TMP", "LANG", "LC_ALL")


class RecomputeError(RuntimeError):
    pass


class CodeHashMismatch(RecomputeError):
    """승인된 코드와 실행하려는 코드가 다름."""


class DataChangedError(RecomputeError):
    """CONFIRM 이후 입력 데이터가 바뀜 — INGEST 부터 다시."""


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _output_path(path: Path, root: Path, input_root: Path) -> Path:
    """junction/symlink를 푼 실제 쓰기 대상이 산출물 폴더 안이고 RAW 밖인지 확인한다."""
    actual = path.resolve()
    if not _inside(actual, root) or _inside(actual, input_root):
        raise RecomputeError(f"출력 경로가 산출물 폴더 밖 또는 RAW 안으로 연결됨: {path} → {actual} (R5)")
    if actual.is_file() and actual.stat().st_nlink > 1:
        raise RecomputeError(f"출력 파일에 hard link가 있어 다른 파일을 변경할 수 있음: {path} (R5)")
    return actual


def _fixed_code(confirmed: Confirmed, out_root: Path) -> tuple[Path, str]:
    """코드 해시를 확인하고 출력 폴더의 approved_code/<해시>.py 로 고정한다. 같은 해시면 그 파일을 재사용."""
    src = confirmed.code_path()
    if _inside(src, Path(confirmed.input_root)):
        raise RecomputeError("RAW 입력 폴더의 스크립트는 실행할 수 없음 (R6)")
    if not src.is_file():
        raise RecomputeError(f"승인된 코드 파일이 없음: {src}")
    raw = src.read_bytes()
    sha = sha256_bytes(raw)
    if sha != confirmed.code.sha256:
        raise CodeHashMismatch(f"코드 해시 {sha[:12]} ≠ 승인값 {confirmed.code.sha256[:12]} — 승인 후 코드가 바뀜, "
                               f"3-1 에서 다시 승인 필요")
    fixed = _output_path(out_root / "approved_code" / f"{sha}.py", out_root, Path(confirmed.input_root))
    if not fixed.exists():
        fixed.parent.mkdir(parents=True, exist_ok=True)
        fixed.write_bytes(raw)
    elif sha256_bytes(fixed.read_bytes()) != sha:
        raise CodeHashMismatch(f"고정된 코드 파일이 변조됨: {fixed}")
    return fixed, sha


def _check_data(confirmed: Confirmed, run_dir: Path) -> tuple[list[dict], list[dict]]:
    """데이터 파일마다 해시 2종을 다시 떠서 CONFIRM 시점 해시와 대조. (계산 로그용 기록, runner 작업 목록)."""
    input_root = Path(confirmed.input_root).resolve()
    records, jobs, rows = [], [], {}
    snapshot_dir = _output_path(run_dir / "input_snapshot", run_dir, input_root)
    snapshot_dir.mkdir()
    for index, d in enumerate(confirmed.data):
        path = (input_root / d.path).resolve()
        if not _inside(path, input_root):
            raise RecomputeError(f"데이터 {d.id}: 입력 폴더 밖 경로 {d.path!r}")
        if not path.is_file():
            raise DataChangedError(f"데이터 {d.id}: 파일이 없음 ({d.path}) — INGEST 부터 다시")
        raw = path.read_bytes()
        fp = fingerprint_bytes(raw, path.suffix)
        if fp["sha256"] != d.sha256:
            raise DataChangedError(f"데이터 {d.id}: CONFIRM 이후 파일이 바뀜 "
                                   f"({fp['sha256'][:12]} ≠ {d.sha256[:12]}) — INGEST 부터 다시")
        if d.content_hash and fp["content_hash"] != d.content_hash:
            raise DataChangedError(f"데이터 {d.id}: 승인된 내용 해시와 다름")
        snapshot = _output_path(snapshot_dir / f"{index:04d}{path.suffix.lower()}", run_dir, input_root)
        snapshot.write_bytes(raw)
        rows[d.id] = fp.pop("row_hashes")
        records.append({"id": d.id, "path": d.path, **fp, "row_hashes_file": "data_rows.json",
                        "snapshot_path": str(snapshot.relative_to(run_dir))})
        jobs.append({"id": d.id, "path": str(snapshot), "read": copy.deepcopy(d.read), "sha256": fp["sha256"]})
    _output_path(run_dir / "data_rows.json", run_dir, input_root).write_text(
        json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    return records, jobs


def _run_sandboxed(code_path: Path, entrypoint: str, params: dict, jobs: list[dict],
                   sandbox: Path, timeout_s: int, code_sha256: str) -> tuple[dict, dict]:
    sandbox.mkdir(parents=True, exist_ok=False)
    job_path, out_path = sandbox / "job.json", sandbox / "result.json"
    job_path.write_text(json.dumps({"code_path": str(code_path), "code_sha256": code_sha256,
                                    "entrypoint": entrypoint, "params": params,
                                    "data": jobs, "out_path": str(out_path)}, ensure_ascii=False),
                        encoding="utf-8")
    job_sha = sha256_bytes(job_path.read_bytes())
    env = {k: os.environ[k] for k in _ENV_KEEP if k in os.environ}   # API 키 등은 넘기지 않는다
    env["PYTHONIOENCODING"] = "utf-8"
    # 수치 라이브러리 스레드를 1개로 — 병렬 합산 순서 때문에 결과가 실행마다 달라지지 않게 (앞단 4단계에서 가져옴)
    env.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    scratch = sandbox / "scratch"
    scratch.mkdir()
    env["TEMP"] = env["TMP"] = str(scratch)
    try:
        proc = subprocess.run([sys.executable, "-I", "-X", "utf8", str(RUNNER), str(job_path), job_sha], cwd=sandbox, env=env,
                              capture_output=True, text=True, encoding="utf-8", errors="replace",
                              timeout=timeout_s)
    except subprocess.TimeoutExpired as e:
        raise RecomputeError(f"계산 코드가 {timeout_s}초 안에 끝나지 않음") from e
    runner = {"python": sys.version.split()[0], "timeout_s": timeout_s, "returncode": proc.returncode,
              "stderr_tail": proc.stderr[-2000:], "execution_policy": "python-audit-v2", "job_sha256": job_sha}
    if not out_path.exists():
        return {"ok": False, "error": f"계산 프로세스가 결과를 남기지 않음 (returncode {proc.returncode}): "
                f"{proc.stderr[-500:]}"}, runner
    try:
        result = json.loads(out_path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        return {"ok": False, "error": f"계산 응답을 읽을 수 없음: {exc}"}, runner
    if not isinstance(result, dict) or not isinstance(result.get("ok"), bool):
        return {"ok": False, "error": "계산 응답 형식이 잘못됨"}, runner
    if proc.returncode != 0 and result["ok"]:
        return {"ok": False, "error": f"계산 프로세스가 비정상 종료함 ({proc.returncode})"}, runner
    return result, runner


def _check_outputs(confirmed: Confirmed, raw: dict) -> tuple[dict, list[str]]:
    """코드가 낸 숫자를 승인된 Output 목록에 맞춘다. 목록에 없는 값은 쓰지 않는다(R3)."""
    produced = raw.get("outputs") or {}
    outputs = {}
    for o in confirmed.outputs:
        v = produced.get(o.id)
        if o.id not in produced:
            outputs[o.id] = {"status": "missing", "value": None, "unit": o.unit,
                             "error": "승인된 코드가 이 값을 내지 않음"}
        elif isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            outputs[o.id] = {"status": "invalid", "value": None, "unit": o.unit,
                             "error": f"수치가 아님: {v!r}"}
        elif (o.kind == "p_value" and not 0 <= v <= 1) or (o.kind == "n" and (v < 0 or int(v) != v)) \
                or (o.kind == "df" and v < 0):
            outputs[o.id] = {"status": "invalid", "value": None, "unit": o.unit, "error": f"{o.kind} 값 범위 오류: {v}"}
        else:
            outputs[o.id] = {"status": "ok", "value": v, "unit": o.unit, "error": None}
    extra = sorted(set(produced) - {o.id for o in confirmed.outputs})
    return outputs, extra


def _discovered(raw: dict) -> tuple[dict, dict]:
    """탐색 실행: 코드가 낸 값 전부를 기록한다. (유한한 숫자, 숫자가 아닌 값). 판정에는 아직 쓰지 않는다."""
    produced, invalid = {}, {}
    for key, v in (raw.get("outputs") or {}).items():
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            invalid[key] = repr(v)
        else:
            produced[key] = v
    return produced, invalid


def run_recompute(confirmed: Confirmed, out_root: str | Path, run_id: str,
                  timeout_s: int = DEFAULT_TIMEOUT_S, discover: bool = False) -> dict:
    """4-1 + 4-2. 계산 로그(dict)를 돌려주고 runs/<run_id>/calc_log.json 에 쓴다.

    코드 해시 불일치·데이터 변경·형식 문제는 예외(계산하지 않음). 코드 실행 실패는 로그에 남기고 status=failed.

    discover=True (통합본 4단계): 항목 목록 승인 전에 승인 코드를 **한 번** 실행해 낸 값 전부(`produced`)와
    결과 메타데이터(`produced_meta`)를 기록한다. 항목 목록은 이 결과로 만들어 사람이 승인한 뒤
    bind_outputs() 가 같은 계산 로그에 붙인다 — 다시 실행하지 않는다. 미확정·미결정 항목이 하나라도 있으면
    범위를 좁힐 수 없으므로 실행 전체를 막는다.
    """
    # 공개 API의 원객체는 앞단이 편집할 수 있다. 실행·승인·로그는 한 번 캡처한 깊은 사본만 사용한다.
    confirmed = Confirmed.from_dict(confirmed.to_dict(), base_dir=confirmed.base_dir)
    confirmed_sha = sha256_text(canonical_json(confirmed.to_dict()))
    out_root = Path(out_root).resolve()
    input_root = Path(confirmed.input_root).resolve()
    if _inside(out_root, input_root):
        raise RecomputeError(f"출력 폴더가 입력 폴더 안에 있음: {out_root} (R5)")
    problems = confirmed.problems(discover=discover)
    if problems:
        raise RecomputeError("confirmed.json 형식 문제: " + "; ".join(problems))
    if not isinstance(run_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", run_id):
        raise RecomputeError("run_id는 경로 구분자 없이 영문·숫자·_·-·.로 지정해야 함")
    run_dir = _output_path(out_root / "runs" / run_id, out_root, input_root)
    lineage_path = _output_path(out_root / "lineage.jsonl", out_root, input_root)
    try:
        run_dir.mkdir(parents=True, exist_ok=False)
    except FileExistsError as exc:
        raise RecomputeError(f"이미 존재하는 run_id: {run_id} — 새 실행 id를 사용해야 함") from exc

    started = now_iso()
    _output_path(run_dir / "confirmed_snapshot.json", run_dir, input_root).write_text(
        json.dumps(confirmed.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    data_records, jobs = _check_data(confirmed, run_dir)
    blocked_dependencies = confirmed.discovery_blockers() if discover else confirmed.unconfirmed_dependencies()
    approval_problems = confirmed.approval_problems() + [d["reason"] for d in blocked_dependencies]
    code_path, code_sha = None, confirmed.code.sha256
    if approval_problems:
        raw = {"ok": False, "blocked": True, "error": "; ".join(approval_problems)}
        runner = {"executed": False, "reason": raw["error"]}
    else:
        code_path, code_sha = _fixed_code(confirmed, out_root)
        try:
            raw, runner = _run_sandboxed(code_path, confirmed.code.entrypoint, copy.deepcopy(confirmed.code.params), jobs,
                                         _output_path(run_dir / "sandbox", run_dir, input_root), timeout_s, code_sha)
            runner["executed"] = True
        except RecomputeError as exc:
            raw = {"ok": False, "error": str(exc)}
            runner = {"executed": True, "timeout_s": timeout_s, "error": str(exc)}
    produced, produced_invalid = {}, {}
    if raw.get("ok") and discover:
        produced, produced_invalid = _discovered(raw)
        outputs, extra, error = {}, [], None
        status = "ok" if produced and not produced_invalid else "partial" if produced else "failed"
        if not produced:
            error = "승인 코드가 유한한 숫자 결과를 하나도 내지 않음"
    elif raw.get("ok"):
        outputs, extra = _check_outputs(confirmed, raw)
        status = "ok" if all(o["status"] == "ok" for o in outputs.values()) else "partial"
        error = None
    else:
        state = "blocked" if raw.get("blocked") else "failed"
        outputs = {o.id: {"status": state, "value": None, "unit": o.unit, "error": raw.get("error")}
                   for o in confirmed.outputs}
        extra, status, error = [], state, raw.get("error")
    finished = now_iso()

    values = produced if discover else {k: v["value"] for k, v in outputs.items()}
    log = {
        "stage": "4-2 계산 로그",
        "stage_version": STAGE_VERSION,
        "run_id": run_id,
        "project_id": confirmed.project_id,
        "status": status,
        "error": error,
        "started_at": started,
        "finished_at": finished,
        "confirmed_sha256": confirmed_sha,
        "confirmed_snapshot_path": "confirmed_snapshot.json",
        "mode": "discover" if discover else "bound",
        "execution_sha256": confirmed.execution_sha256(),
        "execution_gate": {"mode": "discover-all-or-nothing" if discover else "single-compute",
                           "blocked_dependencies": blocked_dependencies},
        "code": {"sha256": code_sha, "fixed_path": str(code_path.relative_to(out_root)) if code_path else None,
                 "entrypoint": confirmed.code.entrypoint, "llm_drafted": confirmed.code.llm_drafted,
                 "approved_by": confirmed.code.approved_by, "approved_at": confirmed.code.approved_at,
                 "approval_hash": confirmed.code.approval_hash,
                 "approval_scope": "bundle" if confirmed.code.approval_hash else "legacy-code"},
        "params": confirmed.code.params,
        "data": data_records,
        "outputs": outputs,
        "unapproved_outputs_ignored": extra,
        **({"produced": produced, "produced_invalid": produced_invalid, "produced_meta": raw.get("meta")}
           if discover else {}),
        "steps": raw.get("steps", []),
        "versions": raw.get("versions"),
        "results_sha256": sha256_text(canonical_json(values)),
        "runner": runner,
        "report_opened": False,     # 블라인드: 이 시점까지 보고서를 열지 않았음
    }
    _output_path(run_dir / "calc_log.json", run_dir, input_root).write_text(
        json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
    Ledger(_output_path(lineage_path, out_root, input_root)).record(
        step="4-1", code_sha256=code_sha, params=confirmed.code.params,
        inputs=[{"path": d["path"], "sha256": d["sha256"]} for d in data_records],
        outputs=[{"path": f"runs/{run_id}/calc_log.json#outputs", "sha256": log["results_sha256"]}],
        note=f"status={status}")
    if status == "ok":   # 실패했으면 작업 폴더(job.json·result.json)를 진단용으로 남긴다
        shutil.rmtree(_output_path(run_dir / "sandbox", run_dir, input_root), ignore_errors=True)
    return log


def bind_outputs(confirmed: Confirmed, out_root: str | Path, run_id: str) -> dict:
    """탐색 실행(discover) 계산 로그에 사람이 승인한 항목 목록을 붙인다 — 다시 실행하지 않는다.

    확인: 탐색 실행 로그인가 · 아직 결합 전인가 · 실행 지문(RAW·코드·파라미터)이 같은가 · 항목 묶음이 봉인됐는가.
    값은 탐색 실행이 기록한 produced 에서 가져와 _check_outputs 로 범위를 검사하고, 미확정 의존 항목은 값을 쓰지 않고
    blocked 로 둔다(관련 주장 E06 '미확정'). 결합 전 로그·인계 사본은 *_discover.json 으로 보존하고,
    calc_log.json · confirmed_snapshot.json 은 결합 결과로 바꿔 5·6 의 기존 확인(블라인드·인계 지문)이 그대로 동작하게 한다.
    계산 시각(finished_at)은 바꾸지 않는다 — 블라인드 입증은 실제 계산 시각 기준이다.
    """
    confirmed = Confirmed.from_dict(confirmed.to_dict(), base_dir=confirmed.base_dir)
    out_root = Path(out_root).resolve()
    input_root = Path(confirmed.input_root).resolve()
    problems = confirmed.problems()
    if problems:
        raise RecomputeError("confirmed.json 형식 문제: " + "; ".join(problems))
    run_dir = _output_path(out_root / "runs" / run_id, out_root, input_root)
    calc_path = _output_path(run_dir / "calc_log.json", run_dir, input_root)
    if not calc_path.is_file():
        raise RecomputeError(f"탐색 실행 계산 로그가 없음: runs/{run_id}")
    raw_calc = calc_path.read_bytes()
    calc = json.loads(raw_calc.decode("utf-8"))
    if (run_dir / "calc_log_discover.json").exists() or calc.get("binding"):
        raise RecomputeError("이미 항목 목록이 결합된 실행 — 다시 감사하려면 4단계 새 실행이 필요")
    if calc.get("mode") != "discover":
        raise RecomputeError("탐색 실행 계산 로그가 아님 — 결합할 수 없음")
    if calc.get("project_id") != confirmed.project_id:
        raise RecomputeError("탐색 실행과 인계 파일의 프로젝트가 다름")
    if calc.get("execution_sha256") != confirmed.execution_sha256():
        raise RecomputeError("4단계 실행 뒤 RAW·코드·파라미터가 바뀜 — 4단계를 다시 실행해야 함")
    # 승인 코드가 없으면(3-1 미확정·거부) 탐색 실행은 막힌 채 기록돼 있다 — 항목 없이 결합해 5·6 에서 모든 수치
    # 주장을 E06(미확정)으로 판정한다. 막히지 않은 실행에 코드 미확정을 허용하지는 않는다.
    no_code = confirmed.code_pending()
    if no_code and calc.get("status") != "blocked":
        raise RecomputeError("승인 코드가 없는데 탐색 실행이 막히지 않았음 — 결합할 수 없음")
    approval = confirmed.approval_problems(allow_code_pending=no_code)
    if not confirmed.code.approval_hash:
        approval.append("항목 목록 승인 지문(approval_hash)이 없음 — seal_approval 로 봉인해야 함")
    if approval:
        raise RecomputeError("항목 목록 승인 문제: " + "; ".join(approval))

    if calc.get("status") in ("ok", "partial"):
        outputs, extra = _check_outputs(confirmed, {"outputs": calc.get("produced") or {}})
    else:   # 탐색 실행이 막혔거나 실패했으면 모든 항목이 같은 상태 — 관련 주장은 E06
        state = calc.get("status") if calc.get("status") in ("blocked", "failed") else "failed"
        outputs = {o.id: {"status": state, "value": None, "unit": o.unit, "error": calc.get("error")}
                   for o in confirmed.outputs}
        extra = []
    blocked = confirmed.unconfirmed_dependencies()
    for dep in blocked:
        for oid in dep["outputs"]:
            if outputs.get(oid, {}).get("status") == "ok":
                outputs[oid] = {"status": "blocked", "value": None, "unit": outputs[oid]["unit"],
                                "error": dep["reason"]}
    if calc.get("status") in ("ok", "partial"):
        status = "ok" if all(o["status"] == "ok" for o in outputs.values()) else "partial"
    else:
        status = calc.get("status")

    # 결합 전 근거 보존 (덮어쓰지 않음)
    _output_path(run_dir / "calc_log_discover.json", run_dir, input_root).write_bytes(raw_calc)
    snap = run_dir / "confirmed_snapshot.json"
    if snap.is_file():
        _output_path(run_dir / "confirmed_snapshot_discover.json", run_dir, input_root).write_bytes(snap.read_bytes())
    _output_path(snap, run_dir, input_root).write_text(
        json.dumps(confirmed.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")

    values = {k: v["value"] for k, v in outputs.items()}
    bound = dict(calc)
    bound.update(
        mode="bound-after-discover",
        status=status,
        confirmed_sha256=sha256_text(canonical_json(confirmed.to_dict())),
        outputs=outputs,
        unapproved_outputs_ignored=extra,
        results_sha256=sha256_text(canonical_json(values)),
        execution_gate={**(calc.get("execution_gate") or {}), "bound_blocked_outputs": blocked},
        code={**(calc.get("code") or {}), "approved_by": confirmed.code.approved_by,
              "approved_at": confirmed.code.approved_at, "approval_hash": confirmed.code.approval_hash,
              "approval_scope": "bundle"},
        binding={"bound_at": now_iso(), "discover_calc_sha256": sha256_bytes(raw_calc),
                 "discover_calc_path": "calc_log_discover.json", "executions": 1,
                 "note": "항목 목록은 탐색 실행 결과로 만들어 사람이 승인 — 값은 같은 실행의 기록을 사용(재실행 없음)"},
    )
    calc_path.write_text(json.dumps(bound, ensure_ascii=False, indent=2), encoding="utf-8")
    Ledger(_output_path(out_root / "lineage.jsonl", out_root, input_root)).record(
        step="4-1 결합", code_sha256=bound["code"]["sha256"], params={"approval_hash": confirmed.code.approval_hash},
        inputs=[{"path": f"runs/{run_id}/calc_log_discover.json", "sha256": bound["binding"]["discover_calc_sha256"]}],
        outputs=[{"path": f"runs/{run_id}/calc_log.json#outputs", "sha256": bound["results_sha256"]}],
        note=f"status={status}")
    return bound
