"""LLM 호출 공통 — 캐시 우선, 프롬프트 지문, 감사 기록(R7).

practice_v4 measuretrace/common/llm.py 에서 옮김. 바뀐 점
  - 캐시·감사 기록 위치를 출력 폴더 기준으로 받는다 (입력 폴더에 쓰지 않음, R5).
  - 응답의 stop_reason 이 refusal 이면 실패로 처리한다.
  - 서버 측 fallback(거절 시 다른 모델로 재시도)을 기본으로 켠다. MT_LLM_FALLBACK=0 이면 끈다.
원칙: 측정값은 보내지 않는다(R2). LLM 응답 속 숫자를 계산 입력으로 쓰지 않는다(R1).
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from .hashing import now_iso

DEFAULT_MODEL = "claude-opus-5-5"
FALLBACK_BETA = "server-side-fallback-2026-07-01"


class LLMError(RuntimeError):
    pass


class LLMLog:
    """출력 폴더 안의 캐시·감사 기록."""

    def __init__(self, out_root: str | Path):
        root = Path(out_root)
        self.cache_dir = root / "llm_cache"
        self.audit_path = root / "llm_audit_log.jsonl"

    def audit(self, event: dict) -> None:
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        with self.audit_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(event, at=now_iso()), ensure_ascii=False) + "\n")


def _fingerprint(system_prompt: str, schema: dict) -> str:
    return hashlib.sha256((system_prompt + json.dumps(schema, sort_keys=True)).encode("utf-8")).hexdigest()[:16]


def _create(client, kwargs: dict, use_fallback: bool, log: LLMLog, base: dict):
    """서버 측 fallback 을 켜고 부른다. 모델·계정이 fallback 을 받지 않아 400 이면 끄고 한 번 더."""
    if not use_fallback:
        return client.messages.create(**kwargs)
    try:
        return client.messages.create(**kwargs, extra_headers={"anthropic-beta": FALLBACK_BETA},
                                      extra_body={"fallbacks": "default"})
    except Exception as e:
        # fallback 인자 자체를 거절한 400 만 재시도한다 (스키마 오류 등 다른 400 은 그대로 올린다)
        if type(e).__name__ != "BadRequestError" or "fallback" not in str(e).lower():
            raise
        log.audit(dict(base, event="fallback_rejected", error=f"{type(e).__name__}: {e}"))
        return client.messages.create(**kwargs)


def call_json(kind: str, system_prompt: str, schema: dict, user_content: str, client, model: str,
              log: LLMLog, max_tokens: int = 16000) -> dict:
    """캐시를 먼저 보고, 없으면 LLM 을 부른다. 캐시 키 = (종류, 프롬프트 지문, 입력). 모두 감사 기록에 남긴다."""
    fp = _fingerprint(system_prompt, schema)
    input_hash = hashlib.sha256(user_content.encode("utf-8")).hexdigest()[:16]
    cache_path = log.cache_dir / f"{kind}_{fp}_{input_hash}.json"
    base = {"kind": kind, "input_hash": input_hash, "prompt_fingerprint": fp, "cache_file": cache_path.name}
    if cache_path.exists():
        log.audit(dict(base, event="cache_hit"))
        return json.loads(cache_path.read_text(encoding="utf-8"))["response"]
    if client is None:
        log.audit(dict(base, event="no_client"))
        raise LLMError("LLM 클라이언트가 없고 캐시에도 없음")

    kwargs = dict(model=model, max_tokens=max_tokens, system=system_prompt,
                  messages=[{"role": "user", "content": user_content}],
                  output_config={"format": {"type": "json_schema", "schema": schema}})
    use_fallback = os.environ.get("MT_LLM_FALLBACK", "1") != "0" and not getattr(client, "is_fake", False)
    try:
        response = _create(client, kwargs, use_fallback, log, base)
        if getattr(response, "stop_reason", None) == "refusal":
            raise LLMError("모델이 요청을 거절함 (stop_reason=refusal)")
        if getattr(response, "stop_reason", None) == "max_tokens":
            raise LLMError("응답이 max_tokens 에서 잘림")
        text = next(b.text for b in response.content if b.type == "text")
        data = json.loads(text)
    except Exception as e:
        log.audit(dict(base, event="call_error", model=model, error=f"{type(e).__name__}: {e}"))
        raise
    log.cache_dir.mkdir(parents=True, exist_ok=True)
    meta = {"model": model, "model_reported": getattr(response, "model", None),
            "response_id": getattr(response, "id", None), "created_at": now_iso()}
    cache_path.write_text(json.dumps({"meta": meta, "response": data}, ensure_ascii=False, indent=2),
                          encoding="utf-8")
    log.audit(dict(base, event="call", **meta))
    return data


class OfflineClient:
    """캐시만 쓰는 클라이언트 (토큰 0). 캐시에 없는 요청은 실패한다."""
    is_fake = True

    class _Messages:
        def create(self, **kwargs):
            raise LLMError("오프라인 모드 — 캐시에 없는 LLM 요청은 보내지 않음")

    def __init__(self):
        self.messages = self._Messages()


def make_client(env_path: str | Path | None = None):
    """(client, model). MEASURETRACE_OFFLINE=1 이면 캐시 전용, 키가 있으면 실제 클라이언트(토큰 사용), 없으면 None."""
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path) if env_path else load_dotenv()
    except ImportError:
        pass
    model = os.environ.get("LLM_MODEL_STRONG", "").strip() or DEFAULT_MODEL
    if os.environ.get("MEASURETRACE_OFFLINE") == "1":
        return OfflineClient(), model
    key = os.environ.get("LLM_API_KEY", "").strip() or os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        return None, model
    import anthropic
    return anthropic.Anthropic(api_key=key), model
