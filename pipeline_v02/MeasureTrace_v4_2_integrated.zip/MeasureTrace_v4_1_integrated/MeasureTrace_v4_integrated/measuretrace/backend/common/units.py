"""단위 해석·환산 (pint). E01 ② 보고 단위 ↔ 재계산 단위 환산에 쓴다.

같은 단위의 다른 표기(ohm/sq, Ω/□)는 정규화 사전으로 흡수한다 (오류코드 E01 오탐 주의).
"""
from __future__ import annotations

import re

import pint

ureg = pint.UnitRegistry()
ureg.define("square = 1 = sq")   # 면저항의 per square — 무차원 형상 인자

ALIASES = {
    "%": "percent", "퍼센트": "percent", "pct": "percent",
    "Ω": "ohm", "Ω": "ohm", "옴": "ohm",
    "Ω/□": "ohm/square", "ohm/□": "ohm/square", "ohm/sq": "ohm/square", "Ω/sq": "ohm/square",
    "ohms/sq": "ohm/square", "ohm per square": "ohm/square",
    "kΩ/□": "kiloohm/square", "kohm/sq": "kiloohm/square", "kΩ": "kiloohm", "MΩ": "megaohm",
    "°C": "degC", "℃": "degC", "µ": "u", "μ": "u",
}


class UnitError(ValueError):
    pass


def normalize(unit: str | None) -> str | None:
    if unit is None:
        return None
    u = unit.strip()
    if not u:
        return None
    if u in ALIASES:
        return ALIASES[u]
    for k, v in (("µ", "u"), ("μ", "u"), ("Ω", "ohm"), ("Ω", "ohm"), ("□", "square"), ("·", "*")):
        u = u.replace(k, v)
    return re.sub(r"\s+", " ", u)


def is_dimensionless(unit: str | None) -> bool:
    n = normalize(unit)
    if n is None:
        return True
    try:
        return ureg.Unit(n).dimensionless
    except Exception as e:
        raise UnitError(f"단위 {unit!r} 를 해석할 수 없음") from e


def convert(value: float, from_unit: str | None, to_unit: str | None) -> float:
    """from_unit → to_unit. 둘 다 없으면 그대로. 차원이 다르거나 해석 불가면 UnitError."""
    f, t = normalize(from_unit), normalize(to_unit)
    if f is None and t is None:
        return value
    try:
        q = ureg.Quantity(value, f or "dimensionless")
        return float(q.to(t or "dimensionless").magnitude)
    except pint.errors.DimensionalityError as e:
        raise UnitError(f"{from_unit!r} 와 {to_unit!r} 는 차원이 달라 환산할 수 없음") from e
    except Exception as e:
        raise UnitError(f"단위 {from_unit!r} → {to_unit!r} 환산 실패: {type(e).__name__}") from e
