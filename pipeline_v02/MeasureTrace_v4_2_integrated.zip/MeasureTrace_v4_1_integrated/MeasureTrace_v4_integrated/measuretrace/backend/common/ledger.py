"""1-3 산출물 이력 장부 (lineage). skeleton_3 mt/lineage.py 를 v4 정의에 맞춰 옮김.

(입력 해시, 코드 해시, 파라미터) → 출력 해시 를 한 줄씩 추가만 한다 (JSON Lines).
"""
from __future__ import annotations

import json
from pathlib import Path

from .hashing import canonical_json, now_iso, sha256_text

LEDGER_NAME = "lineage.jsonl"


class Ledger:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def record(self, step: str, code_sha256: str, params: dict,
               inputs: list[dict], outputs: list[dict], note: str = "") -> dict:
        """inputs / outputs 는 [{"path": ..., "sha256": ...}]."""
        body = {
            "step": step,
            "code_sha256": code_sha256,
            "params_hash": sha256_text(canonical_json(params))[:16],
            "params": params,
            "inputs": sorted(inputs, key=lambda x: x["path"]),
            "outputs": sorted(outputs, key=lambda x: x["path"]),
            "note": note,
        }
        entry = {"id": sha256_text(canonical_json(body))[:12], "ts": now_iso(), **body}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        return entry

    def entries(self) -> list[dict]:
        if not self.path.exists():
            return []
        with open(self.path, encoding="utf-8") as f:
            return [json.loads(ln) for ln in f if ln.strip()]
