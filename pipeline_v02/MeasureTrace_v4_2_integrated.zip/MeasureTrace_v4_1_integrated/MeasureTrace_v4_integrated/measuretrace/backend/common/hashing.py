"""해시 2종 (1-2와 같은 정의) · 행별 해시 · 정규 JSON.

4-2 계산 로그와 6-2 재평가(E07)가 같은 함수로 해시를 떠야 서로 비교할 수 있다.
CSV 내용 정규화: BOM 제거, 개행 통일, 줄 끝 공백 제거, 끝의 빈 줄 제거 (파이프라인 v4 1-2).
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

CONTENT_HASH_METHOD = "text-lines-v1"   # 방법이 다르면 서로 비교하지 않는다
TEXT_SUFFIXES = {".csv", ".tsv", ".txt", ".dat", ".asc", ".prn"}
CHUNK = 1 << 20


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(CHUNK), b""):
            h.update(block)
    return h.hexdigest()


def canonical_json(obj) -> str:
    """키 정렬·공백 없는 JSON. 결과 해시·장부 id 에 쓴다."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def now_iso() -> str:
    """마이크로초까지. 블라인드 입증(계산 로그 시각 < 보고서 열람 시각)에 쓴다."""
    return datetime.now().astimezone().isoformat(timespec="microseconds")


def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "cp949"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def normalized_lines(path: str | Path) -> list[str] | None:
    """텍스트 표의 정규화된 줄 목록. 텍스트 표가 아니면 None."""
    p = Path(path)
    if p.suffix.lower() not in TEXT_SUFFIXES:
        return None
    lines = [ln.rstrip() for ln in _decode(p.read_bytes()).splitlines()]
    while lines and not lines[-1]:
        lines.pop()
    return lines


def content_hash(path: str | Path) -> str | None:
    lines = normalized_lines(path)
    return None if lines is None else sha256_text("\n".join(lines))


def row_hashes(path: str | Path) -> list[str] | None:
    """행마다 짧은 해시. 이전 실행과 행 단위 차이(추가·삭제)를 세는 데 쓴다 (E07)."""
    lines = normalized_lines(path)
    return None if lines is None else [sha256_text(ln)[:16] for ln in lines]


def file_fingerprint(path: str | Path) -> dict:
    """해시 2종 + 행 수 + 행별 해시."""
    return fingerprint_bytes(Path(path).read_bytes(), Path(path).suffix)


def fingerprint_bytes(raw: bytes, suffix: str) -> dict:
    """같은 바이트에서 모든 지문을 계산한다. 실행 사본과 로그가 같은 입력을 가리킨다."""
    lines = None
    if suffix.lower() in TEXT_SUFFIXES:
        lines = [ln.rstrip() for ln in _decode(raw).splitlines()]
        while lines and not lines[-1]:
            lines.pop()
    rows = None if lines is None else [sha256_text(ln)[:16] for ln in lines]
    return {
        "sha256": sha256_bytes(raw),
        "content_hash": None if lines is None else sha256_text("\n".join(lines)),
        "content_hash_method": CONTENT_HASH_METHOD if rows is not None else None,
        "rows": None if rows is None else len(rows),
        "row_hashes": rows,
    }
