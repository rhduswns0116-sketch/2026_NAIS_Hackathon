"""3 CONFIRM → 4 RECOMPUTE 인계 형식 (앞단·뒷단 계약서).

앞단(1~3)은 CONFIRM 이 끝나면 이 형식의 confirmed.json 을 출력 폴더에 쓴다.
뒷단(4~6)은 이 파일만 읽는다. 보고서 내용은 여기에 들어가지 않는다(R4: 보고서는 5-1에서 처음 연다).
이 파일을 바꾸면 반드시 팀 전체에 공지할 것.

참조(ref) 표기 — 의존 관계와 오류 기록의 대상을 같은 표기로 적는다
  "<data_id>"            데이터 파일 전체
  "<data_id>#<column>"   데이터 파일의 한 열
  "item:<id>"            계획서가 요구한 파일·시료·측정 항목 (2-4 누락 점검)
  "eq:<id>" / "code"     식 / 계산 코드
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Literal

from .common.hashing import canonical_json, now_iso, sha256_text

SCHEMA_VERSION = "confirmed-v4.0"

OutputKind = Literal["value", "difference", "ratio", "percent_change",
                     "test_statistic", "p_value", "df", "n"]
OUTPUT_KINDS = OutputKind.__args__
TEST_NAMES = ("student_t", "welch_t", "paired_t", "one_sample_t", "one_way_anova", "other")
READ_OPTION_KEYS = {"sep", "header", "skiprows", "encoding", "decimal", "comment", "sheet_name"}


@dataclass
class Column:
    meaning: str
    unit: str | None = None
    unit_status: Literal["approved", "unresolved"] = "approved"   # 3회 뒤에도 미확정이면 unresolved (E01)


@dataclass
class DataFile:
    """RAW 데이터 파일 하나. 계산의 유일한 데이터 입력 (PROCESSED 는 쓰지 않음)."""
    id: str
    path: str                       # input_root 기준 상대 경로
    sha256: str                     # 1-2 원본 바이트 해시 (CONFIRM 시점)
    content_hash: str | None = None
    read: dict = field(default_factory=dict)          # pandas 읽기 옵션 (READ_OPTION_KEYS 만)
    columns: dict[str, Column] = field(default_factory=dict)


@dataclass
class Equation:
    """2-1b 계획서 수식 (OMML → LaTeX), 3-1 승인."""
    id: str
    latex: str
    context: str = ""               # 수식 앞 문단 문장
    eq_hash: str = ""


@dataclass
class ApprovedCode:
    """3-1에서 승인된 계산 코드. 해시가 맞지 않으면 실행하지 않는다 (R1)."""
    path: str                       # confirmed.json 기준 상대 경로 (출력 폴더 안)
    sha256: str
    entrypoint: str = "compute"     # def compute(data: dict[str, DataFrame], params: dict) -> dict
    params: dict = field(default_factory=dict)
    llm_drafted: bool = True
    approved_by: str = ""
    approved_at: str = ""
    approval_hash: str = ""         # 선택: 코드·파라미터·식·매칭·단위·설계를 함께 승인한 지문


@dataclass
class Output:
    """승인된 코드가 내야 하는 재계산값 하나. 이름·단위·의미는 여기서 정하고, 코드는 숫자만 낸다."""
    id: str
    description: str                # 사람이 읽는 설명. 5-1에서 LLM 이 주장과 짝지을 때 본다 (값은 안 봄)
    kind: OutputKind
    unit: str | None = None
    equations: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)   # ref 표기
    groups: list[str] = field(default_factory=list)       # difference·ratio 는 [대상, 기준] 순서
    terms: list[str] = field(default_factory=list)        # 3-1 승인 지표 용어 (예: ["전도도", "conductance"]).
    # 5-2 에서 주장 문장에 이 중 하나가 있어야 이 항목과 짝지을 수 있다 (value·difference·ratio·percent_change).
    # 비어 있으면 용어 대조를 생략하고 리포트에 그렇게 적는다.


@dataclass
class Test:
    """계획서의 검정 방법 (2-1c 추출, 3-1 승인)."""
    __test__ = False                # pytest 가 테스트 클래스로 모으지 않게
    id: str
    name: str                       # TEST_NAMES
    groups: list[str]
    alpha: float = 0.05
    p_output: str | None = None     # Output id
    stat_output: str | None = None
    df_output: str | None = None
    description: str = ""


@dataclass
class Design:
    """계획서의 설계 — 독립 단위·반복 수 (E04 대조 기준)."""
    independent_unit: str = ""
    groups: dict[str, int] = field(default_factory=dict)   # 집단별 독립 단위 수
    replicates_per_unit: int | None = None                 # 기술적 반복 (예: 위치 7개)
    tests: list[Test] = field(default_factory=list)


@dataclass
class Flag:
    """앞단이 탐지·확정한 오류 기록 (E01 단위, E02 이상값, E03 누락)."""
    code: Literal["E01", "E02", "E03"]
    target: str                     # ref 표기
    detail: str
    decision: Literal["proceed", "unresolved", "missing"]
    location: dict = field(default_factory=dict)          # {file, row, column}
    decided_by: str = ""
    decided_at: str = ""


@dataclass
class Pending:
    """CONFIRM 3회 뒤에도 승인되지 않은 항목 (E06 사유 '미확정')."""
    target: str                     # ref 표기 또는 Output id
    what: str


@dataclass
class Confirmed:
    project_id: str
    input_root: str
    data: list[DataFile]
    code: ApprovedCode
    outputs: list[Output]
    equations: list[Equation] = field(default_factory=list)
    design: Design = field(default_factory=Design)
    flags: list[Flag] = field(default_factory=list)
    pending: list[Pending] = field(default_factory=list)
    confirm_rounds: int = 1
    schema_version: str = SCHEMA_VERSION
    base_dir: str = ""              # confirmed.json 이 있던 폴더 (코드 경로 기준). 저장하지 않음

    # ---- 조회 ----
    def output(self, oid: str | None) -> Output | None:
        return next((o for o in self.outputs if o.id == oid), None)

    def test(self, tid: str | None) -> Test | None:
        return next((t for t in self.design.tests if t.id == tid), None)

    def data_file(self, did: str) -> DataFile | None:
        return next((d for d in self.data if d.id == did), None)

    def code_path(self) -> Path:
        return (Path(self.base_dir) / self.code.path).resolve()

    def approval_payload(self) -> dict:
        """CONFIRM에서 보여 주고 승인해야 하는 계산 해석 묶음. 경로·시각과 구분한다."""
        return {
            "data": [asdict(d) for d in self.data], "equations": [asdict(e) for e in self.equations],
            "outputs": [asdict(o) for o in self.outputs], "design": asdict(self.design),
            "code": {"sha256": self.code.sha256, "entrypoint": self.code.entrypoint, "params": self.code.params},
        }

    def execution_payload(self) -> dict:
        """계산 실행에 들어가는 것만 — RAW(경로·해시·읽기 옵션)와 코드(해시·진입점·파라미터).

        탐색 실행(4단계, 항목 목록 승인 전)과 항목 결합(5·6 직전)이 같은 실행을 가리키는지 이 지문으로 확인한다.
        항목 목록·설계·기록은 계산을 바꾸지 않으므로 넣지 않는다(그것들은 approval_payload 로 따로 봉인).
        """
        return {
            "data": [{"id": d.id, "path": d.path, "sha256": d.sha256, "content_hash": d.content_hash, "read": d.read}
                     for d in self.data],
            "code": {"sha256": self.code.sha256, "entrypoint": self.code.entrypoint, "params": self.code.params},
        }

    def execution_sha256(self) -> str:
        return sha256_text(canonical_json(self.execution_payload()))

    def discovery_blockers(self) -> list[dict]:
        """탐색 실행 전 차단 사유. 항목 목록을 아직 모르므로 미확정·미결정은 범위를 좁히지 않고 전부 막는다 (R3)."""
        blocked = []
        for p in self.pending:
            if p.target != "code":   # 코드 자체의 미확정은 approval_problems 에서 막음
                blocked.append({"target": p.target, "reason": f"미확정 항목 {p.target}: {p.what}"})
        for d in self.data:
            for name, column in d.columns.items():
                if column.unit_status == "unresolved":
                    blocked.append({"target": f"{d.id}#{name}", "reason": f"열 {d.id}#{name}의 단위가 미확정"})
        for flag in self.flags:
            if flag.code in ("E01", "E02") and flag.decision == "unresolved":
                blocked.append({"target": flag.target, "reason": f"{flag.code} 처리 미확정: {flag.detail}"})
        return blocked

    def seal_approval(self, approved_by: str, approved_at: str | None = None) -> None:
        """앞단이 실제 사용자 승인 후 호출한다. 뒷단은 승인/재승인을 자동 생성하지 않는다."""
        if not approved_by.strip():
            raise ValueError("승인자가 필요함")
        self.code.approved_by = approved_by
        self.code.approved_at = approved_at or now_iso()
        self.code.approval_hash = sha256_text(canonical_json(self.approval_payload()))

    def code_pending(self) -> bool:
        """승인된 계산 코드가 없음(3-1 미확정·거부) — 재계산 없이 5·6 에서 모든 수치 주장을 E06(미확정)으로 판정한다."""
        return any(p.target == "code" for p in self.pending)

    def approval_problems(self, allow_code_pending: bool = False) -> list[str]:
        """allow_code_pending: 코드 없이 5·6 을 돌리는 경우(계산은 막힌 채 기록됨) — 코드 미확정만 문제로 보지 않는다."""
        out = []
        if not isinstance(self.code.approved_by, str) or not self.code.approved_by.strip() \
                or not isinstance(self.code.approved_at, str) or not self.code.approved_at.strip():
            out.append("계산 코드의 승인자·승인 시각이 없음")
        else:
            try:
                datetime.fromisoformat(self.code.approved_at)
            except ValueError:
                out.append("승인 시각이 ISO 날짜/시각 형식이 아님")
        if self.code_pending() and not allow_code_pending:
            out.append("계산 코드가 CONFIRM에서 미확정")
        if self.code.approval_hash and self.code.approval_hash != sha256_text(canonical_json(self.approval_payload())):
            out.append("승인 후 파라미터·식·매칭·단위·설계가 바뀜 — CONFIRM에서 다시 승인 필요")
        return out

    # ---- 검사 ----
    def unconfirmed_dependencies(self) -> list[dict]:
        """단일 compute에서 사용하는 미확정 의존 대상. 결과 삭제로 실행 승인을 대신하지 않는다."""
        by_output = {o.id: [o.id, "code", *o.depends_on, *[f"eq:{e}" for e in o.equations]]
                     for o in self.outputs}
        blocked = []

        def add(target: str, reason: str) -> None:
            affected = [oid for oid, refs in by_output.items() if any(refs_overlap(ref, target) for ref in refs)]
            if affected:
                blocked.append({"target": target, "outputs": affected, "reason": reason})

        for p in self.pending:
            if p.target != "code":  # 코드 자체의 미확정은 approval_problems에서 전체 차단
                add(p.target, f"미확정 의존 항목 {p.target}: {p.what}")
        for d in self.data:
            for name, column in d.columns.items():
                if column.unit_status == "unresolved":
                    target = f"{d.id}#{name}"
                    add(target, f"열 {target}의 단위가 미확정")
        for flag in self.flags:
            if flag.code in ("E01", "E02") and flag.decision == "unresolved":
                add(flag.target, f"{flag.code} 처리 미확정: {flag.detail}")
        return blocked

    def problems(self, discover: bool = False) -> list[str]:
        """형식 문제. 비어 있어야 RECOMPUTE 를 시작한다.

        discover=True: 4단계 탐색 실행용 실행 묶음 — 항목 목록은 실행 뒤 승인하므로 비어 있어야 한다.
        """
        out = []
        if not self.data:
            out.append("RAW 데이터 목록이 비어 있음")
        if discover and self.outputs:
            out.append("탐색 실행 묶음에는 Output 목록이 없어야 함 (항목 목록은 실행 뒤 승인)")
        if not discover and not self.outputs and not self.code_pending():
            out.append("승인된 Output 목록이 비어 있음")
        if self.schema_version != SCHEMA_VERSION:
            out.append(f"schema_version {self.schema_version!r} ≠ {SCHEMA_VERSION!r}")
        if isinstance(self.confirm_rounds, bool) or not isinstance(self.confirm_rounds, int) \
                or not 1 <= self.confirm_rounds <= 3:
            out.append(f"confirm_rounds {self.confirm_rounds} — CONFIRM 피드백은 1~3회")
        ids = [o.id for o in self.outputs]
        if len(ids) != len(set(ids)):
            out.append("Output id 중복")
        eq_ids = {e.id for e in self.equations}
        data_ids = {d.id for d in self.data}
        for name, values in (("데이터", [d.id for d in self.data]), ("식", [e.id for e in self.equations]),
                             ("검정", [t.id for t in self.design.tests])):
            if len(values) != len(set(values)):
                out.append(f"{name} id 중복")
        for o in self.outputs:
            if o.kind not in OUTPUT_KINDS:
                out.append(f"Output {o.id}: kind {o.kind!r} 모름")
            for e in o.equations:
                if e not in eq_ids:
                    out.append(f"Output {o.id}: 식 {e!r} 없음")
            for ref in o.depends_on:
                if ref == "code" or ref.startswith("item:"):
                    continue
                if ref.startswith("eq:"):
                    if ref[3:] not in eq_ids:
                        out.append(f"Output {o.id}: 의존 식 {ref!r} 없음")
                    continue
                did, _, column = ref.partition("#")
                if did not in data_ids:
                    out.append(f"Output {o.id}: 의존 데이터 {ref!r} 없음")
                elif column and column not in self.data_file(did).columns:
                    out.append(f"Output {o.id}: 의존 열 {ref!r} 없음")
        for d in self.data:
            bad = set(d.read) - READ_OPTION_KEYS
            if bad:
                out.append(f"데이터 {d.id}: 허용하지 않는 읽기 옵션 {sorted(bad)}")
            for name, column in d.columns.items():
                if column.unit_status not in ("approved", "unresolved"):
                    out.append(f"데이터 {d.id} 열 {name}: unit_status {column.unit_status!r} 모름")
        for t in self.design.tests:
            if t.name not in TEST_NAMES:
                out.append(f"검정 {t.id}: 이름 {t.name!r} 모름 ({TEST_NAMES})")
            for ref in (t.p_output, t.stat_output, t.df_output):
                if ref and ref not in ids:
                    out.append(f"검정 {t.id}: Output {ref!r} 없음")
            if isinstance(t.alpha, bool) or not isinstance(t.alpha, (int, float)) \
                    or not math.isfinite(t.alpha) or not 0 < t.alpha < 1:
                out.append(f"검정 {t.id}: alpha는 0과 1 사이여야 함")
            if any(g not in self.design.groups for g in t.groups):
                out.append(f"검정 {t.id}: 설계에 없는 집단")
        for group, n in self.design.groups.items():
            if isinstance(n, bool) or not isinstance(n, int) or n <= 0:
                out.append(f"집단 {group}: 독립 단위 수는 양의 정수여야 함")
        repeats = self.design.replicates_per_unit
        if repeats is not None and (isinstance(repeats, bool) or not isinstance(repeats, int) or repeats <= 0):
            out.append("기술적 반복 수는 양의 정수여야 함")
        return out

    # ---- 저장·읽기 ----
    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("base_dir")
        return d

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def from_dict(cls, d: dict, base_dir: str = "") -> "Confirmed":
        design = d.get("design") or {}
        return cls(
            project_id=d["project_id"],
            input_root=d["input_root"],
            data=[DataFile(**{**x, "columns": {k: Column(**v) for k, v in (x.get("columns") or {}).items()}})
                  for x in d["data"]],
            code=ApprovedCode(**d["code"]),
            outputs=[Output(**x) for x in d["outputs"]],
            equations=[Equation(**x) for x in d.get("equations", [])],
            design=Design(**{**design, "tests": [Test(**t) for t in design.get("tests", [])]}),
            flags=[Flag(**x) for x in d.get("flags", [])],
            pending=[Pending(**x) for x in d.get("pending", [])],
            confirm_rounds=d.get("confirm_rounds", 1),
            schema_version=d.get("schema_version", ""),
            base_dir=base_dir,
        )

    @classmethod
    def load(cls, path: str | Path) -> "Confirmed":
        p = Path(path)
        return cls.from_dict(json.loads(p.read_text(encoding="utf-8")), base_dir=str(p.resolve().parent))


def refs_overlap(a: str, b: str) -> bool:
    """두 참조가 같은 대상을 가리키는가. 파일 전체는 그 파일의 열을 포함한다."""
    return a == b or a.startswith(b + "#") or b.startswith(a + "#")
