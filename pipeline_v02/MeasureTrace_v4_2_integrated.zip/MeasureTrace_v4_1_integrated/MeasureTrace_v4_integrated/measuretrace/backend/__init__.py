"""MeasureTrace v4 — 뒷단 (4 RECOMPUTE · 5 VALIDATE · 6 AUDIT).

기준 문서: MeasureTrace_파이프라인_v4_확정.md, MeasureTrace_오류코드_v4.md
앞단(1 INGEST · 2 EXTRACT · 3 CONFIRM)의 결과는 contract.Confirmed 형식으로 받는다.
"""
__version__ = "0.1.0"
