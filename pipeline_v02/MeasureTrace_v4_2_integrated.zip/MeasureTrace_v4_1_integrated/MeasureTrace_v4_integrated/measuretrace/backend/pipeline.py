"""뒷단 실행 순서 (파이프라인 v4 5장).

  4-1 → 4-2 → 5-1(보고서 첫 열람) → 5-2 → [6-2 이전 실행과 데이터 비교 → E07] → 5-3 → 6-1
  6-2 의 데이터 비교는 5-3 이 E07 기록을 붙일 수 있도록 5-3 앞에서, 판정 비교는 6-1 결과를 만든 뒤에 한다.

진입점
  run_backend          인계 파일(항목 목록 포함)로 4→5→6 을 한 번에 (단독 뒷단)
  run_discovery        통합본 4단계 — 항목 목록 승인 전 승인 코드를 한 번 실행 (discover)
  run_validate_audit   통합본 5·6 — 같은 실행에 승인된 항목 목록을 결합(bind_outputs)하고 5→6. 재실행 없음

실행:
  python -m measuretrace.pipeline --confirmed <confirmed.json> --report <보고서> --out <출력 폴더>
  LLM: .env 의 LLM_API_KEY(또는 ANTHROPIC_API_KEY)·LLM_MODEL_STRONG. MEASURETRACE_OFFLINE=1 이면 캐시만(토큰 0).
"""
from __future__ import annotations

import argparse
import json
import secrets
import sys
from datetime import datetime
from pathlib import Path

from .audit import (build_result, data_changes, explain_all, find_previous_run,
                    load_completed_run, verdict_changes, write_outputs)
from .audit.storage import AuditError, timestamp
from .common.hashing import now_iso
from .common.llm import LLMLog, make_client
from .contract import Confirmed
from .recompute import bind_outputs, run_recompute
from .validate import BlindnessError, classify, compare_all, extract_claims


def new_run_id() -> str:
    return datetime.now().strftime("%Y%m%dT%H%M%S%f") + "-" + secrets.token_hex(3)


def run_backend(confirmed: Confirmed | str | Path, report_path: str | Path, out_root: str | Path,
                client=None, model: str = "", run_id: str | None = None, previous_run: str | Path | None = "auto",
                explain_with_llm: bool = True, timeout_s: int = 120, expected_report_sha256: str | None = None) -> dict:
    """뒷단 전체. 감사 결과(dict)를 돌려준다. previous_run: "auto"=가장 최근 실행, None=비교 안 함, 경로=그 실행.
    expected_report_sha256: 보고서를 받은 때의 해시 — 주면 5-1 에서 열 때 대조한다."""
    if not isinstance(confirmed, Confirmed):
        confirmed = Confirmed.load(confirmed)
    # 같은 인계 사본을 4~6 전체에서 유지한다. 원객체 편집이 승인된 실행의 주장·설계를 바꾸지 않게 한다.
    confirmed = Confirmed.from_dict(confirmed.to_dict(), base_dir=confirmed.base_dir)
    out_root = Path(out_root).resolve()
    run_id = run_id or new_run_id()
    run_dir = out_root / "runs" / run_id
    report = Path(report_path).resolve()
    if any((Path(confirmed.input_root) / d.path).resolve() == report for d in confirmed.data):
        raise BlindnessError("보고서 경로가 RAW 계산 입력과 같음 (R4)")
    previous = _explicit_previous(previous_run, confirmed)

    # 4 RECOMPUTE — 보고서를 열지 않는다
    calc = run_recompute(confirmed, out_root, run_id, timeout_s=timeout_s)
    return _validate_audit(confirmed, report_path, out_root, run_id, run_dir, calc, client, model,
                           previous_run, previous, explain_with_llm, expected_report_sha256)


def run_discovery(confirmed: Confirmed | str | Path, out_root: str | Path, run_id: str | None = None,
                  timeout_s: int = 120) -> dict:
    """통합본 4단계 — 항목 목록 승인 전 승인 코드를 한 번 실행해 결과 전체를 기록한다(보고서 안 엶)."""
    if not isinstance(confirmed, Confirmed):
        confirmed = Confirmed.load(confirmed)
    return run_recompute(confirmed, Path(out_root).resolve(), run_id or new_run_id(), timeout_s=timeout_s,
                         discover=True)


def run_validate_audit(confirmed: Confirmed | str | Path, report_path: str | Path, out_root: str | Path,
                       run_id: str, client=None, model: str = "", previous_run: str | Path | None = "auto",
                       explain_with_llm: bool = True, expected_report_sha256: str | None = None) -> dict:
    """통합본 5·6 — 4단계 탐색 실행(run_id)에 승인된 항목 목록을 붙이고 5→6 을 실행한다. 다시 계산하지 않는다."""
    if not isinstance(confirmed, Confirmed):
        confirmed = Confirmed.load(confirmed)
    confirmed = Confirmed.from_dict(confirmed.to_dict(), base_dir=confirmed.base_dir)
    out_root = Path(out_root).resolve()
    run_dir = out_root / "runs" / run_id
    report = Path(report_path).resolve()
    if any((Path(confirmed.input_root) / d.path).resolve() == report for d in confirmed.data):
        raise BlindnessError("보고서 경로가 RAW 계산 입력과 같음 (R4)")
    if (run_dir / "blind_log.json").exists():
        raise BlindnessError("이 실행은 이미 보고서를 열었음 — 새 4단계 실행이 필요")
    previous = _explicit_previous(previous_run, confirmed)
    calc = bind_outputs(confirmed, out_root, run_id)
    return _validate_audit(confirmed, report_path, out_root, run_id, run_dir, calc, client, model,
                           previous_run, previous, explain_with_llm, expected_report_sha256)


def _explicit_previous(previous_run, confirmed: Confirmed) -> dict | None:
    if not previous_run or previous_run == "auto":
        return None
    previous = load_completed_run(Path(previous_run), confirmed.project_id)
    if timestamp(previous["completed_at"]) >= timestamp(now_iso()):
        raise AuditError("미래 시각의 실행을 이전 실행으로 지정할 수 없음")
    return previous


def _validate_audit(confirmed: Confirmed, report_path, out_root: Path, run_id: str, run_dir: Path, calc: dict,
                    client, model: str, previous_run, previous: dict | None, explain_with_llm: bool,
                    expected_report_sha256: str | None = None) -> dict:
    # 5 VALIDATE
    claims_out = extract_claims(confirmed, report_path, run_dir, out_root, client, model, expected_report_sha256)
    comparisons = compare_all(claims_out["claims"], confirmed, calc)

    excluded = []
    prev_dir = (find_previous_run(out_root, run_id, confirmed.project_id, excluded) if previous_run == "auto"
                else Path(previous_run) if previous_run else None)
    if prev_dir and previous is None:
        previous = load_completed_run(prev_dir, confirmed.project_id)
    if previous and timestamp(previous["completed_at"]) >= timestamp(calc["started_at"]):
        raise AuditError("현재 계산 시작 전에 완료된 실행만 재평가할 수 있음")
    dchg = data_changes(prev_dir, run_dir, previous) if prev_dir else None
    items = classify(claims_out["claims"], comparisons, confirmed,
                     changed_data_ids=dchg["changed_data_ids"] if dchg else None)

    # 6 AUDIT
    explain_all(items, client, model, LLMLog(out_root), use_llm=explain_with_llm)
    result = build_result(items, claims_out, calc, confirmed, rerun=None)
    result["previous_run_selection"] = {"mode": "auto" if previous_run == "auto" else
                                         "explicit" if previous_run else "none",
                                         "selected": prev_dir.name if prev_dir else None, "excluded": excluded}
    if prev_dir:
        result["rerun"] = {"data": dchg, "verdicts": verdict_changes(previous["result"], result["claims"])}
    write_outputs(result, run_dir, input_root=confirmed.input_root, out_root=out_root)
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="MeasureTrace v4 뒷단 (RECOMPUTE → VALIDATE → AUDIT)")
    ap.add_argument("--confirmed", required=True, help="앞단이 만든 confirmed.json")
    ap.add_argument("--report", required=True, help="최종 보고서 초안 (docx/pdf/txt/md) — 별도 경로")
    ap.add_argument("--out", required=True, help="출력 폴더 (입력 폴더 밖)")
    ap.add_argument("--env", default=None, help=".env 경로")
    ap.add_argument("--no-previous", action="store_true", help="이전 실행과 비교하지 않음")
    ap.add_argument("--no-llm-explain", action="store_true", help="설명 문장을 템플릿으로만")
    args = ap.parse_args(argv)
    client, model = make_client(args.env)
    if client is None:
        print("경고: LLM 키가 없음 — 5-1 주장 추출은 캐시에 있는 것만 가능", file=sys.stderr)
    result = run_backend(args.confirmed, args.report, args.out, client=client, model=model,
                         previous_run=None if args.no_previous else "auto",
                         explain_with_llm=not args.no_llm_explain)
    s = result["summary"]
    print(f"실행 {result['run_id']}: Supported {s['Supported']} · Unsupported {s['Unsupported']} · "
          f"검사 대상 아님 {s['검사 대상 아님']} · 구조화 실패 {s['구조화 실패']}")
    print(f"리포트: {Path(args.out).resolve() / 'runs' / result['run_id'] / 'audit_report.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
