"""허용오차 두 종류 (파이프라인 v4 6장).

① 도구 정확도: 재계산값 vs 벤치마크 정답(반올림 전) — 상대 오차 ≤ 1e-6
② 주장 판정 (E05): 재계산값을 보고서 수치의 유효 자릿수로 반올림해 같으면 일치
   - 소수점이 있으면 그 자릿수까지 ("7.60" → 0.01 단위)
   - 소수점 없는 정수는 끝의 0 을 유효숫자로 보지 않음 ("1200" → 100 단위, "7" → 1 단위)
   - 과학 표기 "3.2e-5", "3.2×10⁻⁵" 지원
   - 반올림은 사사오입(ROUND_HALF_UP). float 는 repr(최단 표현)으로 Decimal 에 옮긴다.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

TOOL_REL_TOL = 1e-6
_SUP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+")
_NUM = re.compile(r"^[+-]?(\d+(?:\.\d*)?|\.\d+)$")


class ReportedNumberError(ValueError):
    pass


@dataclass(frozen=True)
class Reported:
    text: str
    value: Decimal
    quantum: Decimal          # 반올림 단위 (예: 0.01, 1E+2)

    @property
    def float(self) -> float:
        return float(self.value)


def parse_reported(text: str) -> Reported:
    """보고서에 적힌 수치 문자열 → 값과 반올림 단위."""
    s = text.strip().translate(_SUP).replace("−", "-").replace("–", "-").replace(" ", "")
    if re.fullmatch(r"[+-]?\d{1,3}(,\d{3})+(\.\d+)?", s):
        s = s.replace(",", "")
    exponent = 0
    m = re.fullmatch(r"(.+?)(?:[×xX*]10\^?([+-]?\d+)|[eE]([+-]?\d+))", s)
    if m:
        s, exponent = m.group(1), int(m.group(2) or m.group(3))
    if not _NUM.match(s):
        raise ReportedNumberError(f"수치로 읽을 수 없음: {text!r}")
    try:
        mantissa = Decimal(s)
    except InvalidOperation as e:
        raise ReportedNumberError(f"수치로 읽을 수 없음: {text!r}") from e
    digits = s.lstrip("+-")
    if "." in digits:
        decimals = len(digits.split(".")[1])
        q_exp = exponent - decimals
    else:
        stripped = digits.rstrip("0")
        trailing = len(digits) - len(stripped) if stripped else 0
        q_exp = exponent + trailing
    return Reported(text=text, value=mantissa.scaleb(exponent), quantum=Decimal(1).scaleb(q_exp))


def round_like(x: float, reported: Reported) -> Decimal:
    """재계산값 x 를 보고 수치와 같은 단위로 반올림."""
    if not math.isfinite(x):
        raise ValueError(f"유한하지 않은 재계산값 {x}")
    return Decimal(repr(float(x))).quantize(reported.quantum, rounding=ROUND_HALF_UP)


def matches(x: float, reported: Reported) -> tuple[bool, Decimal]:
    """(일치, 반올림한 재계산값)."""
    r = round_like(x, reported)
    return r == reported.value, r


def fmt(d: Decimal) -> str:
    """반올림 결과를 사람이 읽는 문자열로."""
    if d == 0:
        return "0" if d.as_tuple().exponent >= 0 else f"{d:f}"
    exp = d.adjusted()
    if -4 <= exp < 9:
        return f"{d:f}"
    return f"{d:E}"


def tool_accuracy_ok(recomputed: float, benchmark: float, rel_tol: float = TOOL_REL_TOL) -> bool:
    """① 도구 정확도 — 벤치마크 정답과 상대 오차 ≤ 1e-6. 정답이 0 이면 재계산값도 정확히 0 이어야 함."""
    if benchmark == 0:
        return recomputed == 0
    return abs(recomputed - benchmark) / abs(benchmark) <= rel_tol


def power_of_ten_factor(x: float, reported: Reported, allowed=(2, 3, 6, 9, 12)) -> int | None:
    """x × 10^k 가 보고값과 반올림 일치하는 k (환산 누락 의심, E01). 없으면 None."""
    if x == 0 or reported.value == 0:
        return None
    k = round(math.log10(abs(reported.float / x)))
    if abs(k) not in allowed:
        return None
    ok, _ = matches(x * 10 ** k, reported)
    return k if ok else None
