"""5-1 보고서 읽기 — 문장마다 쪽 번호·문장 번호.

DOCX 쪽 번호 [판단]: docx 에는 쪽 정보가 없다. Word 가 저장할 때 남기는 w:lastRenderedPageBreak 가 있으면 그것을,
없으면 명시적 쪽 나눔(w:br type=page, pageBreakBefore)을 센다. 둘 다 없으면 전부 1쪽 — 근사값임을 기록한다.
PDF 는 pdfplumber 쪽 번호, 텍스트는 폼피드(\\f)로 쪽을 나눈다.
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path

from lxml import etree

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

_ABBREV = ("et al.", "e.g.", "i.e.", "vs.", "Fig.", "fig.", "Eq.", "eq.", "No.", "no.", "approx.", "ca.", "cf.",
           "Ref.", "ref.", "Tab.", "Dr.", "Mr.", "Ms.")
_SPLIT = re.compile(r"(?<=[.!?。])\s+(?=\S)")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.replace("−", "-").replace("–", "-").replace(" ", " ")).strip()


def split_sentences(text: str) -> list[str]:
    text = normalize_text(text)
    if not text:
        return []
    protected = text
    for i, a in enumerate(_ABBREV):
        protected = protected.replace(a, a.replace(".", f"\u0000{i}\u0000"))
    parts = _SPLIT.split(protected)
    out = []
    for p in parts:
        for i, a in enumerate(_ABBREV):
            p = p.replace(a.replace(".", f"\u0000{i}\u0000"), a)
        if p.strip():
            out.append(p.strip())
    return out


def _docx_blocks(path: Path) -> tuple[list[tuple[int, str, str]], str]:
    """[(쪽, 종류, 텍스트)], 쪽 번호 방식."""
    root = etree.fromstring(zipfile.ZipFile(path).read("word/document.xml"))
    body = root.find(W + "body")
    rendered = root.find(f".//{W}lastRenderedPageBreak") is not None
    mode = "lastRenderedPageBreak" if rendered else "explicit_page_breaks"
    page = 1
    blocks: list[tuple[int, str, str]] = []

    def is_break(el) -> bool:
        if rendered:
            return el.tag == W + "lastRenderedPageBreak"
        return el.tag == W + "br" and el.get(W + "type") == "page"

    def paragraph(p, kind: str) -> None:
        nonlocal page
        if not rendered and p.find(f"{W}pPr/{W}pageBreakBefore") is not None:
            page += 1
        buf = []
        for el in p.iter():
            if el.tag == W + "t" and el.text:
                buf.append(el.text)
            elif el.tag == W + "tab":
                buf.append(" ")
            elif is_break(el):
                if "".join(buf).strip():
                    blocks.append((page, kind, "".join(buf)))
                buf = []
                page += 1
        if "".join(buf).strip():
            blocks.append((page, kind, "".join(buf)))

    for child in body:
        if child.tag == W + "p":
            paragraph(child, "paragraph")
        elif child.tag == W + "tbl":
            for tr in child.iter(W + "tr"):
                cells = []
                for tc in tr.iter(W + "tc"):
                    cells.append(" ".join("".join(t.text or "" for t in p.iter(W + "t")) for p in tc.iter(W + "p")))
                row = " | ".join(c.strip() for c in cells)
                if row.strip(" |"):
                    blocks.append((page, "table_row", row))
    if page == 1 and not rendered:
        mode = "none (전부 1쪽 — 쪽 정보 없음)"
    return blocks, mode


def read_report(path: str | Path) -> dict:
    """{"sentences": [{sid, page, no_in_page, block, kind, text}], "page_mode": ...}."""
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix == ".docx":
        blocks, mode = _docx_blocks(p)
    elif suffix == ".pdf":
        import pdfplumber
        with pdfplumber.open(str(p)) as pdf:
            blocks = []
            for i, pg in enumerate(pdf.pages, start=1):
                text = pg.extract_text() or ""
                # PDF 줄바꿈은 문장 중간일 수 있어 빈 줄 기준 문단으로 잇는다
                for para in re.split(r"\n\s*\n", text):
                    blocks.append((i, "paragraph", para.replace("\n", " ")))
        mode = "pdf_pages"
    else:
        raw = p.read_bytes()
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp949", errors="replace")
        blocks = []
        for i, pg in enumerate(text.split("\f"), start=1):
            for para in re.split(r"\n\s*\n|\n(?=#)", pg):
                blocks.append((i, "paragraph", para.replace("\n", " ")))
        mode = "form_feed"

    sentences, per_page, references = [], {}, []
    in_refs = False
    for b, (page, kind, text) in enumerate(blocks, start=1):
        if _REF_HEADING.match(normalize_text(text)):
            in_refs = True          # 참고문헌 절은 주장 문장이 아니다 — 원문만 따로 모은다
            continue
        if in_refs:
            if normalize_text(text):
                references.append({"page": page, "text": normalize_text(text)})
            continue
        units = [normalize_text(text)] if kind == "table_row" else split_sentences(text)
        for s in units:
            if not s:
                continue
            per_page[page] = per_page.get(page, 0) + 1
            sentences.append({"sid": f"S{len(sentences) + 1:03d}", "page": page, "no_in_page": per_page[page],
                              "block": b, "kind": kind, "text": s})
    return {"sentences": sentences, "page_mode": mode, "references": references}


_REF_HEADING = re.compile(r"^(\d+\.?\s*)?(참고\s*문헌|references?|bibliography|literature cited)$", re.I)
_REF_NUM = re.compile(r"^\s*[\[(]?(\d+)[\]).]\s*")


def reference_text(ref: str, references: list[dict]) -> str | None:
    """본문 인용 표시("[3]", "3", "[2, 5]" 중 하나의 번호)에 해당하는 참고문헌 원문. 없으면 None."""
    nums = re.findall(r"\d+", ref)
    if len(nums) != 1:
        return None
    for r in references:
        m = _REF_NUM.match(r["text"])
        if m and m.group(1) == nums[0]:
            return r["text"]
    return None
