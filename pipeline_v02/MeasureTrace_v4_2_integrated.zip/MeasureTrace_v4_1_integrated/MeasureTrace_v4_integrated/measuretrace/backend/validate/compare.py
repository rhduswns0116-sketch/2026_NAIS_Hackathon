"""5-2 재계산값과 비교 [PY].

- 수치: 재계산값을 보고 단위로 환산 → 보고 수치의 유효 자릿수로 반올림해 일치 여부 (E05)
        환산이 안 되거나 10^k 배 차이면 단위 문제 (E01 ②)
- 방향: 재계산값 차이의 부호 (E05) / 정도 표현("크게")은 판정 제외로 표시
- 유의성: 계획서 검정의 재계산 p 값 < 유의수준 (E05), 검정이 없으면 E06 '검정 방법 없음'
- n·자유도: 계획서 설계에서 나오는 값과 대조 (E04)
- 대응하는 재계산값이 없으면 E06
여기서는 비교에서 나오는 코드만 붙인다. 앞단 기록(E01①·E02·E03·미확정)과 E07 은 5-3 codes.py 가 붙인다.
"""
from __future__ import annotations

import math
import re
from dataclasses import replace
from decimal import Decimal

from ..common.units import UnitError, convert, is_dimensionless
from ..contract import Confirmed, Test
from .report_reader import normalize_text
from .rounding import ReportedNumberError, fmt, matches, parse_reported, power_of_ten_factor

UNSUPPORTED, RECORD = "unsupported", "record"
E06_REASONS = ("식 없음", "데이터 없음", "미확정", "검정 방법 없음")


def code(cid: str, reason: str, evidence: list[str] | None = None, effect: str = UNSUPPORTED,
         reason_type: str | None = None) -> dict:
    return {"code": cid, "effect": effect, "reason_type": reason_type, "reason": reason, "evidence": evidence or []}


def _rec(calc: dict, oid: str) -> dict:
    rec = (calc.get("outputs") or {}).get(oid) or {"status": "missing", "value": None, "error": "계산 로그에 없음"}
    value = rec.get("value")
    if rec.get("status") == "ok" and (isinstance(value, bool) or not isinstance(value, (int, float))
                                      or not math.isfinite(value)):
        return {**rec, "status": "invalid", "value": None, "error": "유한한 재계산 수치가 아님"}
    return rec


def _checked(out: dict, label: str) -> None:
    out["checks"].append(label)
    out["compared"] = True


def _num(v: float) -> str:
    return f"{v:.6g}"


# ---------------------------------------------------------------------------
# 주장 ↔ 재계산 항목 짝 검증 — LLM 이 낸 짝 후보를 그대로 믿지 않는다 (R1)
# ---------------------------------------------------------------------------
STAT_KINDS = {
    "mean": {"value"}, "median": {"value"}, "value": {"value"}, "sd": {"value"}, "se": {"value"},
    "difference": {"difference"}, "percent_change": {"percent_change"}, "ratio": {"ratio"},
    "t": {"test_statistic"}, "F": {"test_statistic"}, "chi2": {"test_statistic"}, "r": {"value", "test_statistic"},
    "p": {"p_value"}, "n": {"n"}, "df": {"df"},
}
EXPLICIT_ONLY = {"p_value", "df", "n"}          # 통계량이 명시된 주장만 짝지을 수 있는 종류
TERM_KINDS = {"value", "difference", "ratio", "percent_change"}


# 절 경계: 동사 연결 어미(…였고 / …했으며 …) 또는 세미콜론. "최고 9.5" 같은 명사 끝 '고'는 경계가 아니다.
_CLAUSE_END = re.compile(r"(?:였|했|하|되|이|았|었|으)(?:고|며)\s|;")


def claim_clause(sentence: str, source: str) -> str:
    """문장에서 주장 원문이 들어 있는 절. 한 문장에 지표가 둘 이상일 때 다른 절의 용어를 빌리지 않게 한다."""
    s, src = normalize_text(sentence), normalize_text(source)
    i = s.find(src)
    if i < 0:
        return s
    ends = list(_CLAUSE_END.finditer(s))
    start = max((m.end() for m in ends if m.end() <= i), default=0)
    stop = min((m.start() for m in ends if m.start() >= i + len(src)), default=len(s))
    return s[start:stop]


def kind_problem(o, stat: str | None) -> str | None:
    """주장 통계량 ↔ 항목 종류가 맞지 않으면 이유 (언어와 무관한 필수 조건)."""
    if o is None:
        return "승인된 재계산 항목이 없음"
    allowed = STAT_KINDS.get(stat or "")
    if allowed is None:
        if o.kind in EXPLICIT_ONLY:
            return f"통계량이 표시되지 않은 주장을 {o.kind} 항목 {o.id} 와 짝지을 수 없음"
    elif o.kind not in allowed:
        return f"주장 통계량 '{stat}' 와 재계산 항목 {o.id}(종류 {o.kind})의 종류가 맞지 않음"
    return None


_SCRIPTS = (("한글", re.compile(r"[가-힣]")), ("로마자", re.compile(r"[A-Za-z]")))


def _scripts(text: str) -> set[str]:
    return {name for name, rx in _SCRIPTS if rx.search(text)}


def term_evidence(c: dict, o, notes: list[str]) -> tuple[str, str | None]:
    """승인 용어로 짝 확인. ("ok", None) / ("cross", 이유) / ("reject", 이유).

    cross — 승인 용어의 글자 체계가 주장 문장에 없음(한국어 계획서 용어 ↔ 영어 보고서). 용어로는 확인할 수 없어
            값 유일성으로 확인한다(_compare_numeric·_compare_direction). 같은 언어 보고서에서 용어가 없으면
            다른 지표를 가리킨 문장일 수 있어 지금처럼 거절한다(면저항 % ↔ 전도도 %)."""
    if o.kind not in TERM_KINDS:
        return "ok", None
    if not o.terms:
        notes.append(f"{o.id}: 승인된 지표 용어가 없어 용어 대조 생략")
        return "ok", None
    if _unit_identifies_metric(c, o):
        # 보고 단위가 차원을 가진 재계산 단위로 환산되면 단위가 지표를 가려 준다("값 12.1 nS" → 전도도).
        # 용어 대조는 단위로 가릴 수 없는 경우(%·무차원·단위 없는 방향 주장 — 면저항 % ↔ 전도도 %)에 쓴다.
        notes.append(f"{o.id}: 문장에 지표 용어는 없지만 보고 단위 {c.get('unit')!r} 가 재계산 단위 {o.unit!r} 와 "
                     "같은 차원이라 단위로 지표 확인")
        return "ok", None
    clause = claim_clause(c.get("sentence") or c["source_text"], c["source_text"]).lower()
    if any(t.lower() in clause for t in o.terms):
        return "ok", None
    words = [t for t in o.terms if _language_word(t)]
    if words and not any(_scripts(t) & _scripts(clause) for t in words):
        return "cross", (f"주장이 든 절에 승인 용어({', '.join(o.terms)})가 없고, 용어가 문장과 다른 언어"
                         f"({'·'.join(sorted({s for t in words for s in _scripts(t)}))})라 용어로는 확인할 수 없음")
    return "reject", f"주장이 든 절에 재계산 항목 {o.id} 의 승인 용어({', '.join(o.terms)})가 없음"


def _language_word(term: str) -> bool:
    """언어에 묶인 낱말인가. 약어·기호(NEP, D~NEP, R2)는 언어와 무관하게 쓰이므로 제외 — 없으면 그대로 거절 근거."""
    t = term.strip()
    if re.fullmatch(r"[가-힣]+(?:\s+[가-힣]+)*", t):
        return True
    return re.fullmatch(r"[A-Za-z]+(?:[\s-][A-Za-z]+)*", t) is not None and not t.isupper()


def mapping_problem(c: dict, o, stat: str | None, notes: list[str]) -> str | None:
    """짝이 맞지 않으면 이유 — 종류 + 승인 용어 (용어로 확인할 수 없는 경우도 거절). 값 유일성 확인이 없는 곳용."""
    why = kind_problem(o, stat)
    if why:
        return why
    status, why = term_evidence(c, o, notes)
    return None if status == "ok" else why


# 용어 없이 값으로 짝을 확인할 때 보고값의 최소 유효 자릿수 — "0.1"·"3" 처럼 여러 값과 우연히 맞기 쉬운 보고값은 제외
MIN_SIG_FOR_VALUE_ID = 2


def _precise_enough(reported) -> bool:
    if reported.value == 0:
        return reported.quantum <= Decimal("0.01")
    return reported.value.copy_abs().adjusted() - reported.quantum.adjusted() + 1 >= MIN_SIG_FOR_VALUE_ID


# ---------------------------------------------------------------------------
# 변화량 주장의 방향 — "12 % 감소"는 부호 없는 크기 + 방향어다
# ---------------------------------------------------------------------------
CHANGE_KINDS = {"difference", "percent_change"}
_UP = re.compile(r"(증가|상승|늘어|늘었|높아|높았|높다|높게|향상|커졌|커지"
                 r"|\b(?:increas|higher|rise|rose|gain|grew|improv))", re.I)
_DOWN = re.compile(r"(감소|하락|줄어|줄었|낮아|낮았|낮다|낮게|저하|작아"
                   r"|\b(?:decreas|lower|drop|declin|reduc|fell|fall))", re.I)


def change_direction(c: dict) -> str:
    """signed(보고값에 부호) / up / down / magnitude(방향어 없음) / ambiguous(방향어가 양쪽)."""
    if (c.get("value_text") or "").strip()[:1] in "+-−":
        return "signed"
    for text in (c["source_text"], claim_clause(c.get("sentence") or c["source_text"], c["source_text"])):
        up, down = bool(_UP.search(text)), bool(_DOWN.search(text))
        if up and down:
            return "ambiguous"
        if up or down:
            return "up" if up else "down"
    return "magnitude"


def _unit_identifies_metric(c: dict, o) -> bool:
    """문장에 용어가 없을 때, 보고 단위가 차원 있는 재계산 단위로 환산되는가 (단위가 지표를 가려 줌)."""
    unit = c.get("unit")
    if not unit or not o.unit or o.kind not in ("value", "difference"):
        return False
    try:
        if is_dimensionless(o.unit):
            return False
        convert(1.0, unit, o.unit)
        return True
    except UnitError:
        return False


def _unmatched(c: dict, oid: str, why: str) -> dict:
    return code("E06", f"보고서 주장 '{c['source_text']}' 에 대응하는 재계산 항목이 없음 — LLM 짝 후보 {oid} 거절: {why}",
                [f"LLM 짝 후보: {oid}", why], reason_type="식 없음")


def _q(v: float, unit: str | None) -> str:
    return f"{_num(v)} {unit}" if unit else _num(v)


def _missing_value(oid: str, rec: dict) -> dict:
    return code("E06", f"재계산 항목 {oid} 의 값이 없음 ({rec.get('status')}: {rec.get('error')})",
                [f"4-2 계산 로그 outputs.{oid}.status={rec.get('status')}"],
                reason_type="미확정" if rec.get("status") == "blocked" else "데이터 없음")


# ---------------------------------------------------------------------------
# E04 — n·자유도 vs 계획서 설계
# ---------------------------------------------------------------------------
def expected_df(test: Test, confirmed: Confirmed, calc: dict) -> tuple[list[float] | None, str]:
    """(기대 자유도 목록, 근거). 계산할 수 없으면 (None, 이유)."""
    g = confirmed.design.groups
    ns = [g.get(x) for x in test.groups]
    if test.name == "welch_t":
        if test.df_output and _rec(calc, test.df_output)["status"] == "ok":
            return [_rec(calc, test.df_output)["value"]], f"Welch 자유도 재계산값 ({test.df_output})"
        return None, "Welch 자유도 재계산값 없음"
    if any(n is None for n in ns) or not ns:
        return None, f"설계에 집단 {test.groups} 의 독립 단위 수가 없음"
    if test.name == "student_t" and len(ns) == 2:
        return [ns[0] + ns[1] - 2], f"2표본 t: {ns[0]} + {ns[1]} − 2"
    if test.name in ("paired_t", "one_sample_t"):
        if test.name == "paired_t" and len(set(ns)) != 1:
            return None, "대응표본 설계의 집단별 쌍 수가 다름"
        return [ns[0] - 1], f"{test.name}: {ns[0]} − 1"
    if test.name == "one_way_anova":
        k, total = len(ns), sum(ns)
        return [k - 1, total - k], f"일원 분산분석: ({k} − 1, {total} − {k})"
    return None, f"검정 {test.name} 의 자유도 규칙 없음"


def _pseudorep_hint(reported: float, confirmed: Confirmed, test: Test | None) -> str:
    d = confirmed.design
    if not d.replicates_per_unit or not d.groups:
        return ""
    groups = test.groups if test else list(d.groups)
    total = sum(d.groups.get(x, 0) for x in groups)
    tech = total * d.replicates_per_unit
    if reported in (tech, tech - 1, tech - 2, tech - len(groups)):
        return (f" — 기술적 반복({d.replicates_per_unit}회)을 독립 {d.independent_unit or '단위'}로 센 값과 같음 "
                f"(pseudoreplication 의심: {total} × {d.replicates_per_unit} = {tech})")
    return ""


def check_df(df_text: str, test: Test, confirmed: Confirmed, calc: dict) -> tuple[list[dict], list[str]]:
    expected, why = expected_df(test, confirmed, calc)
    if expected is None:
        return [code("E06", f"자유도 대조 불가 — {why}", reason_type="데이터 없음")], []
    parts = [p for p in df_text.replace(";", ",").split(",") if p.strip()]
    try:
        reported = [parse_reported(p) for p in parts]
    except ReportedNumberError:
        return [code("E06", f"자유도 {df_text!r} 를 읽지 못해 비교할 수 없음", reason_type="데이터 없음")], []
    ev = [f"보고 자유도 {df_text}", f"계획서 설계 기대 자유도 {', '.join(_num(e) for e in expected)} ({why})"]
    if len(reported) != len(expected):
        return [code("E04", f"자유도 개수가 다름: 보고 {df_text} vs 설계 {expected}", ev)], []
    for r, e in zip(reported, expected):
        ok = matches(e, r)[0] if test.name == "welch_t" else r.float == e
        if not ok:
            return [code("E04", f"보고 자유도 {df_text} ≠ 설계 기대값 {', '.join(_num(x) for x in expected)}"
                                + _pseudorep_hint(r.float, confirmed, test), ev)], []
    return [], [f"자유도 일치 ({df_text})"]


def allowed_n(confirmed: Confirmed, test: Test | None, groups: list[str] | None = None,
              scope: str | None = None) -> tuple[set[int], str]:
    g = confirmed.design.groups
    selected = groups if groups is not None else (test.groups if test else list(g))
    if not selected or any(x not in g for x in selected):
        return set(), "설계에 독립 단위 수가 없음"
    counts = [g[x] for x in selected]
    why = f"설계: {', '.join(f'{x}={g[x]}' for x in selected)}"
    if scope == "pairs" or (test and test.name == "paired_t"):
        return ({counts[0]} if len(set(counts)) == 1 else set()), why + " (독립 쌍 수)"
    if scope == "group":
        return ({counts[0]} if len(selected) == 1 else set()), why + " (해당 집단)"
    if scope == "total" or test is None or len(selected) == 1:
        return {sum(counts)}, why + f" (합 {sum(counts)})"
    return set(), why + " — 보고 n의 대상 집단/전체 범위를 특정하지 못함"


def check_n(n_text: str, confirmed: Confirmed, test: Test | None, groups: list[str] | None = None,
            scope: str | None = None) -> tuple[list[dict], list[str]]:
    allowed, why = allowed_n(confirmed, test, groups, scope)
    if not allowed:
        return [code("E06", f"n 대조 불가 — {why}", reason_type="데이터 없음")], []
    try:
        n = parse_reported(n_text).float
    except ReportedNumberError:
        return [code("E06", f"n {n_text!r} 를 읽지 못해 비교할 수 없음", reason_type="데이터 없음")], []
    if n in allowed:
        return [], [f"n 일치 ({n_text}, {why})"]
    return [code("E04", f"보고 n={n_text} 이(가) 설계의 독립 단위 수와 맞지 않음" + _pseudorep_hint(n, confirmed, test),
                 [f"보고 n {n_text}", why])], []


def _single_test(confirmed: Confirmed, test_id: str | None) -> tuple[Test | None, str]:
    t = confirmed.test(test_id)
    if t:
        return t, ""
    if len(confirmed.design.tests) == 1:
        return confirmed.design.tests[0], f"보고서가 검정을 특정하지 않아 계획서의 유일한 검정 {confirmed.design.tests[0].id} 로 봄"
    return None, ""


# ---------------------------------------------------------------------------
# 주장 종류별 비교
# ---------------------------------------------------------------------------
def _compare_numeric(c: dict, confirmed: Confirmed, calc: dict, out: dict) -> None:
    stat = c.get("statistic")
    out["reported"] = f"{c['value_text']}{(' ' + c['unit']) if c.get('unit') else ''}"
    if stat in ("n", "df"):
        test, note = (_single_test(confirmed, c.get("test_id"))
                      if stat == "df" or c.get("test_id") else (None, ""))
        if note:
            out["notes"].append(note)
        if stat == "df":
            if test is None:
                out["codes"].append(code("E06", "자유도 주장에 대응하는 계획서 검정이 없음", reason_type="검정 방법 없음"))
                return
            codes, notes = check_df(c["value_text"], test, confirmed, calc)
            if test.name == "welch_t" and test.df_output:
                out["outputs_used"].append(test.df_output)
                rec = _rec(calc, test.df_output)
                if rec["status"] == "ok":
                    out["recomputed"] = {"raw": rec["value"], "unit": None}
                elif rec["status"] == "blocked":
                    codes = [_missing_value(test.df_output, rec)]
        else:
            n_output = confirmed.output(c.get("output_id"))
            groups = ([c["n_group"]] if c.get("n_group") else
                      n_output.groups if n_output and n_output.kind == "n" and n_output.groups else None)
            scope = c.get("n_scope") or ("group" if groups and len(groups) == 1 else None)
            codes, notes = check_n(c["value_text"], confirmed, test, groups, scope)
        out["codes"] += codes
        out["notes"] += notes
        if not any(k["code"] == "E06" for k in codes):
            _checked(out, "n·자유도 vs 계획서 설계 (E04)")
        if stat == "n" and c.get("output_id"):
            why = mapping_problem(c, confirmed.output(c["output_id"]), stat, out["notes"])
            if why:
                out["notes"].append(f"LLM 짝 후보 {c['output_id']} 거절 ({why}) — 설계와만 대조")
                return
            rec = _rec(calc, c["output_id"])
            out["outputs_used"].append(c["output_id"])
            if rec["status"] == "ok":
                out["recomputed"] = {"raw": rec["value"], "unit": rec.get("unit")}
                try:
                    reported_n = parse_reported(c["value_text"]).float
                except ReportedNumberError:
                    return
                if reported_n != rec["value"]:
                    out["codes"].append(code("E04", f"보고 n={c['value_text']} ≠ 재계산 데이터의 n={_num(rec['value'])}",
                                             [f"재계산 항목 {c['output_id']}"]))
            else:
                out["codes"].append(_missing_value(c["output_id"], rec))
        return

    oid = c.get("output_id")
    if not oid:
        out["codes"].append(code("E06", f"보고서 수치 '{c['source_text']}' 에 대응하는 재계산 항목이 계획서에 없음",
                                 reason_type="식 없음"))
        return
    o, rec = confirmed.output(oid), _rec(calc, oid)
    why = kind_problem(o, stat)
    evidence, term_why = ("ok", None) if why else term_evidence(c, o, out["notes"])
    if why or evidence == "reject":
        out["codes"].append(_unmatched(c, oid, why or term_why))
        return
    if rec["status"] != "ok":
        out["outputs_used"].append(oid)
        out["codes"].append(_missing_value(oid, rec))
        return
    try:
        reported = parse_reported(c["value_text"])
    except ReportedNumberError as e:
        out["codes"].append(code("E06", f"보고 수치를 읽지 못해 비교할 수 없음: {e}", reason_type="데이터 없음"))
        return
    value = rec["value"]

    if stat == "p" and c.get("p_comparator") in ("<", "<=", ">", ">="):
        out["outputs_used"].append(oid)
        out["recomputed"] = {"raw": value, "unit": o.unit}
        op = c["p_comparator"]
        ok = {"<": value < reported.float, "<=": value <= reported.float,
              ">": value > reported.float, ">=": value >= reported.float}[op]
        _checked(out, f"p 값 부등호 (재계산 p {op} {c['value_text']})")
        out["recomputed"]["compared"] = _num(value)
        if not ok:
            out["codes"].append(code("E05", f"보고 'p {op} {c['value_text']}' 인데 재계산 p = {_num(value)}",
                                     [f"재계산 항목 {oid}"]))
        return

    if evidence == "cross":
        # 용어로 확인할 수 없는 짝(다른 언어 보고서) — 보고값이 보고 자릿수로 이 항목 하나와만 맞을 때만 인정.
        # 안 맞으면 짝이 틀렸는지 값이 틀렸는지 가릴 수 없으므로 E05 가 아니라 E06(짝 확인 불가).
        problem = _value_identifies(c, o, value, reported, stat, confirmed, calc)
        if problem:
            out["codes"].append(_unmatched(c, oid, f"{term_why} — {problem}"))
            return
        out["notes"].append(f"{oid}: {term_why} → 보고값이 같은 종류의 승인 항목 가운데 {oid} 하나와만 맞아 값으로 짝 확인")
    out["outputs_used"].append(oid)
    out["recomputed"] = {"raw": value, "unit": o.unit}
    try:
        m = _match_value(c, o, value, reported, out["notes"])
    except _NoCompare as e:
        out["codes"].append(e.code)
        return
    ok, rounded, conv, shown_unit, reported = m["ok"], m["rounded"], m["conv"], m["shown_unit"], m["reported"]
    unit_r = c.get("unit")
    _checked(out, m["label"])
    out["recomputed"].update(in_reported_unit=conv, rounded=fmt(rounded), rounded_unit=shown_unit)
    conv_step = f" → {_q(conv, shown_unit)}" if shown_unit != o.unit else ""
    shown_reported = c["value_text"]
    if o.kind in CHANGE_KINDS and change_direction(c) == "down":
        shown_reported = f"{c['value_text']} 감소(= {fmt(reported.value)})"
    elif o.kind in CHANGE_KINDS and change_direction(c) == "magnitude":
        shown_reported = f"{c['value_text']} (크기)"
    ev = [f"보고 {shown_reported}" + (f" {unit_r}" if unit_r else ""),
          f"재계산 {_q(value, o.unit)}{conv_step} → 반올림 {fmt(rounded)}",
          f"반올림 단위 {reported.quantum}"]
    if o.kind in CHANGE_KINDS and o.groups:
        ev.append(f"재계산 부호: {' − '.join(o.groups)} (대상 − 기준)")
    if ok:
        out["notes"].append(f"수치 일치 (반올림 {fmt(rounded)})")
        return
    k = power_of_ten_factor(conv, reported)
    if k is not None:
        out["codes"].append(code("E01", f"보고값이 재계산값의 10^{k} 배 — 단위 환산 누락 의심", ev))
    else:
        out["codes"].append(code("E05", f"보고 {shown_reported} ≠ 재계산 반올림 {fmt(rounded)}", ev))


class _NoCompare(Exception):
    """값 비교 전에 멈추는 경우(단위 없음·환산 불가·방향어 모호) — 붙일 코드를 갖고 있다."""

    def __init__(self, code_: dict):
        super().__init__(code_["reason"])
        self.code = code_


def _match_value(c: dict, o, value: float, reported, notes: list[str] | None) -> dict:
    """재계산값을 보고 단위로 환산하고 방향어를 반영해 보고 자릿수로 반올림 비교. notes=None 이면 메모를 남기지 않음."""
    unit_r = c.get("unit")
    try:
        if unit_r is None and not is_dimensionless(o.unit):
            # 단위 없이는 어느 크기로 읽을지 정할 수 없다 — 값 비교(와 10^k 판정)를 하지 않는다
            raise _NoCompare(code("E01", f"보고 수치에 단위가 없음 (재계산 단위 {o.unit}) — 단위를 적어야 비교 가능",
                                  [f"보고 '{c['source_text']}'", f"재계산 {_q(value, o.unit)}"]))
        conv, shown_unit = convert(value, o.unit, unit_r if unit_r is not None else o.unit), unit_r or o.unit
    except UnitError as e:
        raise _NoCompare(code("E01", f"보고 단위와 재계산 단위를 환산할 수 없음: {e}",
                              [f"보고 단위 {unit_r!r}", f"재계산 단위 {o.unit!r}"])) from e
    label = "수치 (보고 유효 자릿수로 반올림)"
    if o.kind in CHANGE_KINDS:
        # 재계산 항목은 [대상 − 기준] 부호를 갖는다. 보고서는 "12 % 감소"처럼 크기와 방향어로 쓴다.
        # 가정: 주장이 항목과 같은 틀(기준 대비 대상)로 서술됨 — 5-1 항목 목록에 집단 순서를 보여 준다.
        mode = change_direction(c)
        if mode == "ambiguous":
            raise _NoCompare(code("E06", f"주장 '{c['source_text']}' 에 증가·감소 표현이 함께 있어 방향을 정할 수 없음",
                                  [f"재계산 {_q(value, o.unit)} (집단 {' − '.join(o.groups) or '미기재'})"],
                                  reason_type="데이터 없음"))
        if mode == "down":
            reported = replace(reported, value=-reported.value)
            label = "변화량 (감소 → 음수로 보고 유효 자릿수 반올림)"
        elif mode == "up":
            label = "변화량 (증가 → 양수로 보고 유효 자릿수 반올림)"
        elif mode == "magnitude":
            conv = abs(conv)
            label = "변화량 크기 (방향 표현 없음 — 부호는 비교하지 않음)"
            if notes is not None:
                notes.append("보고값에 증가·감소 표현이 없어 크기만 비교함")
    ok, rounded = matches(conv, reported)
    return {"ok": ok, "rounded": rounded, "conv": conv, "shown_unit": shown_unit, "reported": reported, "label": label}


def _value_identifies(c: dict, o, value: float, reported, stat: str | None, confirmed: Confirmed,
                      calc: dict) -> str | None:
    """용어 없이 값으로 짝을 확인할 수 없으면 이유. 보고값이 (1) 충분한 자릿수로 (2) 이 항목과 맞고
    (3) 같은 종류의 다른 승인 항목과는 맞지 않아야 한다."""
    if not _precise_enough(reported):
        return f"보고값 {c['value_text']} 의 유효 자릿수가 {MIN_SIG_FOR_VALUE_ID} 자리 미만이라 값으로 짝을 가릴 수 없음"
    try:
        m = _match_value(c, o, value, reported, None)
    except _NoCompare as e:
        return f"값으로도 확인하지 못함 ({e.code['reason']})"
    if not m["ok"]:
        return (f"보고값 {c['value_text']} 이 {o.id} 의 재계산 반올림 {fmt(m['rounded'])} 와 달라 짝이 틀렸는지 "
                "값이 틀렸는지 가릴 수 없음")
    allowed = STAT_KINDS.get(stat or "") or TERM_KINDS
    rivals = []
    for other in confirmed.outputs:
        if other.id == o.id or other.kind not in allowed:
            continue
        rec = _rec(calc, other.id)
        if rec["status"] != "ok":
            continue
        try:
            if _match_value(c, other, rec["value"], reported, None)["ok"]:
                rivals.append(other.id)
        except _NoCompare:
            continue
    if rivals:
        return f"보고값 {c['value_text']} 이 다른 승인 항목({', '.join(rivals)})과도 맞아 어느 항목인지 가릴 수 없음"
    return None


def _pair_identifies(lo, ro, confirmed: Confirmed) -> str | None:
    """방향 주장의 두 항목을 용어 없이 확인할 수 없으면 이유."""
    if len(lo.groups) != 1 or len(ro.groups) != 1 or lo.groups == ro.groups:
        return "두 항목이 서로 다른 한 조건씩의 값이 아니어서 짝을 가릴 수 없음"
    if sorted(lo.terms) != sorted(ro.terms) or lo.unit != ro.unit:
        return f"{lo.id}·{ro.id} 가 같은 지표(용어·단위)가 아님"
    pair = {lo.groups[0], ro.groups[0]}
    metrics: dict[tuple, set] = {}
    for o in confirmed.outputs:
        if o.kind == "value" and len(o.groups) == 1:
            metrics.setdefault((tuple(sorted(o.terms)), o.unit), set()).add(o.groups[0])
    rivals = [m for m, gs in metrics.items() if m != (tuple(sorted(lo.terms)), lo.unit) and pair <= gs]
    if rivals:
        return f"두 조건 {sorted(pair)} 에 값 항목을 가진 다른 지표({', '.join('/'.join(t) or '용어 없음' for t, _ in rivals)})도 있어 어느 지표인지 가릴 수 없음"
    return None


def _compare_direction(c: dict, confirmed: Confirmed, calc: dict, out: dict) -> None:
    lhs, rhs, rel = c.get("lhs_output"), c.get("rhs_output"), c["relation"]
    out["reported"] = f"{lhs or '?'} {'>' if rel == 'greater' else '<'} {rhs or '?'}"
    if c.get("degree_word"):
        out["notes"].append(f"정도 표현 '{c['degree_word']}' 는 판정 제외 — 방향만 검사")
    if not lhs or not rhs:
        out["codes"].append(code("E06", f"방향 주장 '{c['source_text']}' 에 대응하는 재계산 항목 쌍이 없음",
                                 reason_type="식 없음"))
        return
    cross = []
    for oid in (lhs, rhs):     # 방향은 두 조건의 값끼리 비교한다 — 값 종류만, 승인 용어도 확인
        o = confirmed.output(oid)
        why = kind_problem(o, "value")
        evidence, term_why = ("ok", None) if why else term_evidence(c, o, out["notes"])
        if why or evidence == "reject":
            out["codes"].append(_unmatched(c, oid, why or term_why))
            return
        if evidence == "cross":
            cross.append(term_why)
    if cross:
        # 용어로 확인할 수 없는 방향 주장(다른 언어 보고서) — 두 항목이 같은 지표의 두 조건이고, 그 두 조건에
        # 값 항목을 가진 지표가 이것 하나뿐일 때만 인정 (보고서가 어느 지표를 말하는지 달리 읽힐 여지가 없음)
        problem = _pair_identifies(confirmed.output(lhs), confirmed.output(rhs), confirmed)
        if problem:
            out["codes"].append(_unmatched(c, lhs, f"{cross[0]} — {problem}"))
            return
        out["notes"].append(f"{cross[0]} → 두 조건에 값 항목을 가진 지표가 {lhs}·{rhs} 의 지표 하나뿐이라 짝 확인")
    out["outputs_used"] += [lhs, rhs]
    for oid in (lhs, rhs):
        if _rec(calc, oid)["status"] != "ok":
            out["codes"].append(_missing_value(oid, _rec(calc, oid)))
            return
    lo, ro = confirmed.output(lhs), confirmed.output(rhs)
    lv = _rec(calc, lhs)["value"]
    try:
        rv = convert(_rec(calc, rhs)["value"], ro.unit, lo.unit)
    except UnitError as e:
        out["codes"].append(code("E01", f"방향 비교의 두 항목 단위가 맞지 않음: {e}"))
        return
    diff = lv - rv
    ok = diff > 0 if rel == "greater" else diff < 0
    rel_pct = f" ({diff / rv * 100:+.3g} %)" if rv else ""
    _checked(out, "방향 (재계산 차이의 부호)")
    out["recomputed"] = {"lhs": lv, "rhs": rv, "difference": diff, "unit": lo.unit}
    ev = [f"{lhs} = {_num(lv)} {lo.unit or ''}".rstrip(), f"{rhs} = {_num(rv)} {lo.unit or ''}".rstrip(),
          f"차이 {lhs} − {rhs} = {_num(diff)}{rel_pct}"]
    if ok:
        out["notes"].append("방향 일치")
    else:
        word = "크다" if rel == "greater" else "작다"
        out["codes"].append(code("E05", f"보고는 {lhs} 가 {rhs} 보다 {word}고 하나 재계산 차이는 {_num(diff)}{rel_pct}", ev))


def _compare_significance(c: dict, confirmed: Confirmed, calc: dict, out: dict) -> None:
    parts = [f"df={c['df_text']}" if c.get("df_text") else "", f"n={c['n_text']}" if c.get("n_text") else "",
             f"p {c.get('p_comparator') or '='} {c['p_text']}" if c.get("p_text") else ""]
    out["reported"] = " ".join(["유의함" if c["significant"] else "유의하지 않음"] + [p for p in parts if p])
    if not confirmed.design.tests:
        out["codes"].append(code("E06", "계획서에 검정 방법이 없어 유의성은 판정할 수 없음 (방향은 별도 검사)",
                                 reason_type="검정 방법 없음"))
        return
    test, note = _single_test(confirmed, c.get("test_id"))
    if note:
        out["notes"].append(note)
    if test is None:
        out["codes"].append(code("E06", "유의성 주장에 대응하는 계획서 검정을 특정하지 못함",
                                 [f"계획서 검정: {[t.id for t in confirmed.design.tests]}"], reason_type="검정 방법 없음"))
        return
    if not test.p_output:
        out["codes"].append(code("E06", f"검정 {test.id} 의 p 값 재계산 항목이 없음", reason_type="데이터 없음"))
        return
    out["outputs_used"].append(test.p_output)
    rec = _rec(calc, test.p_output)
    if rec["status"] != "ok":
        out["codes"].append(_missing_value(test.p_output, rec))
        return
    p = rec["value"]
    if not 0 <= p <= 1:
        out["codes"].append(code("E06", "재계산 p 값이 0~1 범위 밖임", reason_type="데이터 없음"))
        return
    sig = p < test.alpha
    _checked(out, f"유의성 (계획서 검정 {test.name}, α={test.alpha})")
    out["recomputed"] = {"p": p, "alpha": test.alpha, "significant": sig, "test": test.id}
    ev = [f"계획서 검정 {test.id} ({test.name}), 집단 {test.groups}", f"재계산 p = {_num(p)}, α = {test.alpha}"]
    if sig != c["significant"]:
        out["codes"].append(code("E05", f"보고는 '{'유의함' if c['significant'] else '유의하지 않음'}' 이나 "
                                        f"재계산 p = {_num(p)} (α={test.alpha}) → "
                                        f"{'유의함' if sig else '유의하지 않음'}", ev))
    if c.get("p_text"):
        try:
            rp = parse_reported(c["p_text"])
            op = c.get("p_comparator") or "="
            if op == "=":
                ok, r = matches(p, rp)
                shown = f"재계산 p 반올림 {fmt(r)}"
            else:
                ok = {"<": p < rp.float, "<=": p <= rp.float, ">": p > rp.float, ">=": p >= rp.float}[op]
                shown = f"재계산 p = {_num(p)}"
            _checked(out, f"p 값 (p {op} {c['p_text']})")
            if not ok:
                out["codes"].append(code("E05", f"보고 'p {op} {c['p_text']}' 와 {shown} 가 맞지 않음", ev))
        except ReportedNumberError:
            out["codes"].append(code("E06", f"p 값 {c['p_text']!r} 를 읽지 못해 비교할 수 없음", reason_type="데이터 없음"))
    for key, fn in (("df_text", lambda t: check_df(t, test, confirmed, calc)),
                    ("n_text", lambda t: check_n(t, confirmed, test,
                         [c["n_group"]] if c.get("n_group") else None, c.get("n_scope")))):
        if c.get(key):
            codes, notes = fn(c[key])
            out["codes"] += codes
            out["notes"] += notes
            if key == "df_text" and test.name == "welch_t" and test.df_output:
                out["outputs_used"].append(test.df_output)
            if not any(k["code"] == "E06" for k in codes):
                _checked(out, f"{key[:-5]} vs 계획서 설계 (E04)")


def compare_claim(c: dict, confirmed: Confirmed, calc: dict) -> dict:
    out = {"claim_id": c["claim_id"], "claim_type": c["claim_type"], "reported": None, "recomputed": None,
           "outputs_used": [], "checks": [], "compared": False, "codes": [], "notes": []}
    if confirmed.code_pending():
        # 파이프라인 v4: 승인된 계산 코드가 없으면 재계산할 수 없어 모든 수치 주장은 E06(미확정)
        what = next((p.what for p in confirmed.pending if p.target == "code"), "")
        out["codes"].append(code("E06", f"승인된 계산 코드가 없음(3-1 미확정·거부) — 재계산할 수 없음{': ' + what if what else ''}",
                                 ["미확정 항목: code"], reason_type="미확정"))
        return out
    {"numeric": _compare_numeric, "direction": _compare_direction,
     "significance": _compare_significance}[c["claim_type"]](c, confirmed, calc, out)
    out["outputs_used"] = list(dict.fromkeys(out["outputs_used"]))
    return out


def compare_all(claims: list[dict], confirmed: Confirmed, calc: dict) -> list[dict]:
    return [compare_claim(c, confirmed, calc) for c in claims]
