"""5-1 주장 추출·분류 [LLM] — 보고서를 여기서 처음 연다.

블라인드(R4): 4-2 계산 로그가 끝난 뒤에만 보고서를 연다. 열람 시각을 blind_log.json 에 남기고
"계산 로그 완료 시각 < 보고서 열람 시각" 이 아니면 멈춘다.

LLM 이 보는 것: 보고서 문장, 승인된 재계산 항목의 이름·설명·단위·집단(값은 보지 않음), 검정 이름.
LLM 이 하는 것: 문장 분류, 주장 구조화, 주장 ↔ 재계산 항목 짝 후보.
파이썬이 검증(R1): 원문이 문장에 글자 그대로 있나, 수치·단위·자유도가 원문에 있나, 항목 id 가 실제로 있나.
(practice_v4 extract/report_claims.py 의 후보 선정·검증 방식을 v4 분류 체계로 옮김)
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..common.hashing import canonical_json, now_iso, sha256_bytes, sha256_text
from ..common.llm import LLMLog, call_json
from ..contract import Confirmed
from .report_reader import normalize_text, read_report, reference_text

STAGE_VERSION = "claims-v4.0"
BATCH = 40

CATEGORIES = ("numeric", "direction", "significance", "degree", "mixed", "citation", "qualitative", "none")
TARGET_CATEGORIES = ("numeric", "direction", "significance", "degree", "mixed")
CATEGORY_KO = {
    "numeric": "자기 데이터 수치 주장", "direction": "방향 주장", "significance": "유의성 주장",
    "degree": "정도 표현", "mixed": "혼합(자기 값 + 문헌값)", "citation": "문헌 인용",
    "qualitative": "수치와 연결되지 않는 정성 문장", "none": "주장 아님(제목·설명 등)",
}
CLAIM_TYPES = ("numeric", "direction", "significance")
STATISTICS = ("mean", "median", "sd", "se", "value", "difference", "percent_change", "ratio",
              "t", "F", "chi2", "r", "p", "n", "df", "other")
P_COMPARATORS = ("=", "<", "<=", ">", ">=")


class BlindnessError(RuntimeError):
    """계산 로그 전에 보고서를 열려고 함."""


SYSTEM_PROMPT = """너는 연구 보고서 문장을 분류하고 수치 주장을 구조로 옮기는 도구다.
주장이 맞는지 판단하지 마라. 계산하지 마라. 문장에 적힌 것만 옮긴다.

[문장 분류 category]
- numeric: 이 연구 자신의 데이터로 얻은 수치를 말함 (예: "평균 전도도는 7.6 nS였다")
- direction: 두 대상의 크기 비교·증감을 말함 (예: "A가 B보다 높았다", "어닐링 후 증가했다")
- significance: 통계적 유의성을 말함 ("유의하게", "유의한 차이가 없었다", p 값, t(8)=…)
- degree: 정도 표현이 붙은 방향 주장 ("크게 증가") — 방향만 claims 에 넣고 degree_word 에 정도 단어
- mixed: 자기 값과 문헌값이 함께 있음 — 자기 값만 claims 에, 문헌값은 literature_values 에
- citation: 문헌 인용([3], et al., "보고된 바", "알려져 있다") — claims 는 비우고 citation_refs 에 인용 표시
- qualitative: 수치·지표와 연결되지 않는 정성 문장 ("균일한 막이 형성되었다") — claims 비움
- none: 제목, 표 머리글, 방법 설명 등 주장이 아닌 문장 — claims 비움
한 문장에 여러 종류가 섞이면 가장 강한 것 하나를 category 로 고르고, claims 에는 전부 넣는다.
("유의하게 증가(t(8)=4.2, p<0.01)" → significance 항목 1개 + direction 항목 1개 + t 값 numeric 항목 1개)

[claims 항목]
- claim_type numeric: value_text 는 문장에 적힌 수치 글자 그대로(자릿수·지수 표기 유지, 예 "7.60", "3.2×10⁻⁵").
  unit 은 문장에 적힌 단위 글자 그대로 (없으면 빈 문자열). output_id 는 [재계산 항목] 중 이 수치와 같은 의미의 것.
  통계량 값(t, F 등)은 numeric 항목으로 따로 넣는다(statistic 으로 구분).
  자유도·p 값·n 이 유의성 주장과 같은 괄호에 있으면 significance 항목의 df_text·p_text·n_text 에만 넣고
  numeric 항목을 따로 만들지 마라. 검정과 무관하게 n 만 말하는 문장("시료 10개 (n = 10)")은 numeric(statistic=n).
- claim_type direction: lhs_output 가 rhs_output 보다 크다고 말하면 relation="greater", 작다면 "less".
  "증가했다"면 lhs=나중·처리 후, rhs=이전·기준. 두 항목은 [재계산 항목]의 value 종류에서 고른다.
- claim_type significance: significant 는 유의하다고 말하면 true, 유의하지 않다고 말하면 false.
  test_id 는 [검정] 중 해당하는 것. test_name·df_text·n_text·p_text·p_comparator 는 문장에 있을 때만.
  p_text 에는 숫자만 넣고 부등호는 p_comparator 에 넣는다 ("p < 0.001" → p_text "0.001", p_comparator "<").
  n이 나오면 n_scope는 group(집단별), total(전체), pairs(독립 쌍) 중 원문에 맞는 것,
  n_group은 집단별 n일 때 승인 목록의 집단 id다. 특정할 수 없으면 빈 문자열.
- source_text 는 그 주장 부분을 문장에서 글자 그대로 복사한다(바꿔 쓰지 않음).
- 짝이 되는 재계산 항목이 없으면 output_id 등은 빈 문자열 (계획서에 없는 지표일 수 있음 — 억지로 고르지 마라).
  단위나 변화 종류가 같아도 지표가 다르면(예: 면저항 ↔ 전도도) 짝이 아니다.
- 값이 없으면: 문자열 필드는 빈 문자열 "", statistic·relation·significant·p_comparator·n_scope 는 null."""

def _nullable_enum(values) -> dict:
    """구조화 출력 API 는 type 목록과 enum 을 함께 받지 않는다 → anyOf 로."""
    return {"anyOf": [{"type": "string", "enum": list(values)}, {"type": "null"}]}


# 구조화 출력 API 제약: null 허용(type 목록·anyOf) 필드는 스키마 전체에서 16개까지 (실제 호출 400 으로 확인).
# 그래서 자유 문자열 필드는 null 대신 빈 문자열 "" 로 '없음'을 받고, 파이썬이 None 으로 되돌린다
# (_blank_to_none). null 은 선택지·참거짓 필드에만 쓴다.
MAX_UNION_FIELDS = 16
TEXT_FIELDS = ("value_text", "unit", "output_id", "lhs_output", "rhs_output", "degree_word", "test_id",
               "test_name", "df_text", "n_text", "p_text", "n_group")

_ITEM = {
    "type": "object",
    "properties": {
        "claim_type": {"type": "string", "enum": list(CLAIM_TYPES)},
        "source_text": {"type": "string"},
        **{k: {"type": "string"} for k in TEXT_FIELDS},
        "statistic": _nullable_enum(STATISTICS),
        "relation": _nullable_enum(["greater", "less"]),
        "significant": {"type": ["boolean", "null"]},
        "p_comparator": _nullable_enum(P_COMPARATORS),
        "n_scope": _nullable_enum(["group", "total", "pairs"]),
    },
    "required": ["claim_type", "source_text", "value_text", "unit", "statistic", "output_id", "relation",
                 "lhs_output", "rhs_output", "degree_word", "significant", "test_id", "test_name", "df_text",
                 "n_text", "p_text", "p_comparator", "n_scope", "n_group"],
    "additionalProperties": False,
}
SCHEMA = {
    "type": "object",
    "properties": {"sentences": {"type": "array", "items": {
        "type": "object",
        "properties": {
            "sid": {"type": "string"},
            "category": {"type": "string", "enum": list(CATEGORIES)},
            "citation_refs": {"type": "array", "items": {"type": "string"}},
            "literature_values": {"type": "array", "items": {"type": "string"}},
            "claims": {"type": "array", "items": _ITEM},
        },
        "required": ["sid", "category", "citation_refs", "literature_values", "claims"],
        "additionalProperties": False,
    }}},
    "required": ["sentences"],
    "additionalProperties": False,
}


def catalog_text(confirmed: Confirmed) -> str:
    """LLM 에 보여 줄 재계산 항목·검정 목록. 값은 넣지 않는다(R2)."""
    lines = ["[재계산 항목]"]
    for o in confirmed.outputs:
        g = f" 집단={'/'.join(o.groups)}" if o.groups else ""
        t = f" 용어={'/'.join(o.terms)}" if o.terms else ""
        lines.append(f"- {o.id}: {o.description} (종류={o.kind}, 단위={o.unit or '없음'}{g}{t})")
    lines.append("[검정]")
    if not confirmed.design.tests:
        lines.append("- 없음 (계획서에 검정 방법이 없음)")
    for t in confirmed.design.tests:
        lines.append(f"- {t.id}: {t.name} 집단={'/'.join(t.groups)} {t.description}".rstrip())
    return "\n".join(lines)


class ReportChangedError(ValueError):
    """보고서가 받은 때(1 INGEST)의 해시와 다름."""


def open_report(report_path: str | Path, run_dir: Path, confirmed: Confirmed,
                expected_sha256: str | None = None) -> dict:
    """블라인드 확인 후 보고서를 열고 blind_log.json 을 쓴다.
    expected_sha256: 보고서를 받은 때 기록한 해시 — 다르면 열람 기록을 남기기 전에 멈춘다."""
    calc_path = run_dir / "calc_log.json"
    if not calc_path.exists():
        raise BlindnessError("4-2 계산 로그가 없음 — RECOMPUTE 전에는 보고서를 열 수 없음 (R4)")
    calc = json.loads(calc_path.read_text(encoding="utf-8"))
    if calc.get("confirmed_sha256") != sha256_text(canonical_json(confirmed.to_dict())):
        raise BlindnessError("계산 로그의 승인 입력과 현재 confirmed.json이 다름 — 다시 재계산 필요")
    opened_at = now_iso()
    if not calc.get("finished_at") or not calc["finished_at"] < opened_at:
        raise BlindnessError(f"계산 로그 완료 시각 {calc.get('finished_at')} 이 보고서 열람 시각 {opened_at} 보다 "
                             f"앞서지 않음 (R4)")
    report = Path(report_path).resolve()
    input_root = Path(confirmed.input_root).resolve()
    if any((input_root / d.path).resolve() == report for d in confirmed.data):
        raise BlindnessError("보고서를 RAW 계산 입력으로 등록할 수 없음 (R4)")
    inside_input = input_root in report.parents
    report_bytes = report.read_bytes()
    if expected_sha256 and sha256_bytes(report_bytes) != expected_sha256:
        raise ReportChangedError(f"보고서 {report.name} 가 받은 때(해시 {expected_sha256[:12]})와 다름 "
                                 f"(지금 {sha256_bytes(report_bytes)[:12]}) — 1단계부터 새 실행")
    snapshot = run_dir / ("report_snapshot" + report.suffix.lower())
    snapshot.write_bytes(report_bytes)
    blind = {
        "stage": "5-1 보고서 첫 열람",
        "calc_finished_at": calc["finished_at"],
        "report_opened_at": opened_at,
        "blind_ok": True,
        "report_path": str(report),
        "report_sha256": sha256_bytes(report_bytes),
        "snapshot_path": str(snapshot),
        "report_inside_input_root": inside_input,
        "note": ("보고서가 RAW 입력 폴더 안에 있음 — 재계산은 승인된 데이터 파일만 읽으므로 블라인드는 유지되지만, "
                 "보고서는 별도 경로로 받는 것이 원칙" if inside_input else ""),
    }
    (run_dir / "blind_log.json").write_text(json.dumps(blind, ensure_ascii=False, indent=2), encoding="utf-8")
    return blind


# ---------------------------------------------------------------------------
# 검증 (R1)
# ---------------------------------------------------------------------------
_MANTISSA = r"(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d*)?|\.\d+"
_NUMBER_PATTERN = (rf"[+-]?(?:{_MANTISSA})"
                   r"(?:[eE][+-]?\d+|[×xX*]10\^?[+-]?\d+|[×xX*]10\^?[⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)?")
_NUMBER = re.compile(_NUMBER_PATTERN)


def _compact(s: str) -> str:
    return re.sub(r"\s+", "", normalize_text(s))


def _in_text(fragment: str | None, text: str) -> bool:
    return bool(fragment) and _compact(fragment) in _compact(text)


def _number_tokens(text: str) -> list[str]:
    """숫자 토큰. 공백을 다 지우면 표의 이웃 칸이 한 숫자로 붙으므로("37 2.176" → 372.176) 공백은 경계로 두고,
    부호 뒤 공백("- 3.2")과 지수 표기 주변 공백("1.2 × 10⁻³")만 붙인다. 앞의 '+'는 부호 없는 수와 같게 본다."""
    t = normalize_text(text)
    t = re.sub(r"\s*([×xX*])\s*(?=10\^?[+\-⁻⁺]?[\d⁰¹²³⁴⁵⁶⁷⁸⁹])", r"\1", t)
    t = re.sub(r"(?<![\w.])([+-])\s+(?=[\d.])", r"\1", t)
    return [n[1:] if n.startswith("+") else n for n in _NUMBER.findall(t)]


def _numbers_in(fragment: str, text: str) -> bool:
    """숫자 전체 토큰을 순서대로 확인한다. 부호·지수·보고 자릿수를 생략할 수 없다."""
    nums = _number_tokens(fragment)
    have = _number_tokens(text)
    return bool(nums) and any(have[i:i + len(nums)] == nums for i in range(len(have) - len(nums) + 1))


def _number_in(fragment: str, text: str) -> bool:
    s = _compact(fragment)
    return _NUMBER.fullmatch(s) is not None and _number_tokens(s)[0] in _number_tokens(text)


_CMP = re.compile(r"^\s*(<=|>=|≤|≥|<|>|=)\s*(.+)$")
_CMP_NORM = {"≤": "<=", "≥": ">="}
# p 표기: p<0.05, p값<0.05, p-value=0.003, pvalue=… (공백은 _compact 가 이미 지움 — "p 값" → "p값")
_SOURCE_P = re.compile(rf"(?<![A-Za-z])p(?:값|-?value)?(<=|>=|≤|≥|<|>|=)({_NUMBER_PATTERN})", re.I)
_SOURCE_N = re.compile(rf"(?<![A-Za-z])n=({_NUMBER_PATTERN})", re.I)
_SOURCE_DF = re.compile(r"(?<![A-Za-z])[tF]\(([^()]+)\)", re.I)


def _split_comparator(item: dict, text_key: str, notes: list[str]) -> None:
    """LLM 이 숫자 칸에 부등호까지 넣은 경우("< 0.001") 부등호를 p_comparator 로 옮긴다."""
    m = _CMP.match(item.get(text_key) or "")
    if not m:
        return
    op = _CMP_NORM.get(m.group(1), m.group(1))
    if item.get("p_comparator") not in (None, op):
        notes.append(f"{text_key} 의 부등호 {op} 와 p_comparator {item['p_comparator']} 가 다름 → {op} 사용")
    item[text_key], item["p_comparator"] = m.group(2).strip(), op


def _pm_unit(value_text: str, unit: str, sentence: str) -> bool:
    """문장에 '값 ± 숫자 단위' 가 바로 이어지는가 (공백 무시). 예: 12.1 ± 0.7 nS → 12.1 의 단위 nS."""
    text, value, u = _compact(sentence), _compact(value_text or ""), _compact(unit or "")
    if not value or not u:
        return False
    return re.search(re.escape(value) + r"(?:±|\+/-|\+-)" + _NUMBER_PATTERN + re.escape(u) + r"(?![A-Za-z])",
                     text) is not None


def _blank_to_none(item: dict) -> None:
    """스키마 제약으로 "" 로 받은 '없음'을 None 으로 되돌린다 (공백만 있어도 없음)."""
    for key in TEXT_FIELDS:
        if isinstance(item.get(key), str) and not item[key].strip():
            item[key] = None


def verify_item(item: dict, sentence: str, confirmed: Confirmed) -> tuple[str | None, list[str]]:
    """(버릴 이유 또는 None, 고친 내용 메모). 항목은 제자리에서 고친다."""
    notes = []
    _blank_to_none(item)
    _split_comparator(item, "p_text", notes)
    if item.get("statistic") == "p":
        _split_comparator(item, "value_text", notes)
    if not _in_text(item.get("source_text"), sentence):
        return "원문(source_text)이 문장에 글자 그대로 없음", notes
    ct = item.get("claim_type")
    if ct == "numeric":
        has_number = (_numbers_in(item.get("value_text") or "", item["source_text"])
                      if item.get("statistic") == "df" else
                      _number_in(item.get("value_text") or "", item["source_text"]))
        if not has_number:
            return f"수치 {item.get('value_text')!r} 가 원문에 적혀 있지 않음", notes
        if item.get("unit") and not _in_text(item["unit"], item["source_text"]):
            if _pm_unit(item["value_text"], item["unit"], sentence):
                # "12.1 ± 0.7 nS" — 평균 ± 표준편차 뒤에 붙은 단위는 두 값 모두의 단위다 (다른 주장 단위를 빌린 것이 아님)
                notes.append(f"단위 {item['unit']!r} 를 원문 '{item['value_text']} ± … {item['unit']}' 표기에서 확인")
            else:
                return f"단위 {item['unit']!r} 가 해당 주장 원문에 적혀 있지 않음", notes
    elif ct == "direction":
        if item.get("relation") not in ("greater", "less"):
            return f"방향 주장인데 relation 이 {item.get('relation')!r}", notes
    elif ct == "significance":
        if not isinstance(item.get("significant"), bool):
            return "유의성 주장인데 significant 가 참/거짓이 아님", notes
    else:
        return f"알 수 없는 주장 종류 {ct!r}", notes

    known = {o.id for o in confirmed.outputs}
    for key in ("output_id", "lhs_output", "rhs_output"):
        if item.get(key) and item[key] not in known:
            notes.append(f"{key} {item[key]!r} 는 승인된 재계산 항목이 아님 → 비움")
            item[key] = None
    if item.get("test_id") and confirmed.test(item["test_id"]) is None:
        notes.append(f"test_id {item['test_id']!r} 는 계획서 검정이 아님 → 비움")
        item["test_id"] = None
    source = _compact(item["source_text"])
    if ct == "significance":
        for key, pattern in (("df_text", _SOURCE_DF), ("n_text", _SOURCE_N)):
            found = pattern.search(source)
            if found:
                literal = found.group(1)
                if item.get(key) and _compact(item[key]) != literal:
                    return f"{key} {item[key]!r} 가 원문 통계 표기 {literal!r} 와 다름", notes
                if not item.get(key):
                    item[key] = literal
                    notes.append(f"{key} 를 원문 통계 표기에서 읽음")
    if item.get("p_text") or (ct == "numeric" and item.get("statistic") == "p"):
        key = "value_text" if ct == "numeric" else "p_text"
        candidates = [m for m in _SOURCE_P.finditer(source) if m.group(2) == _compact(item[key])]
        if len(candidates) != 1:
            return f"p 값 {item[key]!r} 의 원문 부등호를 특정할 수 없음", notes
        op = _CMP_NORM.get(candidates[0].group(1), candidates[0].group(1))
        if item.get("p_comparator") not in (None, op):
            return f"p 부등호 {item['p_comparator']!r} 가 원문 {op!r} 와 다름", notes
        item["p_comparator"] = op
    elif ct == "significance":
        found = _SOURCE_P.search(source)
        if found:
            item["p_text"] = found.group(2)
            item["p_comparator"] = _CMP_NORM.get(found.group(1), found.group(1))
            notes.append("p 값과 부등호를 원문에서 읽음")
    for key in ("df_text", "n_text", "p_text"):
        if item.get(key) and not _numbers_in(item[key], item["source_text"]):
            return f"{key} {item[key]!r} 의 숫자 전체가 해당 주장 원문에 없음", notes
    return None, notes


def extract_claims(confirmed: Confirmed, report_path: str | Path, run_dir: Path, out_root: Path,
                   client, model: str, expected_report_sha256: str | None = None) -> dict:
    """5-1 전체. claims.json 을 쓰고 돌려준다."""
    blind = open_report(report_path, run_dir, confirmed, expected_report_sha256)
    report = read_report(blind["snapshot_path"])
    sentences = report["sentences"]
    by_sid = {s["sid"]: s for s in sentences}
    log = LLMLog(out_root)
    catalog = catalog_text(confirmed)

    labelled, failures = {}, []
    for i in range(0, len(sentences), BATCH):
        chunk = sentences[i:i + BATCH]
        user = catalog + "\n\n[보고서 문장]\n" + "\n".join(f"[{s['sid']}] {s['text']}" for s in chunk)
        try:
            data = call_json("report_claims", SYSTEM_PROMPT, SCHEMA, user, client, model, log)
        except Exception as e:   # LLMError·네트워크 오류 등 — 한 묶음이 실패해도 나머지는 계속
            failures.append({"sids": [s["sid"] for s in chunk], "error": f"{type(e).__name__}: {e}"})
            continue
        chunk_ids = {s["sid"] for s in chunk}
        for row in data.get("sentences", []):
            if row.get("sid") in chunk_ids and row["sid"] not in labelled:
                labelled[row["sid"]] = row

    claims, rejected, non_target, unstructured = [], [], [], []
    for s in sentences:
        row = labelled.get(s["sid"])
        loc = {"sid": s["sid"], "page": s["page"], "no_in_page": s["no_in_page"], "sentence": s["text"]}
        if row is None:
            unstructured.append({**loc, "reason": "LLM 분류 결과 없음"})
            continue
        cat = row.get("category") if row.get("category") in CATEGORIES else "none"
        refs = row.get("citation_refs", [])
        ref_texts = [{"ref": r, "text": reference_text(r, report["references"])} for r in refs]
        if cat not in TARGET_CATEGORIES:
            non_target.append({**loc, "category": cat, "category_ko": CATEGORY_KO[cat],
                               "citation_refs": refs, "reference_texts": ref_texts,
                               "literature_values": row.get("literature_values", [])})
            continue
        k, rejected_count = 0, 0
        for item in row.get("claims", []):
            problem, notes = verify_item(item, s["text"], confirmed)
            if problem:
                rejected.append({**loc, "source_text": item.get("source_text"), "reason": problem})
                rejected_count += 1
                continue
            k += 1
            claims.append({"claim_id": f"{s['sid']}-{k}", **loc, "category": cat,
                           "category_ko": CATEGORY_KO[cat], **item,
                           "source_text": normalize_text(item["source_text"]),
                           "literature_values": row.get("literature_values", []),
                           "citation_refs": refs, "reference_texts": ref_texts,
                           "extraction_notes": notes})
        if k == 0 or rejected_count:
            reason = (f"주장 후보 {rejected_count}개 원문 검증 실패 (통과 {k}개)" if rejected_count else
                      "검사 대상 문장인데 검증을 통과한 주장이 없음")
            unstructured.append({**loc, "category": cat, "reason": reason})

    out = {"stage": "5-1 주장 추출·분류", "stage_version": STAGE_VERSION, "blind": blind,
           "page_mode": report["page_mode"], "sentence_count": len(sentences),
           "references": report["references"], "claims": claims,
           "non_target": non_target, "unstructured": unstructured, "rejected": rejected,
           "llm_failures": failures}
    (run_dir / "claims.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out
