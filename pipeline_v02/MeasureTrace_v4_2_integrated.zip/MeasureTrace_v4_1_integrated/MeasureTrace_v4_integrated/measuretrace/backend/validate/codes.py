"""5-3 오류 코드 분류 [PY] — 주장마다 판정 + 오류 코드 + 사유.

비교 결과(5-2)의 코드에 더해 주장이 쓰는 재계산 항목의 의존 관계를 따라 앞단 기록을 붙인다.
  E01 ① 3회 피드백 뒤에도 단위가 미확정인 열 (unit_status=unresolved, 또는 E01 기록 decision=unresolved)
  E02    이상값: '그대로 진행'이면 기록, 미결정이면 Unsupported
  E03    필요 데이터 누락
  E06    '미확정' — CONFIRM 3회 뒤에도 승인되지 않은 항목에 의존
  E07    데이터 버전 변경 (6-2 가 탐지) — 기록
판정: 판정을 바꾸는 코드(effect=unsupported)가 하나라도 있으면 Unsupported, 아니면 Supported.
"""
from __future__ import annotations

from ..contract import Confirmed, refs_overlap
from .compare import RECORD, UNSUPPORTED, code

SUPPORTED, UNSUPPORTED_V, NOT_TARGET = "Supported", "Unsupported", "검사 대상 아님"
CODE_NAMES = {
    "E01": "단위 누락·불일치", "E02": "측정값 이상 (사양 범위 이탈·결측)", "E03": "필요 데이터 누락",
    "E04": "반복 단위·표본 수 불일치", "E05": "주장 수치 불일치 (방향 포함)", "E06": "재계산 대응 없음",
    "E07": "데이터 버전 변경",
}


def dependencies(confirmed: Confirmed, output_ids: list[str]) -> list[str]:
    deps = []
    for oid in output_ids:
        o = confirmed.output(oid)
        if o is None:
            continue
        deps += [oid, "code"] + list(o.depends_on) + [f"eq:{e}" for e in o.equations]
    return list(dict.fromkeys(deps))


def dependency_codes(confirmed: Confirmed, output_ids: list[str]) -> list[dict]:
    deps = dependencies(confirmed, output_ids)
    out = []

    def hit(target: str) -> list[str]:
        return [d for d in deps if refs_overlap(d, target)]

    for d in confirmed.data:
        for col, info in d.columns.items():
            ref = f"{d.id}#{col}"
            if info.unit_status == "unresolved" and hit(ref):
                out.append(code("E01", f"열 {ref} 의 단위가 CONFIRM 뒤에도 미확정",
                                [f"{d.path} 열 {col}", f"의존: {', '.join(hit(ref))}"]))
    for f in confirmed.flags:
        via = hit(f.target)
        if not via:
            continue
        loc = ", ".join(f"{k}={v}" for k, v in f.location.items())
        ev = [f"대상 {f.target}" + (f" ({loc})" if loc else ""), f"의존: {', '.join(via)}"]
        if f.decided_by:
            ev.append(f"결정: {f.decision} — {f.decided_by} {f.decided_at}".rstrip())
        if f.code == "E01" and f.decision == "unresolved":
            out.append(code("E01", f"단위 미확정: {f.detail}", ev))
        elif f.code == "E02":
            if f.decision == "proceed":
                out.append(code("E02", f"이상값을 그대로 진행하기로 결정: {f.detail}", ev, effect=RECORD))
            else:
                out.append(code("E02", f"이상값 처리 미결정: {f.detail}", ev))
        elif f.code == "E03":
            out.append(code("E03", f"필요 데이터 누락: {f.detail}", ev))
    for p in confirmed.pending:
        via = hit(p.target)
        if via:
            out.append(code("E06", f"CONFIRM 3회 뒤에도 미확정: {p.what}", [f"대상 {p.target}", f"의존: {', '.join(via)}"],
                            reason_type="미확정"))
    return out


def e07_codes(confirmed: Confirmed, output_ids: list[str], changed_data_ids: dict[str, str]) -> list[dict]:
    """6-2 가 찾은 변경 데이터 {data_id: 요약} 중 이 주장이 쓰는 것."""
    deps = dependencies(confirmed, output_ids)
    return [code("E07", f"이전 실행 대비 데이터 변경: {summary}", [f"데이터 {did}"], effect=RECORD)
            for did, summary in changed_data_ids.items() if any(refs_overlap(d, did) for d in deps)]


def classify(claims: list[dict], comparisons: list[dict], confirmed: Confirmed,
             changed_data_ids: dict[str, str] | None = None) -> list[dict]:
    """주장마다 {claim, comparison, codes, verdict}. claims 와 comparisons 는 같은 순서."""
    results = []
    if len(claims) != len(comparisons):
        raise ValueError("주장과 비교 결과 개수가 다름")
    for c, cmp in zip(claims, comparisons):
        if c["claim_id"] != cmp["claim_id"]:
            raise ValueError("주장과 비교 결과의 claim_id가 다름")
        outputs = list(cmp["outputs_used"])
        codes = list(cmp["codes"]) + dependency_codes(confirmed, outputs)
        if changed_data_ids:
            codes += e07_codes(confirmed, outputs, changed_data_ids)
        if any(k["code"] == "E03" for k in codes):   # 누락이 원인이면 '데이터 없음' E06 은 겹치므로 뺀다
            codes = [k for k in codes if not (k["code"] == "E06" and k.get("reason_type") == "데이터 없음")]
        if not cmp.get("compared", False) and not any(k["effect"] == UNSUPPORTED for k in codes):
            codes.append(code("E06", "비교를 수행하지 못함", reason_type="데이터 없음"))
        verdict = UNSUPPORTED_V if any(k["effect"] == UNSUPPORTED for k in codes) else SUPPORTED
        for k in codes:
            k["name"] = CODE_NAMES[k["code"]]
        results.append({"claim": c, "comparison": cmp, "codes": codes, "verdict": verdict})
    return results
