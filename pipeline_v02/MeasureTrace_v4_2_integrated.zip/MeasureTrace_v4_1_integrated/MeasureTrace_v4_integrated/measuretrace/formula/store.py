"""검사를 통과한 수식 코드의 승인 기록과 재사용 [PY].

기록 한 줄 = 재사용 키(기준 수식 · 변수 뜻 · binding · 적용 조건 · 검사기 버전) + 코드 본문 + 코드 해시 + 검사 결과.
JSON Lines 로 추가만 한다(고치거나 지우지 않음 — 1-3 이력 장부와 같은 방식). 같은 키면 가장 나중 줄이 유효하다.

다음 실행에서 키가 같으면 LLM 에 다시 만들게 하지 않고 승인된 코드를 그대로 쓴다 — 같은 입력에 같은 계산 코드.
기록된 코드 본문의 해시가 기록된 해시와 다르면(파일을 손으로 고친 경우) 재사용하지 않는다.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Callable

from measuretrace.formula.check import (CheckResult, Reference, check_function, code_sha256, parse_reference,
                                        reference_key)
from measuretrace.paths import OUTPUTS_DIR

STORE_PATH = OUTPUTS_DIR / "formula_approvals.jsonl"


class NotApproved(ValueError):
    """검사를 통과하지 못한 코드를 승인하려 함."""


class ApprovalStore:
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else STORE_PATH

    def _records(self) -> list[dict]:
        if not self.path.exists():
            return []
        out = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return out

    def lookup(self, reference: Reference, binding: dict, conditions: dict, output=None) -> dict | None:
        """조건이 같은 승인 기록 — 없거나 코드가 기록과 달라졌으면 None."""
        key = reference_key(reference, binding, conditions, output)
        hits = [r for r in self._records() if r.get("key") == key]
        if not hits:
            return None
        rec = hits[-1]
        if rec.get("status") != "approved" or code_sha256(rec.get("code", "")) != rec.get("code_sha256"):
            return None
        return rec

    def approve(self, result: CheckResult, code: str, reference: Reference, binding: dict, conditions: dict,
                output=None, approved_by: str = "formula-check") -> dict:
        """검사에 통과(proven)한 코드만 기록한다. 검사한 것과 같은 코드·기준 수식·binding·output 이어야 하고,
        계산 코드 정적 점검(recompute.sandbox — 최상위 문장 포함 전체 코드)도 통과해야 한다.
        수식 검사는 func_name 한 함수만 보므로, 나머지 코드의 안전은 정적 점검이 맡는다."""
        if not result.ok:
            raise NotApproved(f"{result.eq_id}: 검사 결과 {result.status} — 승인할 수 없음 ({'; '.join(result.reasons)})")
        if result.code_sha256 != code_sha256(code):
            raise NotApproved(f"{result.eq_id}: 검사한 코드와 승인하려는 코드가 다름")
        if (result.reference != reference.to_dict() or result.binding != dict(sorted(binding.items()))
                or result.output != output):
            raise NotApproved(f"{result.eq_id}: 검사한 기준 수식·binding·output 과 승인하려는 것이 다름")
        from measuretrace.recompute import sandbox
        problems = sandbox.static_check(code)
        if problems:
            raise NotApproved(f"{result.eq_id}: 계산 코드 정적 점검 위반 — {'; '.join(problems)}")
        rec = {"ts": datetime.now().astimezone().isoformat(timespec="seconds"), "status": "approved",
               "key": reference_key(reference, binding, conditions, output), "eq_id": reference.eq_id,
               "func_name": result.func_name, "code_sha256": result.code_sha256, "code": code,
               "reference": reference.to_dict(), "binding": dict(sorted(binding.items())), "output": output,
               "conditions": conditions, "check": {k: v for k, v in result.to_dict().items()
                                                   if k in ("status", "sizes", "notes", "checker")},
               "approved_by": approved_by}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return rec


def verify_or_reuse(reference: Reference, binding: dict, conditions: dict,
                    generate: Callable[[], tuple[str, str]], store: ApprovalStore | None = None,
                    output=None, max_attempts: int = 1) -> dict:
    """승인 기록이 있으면 재사용, 없으면 generate()(→ (코드, 함수 이름), 보통 LLM 호출)로 만들어 검사·승인.

    돌려주는 값: {"reused": bool, "approved": bool, "code", "func_name", "code_sha256", "record"|None, "checks": [...]}
                 (승인하지 못하면 "error" 에 사유).
    검사에 떨어진 코드는 기록하지 않고 approved=False 로 돌려준다 — 실행하지 말 것.
    """
    store = store or ApprovalStore()
    try:
        parse_reference(reference)
    except ValueError as e:     # 기준 수식이 잘못이면 코드를 만들 이유가 없다
        return {"reused": False, "approved": False, "code": None, "func_name": None, "code_sha256": None,
                "record": None, "checks": [], "error": str(e)}
    rec = store.lookup(reference, binding, conditions, output)
    if rec:
        return {"reused": True, "approved": True, "code": rec["code"], "func_name": rec["func_name"],
                "code_sha256": rec["code_sha256"], "record": rec, "checks": []}
    checks = []
    for _ in range(max(1, max_attempts)):
        code, func_name = generate()
        result = check_function(code, func_name, reference, binding, output=output)
        checks.append(result.to_dict())
        if result.ok:
            try:
                rec = store.approve(result, code, reference, binding, conditions, output)
            except NotApproved as e:
                checks[-1]["approval_error"] = str(e)
                continue
            return {"reused": False, "approved": True, "code": code, "func_name": func_name,
                    "code_sha256": result.code_sha256, "record": rec, "checks": checks}
    return {"reused": False, "approved": False, "code": code, "func_name": func_name,
            "code_sha256": checks[-1]["code_sha256"], "record": None, "checks": checks,
            "error": checks[-1].get("approval_error") or "; ".join(checks[-1]["reasons"]) or checks[-1]["status"]}
