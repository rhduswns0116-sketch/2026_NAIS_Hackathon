"""LLM 이 만든 수식 함수가 승인된 기준 수식과 수학적으로 같은지 검사한다 [PY] — 실행 전 검사.

흐름
  1. 연구자가 원문과 대조해 기준 수식(SymPy 문법 글)과 변수 뜻을 승인한다 → Reference. 이것이 검증 기준이다.
  2. LLM 이 그 수식을 Python 함수로 구현한다.
  3. check_function() 이 그 함수의 AST 를 **실행하지 않고** 기호로 따라가 SymPy 식으로 바꾼 뒤 기준 수식과 비교한다.
       - 먼저 결정적 난수점(시드 = 입력 해시)에서 수치로 비교해 반례를 찾는다 → 있으면 mismatch(반례 값 기록)
       - 반례가 없으면 simplify(코드 − 기준) == 0 을 확인한다 → proven
       - 기호로 0 을 증명하지 못하면 inconclusive(연구자 확인 필요). 통과(ok)는 proven 뿐이다.
  4. 통과한 코드만 store.ApprovalStore 에 코드 해시 · 기준 수식 · 적용 조건과 함께 남기고, 조건이 같으면 재사용한다.

범위(작은 모듈 — 지원하지 않는 구문은 추측하지 않고 unsupported 로 멈춘다)
  - 대상은 스칼라 하나(또는 dict/tuple 의 한 항목)를 돌려주는 순수 계산 함수. 파일 읽기·표 가공 코드는 대상이 아니다.
  - 목록 인자(측정값 목록 등)는 길이를 몇 가지(기본 2·3·5)로 고정해 원소 기호로 펼쳐 비교한다.
    기준 수식의 Sum 도 같은 길이로 펼친다. 따라서 증명은 '검사한 길이들에서' 성립한다(결과에 길이를 남긴다).
  - 분기: 판정할 수 있는 조건은 그 갈래만 따라간다. 판정할 수 없는 조건 중 한쪽이 nan/None 반환·raise 인
    보호 분기(예: if den == 0: return nan)는 일반 위치 가정으로 건너뛰고 notes 에 남긴다. 그 밖은 unsupported.
  - 반복문은 range(상수)·목록·zip·enumerate 위에서만 펼친다. while·break·continue 는 unsupported.
"""
from __future__ import annotations

import ast
import hashlib
import json
import random
from dataclasses import dataclass, field

import sympy as sp

CHECKER_VERSION = "formula-check/1"   # 비교 규칙이 바뀌면 올린다 — 승인 기록 재사용 키에 들어간다
DEFAULT_SIZES = (2, 3, 5)
NUMERIC_POINTS = 8
MAX_UNROLL = 10_000                    # 펼치는 반복 횟수 상한 (무한·폭주 방지)
MAX_EXPONENT = 64                      # 상수 지수 상한 — 2**(10**9) 같은 식이 검사기를 멈추지 않게


class Unsupported(Exception):
    """검사기가 따라갈 수 없는 구문 — 추측하지 않고 멈춘다."""


# ------------------------------------------------------------------ 기준 수식

@dataclass
class Reference:
    """연구자가 승인한 기준 수식.

    expr       SymPy 문법 글. 예: "sqrt(((n_A-1)*s_A**2 + (n_C-1)*s_C**2)/(n_A+n_C-2))",
               목록 변수는 첨자로: "Sum((V[k]-Vbar)**2, (k, 1, n))". ^ 는 거듭제곱으로 읽는다.
    variables  기호 → 뜻(원문 표현). 식에 나오는 자유 기호는 모두 여기 있어야 한다(합의 첨자 제외).
    vectors    목록 기호 → 길이 기호. 예: {"V": "n"}. 길이 기호도 variables 에 적는다.
    source     원문 위치(예: "계획서 p.3 식 6").
    assume     기호 가정 — 기본 "real". "positive" 는 모든 기호(목록 원소 포함)가 양수라고 연구자가 확인했을 때만
               쓴다(개수·표준편차 등): 그 가정으로 sqrt(x**2) = x 같은 단순화가 증명으로 인정된다.
    """
    eq_id: str
    expr: str
    variables: dict[str, str]
    vectors: dict[str, str] = field(default_factory=dict)
    source: str = ""
    assume: str = "real"
    approved_by: str | None = None
    approved_at: str | None = None

    def to_dict(self) -> dict:
        return {"eq_id": self.eq_id, "expr": self.expr, "variables": dict(sorted(self.variables.items())),
                "vectors": dict(sorted(self.vectors.items())), "source": self.source, "assume": self.assume,
                "approved_by": self.approved_by, "approved_at": self.approved_at}


# 기준 수식에 쓸 수 있는 함수 — parse_expr 는 eval 이므로 글을 먼저 AST 로 검사한다
_REF_FUNCS = {"sqrt": sp.sqrt, "exp": sp.exp, "log": sp.log, "ln": sp.log, "Abs": sp.Abs, "abs": sp.Abs,
              "Sum": sp.Sum, "Min": sp.Min, "Max": sp.Max, "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
              "asin": sp.asin, "acos": sp.acos, "atan": sp.atan, "Rational": sp.Rational}
_REF_CONSTS = {"pi": sp.pi, "E": sp.E}
_REF_NODES = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Call, ast.Name, ast.Load, ast.Constant, ast.Tuple,
              ast.Subscript, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.BitXor, ast.USub, ast.UAdd)


def _symbol(name: str, assume: str) -> sp.Symbol:
    return sp.Symbol(name, positive=True) if assume == "positive" else sp.Symbol(name, real=True)


def parse_reference(ref: Reference) -> sp.Expr:
    """기준 수식 글 → SymPy 식. 허용한 구문·함수·기호만 받는다."""
    try:
        tree = ast.parse(ref.expr.replace("^", "**"), mode="eval")
    except SyntaxError as e:
        raise ValueError(f"{ref.eq_id}: 기준 수식 문법 오류 — {e}") from None
    for node in ast.walk(tree):
        if not isinstance(node, _REF_NODES):
            raise ValueError(f"{ref.eq_id}: 기준 수식에 쓸 수 없는 구문 {type(node).__name__}")
        if isinstance(node, ast.Call) and not (isinstance(node.func, ast.Name) and node.func.id in _REF_FUNCS):
            raise ValueError(f"{ref.eq_id}: 기준 수식에 쓸 수 없는 함수 {ast.unparse(node.func)}")
        if isinstance(node, ast.Subscript) and not (isinstance(node.value, ast.Name) and node.value.id in ref.vectors):
            raise ValueError(f"{ref.eq_id}: 첨자는 vectors 에 적은 목록 기호에만 쓸 수 있음 — {ast.unparse(node)}")
        if isinstance(node, ast.Constant) and (isinstance(node.value, bool) or not isinstance(node.value, (int, float))):
            raise ValueError(f"{ref.eq_id}: 기준 수식에는 숫자 상수만 쓸 수 있음 — {node.value!r}")
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Pow, ast.BitXor)):
            exp_nodes = list(ast.walk(node.right))
            if not any(isinstance(x, ast.Name) for x in exp_nodes) and (
                    any(isinstance(x, ast.BinOp) and isinstance(x.op, (ast.Pow, ast.BitXor)) for x in exp_nodes)
                    or any(isinstance(x, ast.Constant) and abs(x.value) > MAX_EXPONENT for x in exp_nodes
                           if isinstance(x.value, (int, float)))):
                raise ValueError(f"{ref.eq_id}: 상수 지수가 너무 큼 — {ast.unparse(node)}")
        if isinstance(node, ast.Name) and node.id.startswith("_"):
            raise ValueError(f"{ref.eq_id}: 밑줄로 시작하는 이름은 쓸 수 없음")
    for v, n in ref.vectors.items():
        if n not in ref.variables:
            raise ValueError(f"{ref.eq_id}: 목록 {v} 의 길이 기호 {n} 가 variables 에 없음")
    local: dict = {**_REF_FUNCS, **_REF_CONSTS}
    for name in ref.variables:
        local[name] = sp.IndexedBase(name) if name in ref.vectors else _symbol(name, ref.assume)
    for name in {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)} - set(local):
        local[name] = sp.Symbol(name, integer=True)   # 합의 첨자(k, i …) — 아래에서 자유 기호로 남으면 오류
    expr = sp.sympify(eval(compile(tree, "<reference>", "eval"), {"__builtins__": {}}, local))  # noqa: S307 — 위에서 구문 검사
    free = {s.name for s in expr.free_symbols if not isinstance(s, sp.Indexed)} - set(ref.variables)
    free -= {b.name for b in expr.atoms(sp.IndexedBase)}
    if free:
        raise ValueError(f"{ref.eq_id}: variables 에 뜻이 없는 기호 {sorted(free)}")
    return expr


# ------------------------------------------------------------------ 코드 → SymPy (실행하지 않음)

_NAN = sp.nan
_UNKNOWN = object()   # 판정할 수 없는 조건 — None(파이썬 값)과 섞이지 않게 따로 둔다


def _sym_sum(xs):
    return sp.Add(*[_as_expr(x) for x in _as_list(xs)])


def _mean(xs):
    xs = _as_list(xs)
    if not xs:
        raise Unsupported("빈 목록의 평균")
    return _sym_sum(xs) / len(xs)


def _var(xs, ddof=0):
    xs = _as_list(xs)
    m = _mean(xs)
    return sp.Add(*[(_as_expr(x) - m) ** 2 for x in xs]) / (len(xs) - int(ddof))


def _float(x=0):
    if isinstance(x, str):
        t = x.strip().lower()
        if t in ("nan", "+nan", "-nan"):
            return _NAN
        if t in ("inf", "+inf", "infinity"):
            return sp.oo
        if t in ("-inf", "-infinity"):
            return -sp.oo
        return sp.Rational(t)
    return _as_expr(x)


def _log(x, base=None):
    return sp.log(_as_expr(x)) if base is None else sp.log(_as_expr(x), _as_expr(base))


def _concrete_int(x, what):
    if isinstance(x, bool) or not (isinstance(x, int) or (isinstance(x, sp.Integer))):
        raise Unsupported(f"{what} 는 상수 정수여야 함: {x}")
    return int(x)


def _range(*args):
    n = [_concrete_int(a, "range 인자") for a in args]
    r = range(*n)
    if len(r) > MAX_UNROLL:
        raise Unsupported("range 가 너무 김")
    return [sp.Integer(i) for i in r]


_FUNCS = {
    # 이름 → (구현). math/numpy/statistics 는 모듈 이름을 붙인 정규 이름으로 찾는다.
    "sqrt": lambda x: sp.sqrt(_as_expr(x)), "exp": lambda x: sp.exp(_as_expr(x)), "log": _log,
    "log10": lambda x: sp.log(_as_expr(x), 10), "log2": lambda x: sp.log(_as_expr(x), 2),
    "sin": lambda x: sp.sin(_as_expr(x)), "cos": lambda x: sp.cos(_as_expr(x)), "tan": lambda x: sp.tan(_as_expr(x)),
    "asin": lambda x: sp.asin(_as_expr(x)), "acos": lambda x: sp.acos(_as_expr(x)),
    "atan": lambda x: sp.atan(_as_expr(x)), "fabs": lambda x: sp.Abs(_as_expr(x)),
    "abs": lambda x: sp.Abs(_as_expr(x)), "pow": lambda a, b: _as_expr(a) ** _as_expr(b),
    "sum": _sym_sum, "fsum": _sym_sum, "mean": _mean, "fmean": _mean,
    "variance": lambda xs: _var(xs, 1), "stdev": lambda xs: sp.sqrt(_var(xs, 1)),
    "pvariance": lambda xs: _var(xs, 0), "pstdev": lambda xs: sp.sqrt(_var(xs, 0)),
    "var": lambda xs, ddof=0: _var(xs, ddof), "std": lambda xs, ddof=0: sp.sqrt(_var(xs, ddof)),
    "min": lambda *a: sp.Min(*[_as_expr(x) for x in (_as_list(a[0]) if len(a) == 1 else a)]),
    "max": lambda *a: sp.Max(*[_as_expr(x) for x in (_as_list(a[0]) if len(a) == 1 else a)]),
    "float": _float, "len": lambda xs: sp.Integer(len(_as_list(xs))), "range": _range,
    "list": lambda xs=(): list(_as_list(xs)), "tuple": lambda xs=(): tuple(_as_list(xs)),
    "zip": lambda *xs: [tuple(t) for t in zip(*[_as_list(x) for x in xs])],
    "enumerate": lambda xs, start=0: [(sp.Integer(i + int(start)), x) for i, x in enumerate(_as_list(xs))],
    "array": lambda xs: list(_as_list(xs)), "asarray": lambda xs: list(_as_list(xs)),
}
# 모듈별로 허용하는 이름 (numpy 의 var/std 는 ddof 기본 0, statistics 의 variance/stdev 는 n−1)
_MODULE_FUNCS = {
    "math": {"sqrt", "exp", "log", "log10", "log2", "sin", "cos", "tan", "asin", "acos", "atan", "fabs", "pow",
             "fsum"},
    "numpy": {"sqrt", "exp", "log", "log10", "log2", "sin", "cos", "tan", "abs", "sum", "mean", "var", "std", "min",
              "max", "array", "asarray"},
    "statistics": {"mean", "fmean", "variance", "stdev", "pvariance", "pstdev"},
}
_BUILTINS = {"abs", "pow", "sum", "min", "max", "float", "len", "range", "list", "tuple", "zip", "enumerate"}
_MODULE_CONSTS = {("math", "pi"): sp.pi, ("math", "e"): sp.E, ("numpy", "pi"): sp.pi, ("numpy", "e"): sp.E,
                  ("math", "nan"): _NAN, ("numpy", "nan"): _NAN, ("math", "inf"): sp.oo, ("numpy", "inf"): sp.oo}
_MODULE_ALIASES = {"np": "numpy"}


@dataclass(frozen=True)
class _Module:
    name: str


@dataclass(frozen=True)
class _Func:
    name: str          # _FUNCS 키


def _as_list(x):
    if isinstance(x, (list, tuple)):
        return list(x)
    raise Unsupported(f"목록이 필요한 자리에 목록이 아닌 값: {x}")


def _as_expr(x):
    if isinstance(x, bool):
        return sp.Integer(int(x))
    if isinstance(x, int):
        return sp.Integer(x)
    if isinstance(x, sp.Basic):
        return x
    raise Unsupported(f"수가 필요한 자리에 수가 아닌 값: {type(x).__name__}")


_BOOLEAN = sp.logic.boolalg.Boolean


def _condition(v):
    """조건 값 → '참일 때'를 나타내는 SymPy 논리식. 나타낼 수 없으면 None."""
    if isinstance(v, bool):
        return sp.true if v else sp.false
    if isinstance(v, _BOOLEAN):
        return v
    if isinstance(v, sp.Expr):
        return sp.Ne(v, 0)        # if x: → x != 0
    return None


def _truth(x):
    """판정할 수 있으면 True/False, 아니면 None."""
    if x is _UNKNOWN:
        return None
    if isinstance(x, bool):
        return x
    if x is None:
        return False
    if isinstance(x, (list, tuple, dict, str)):
        return bool(x)
    if x is sp.true or x is sp.false:
        return bool(x)
    if isinstance(x, sp.Basic):
        if x.is_Relational or isinstance(x, sp.logic.boolalg.Boolean):
            return None
        z = x.is_zero
        return None if z is None else not z
    return None


def _num(value: float | int) -> sp.Expr:
    if isinstance(value, bool) or isinstance(value, int):
        return sp.Integer(int(value))
    if value != value:
        return _NAN
    if value in (float("inf"), float("-inf")):
        return sp.oo if value > 0 else -sp.oo
    return sp.Rational(repr(value))    # 0.1 → 1/10 (소수 표기 그대로, 이진 오차 없이)


class _Return(Exception):
    def __init__(self, value):
        self.value = value


class _Interp:
    """함수 본문을 기호 값으로 따라간다. 파이썬 코드는 한 줄도 실행하지 않는다."""

    def __init__(self, tree: ast.Module):
        self.defs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
        self.names: dict[str, object] = {}
        self.notes: list[str] = []
        self.guards: list[tuple[str, sp.Basic]] = []   # (설명, 보호 분기가 작동하는 조건) — 수치 검사에서 확인
        self.steps = 0
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    root = a.name.split(".")[0]
                    if a.asname:
                        self.names[a.asname] = _Module(_MODULE_ALIASES.get(a.name, a.name))
                    else:
                        self.names[root] = _Module(root)
            elif isinstance(node, ast.ImportFrom) and node.module in _MODULE_FUNCS:
                for a in node.names:
                    if a.name in _MODULE_FUNCS[node.module]:
                        self.names[a.asname or a.name] = _Func(a.name)
                    elif (node.module, a.name) in _MODULE_CONSTS:
                        self.names[a.asname or a.name] = _MODULE_CONSTS[(node.module, a.name)]
        self._load_constants(tree)

    def _load_constants(self, tree: ast.Module):
        """모듈 최상위의 단순 상수(NS = 1e9 등). 최상위에서 다른 방식으로도 바뀌거나 global 로 선언된 이름은 싣지 않는다."""
        simple, other = [], set()
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                simple.append(node)
            elif not isinstance(node, (ast.FunctionDef, ast.Import, ast.ImportFrom, ast.Expr)):
                other |= {n.id for n in ast.walk(node) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}
        other |= {name for n in ast.walk(tree) if isinstance(n, (ast.Global, ast.Nonlocal)) for name in n.names}
        for node in simple:
            name = node.targets[0].id
            if name in other:
                continue
            try:
                self.names[name] = self.expr(node.value, {})
            except Exception:           # 상수로 풀 수 없는 값은 싣지 않는다 — 함수가 쓰면 '알 수 없는 이름'
                self.names.pop(name, None)
        self.steps = 0

    # ---- 함수 호출
    def call(self, fdef: ast.FunctionDef, args: list, kwargs: dict, depth: int = 0):
        if depth > 20:
            raise Unsupported("재귀가 너무 깊음")
        a = fdef.args
        if a.vararg or a.kwarg or a.kwonlyargs or a.posonlyargs:
            raise Unsupported(f"{fdef.name}: *args·**kwargs·키워드 전용 인자는 지원하지 않음")
        params = [p.arg for p in a.args]
        env: dict = {}
        if len(args) > len(params):
            raise Unsupported(f"{fdef.name}: 인자 개수가 많음")
        env.update(zip(params, args))
        for k, v in kwargs.items():
            if k not in params or k in env:
                raise Unsupported(f"{fdef.name}: 인자 {k} 오류")
            env[k] = v
        defaults = dict(zip(params[len(params) - len(a.defaults):], a.defaults))
        for p in params:
            if p not in env:
                if p not in defaults:
                    raise Unsupported(f"{fdef.name}: 인자 {p} 값 없음")
                env[p] = self.expr(defaults[p], {})
        try:
            self.block(fdef.body, env, depth)
        except _Return as r:
            return r.value
        return None

    # ---- 문장
    def block(self, stmts, env, depth):
        for s in stmts:
            self.stmt(s, env, depth)

    def _tick(self):
        self.steps += 1
        if self.steps > MAX_UNROLL * 10:
            raise Unsupported("따라갈 문장이 너무 많음")

    def stmt(self, s, env, depth):
        self._tick()
        if isinstance(s, ast.Expr):
            if isinstance(s.value, ast.Constant):       # 문서 문자열
                return
            c = s.value
            if isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr in ("append", "extend") \
                    and len(c.args) == 1 and not c.keywords:
                target = self.expr(c.func.value, env, depth)
                if isinstance(target, list):
                    item = self.expr(c.args[0], env, depth)
                    target.extend(_as_list(item)) if c.func.attr == "extend" else target.append(item)
                    return
            raise Unsupported(f"{s.lineno}줄: 결과를 쓰지 않는 식(부수 효과) — {ast.unparse(s)[:60]}")
        if isinstance(s, (ast.Pass, ast.Import, ast.ImportFrom)):
            return
        if isinstance(s, ast.Return):
            raise _Return(None if s.value is None else self.expr(s.value, env, depth))
        if isinstance(s, ast.Assign):
            v = self.expr(s.value, env, depth)
            for t in s.targets:
                self.assign(t, v, env)
            return
        if isinstance(s, ast.AnnAssign):
            if s.value is not None:
                self.assign(s.target, self.expr(s.value, env, depth), env)
            return
        if isinstance(s, ast.AugAssign):
            cur = self.expr(ast.Name(s.target.id, ast.Load()), env, depth) if isinstance(s.target, ast.Name) else None
            if cur is None:
                raise Unsupported(f"{s.lineno}줄: 이름이 아닌 대상의 복합 대입")
            env[s.target.id] = self.binop(s.op, cur, self.expr(s.value, env, depth))
            return
        if isinstance(s, ast.For):
            if s.orelse:
                raise Unsupported(f"{s.lineno}줄: for-else")
            items = _as_list(self.expr(s.iter, env, depth))
            if len(items) > MAX_UNROLL:
                raise Unsupported(f"{s.lineno}줄: 반복이 너무 김")
            for item in items:
                self.assign(s.target, item, env)
                self.block(s.body, env, depth)
            return
        if isinstance(s, ast.If):
            v = self.expr(s.test, env, depth)
            t = _truth(v)
            if t is True:
                return self.block(s.body, env, depth)
            if t is False:
                return self.block(s.orelse, env, depth)
            cond, fires = ast.unparse(s.test), _condition(v)
            if fires is not None and self._is_guard(s.body):
                self._guard(f"{s.lineno}줄: 보호 분기 'if {cond}'", fires)
                return self.block(s.orelse, env, depth)
            if fires is not None and s.orelse and self._is_guard(s.orelse):
                self._guard(f"{s.lineno}줄: 보호 분기 'if not ({cond})'", sp.Not(fires))
                return self.block(s.body, env, depth)
            raise Unsupported(f"{s.lineno}줄: 기호 값으로 판정할 수 없는 분기 'if {cond}'")
        raise Unsupported(f"{s.lineno}줄: 지원하지 않는 문장 {type(s).__name__}")

    def _guard(self, text: str, fires):
        """보호 분기는 건너뛰되 작동 조건을 남긴다 — 검사 점에서 작동하면 proven 이 될 수 없다(정상 입력에서 nan)."""
        self.notes.append(f"{text} 는 일반 위치 가정으로 건너뜀 (검사 점에서 작동하지 않음을 확인)")
        self.guards.append((text, fires))

    def _is_guard(self, body) -> bool:
        """nan/None/무한 을 돌려주거나 예외를 내는 짧은 분기."""
        if not body:
            return False
        last = body[-1]
        if isinstance(last, ast.Raise):
            return True
        if isinstance(last, ast.Return):
            if last.value is None or (isinstance(last.value, ast.Constant) and last.value.value is None):
                return True
            try:
                v = self.expr(last.value, {})
            except Exception:
                return False
            return v is None or v is _NAN or (isinstance(v, sp.Basic) and v.has(sp.oo, -sp.oo, sp.zoo, _NAN))
        return False

    def assign(self, target, value, env):
        if isinstance(target, ast.Name):
            env[target.id] = value
        elif isinstance(target, (ast.Tuple, ast.List)):
            vals = _as_list(value)
            if len(vals) != len(target.elts):
                raise Unsupported("풀어 쓰는 대입의 개수가 맞지 않음")
            for t, v in zip(target.elts, vals):
                self.assign(t, v, env)
        else:
            raise Unsupported(f"지원하지 않는 대입 대상 {ast.unparse(target)}")

    # ---- 식
    def binop(self, op, a, b):
        if isinstance(a, (list, tuple)) or isinstance(b, (list, tuple)):
            if isinstance(op, ast.Add) and isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
                return list(a) + list(b)
            raise Unsupported("목록끼리의 산술(배열 연산)은 지원하지 않음 — 원소별로 풀어 써야 함")
        a, b = _as_expr(a), _as_expr(b)
        if isinstance(op, ast.Add):
            return a + b
        if isinstance(op, ast.Sub):
            return a - b
        if isinstance(op, ast.Mult):
            return a * b
        if isinstance(op, ast.Div):
            return a / b
        if isinstance(op, ast.Pow):
            if b.is_Number and abs(b) > MAX_EXPONENT:
                raise Unsupported(f"지수가 너무 큼: {b}")
            return a ** b
        if isinstance(op, ast.FloorDiv) and a.is_Integer and b.is_Integer:
            return sp.Integer(int(a) // int(b))
        if isinstance(op, ast.Mod) and a.is_Integer and b.is_Integer:
            return sp.Integer(int(a) % int(b))
        raise Unsupported(f"지원하지 않는 연산 {type(op).__name__}")

    def compare(self, op, a, b):
        if isinstance(op, (ast.Is, ast.IsNot)):
            if a is None or b is None:
                same = (a is None) and (b is None)
                return same if isinstance(op, ast.Is) else not same
            raise Unsupported("is 비교는 None 과만 지원")
        a, b = _as_expr(a), _as_expr(b)
        rel = {ast.Eq: sp.Eq, ast.NotEq: sp.Ne, ast.Lt: sp.Lt, ast.LtE: sp.Le, ast.Gt: sp.Gt, ast.GtE: sp.Ge}.get(type(op))
        if rel is None:
            raise Unsupported(f"지원하지 않는 비교 {type(op).__name__}")
        try:
            return rel(a, b)
        except TypeError:
            return _UNKNOWN

    def expr(self, e, env, depth=0):
        self._tick()
        if isinstance(e, ast.Constant):
            v = e.value
            if v is None or isinstance(v, (str, bool)):
                return v
            if isinstance(v, (int, float)):
                return _num(v)
            raise Unsupported(f"지원하지 않는 상수 {v!r}")
        if isinstance(e, ast.Name):
            if e.id in env:
                return env[e.id]
            if e.id in self.names:
                return self.names[e.id]
            if e.id in self.defs:
                return self.defs[e.id]
            if e.id in _BUILTINS:
                return _Func(e.id)
            raise Unsupported(f"알 수 없는 이름 {e.id} (전역 변수·정의되지 않은 이름)")
        if isinstance(e, ast.Attribute):
            base = self.expr(e.value, env, depth)
            if isinstance(base, _Module):
                if (base.name, e.attr) in _MODULE_CONSTS:
                    return _MODULE_CONSTS[(base.name, e.attr)]
                if e.attr in _MODULE_FUNCS.get(base.name, ()):
                    return _Func(e.attr)
            raise Unsupported(f"지원하지 않는 속성 {ast.unparse(e)}")
        if isinstance(e, ast.BinOp):
            return self.binop(e.op, self.expr(e.left, env, depth), self.expr(e.right, env, depth))
        if isinstance(e, ast.UnaryOp):
            v = self.expr(e.operand, env, depth)
            if isinstance(e.op, ast.USub):
                return -_as_expr(v)
            if isinstance(e.op, ast.UAdd):
                return _as_expr(v)
            if isinstance(e.op, ast.Not):
                t = _truth(v)
                if t is not None:
                    return not t
                c = _condition(v)
                return _UNKNOWN if c is None else sp.Not(c)
            raise Unsupported("지원하지 않는 단항 연산")
        if isinstance(e, ast.BoolOp):
            # 파이썬 의미 그대로: and 는 처음 거짓인 피연산자, or 는 처음 참인 피연산자(없으면 마지막)를 돌려준다
            vals = [self.expr(v, env, depth) for v in e.values]
            is_and = isinstance(e.op, ast.And)
            for v in vals:
                t = _truth(v)
                if t is None:
                    break
                if t is not is_and:
                    return v
            else:
                return vals[-1]
            conds = [_condition(v) for v in vals]
            if None in conds:
                return _UNKNOWN
            return sp.And(*conds) if is_and else sp.Or(*conds)
        if isinstance(e, ast.Compare):
            parts, left = [], self.expr(e.left, env, depth)
            for op, comp in zip(e.ops, e.comparators):
                right = self.expr(comp, env, depth)
                r = self.compare(op, left, right)
                t = _truth(r)
                if t is False:
                    return False
                if t is None:
                    if not isinstance(r, _BOOLEAN):
                        return _UNKNOWN
                    parts.append(r)
                left = right
            return sp.And(*parts) if parts else True
        if isinstance(e, ast.IfExp):
            v = self.expr(e.test, env, depth)
            t = _truth(v)
            if t is None:
                # 한쪽이 nan 인 보호 식(예: x / y if y != 0 else nan)은 다른 쪽으로
                other = self._guard_other(e, _condition(v), env, depth)
                if other is None:
                    raise Unsupported(f"판정할 수 없는 조건식 {ast.unparse(e)[:60]}")
                return other
            return self.expr(e.body if t else e.orelse, env, depth)
        if isinstance(e, (ast.Tuple, ast.List)):
            return [self.expr(x, env, depth) for x in e.elts] if isinstance(e, ast.List) \
                else tuple(self.expr(x, env, depth) for x in e.elts)
        if isinstance(e, ast.Dict):
            return {self.expr(k, env, depth): self.expr(v, env, depth) for k, v in zip(e.keys, e.values)}
        if isinstance(e, ast.Subscript):
            base = self.expr(e.value, env, depth)
            if isinstance(e.slice, ast.Slice):
                parts = [None if p is None else _concrete_int(self.expr(p, env, depth), "자르기 범위")
                         for p in (e.slice.lower, e.slice.upper, e.slice.step)]
                return list(_as_list(base))[slice(*parts)]
            idx = self.expr(e.slice, env, depth)
            if isinstance(base, dict):
                if idx not in base:
                    raise Unsupported(f"사전에 키 {idx!r} 없음")
                return base[idx]
            return _as_list(base)[_concrete_int(idx, "첨자")]
        if isinstance(e, (ast.ListComp, ast.GeneratorExp)):
            return self.comprehension(e, env, depth)
        if isinstance(e, ast.Call):
            fn = self.expr(e.func, env, depth)
            if any(isinstance(a, ast.Starred) for a in e.args) or any(k.arg is None for k in e.keywords):
                raise Unsupported("*args·**kwargs 호출은 지원하지 않음")
            args = [self.expr(a, env, depth) for a in e.args]
            kwargs = {k.arg: self.expr(k.value, env, depth) for k in e.keywords}
            if isinstance(fn, ast.FunctionDef):
                return self.call(fn, args, kwargs, depth + 1)
            if isinstance(fn, _Func):
                try:
                    return _FUNCS[fn.name](*args, **kwargs)
                except TypeError as err:
                    raise Unsupported(f"{fn.name}() 인자 오류: {err}") from None
            raise Unsupported(f"호출할 수 없는 대상 {ast.unparse(e.func)}")
        raise Unsupported(f"지원하지 않는 식 {type(e).__name__}: {ast.unparse(e)[:60]}")

    def _guard_other(self, e: ast.IfExp, cond, env, depth):
        if cond is None:
            return None
        for guard, other, fires in ((e.orelse, e.body, sp.Not(cond)), (e.body, e.orelse, cond)):
            try:
                g = self.expr(guard, env, depth)
            except Unsupported:
                continue
            if g is None or g is _NAN or (isinstance(g, sp.Basic) and g.has(sp.oo, -sp.oo, sp.zoo, _NAN)):
                self._guard(f"{e.lineno}줄: 보호 조건식 '{ast.unparse(e)[:60]}'", fires)
                return self.expr(other, env, depth)
        return None

    def comprehension(self, e, env, depth):
        if len(e.generators) != 1 or e.generators[0].is_async:
            raise Unsupported("생성자가 하나인 컴프리헨션만 지원")
        g = e.generators[0]
        out, local = [], dict(env)
        for item in _as_list(self.expr(g.iter, local, depth)):
            self.assign(g.target, item, local)
            conds = [_truth(self.expr(c, local, depth)) for c in g.ifs]
            if None in conds:
                raise Unsupported("컴프리헨션의 조건을 판정할 수 없음")
            if all(conds):
                out.append(self.expr(e.elt, local, depth))
        return out


def translate(code: str, func_name: str, args: dict, output=None) -> tuple[sp.Expr, list[str], list]:
    """코드의 func_name 함수를 args(인자 이름 → 기호 값)로 따라가 SymPy 식을 만든다. (식, notes, 보호 분기 조건)."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        raise Unsupported(f"문법 오류: {e}") from None
    it = _Interp(tree)
    if func_name not in it.defs:
        raise Unsupported(f"함수 {func_name} 가 코드 최상위에 없음")
    fdef = it.defs[func_name]
    params = [p.arg for p in fdef.args.args]
    missing = [p for p in params if p not in args]
    extra = [a for a in args if a not in params]
    if missing or extra:
        raise Unsupported(f"{func_name} 인자와 binding 이 맞지 않음 — 빠짐 {missing}, 없는 인자 {extra}")
    value = it.call(fdef, [], dict(args))
    if output is not None:
        if isinstance(value, dict) and output in value:
            value = value[output]
        elif isinstance(value, (list, tuple)) and isinstance(output, int) and -len(value) <= output < len(value):
            value = list(value)[output]
        else:
            raise Unsupported(f"반환값에서 {output!r} 를 찾을 수 없음")
    if isinstance(value, (list, tuple, dict)) or value is None or isinstance(value, str):
        raise Unsupported(f"{func_name} 가 수 하나를 돌려주지 않음 (output 으로 항목을 지정)")
    return sp.sympify(_as_expr(value)), it.notes, it.guards


# ------------------------------------------------------------------ 비교

@dataclass
class CheckResult:
    eq_id: str
    func_name: str
    status: str                  # proven | mismatch | inconclusive | unsupported | invalid_reference
    code_sha256: str
    reference: dict
    binding: dict
    output: object = None
    sizes: list = field(default_factory=list)
    details: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    reasons: list = field(default_factory=list)
    checker: str = CHECKER_VERSION

    @property
    def ok(self) -> bool:
        return self.status == "proven"

    def to_dict(self) -> dict:
        return {"eq_id": self.eq_id, "func_name": self.func_name, "status": self.status, "ok": self.ok,
                "code_sha256": self.code_sha256, "reference": self.reference, "binding": self.binding,
                "output": self.output, "sizes": self.sizes, "details": self.details, "notes": self.notes,
                "reasons": self.reasons, "checker": self.checker}


def code_sha256(code: str) -> str:
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def _finite(v) -> bool:
    return v is not None and v.is_real is True and v.is_finite is True


def _numeric_check(a: sp.Expr, b: sp.Expr, guards: list, seed: str, assume: str, points: int) -> dict:
    """결정적 난수점에서 코드(a)와 기준(b)을 비교한다.
    돌려주는 값: {"counterexample": …} | {"guard_fired": …, "tested": n} | {"tested": n} (n == 0 이면 유한한 점을 못 찾음)."""
    syms = sorted(a.free_symbols | b.free_symbols | {s for _, g in guards for s in g.free_symbols}, key=str)
    rng = random.Random(seed)
    tested, fired = 0, None
    for _ in range(points * 10):
        if tested >= points:
            break
        # 크기 1.5~6: 개수·표본 크기 기호에서 (n−2) 같은 분모가 0 근처로 가지 않게. real 이면 부호도 섞는다
        vals = {s: sp.Rational(rng.randint(150, 600), 100) * (1 if assume == "positive" or rng.random() < .5 else -1)
                for s in syms}
        vb = sp.N(b.subs(vals), 30)
        if not _finite(vb):
            continue                       # 기준 수식이 정의되지 않는 점은 비교하지 않는다
        va = sp.N(a.subs(vals), 30)
        at = {str(k): str(v) for k, v in vals.items()}
        if not _finite(va):                # 기준은 값이 있는데 코드는 nan·무한·복소수
            return {"counterexample": {"at": at, "code": str(va), "reference": str(vb.evalf(12))}}
        tested += 1
        if abs(va - vb) > sp.Float("1e-9", 30) * max(abs(va), abs(vb)):
            return {"counterexample": {"at": at, "code": str(va.evalf(12)), "reference": str(vb.evalf(12))}}
        if fired is None:
            for text, g in guards:
                if g.subs(vals) is sp.true:
                    fired = {"guard": text, "at": at, "reference": str(vb.evalf(12))}
                    break
    return {"guard_fired": fired, "tested": tested} if fired else {"tested": tested}


def _vector_elements(ref_k: sp.Expr, v: str, length: int):
    """기준 수식을 펼친 뒤 목록 v 의 원소들 — 첨자가 정수이고 이어진 length 개여야 한다. 아니면 오류 글."""
    atoms = [a for a in ref_k.atoms(sp.Indexed) if a.base.label.name == v]
    if not atoms:
        return [sp.IndexedBase(v)[1 + i] for i in range(length)]
    if any(len(a.indices) != 1 or not a.indices[0].is_Integer for a in atoms):
        return f"기준 수식의 {v} 첨자가 정수 하나로 풀리지 않음(합의 범위를 확인)"
    idx = sorted(int(a.indices[0]) for a in atoms)
    if idx != list(range(idx[0], idx[0] + length)):
        return f"기준 수식의 {v} 첨자 {idx} 가 길이 {length} 의 이어진 범위가 아님"
    return [sp.IndexedBase(v)[i] for i in idx]


def check_function(code: str, func_name: str, reference: Reference, binding: dict[str, str],
                   output=None, sizes=DEFAULT_SIZES) -> CheckResult:
    """code 의 func_name 이 reference 를 구현하는지 검사한다(코드 실행 없음).

    binding  함수 인자 이름 → 기준 수식 기호. 예: {"n_a": "n_A", "values": "V"}.
             목록 기호(reference.vectors)에 묶인 인자는 목록으로, 길이 기호에 묶인 인자는 그 길이(정수)로 넣는다.
    output   함수가 dict/tuple 을 돌려주면 비교할 항목의 키/위치.
    """
    res = CheckResult(reference.eq_id, func_name, "unsupported", code_sha256(code), reference.to_dict(),
                      dict(sorted(binding.items())), output)
    try:
        ref_expr = parse_reference(reference)
    except ValueError as e:
        res.status, res.reasons = "invalid_reference", [str(e)]
        return res
    unknown = sorted(set(binding.values()) - set(reference.variables))
    if unknown:
        res.status, res.reasons = "invalid_reference", [f"binding 이 가리키는 기호가 기준 수식 variables 에 없음: {unknown}"]
        return res
    # 코드 인자로 들어오지 않는 기준 기호(길이 기호 제외)가 있으면 코드는 그 값을 알 방법이 없다
    lengths = set(reference.vectors.values())
    used = {s.name for s in ref_expr.free_symbols if not isinstance(s, sp.Indexed)}
    used |= {b.name for b in ref_expr.atoms(sp.IndexedBase)}
    unbound = sorted(used - set(binding.values()) - lengths)
    if unbound:
        res.status = "mismatch"
        res.reasons = [f"기준 수식의 {unbound} 가 함수 인자로 들어오지 않음 — 코드가 상수로 박았거나 빠뜨림"]
        return res

    len_syms = sorted(lengths)
    size_list = list(sizes) if reference.vectors else [None]
    all_notes: list[str] = []
    for size in size_list:
        # 길이 기호마다 서로 다른 길이(size, size+1, …) — 두 목록의 n 을 바꿔 쓴 오류도 드러나게
        n_of = {n: size + j for j, n in enumerate(len_syms)} if size is not None else {}
        subs = {_symbol(n, reference.assume): sp.Integer(k) for n, k in n_of.items()}
        try:
            ref_k = ref_expr.subs(subs).doit() if subs else ref_expr.doit()
        except (ValueError, TypeError) as e:
            res.status, res.reasons = "invalid_reference", [f"기준 수식을 펼치지 못함: {e}"]
            return res
        vec_vals = {}
        for v, n in reference.vectors.items():
            elems = _vector_elements(ref_k, v, n_of[n])
            if isinstance(elems, str):
                res.status, res.reasons = "invalid_reference", [elems]
                return res
            vec_vals[v] = elems
        # 원소 가정(양수·실수)을 식 비교에 반영하려고 Indexed → 가정 붙은 기호로 바꾼다
        elem_sym = {e: _symbol(f"{e.base.label.name}[{e.indices[0]}]", reference.assume)
                    for es in vec_vals.values() for e in es}
        args = {}
        for param, s in binding.items():
            if s in reference.vectors:
                args[param] = [elem_sym[e] for e in vec_vals[s]]
            elif s in n_of:
                args[param] = sp.Integer(n_of[s])
            else:
                args[param] = _symbol(s, reference.assume)
        ref_k = ref_k.xreplace(elem_sym)
        try:
            code_k, notes, guards = translate(code, func_name, args, output)
        except Unsupported as e:
            res.status, res.reasons = "unsupported", [str(e)]
            return res
        except (RecursionError, ValueError, TypeError, ZeroDivisionError, AttributeError, KeyError, IndexError) as e:
            # 검사기가 예상하지 못한 코드 모양 — 승인하지 않는다(추측 금지)
            res.status, res.reasons = "unsupported", [f"검사기가 따라가지 못함: {type(e).__name__}: {e}"]
            return res
        all_notes += [n for n in notes if n not in all_notes]
        res.notes = all_notes
        detail = {"size": n_of or None, "code_expr": str(code_k), "reference_expr": str(ref_k)}
        seed = hashlib.sha256(f"{res.code_sha256}|{reference.expr}|{size}".encode()).hexdigest()
        num = _numeric_check(code_k, ref_k, guards, seed, reference.assume, NUMERIC_POINTS)
        if "counterexample" in num:
            ce = num["counterexample"]
            detail.update(method="numeric", result="counterexample", counterexample=ce)
            res.details.append(detail)
            res.sizes = [d["size"] for d in res.details]
            res.status = "mismatch"
            res.reasons = [f"길이 {n_of or '-'} 에서 반례: 코드 {ce['code']} ≠ 기준 {ce['reference']}"]
            return res
        if num.get("guard_fired"):
            g = num["guard_fired"]
            detail.update(method="numeric", result="guard fired", guard_fired=g)
            res.details.append(detail)
            res.sizes = [d["size"] for d in res.details]
            res.status = "inconclusive"
            res.reasons = [f"{g['guard']} 가 기준 수식이 정의되는 점 {g['at']} 에서 작동 — 정상 입력에서 nan·예외를 낼 수 있음"
                           " (연구자 확인 필요)"]
            return res
        diff = code_k - ref_k
        proven = sp.expand(diff) == 0 or sp.simplify(diff) == 0
        if not proven:
            # 제곱근 형태: 둘 다 0 이상이면 제곱이 같을 때 같다
            nonneg = all(x.is_nonnegative for x in (code_k, ref_k))
            proven = bool(nonneg and sp.simplify(code_k ** 2 - ref_k ** 2) == 0)
        detail.update(method="symbolic" if proven else "numeric",
                      result="equal" if proven else "no counterexample, not proven", numeric_points=num["tested"])
        res.details.append(detail)
    res.sizes = [d["size"] for d in res.details]
    if all(d["result"] == "equal" for d in res.details):
        res.status = "proven"
    else:
        res.status = "inconclusive"
        res.reasons = ["수치 반례는 없지만 기호로 같음을 증명하지 못함 — 연구자 확인 필요"]
    return res


def reference_key(reference: Reference, binding: dict, conditions: dict, output=None) -> str:
    """재사용 키 — 기준 수식(정규화) · 변수 뜻 · binding · 적용 조건 · 검사기 버전이 모두 같을 때만 같다."""
    expr = sp.srepr(parse_reference(reference))
    payload = {"eq_id": reference.eq_id, "expr": expr, "variables": dict(sorted(reference.variables.items())),
               "vectors": dict(sorted(reference.vectors.items())), "assume": reference.assume,
               "binding": dict(sorted(binding.items())), "output": output,
               "conditions": conditions, "checker": CHECKER_VERSION}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
