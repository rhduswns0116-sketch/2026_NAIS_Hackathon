"""앞단(1~3) → 뒷단(4 RECOMPUTE · 5 VALIDATE · 6 AUDIT) 연결. 인계 형식은 measuretrace/backend/contract.py (confirmed-v4.0).

통합(2026-09-30): 승인 코드는 **뒷단 엔진에서 한 번만** 실행한다. 예전에는 앞단 4단계와 뒷단 4-1 이 같은 코드를 두 번 돌리고
교차 확인했다. 항목 목록(Output)은 계산 전에 알 수 없으므로(2-1c 보고 목록에는 n·df·p 가 빠져 있음) 순서는 이렇다.

  run_step4(run_id)                     4 RECOMPUTE — 실행 묶음(RAW·식·설계·기록·3-1 승인 코드, 항목 목록 없음)을 만들어
                                        뒷단 run_discovery 로 한 번 실행. 결과 전부와 메타데이터(id·이름·기호·단위·조건·식)를 기록.
  preview(run_id)                       그 결과로 항목 목록을 만든 전체 묶음을 보여 준다(파일을 쓰지 않음). 화면은 지문을 받아 둔다.
  run(run_id, respondent, bundle_sha256, report=None)
                                        같은 묶음을 다시 만들어 지문이 같을 때만 사용자 승인으로 봉인(seal_approval)하고
                                        뒷단 run_validate_audit 를 실행한다 — 같은 계산 로그에 항목 결합(bind_outputs, 재실행 없음)
                                        → 5-1 보고서 첫 열람 → 5-2 → 5-3 → 6-1 · 6-2. 이미 감사한 실행을 다시 감사하면 4단계를 새로 실행.
  get(run_id)                           저장된 마지막 결과 (다시 실행하지 않음).

바꾸는 규칙 (모두 규칙 — LLM 없음. 화면에 그대로 보여 주고 사람이 승인한다)
  - 데이터: 1-1 에서 RAW 로 분류한 파일. 원본 해시는 1-2 값, 내용 해시는 뒷단 정의로 다시 뜬다(원본 해시가 다르면 거부).
  - 열: 2-1a 헤더 해석(뜻) · 3-3 확정 단위 > 2-3 헤더 단위. 3회 뒤 미확정 E01 열은 unit_status=unresolved.
  - Output: 4단계 탐색 실행이 보고한 결과 목록(id·이름·기호·조건·식·단위). 종류(kind)는 이름·기호 규칙,
    집단은 계획서 설계의 조건 이름, 변화량의 [대상, 기준] 순서는 승인된 식(LaTeX)의 첨자 순서, 지표 용어는 이름에서.
  - 코드: 3-1 승인 본문을 한 글자도 바꾸지 않고 싣고, 뒷단 규약 mt_compute(data, params) → {"outputs", "meta"} 로 옮기는
    어댑터를 붙인다(결과 전부 보고). 어댑터가 붙은 파일의 해시가 인계 코드 해시이고, 승인 본문 해시는 params.front_code_sha256 로
    함께 봉인한다. 실행 묶음과 전체 묶음은 같은 코드·파라미터·RAW 를 만들어 실행 지문(execution_sha256)이 같다.
  - 기록: E02 결정(그대로 진행 → proceed, 재측정·미확정 → unresolved), E03 누락(→ missing), 3회 뒤 미확정 → pending.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import stat
from datetime import datetime
from pathlib import Path

from measuretrace import ledger
from measuretrace.backend.common.hashing import canonical_json, file_fingerprint, sha256_text
from measuretrace.backend.common.units import UnitError, is_dimensionless
from measuretrace.backend.contract import (TEST_NAMES, ApprovedCode, Column, Confirmed, DataFile, Design, Equation,
                                           Flag, Output, Pending, Test)
from measuretrace.confirm.run import EXTRACT_FILES, load_extract
from measuretrace.extract.run import find_snapshot
from measuretrace.ingest import workspace
from measuretrace.paths import OUTPUTS_DIR, PACKAGE_DIR, rel
from measuretrace.recompute.run import _approved_body

STAGE_VERSION = "bridge-v1"
ENTRYPOINT = "mt_compute"
REPORT_SUFFIXES = (".docx", ".pdf", ".txt", ".md")
BRIDGE_CODE = [PACKAGE_DIR / "bridge.py", PACKAGE_DIR / "backend"]
TERM_KINDS = ("value", "difference", "ratio", "percent_change")
CHANGE_KINDS = ("difference", "ratio", "percent_change")
NO_UNIT = {"", "무차원", "dimensionless", "-", "—", "없음", "개", "개수", "count", "ea", "none", "1"}
STAT_WORDS = {"평균", "표준편차", "표준오차", "합동", "중앙값", "분산", "증가율", "감소율", "변화율", "차이", "비율",
              "mean", "average", "sd", "std", "standard", "deviation", "error", "pooled", "median", "difference",
              "ratio", "change", "percent", "rate"}
FILLER = {"조건", "시료", "전체", "두", "최종", "양측", "단측", "수", "값", "및", "of", "the", "per", "condition",
          "sample", "group", "value"}
START, END = "# ==== 3-1 승인 본문 시작 ====\n", "# ==== 3-1 승인 본문 끝 ====\n"

ADAPTER = '''

# ==== 뒷단 규약 어댑터 (bridge 가 자동 생성 — 위 승인 본문은 호출만 한다) ====
# 규약: def mt_compute(data: dict[str, DataFrame], params: dict)
#         -> {"outputs": {결과 id: 숫자}, "steps": [...], "meta": {"results": [...], "intermediate": {...}}}
# 승인 본문의 compute(files) 에는 해시를 확인한 RAW 실행 사본 경로를 {실험 폴더 기준 상대 경로: 사본 경로} 로 넘긴다.
# 4단계 탐색 실행(discover): 결과를 전부 보고한다. 결과 id 는 기호(없으면 이름)로 만들고 겹치면 _2, _3 … 을 붙인다.
# 어떤 결과를 판정에 쓸지는 5·6 직전에 사람이 승인하는 항목 목록이 정한다(뒷단 bind_outputs).
import re as mt_re


def mt_slug(text):
    s = mt_re.sub(r"[^0-9A-Za-z_.-]+", "_", "" if text is None else str(text)).strip("_.-")
    return s if s and s[0].isalnum() else ""


def mt_compute(data, params):
    paths = params["data_paths"]
    files = {}
    for data_id, frame in data.items():
        files[paths[data_id]] = frame.attrs["source_path"]
    result = compute(files)
    outputs, rows, used = {}, [], set()
    for row in result.get("results") or []:
        if not isinstance(row, dict):
            continue
        base = mt_slug(row.get("symbol")) or mt_slug(row.get("name")) or "r"
        oid, k = base, 2
        while oid in used:
            oid = base + "_" + str(k)
            k += 1
        used.add(oid)
        outputs[oid] = row.get("value")
        rows.append({"id": oid, "name": row.get("name"), "symbol": row.get("symbol"), "unit": row.get("unit"),
                     "condition": row.get("condition"), "eq_id": row.get("eq_id")})
    steps = []
    for name, value in (result.get("intermediate") or {}).items():
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            steps.append({"name": str(name), "value": value})
        elif isinstance(value, dict):
            for sub, x in list(value.items())[:200]:
                if isinstance(x, (int, float)) and not isinstance(x, bool):
                    steps.append({"name": str(name) + "." + str(sub), "value": x})
    return {"outputs": outputs, "steps": steps,
            "meta": {"results": rows, "intermediate": result.get("intermediate") or {}}}
'''


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _slug(text: str) -> str:
    s = re.sub(r"[^0-9A-Za-z_.-]+", "_", text or "").strip("_.-")
    return s if s and s[0].isalnum() else ""


def result_key(r: dict) -> str:
    return "\x1f".join("" if r.get(k) is None else str(r.get(k)) for k in ("name", "symbol", "condition", "eq_id"))


def _paths(run_id: str) -> dict:
    snap = find_snapshot(run_id)
    base = snap.parent
    project = json.loads(snap.read_text(encoding="utf-8"))["project"]
    return {"snapshot": snap, "base": base, "handoff": base / "handoff", "audit": base / "audit",
            "view": base / "audit" / "audit_view.json", "out_root": OUTPUTS_DIR / "_backend" / project}


def _read(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


# ── 규칙 ─────────────────────────────────────────────────────────────────
_DESCRIPTIVE = re.compile(r"평균|최솟값|최댓값|최소|최대|중앙값|표준|계수|절편|결정|"
                          r"mean|average|min|max|median|coefficient|intercept|slope", re.I)


def output_kind(r: dict, n_groups: int = 2) -> str:
    name = (r.get("name") or "").lower()
    sym = (r.get("symbol") or "").strip().lower()
    unit = (r.get("unit") or "").strip()
    if sym in ("p", "p_value", "pvalue") or re.search(r"p\s*값|p-?value", name):
        return "p_value"
    if sym in ("df", "dof", "nu", "ν") or "자유도" in name or "degrees of freedom" in name:
        return "df"
    if re.fullmatch(r"n(_\w+)?", sym) or re.search(r"시료\s*수|표본\s*수|sample size", name):
        return "n"
    if sym in ("t", "f", "t_stat", "f_stat") or "통계량" in name or "statistic" in name:
        return "test_statistic"
    if re.search(r"증가율|감소율|변화율|percent change|% change", name) or \
            (unit == "%" and re.search(r"변화|증가|감소|change", name)):
        return "percent_change"
    if re.search(r"차이|difference", name):
        return "difference"
    # ratio 는 두 조건 사이의 비. '교란 비율 평균'·'교란 비율 이차 회귀 계수'처럼 변수 이름에 '비율'이 든
    # 기술통계·회귀 결과나, 집단이 둘 미만인 설계의 결과는 값(value)이다.
    if re.search(r"비율|ratio", name) and unit != "%" and n_groups >= 2 and not _DESCRIPTIVE.search(name):
        return "ratio"
    return "value"


def output_unit(u: str | None) -> str | None:
    u = (u or "").strip()
    return None if u.lower() in NO_UNIT else u


def _overlapping(conditions: list[dict]) -> bool:
    """두 조건 이상이 같은 시료 이름을 가지는가 (집단이라면 시료가 서로 겹치지 않는다)."""
    seen: set[str] = set()
    for c in conditions:
        s = {str(x).strip().lower() for x in c.get("samples") or []}
        if s & seen:
            return True
        seen |= s
    return False


def condition_group(cond: str | None, conditions: list[dict]) -> str | None:
    if not cond:
        return None
    c = cond.strip()
    for x in conditions:
        if c.lower() in (x["name"].lower(), (x.get("label") or "").lower()):
            return x["name"]
    for x in conditions:
        if re.search(r"\(\s*%s\s*\)" % re.escape(x["name"]), c):
            return x["name"]
    return None


def missing_group(m: dict, conditions: list[dict]) -> str | None:
    """2-4 누락의 조건(라벨일 수 있음, 예: '어닐링 (A)')을 설계 집단 이름(예: 'annealed')으로 — 못 찾으면 시료로 찾음."""
    grp = condition_group(m.get("condition"), conditions)
    if grp is None and m.get("sample"):
        s = str(m["sample"]).strip().lower()
        grp = next((c["name"] for c in conditions
                    if s in {str(v).strip().lower() for v in c.get("samples") or []}), None)
    return grp


def missing_applies(m: dict, out_groups: list[str], conditions: list[dict]) -> bool:
    """이 누락(E03)이 이 집단들의 재계산 항목에 걸리는가. 집단을 못 찾은 누락은 모든 항목에 건다(빠뜨리는 것보다 안전)."""
    if not m.get("condition") or not out_groups:
        return True
    grp = missing_group(m, conditions)
    return grp is None or grp in out_groups


def change_order(latex: str | None, names: list[str]) -> list[str]:
    """변화량 식의 [대상, 기준] — 식에 두 집단 첨자가 나오는 순서 (예: (G_A − G_C)/G_C → [A, C])."""
    found = []
    for m in re.finditer(r"_\{?\s*([A-Za-z0-9]+)\s*\}?", latex or ""):
        if m.group(1) in names and m.group(1) not in found:
            found.append(m.group(1))
    return found if len(names) == 2 and len(found) == 2 else []


def _tokens(name: str) -> list[str]:
    return [t for t in re.split(r"[\s,()/\[\]·_\-]+", name or "") if t and not t.isdigit()]


def metric_terms(name: str) -> tuple[list[str], list[str]]:
    toks = _tokens(name)
    metric = [t for t in toks if t.lower() not in STAT_WORDS and t.lower() not in FILLER and len(t) >= 2]
    stats = [t for t in toks if t.lower() in STAT_WORDS]
    return metric, stats


def test_name(method: str) -> str:
    m = (method or "").lower()
    if "대응" in m or "paired" in m:
        return "paired_t"
    if "welch" in m:
        return "welch_t"
    if "anova" in m or "분산분석" in m:
        return "one_way_anova"
    if "일표본" in m or "단일 표본" in m or "one-sample" in m or "one sample" in m:
        return "one_sample_t"
    if re.search(r"(?<![a-z])t(?![a-z])|t-?test|student", m):   # "t 검정", "2표본 t", "t-test"
        return "student_t"
    return "other"


# ── 인계 묶음 만들기 ─────────────────────────────────────────────────────
def _assemble(run_id: str, results: list[dict] | None) -> dict:
    """인계 묶음(Confirmed, 봉인 전)과 부가 정보. 파일을 쓰지 않는다.

    results=None  4단계 실행 묶음 — RAW·식·설계·기록·코드. 항목 목록·검정은 없다(탐색 실행 뒤에 정함).
    results=[..]  5·6 전체 묶음 — 탐색 실행이 보고한 결과 메타데이터(id·이름·기호·단위·조건·식)로 항목 목록을 만든다.
    두 경우 모두 같은 RAW·코드·파라미터를 만들어 실행 지문(execution_sha256)이 같다.
    """
    p = _paths(run_id)
    base = p["base"]
    snap = _read(p["snapshot"])
    conf_path = base / "confirm" / "confirmed.json"
    state_path = base / "confirm" / "confirm_state.json"
    if not conf_path.exists():
        raise ValueError("3 CONFIRM 이 끝나지 않음 — confirmed.json 이 없음")
    front = _read(conf_path)
    state = _read(state_path)
    no_code = not front.get("code")   # 3-1 미확정·거부 — 계산은 막힌 채 기록하고 5·6 에서 모든 수치 주장 E06(미확정)
    # 3 CONFIRM 확정 뒤 2 EXTRACT 결과가 바뀌면 확정 내용과 실행 입력이 어긋난다 (앞단 B11 검사를 이쪽으로 옮김)
    drift = [n for n, h in (front.get("extract_hashes") or {}).items()
             if n != "summary" and (not (base / "extract" / EXTRACT_FILES[n]).exists()
                                    or hashlib.sha256((base / "extract" / EXTRACT_FILES[n]).read_bytes()).hexdigest() != h)]
    if drift:
        raise ValueError(f"3 CONFIRM 확정 뒤 2 EXTRACT 결과가 바뀜: {drift} — 다시 확인 필요")
    ex = load_extract(base / "extract")
    plan = ((ex.get("plan") or {}).get("analysis")) or {}
    items = state.get("items", [])
    by_id = {i["id"]: i for i in items}
    warnings: list[str] = []

    # 데이터 · 열
    input_root = (workspace.run_dir(run_id) / "data").resolve()
    raw_files = [f for f in snap["files"] if f["zone"] == "data" and f["category"] == "raw"]
    if not raw_files:
        raise ValueError("RAW 로 분류된 파일이 없음")
    header_cols = {}
    group_of = {}
    for g in (ex.get("headers") or {}).get("groups", []):
        for path in g.get("files", []):
            group_of[path] = g["group_id"]
        for c in ((g.get("analysis") or {}).get("columns") or []):
            header_cols[(g["group_id"], c["name"])] = c
    check_units = {c["column"]: c.get("unit") for c in (ex.get("checks") or {}).get("columns", [])}
    confirmed_units = (state.get("overrides") or {}).get("units", {})
    decimal_comma = set((ex.get("checks") or {}).get("decimal_comma_files", []))
    used_ids, data, id_of = set(), [], {}
    for f in raw_files:
        did = _slug(Path(f["path"]).with_suffix("").as_posix()) or f"raw{len(data) + 1}"
        while did in used_ids:
            did += "_"
        used_ids.add(did)
        id_of[f["path"]] = did
        fp = file_fingerprint(input_root / f["path"])
        if fp["sha256"] != f["sha256"]:
            raise ValueError(f"RAW {f['path']} 가 1 INGEST 이후 바뀜 — 1단계부터 새 실행")
        content = f.get("content") or {}
        table = content.get("table") or {}
        read = {}
        if table.get("delimiter") and table["delimiter"] not in (",", None):
            read["sep"] = table["delimiter"]
        enc = (content.get("encoding") or "").lower()
        if enc and enc not in ("utf-8", "utf-8-sig", "utf8", "ascii"):
            read["encoding"] = content["encoding"]
        if f["path"] in decimal_comma:
            read["decimal"] = ","
        columns = {}
        for col in table.get("columns") or []:
            h = header_cols.get((group_of.get(f["path"]), col)) or {}
            meaning = " — ".join(x for x in (h.get("quantity"), h.get("meaning")) if x) or col
            unit = confirmed_units.get(col) or check_units.get(col) or h.get("unit_in_header") or None
            unresolved = by_id.get(f"3-3:unit:{col}", {}).get("status") == "unresolved"
            columns[col] = Column(meaning=meaning, unit=unit, unit_status="unresolved" if unresolved else "approved")
        data.append(DataFile(id=did, path=f["path"], sha256=fp["sha256"], content_hash=fp["content_hash"],
                             read=read, columns=columns))

    # 식
    eq_list = (ex.get("equations") or {}).get("equations", [])
    equations = [Equation(id=e["id"], latex=e.get("latex") or "", context=e.get("sentence") or "",
                          eq_hash=e.get("omml_sha256") or "") for e in eq_list]
    eq_ids = {e.id for e in equations}
    latex_of = {e.id: e.latex for e in equations}

    # 설계
    d = plan.get("design") or {}
    conditions = [c for c in d.get("conditions", []) if c.get("name")]
    if _overlapping(conditions):
        # 조건들이 같은 시료를 나눠 가지면 집단(서로 겹치지 않는 독립 단위 묶음)이 아니다 — 연속 변수(NEP·교란 비율)를
        # 조건으로 적은 경우. 2-4 가 계획서에서 하나하나 풀어 적은 시료 목록이 겹치지 않으면 그것을 집단으로 쓴다.
        required = [c for c in (((ex.get("missing") or {}).get("required") or {}).get("conditions") or [])
                    if c.get("name") and c.get("samples")]
        warnings.append(f"설계 조건 {[c['name'] for c in conditions]} 이 같은 시료를 공유해 집단으로 보지 않음 — "
                        + (f"2-4 시료 목록의 조건 {[c['name'] for c in required]} 을 집단으로 씀"
                           if required and not _overlapping(required) else "집단 없이 인계 (n 은 설계와 대조하지 못함)"))
        conditions = required if required and not _overlapping(required) else []
    groups = {c["name"]: len(c.get("samples") or []) for c in conditions if c.get("samples")}
    names = list(groups)
    rpu = d.get("replicates_per_unit")
    design = Design(independent_unit=d.get("independent_unit") or "", groups=groups,
                    replicates_per_unit=rpu if isinstance(rpu, int) and not isinstance(rpu, bool) and rpu > 0 else None)

    # 의존 열 — 매칭표에서 그 식을 쓰는 데이터 열
    cols_for_eq: dict[str, set] = {}
    for row in plan.get("matching", []):
        for e in row.get("eq_ids", []):
            cols_for_eq.setdefault(e, set()).update(row.get("data_columns", []))
    e03 = [x for x in ((front.get("missing") or {}).get("e03") or [])]
    # 장비 사양서가 없으면 E02 범위 판정만 잠정이 된다(2-2) — 재계산 값의 의존으로 걸지 않고 기록으로만 남긴다
    spec_missing = [m for m in e03 if m.get("kind") == "필요 문서 없음"
                    and (m.get("doc_kind") == "spec" or str(m.get("detail", "")).endswith("(spec)"))]
    if spec_missing:
        warnings.append(f"E03 사양서 누락 {len(spec_missing)}건은 재계산 항목의 의존으로 걸지 않음 (E02 범위 판정만 잠정) — "
                        + "; ".join(str(m.get("detail")) for m in spec_missing))

    def item_ref(x: dict) -> str:
        if x.get("condition") and x.get("sample"):
            return f"item:{x['condition']}/{x['sample']}"
        return "item:" + (_slug(f"{x.get('kind', '')}_{x.get('detail', '')}") or "missing")

    # Output — 4단계 탐색 실행이 보고한 결과 목록 (실행 묶음이면 비어 있음)
    results = results or []
    rows, seen_keys = [], set()
    for r in results:
        key = result_key(r)
        if key in seen_keys:
            warnings.append(f"결과 '{r.get('name')}' ({r.get('condition')}) 가 같은 이름·기호·조건·식으로 두 번 나와 첫 값만 인계")
            continue
        seen_keys.add(key)
        kind = output_kind(r, len(groups))
        grp = condition_group(r.get("condition"), conditions)
        if r.get("condition") and grp is None:
            warnings.append(f"결과 '{r.get('name')}' 의 조건 '{r.get('condition')}' 을 설계의 조건({', '.join(names) or '없음'})과 연결하지 못함")
        rows.append({"r": r, "key": key, "kind": kind, "group": grp})
    ids_used = set()
    outputs, keymap, table = [], {}, []
    unit_names: dict[str, set] = {}
    for x in rows:
        metric, _ = metric_terms(x["r"].get("name") or "")
        if metric and x["kind"] in TERM_KINDS:
            unit_names.setdefault(output_unit(x["r"].get("unit")) or "", set()).update(metric)
    for i, x in enumerate(rows, 1):
        r, kind, grp = x["r"], x["kind"], x["group"]
        oid = r.get("id")   # 탐색 실행의 어댑터가 붙인 결과 id — 값은 같은 id 로 계산 로그에 있다
        if not oid or oid in ids_used:
            raise ValueError(f"탐색 실행 결과 id 가 없거나 겹침: {oid!r}")
        ids_used.add(oid)
        unit = output_unit(r.get("unit"))
        try:
            is_dimensionless(unit)
        except UnitError:
            if re.fullmatch(r"[\s가-힣]+", re.sub(r"\([^()]*\)", "", unit or "")):
                # '모형 단위'·'비율(0~1)'처럼 한글 낱말(+괄호 설명)뿐인 표기는 단위 기호가 아니라 설명이다
                # (회귀 계수 등 파생 단위를 코드가 적지 않았거나, 무차원 비율에 범위를 적은 경우)
                warnings.append(f"{oid}: 단위 '{unit}' 는 단위 기호가 아닌 설명이라 단위 없이 인계 — 단위 없는 보고값과 수치만 비교")
                unit = None
            else:
                warnings.append(f"{oid}: 단위 '{unit}' 를 해석할 수 없음 — 보고값과 환산하지 못해 E01 이 날 수 있음")
        eq = r.get("eq_id") if r.get("eq_id") in eq_ids else None
        if r.get("eq_id") and not eq:
            warnings.append(f"{oid}: 식 {r.get('eq_id')} 가 계획서 식 목록에 없음")
        if grp:
            out_groups, group_note = [grp], "결과의 조건"
        elif kind in CHANGE_KINDS:
            out_groups = change_order(latex_of.get(eq), names)
            group_note = "식 첨자 순서 [대상, 기준]" if out_groups else "정하지 못함 — 방향은 보고 표현으로만 비교"
        elif kind in ("test_statistic", "p_value", "df"):
            out_groups, group_note = list(names), "검정 집단"
        else:
            out_groups, group_note = [], ""
        terms = []
        if kind in TERM_KINDS:
            metric, stats = metric_terms(r.get("name") or "")
            terms = metric or (stats + sorted(unit_names.get(unit or "", set())))
            terms = list(dict.fromkeys(terms))
        cols = cols_for_eq.get(eq or "", set())
        deps = []
        for f in raw_files:
            did = id_of[f["path"]]
            fcols = [c for c in sorted(cols) if c in next(dd for dd in data if dd.id == did).columns]
            deps += [f"{did}#{c}" for c in fcols] if fcols else [did]
        for m in e03:
            if m in spec_missing:
                continue
            if missing_applies(m, out_groups, conditions):
                deps.append(item_ref(m))
        desc = (r.get("name") or oid) + (f" — 조건 {r['condition']}" if r.get("condition") else "") \
            + (f" (식 {eq})" if eq else "")
        if kind in CHANGE_KINDS and len(out_groups) == 2:
            desc += f" [대상 {out_groups[0]} − 기준 {out_groups[1]}]"
        outputs.append(Output(id=oid, description=desc, kind=kind, unit=unit, equations=[eq] if eq else [],
                              depends_on=list(dict.fromkeys(deps)), groups=out_groups, terms=terms))
        keymap[x["key"]] = oid
        table.append({"id": oid, "name": r.get("name"), "symbol": r.get("symbol"), "condition": r.get("condition"),
                      "kind": kind, "unit": unit, "front_unit": r.get("unit"), "groups": out_groups,
                      "group_note": group_note, "equation": eq, "terms": terms,
                      "depends_on": f"{len(deps)}개 ({', '.join(sorted({dd.split('#')[1] for dd in deps if '#' in dd})) or '파일 전체'})"})

    # 검정
    t = plan.get("test") or {}
    if t.get("present") and results:   # 검정은 항목(p·t·df)을 가리키므로 전체 묶음에서만
        def first(k):
            return next((o.id for o in outputs if o.kind == k), None)
        alpha = t.get("alpha")
        design.tests.append(Test(id="T1", name=test_name(t.get("method", "")), groups=list(names),
                                 alpha=alpha if isinstance(alpha, (int, float)) and 0 < alpha < 1 else 0.05,
                                 p_output=first("p_value"), stat_output=first("test_statistic"), df_output=first("df"),
                                 description=" · ".join(x for x in (t.get("method"), t.get("alternative")) if x)))
        if design.tests[0].name == "other":
            warnings.append(f"검정 방법 '{t.get('method')}' 을 {TEST_NAMES[:-1]} 중 하나로 정하지 못해 'other' 로 둠")

    # 기록 (E02 · E03)
    flags = []
    for it in items:
        if it["kind"] != "anomaly":
            continue
        prop, ans = it["proposal"], it.get("answer") or {}
        did = id_of.get(prop.get("file"))
        if did is None:
            continue
        decision = "proceed" if it["status"] == "decided" else "unresolved"
        detail = f"{prop.get('kind')} {prop.get('count')}건" + (" — 재측정 결정" if it["status"] == "remeasure" else "")
        flags.append(Flag(code="E02", target=f"{did}#{prop.get('column')}", detail=detail, decision=decision,
                          location={"file": prop.get("file"), "column": prop.get("column"),
                                    "rows": ",".join(str(x.get("line")) for x in (prop.get("rows") or [])[:20])},
                          decided_by=ans.get("respondent") or "", decided_at=ans.get("at") or ""))
    miss_item = by_id.get("3-1:missing") or {}
    for m in e03:
        flags.append(Flag(code="E03", target=item_ref(m),
                          detail=" ".join(str(x) for x in (m.get("kind"), m.get("condition"), m.get("sample"), m.get("detail")) if x),
                          decision="missing", location={k: m[k] for k in ("file",) if m.get(k)},
                          decided_by=(miss_item.get("answer") or {}).get("respondent") or "",
                          decided_at=(miss_item.get("answer") or {}).get("at") or ""))

    # 미확정 (3회 뒤)
    pending = []
    test_outs = [o.id for o in outputs if o.kind in ("p_value", "test_statistic", "df", "n")]
    for it in items:
        if it["status"] != "unresolved":
            continue
        k = it["kind"]
        if k == "equation":
            pending.append(Pending(target=f"eq:{it['id'].split(':')[-1]}", what=it["title"]))
        elif k in ("code", "plan_missing", "processing", "matching"):
            pending.append(Pending(target="code", what=it["title"]))
        elif k in ("design", "test"):
            pending += [Pending(target=o, what=it["title"]) for o in test_outs]
        elif k in ("spec", "overflow"):
            warnings.append(f"장비 사양 '{it['title']}' 이 미확정 — E02 범위 판정이 잠정인 채로 인계")

    # 코드 — 승인 본문 + 어댑터
    if no_code:
        # 계산하지 않는다: 코드 자리는 비워 두고 'code' 미확정으로 인계 → 4단계는 막힌 채 기록(블라인드 입증용 계산 로그),
        # 5·6 은 항목 없이 결합해 모든 수치 주장을 E06(미확정)으로 판정
        if not any(x.target == "code" for x in pending):
            pending.append(Pending(target="code", what="3-1 에서 계산 코드를 승인하지 않음(미확정·거부)"))
        warnings.append("승인된 계산 코드가 없음 — 재계산하지 않고, 5·6 에서 보고서의 모든 수치 주장은 E06(미확정)")
        code = ApprovedCode(path="", sha256="", entrypoint=ENTRYPOINT,
                            params={"data_paths": {dd.id: dd.path for dd in data}, "front_code_sha256": "",
                                    "front_code_approved_by": "", "front_code_approved_at": ""},
                            llm_drafted=True)
        rounds = state.get("round") or 1
        c = Confirmed(project_id=snap["project"], input_root=str(input_root), data=data, code=code, outputs=[],
                      equations=equations, design=design, flags=flags, pending=pending,
                      confirm_rounds=min(max(int(rounds), 1), 3))
        reports = [f["path"] for f in snap["files"] if f["zone"] == "report"
                   and Path(f["path"]).suffix.lower() in REPORT_SUFFIXES]
        return {"confirmed": c, "code_text": None, "table": [], "warnings": warnings, "reports": reports,
                "front": front, "base": base}
    body = _approved_body(base / "confirm" / "approved_code.py")
    body_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
    if body_sha != front["code"]["sha256"]:
        raise ValueError(f"승인 코드 파일이 3-1 승인 뒤 바뀜 ({body_sha[:12]} ≠ {front['code']['sha256'][:12]})")
    wrapped = (f"# MeasureTrace 인계 코드 ({STAGE_VERSION}) — 3-1 승인 본문(sha256 {body_sha}) + 뒷단 규약 어댑터\n"
               f"# 승인 본문: {front['code'].get('approved_by')} · {front['code'].get('approved_at')}\n\n"
               + START + body.rstrip("\n") + "\n" + END + ADAPTER)
    embedded = wrapped.split(START, 1)[1].rsplit(END, 1)[0]
    if hashlib.sha256(embedded.rstrip("\n").encode("utf-8")).hexdigest() != \
            hashlib.sha256(body.rstrip("\n").encode("utf-8")).hexdigest():
        raise ValueError("인계 코드에 실은 승인 본문이 원본과 다름")
    code = ApprovedCode(path="approved_code_v4.py", sha256=hashlib.sha256(wrapped.encode("utf-8")).hexdigest(),
                        entrypoint=ENTRYPOINT,
                        params={"data_paths": {dd.id: dd.path for dd in data}, "front_code_sha256": body_sha,
                                "front_code_approved_by": front["code"].get("approved_by") or "",
                                "front_code_approved_at": front["code"].get("approved_at") or ""},
                        llm_drafted=True)
    rounds = state.get("round") or 1
    c = Confirmed(project_id=snap["project"], input_root=str(input_root), data=data, code=code, outputs=outputs,
                  equations=equations, design=design, flags=flags, pending=pending,
                  confirm_rounds=min(max(int(rounds), 1), 3))
    reports = [f["path"] for f in snap["files"] if f["zone"] == "report"
               and Path(f["path"]).suffix.lower() in REPORT_SUFFIXES]
    return {"confirmed": c, "code_text": wrapped, "table": table, "warnings": warnings, "reports": reports,
            "front": front, "base": base}


def build_exec(run_id: str) -> dict:
    """4단계 실행 묶음. 실행 승인은 3-1 코드 승인이다 — 승인자·시각을 그대로 옮기고 묶음 지문으로 잠근다."""
    b = _assemble(run_id, None)
    c, code = b["confirmed"], b["front"]["code"] or {}   # 코드가 없으면 승인자도 없음 → 뒷단이 실행을 막는다
    c.code.approved_by = code.get("approved_by") or ""
    c.code.approved_at = code.get("approved_at") or ""
    c.code.approval_hash = bundle_sha(c)
    return b


def _step4(run_id: str) -> dict | None:
    p = _paths(run_id)
    path = p["base"] / "recompute" / "backend_run.json"
    return _read(path) if path.exists() else None


def discovery_rows(calc: dict) -> list[dict]:
    """탐색 실행 계산 로그 → 결과 행(id·이름·기호·단위·조건·식·값). 값은 계산 로그의 produced 에서."""
    produced = calc.get("produced") or {}
    rows = []
    for m in ((calc.get("produced_meta") or {}).get("results") or []):
        if isinstance(m, dict) and m.get("id") in produced:
            rows.append({**m, "value": produced[m["id"]]})
    return rows


def _discover_calc(run_id: str) -> tuple[dict, dict]:
    """(4단계 뒷단 실행 기록, 탐색 실행 계산 로그 — 결합 전 판본)."""
    s4 = _step4(run_id)
    if s4 is None:
        raise ValueError("4 RECOMPUTE 를 먼저 실행해야 함 — 승인 코드가 내는 결과 목록으로 재계산 항목을 정함")
    run_dir = _paths(run_id)["out_root"] / "runs" / s4["backend_run_id"]
    path = run_dir / "calc_log_discover.json"
    if not path.exists():
        path = run_dir / "calc_log.json"
    return s4, _read(path)


def build(run_id: str) -> dict:
    """5·6 전체 묶음 — 4단계 탐색 실행 결과로 항목 목록을 만든다. 파일을 쓰지 않는다."""
    s4, calc = _discover_calc(run_id)
    b = _assemble(run_id, discovery_rows(calc))
    # 코드 미확정(승인 코드 없음, 또는 3회 뒤에도 코드·가공·매칭 미확정) — 4단계는 막힌 채 기록, 항목 없이 5·6 (모두 E06 미확정)
    code_pending = b["confirmed"].code_pending()
    if code_pending and calc.get("status") != "blocked":
        raise ValueError("계산 코드가 미확정인데 4 RECOMPUTE 기록이 막힘(blocked) 상태가 아님 — 4 RECOMPUTE 를 다시 실행")
    if code_pending:
        b["confirmed"].outputs, b["confirmed"].design.tests, b["table"] = [], [], []
        if b["code_text"] is not None:
            b["warnings"].append("계산 코드가 3 CONFIRM 에서 미확정(코드·가공·매칭) — 4단계는 계산하지 않았고, "
                                 "5·6 에서 보고서의 모든 수치 주장은 E06(미확정)")
    elif (calc.get("status") not in ("ok", "partial") or not calc.get("produced")):
        raise ValueError(f"4 RECOMPUTE 가 성공하지 않음(상태 {calc.get('status')}) — 결과 목록이 없어 인계할 수 없음")
    if b["confirmed"].execution_sha256() != calc.get("execution_sha256"):
        raise ValueError("4 RECOMPUTE 이후 RAW·코드·확정 기록이 바뀜 — 4 RECOMPUTE 를 다시 실행")
    b["step4"] = s4
    return b


def bundle_sha(c: Confirmed) -> str:
    return sha256_text(canonical_json(c.approval_payload()))


def preview(run_id: str) -> dict:
    b = build(run_id)
    c = b["confirmed"]
    return {"stage": "인계 (3 → 5·6)", "stage_version": STAGE_VERSION, "run_id": run_id,
            "bundle_sha256": bundle_sha(c), "problems": c.problems(), "approval_problems_before_seal":
            [x for x in c.approval_problems(allow_code_pending=c.code_pending()) if "승인자" not in x],
            "no_code": c.code_pending(),
            "blocked_dependencies": c.unconfirmed_dependencies(), "warnings": b["warnings"], "reports": b["reports"],
            "outputs": b["table"], "design": {"independent_unit": c.design.independent_unit, "groups": c.design.groups,
                                              "replicates_per_unit": c.design.replicates_per_unit},
            "tests": [t.__dict__ for t in c.design.tests],
            "flags": [f.__dict__ for f in c.flags], "pending": [p.__dict__ for p in c.pending],
            "data_count": len(c.data), "equations": [e.id for e in c.equations],
            "code": {"sha256": c.code.sha256, "front_code_sha256": c.code.params["front_code_sha256"],
                     "front_approved_by": c.code.params["front_code_approved_by"], "entrypoint": c.code.entrypoint},
            "llm": _llm_status()}


def _llm_status() -> dict:
    from measuretrace.llm import _settings
    key, model, source = _settings()
    offline = os.environ.get("MEASURETRACE_OFFLINE") == "1"
    return {"available": bool(key) or offline, "model": model, "offline": offline, "key_source": source or None}


def _client():
    from measuretrace.backend.common.llm import OfflineClient
    from measuretrace.llm import _settings
    key, model, _ = _settings()
    if os.environ.get("MEASURETRACE_OFFLINE") == "1":
        return OfflineClient(), model
    if not key:
        return None, model
    import anthropic
    return anthropic.Anthropic(api_key=key, max_retries=3, timeout=600), model


def run_step4(run_id: str) -> dict:
    """4 RECOMPUTE — 실행 묶음을 만들어 뒷단 엔진으로 승인 코드를 **한 번** 실행한다(탐색 실행).

    확인이 실패하면(승인 코드 변경·추출 결과 변경·RAW 변경·정적 점검 위반) ValueError — 실행하지 않는다.
    반환: {calc(뒷단 계산 로그), rows(결과 행), checks, backend_run_id, handoff}
    """
    from measuretrace.backend.pipeline import new_run_id, run_discovery
    from measuretrace.backend.recompute import RecomputeError
    from measuretrace.backend.recompute._runner import static_violations
    p = _paths(run_id)
    b = build_exec(run_id)      # 승인 코드 해시 · 추출 결과 · RAW 해시를 여기서 확인 (어긋나면 ValueError)
    c = b["confirmed"]
    no_code = b["code_text"] is None
    checks = [{"check": "3-1 승인 본문 해시", "ok": not no_code,
               "problems": ["승인된 계산 코드가 없음(3-1 미확정·거부) — 계산하지 않고 막힌 채 기록"] if no_code else []},
              {"check": "추출 결과가 확정 때와 같음", "ok": True},
              {"check": "RAW 사본이 1단계 해시와 같음", "ok": True}]
    if not no_code:
        problems = static_violations(b["code_text"])
        checks.append({"check": "정적 점검 (뒷단 격리 실행 규칙)", "ok": not problems, "problems": problems})
        if problems:
            raise ValueError("정적 점검에서 금지 항목 발견: " + "; ".join(problems[:5]))
    backend_run = new_run_id()
    hdir = p["handoff"] / backend_run
    hdir.mkdir(parents=True, exist_ok=False)
    if not no_code:
        code_path = hdir / c.code.path
        code_path.write_text(b["code_text"], encoding="utf-8", newline="\n")
        os.chmod(code_path, stat.S_IREAD)
        if hashlib.sha256(code_path.read_bytes()).hexdigest() != c.code.sha256:
            raise ValueError("인계 코드 파일을 쓴 뒤 해시가 달라짐")
    c.base_dir = str(hdir)
    c.save(hdir / "confirmed_exec.json")
    try:
        calc = run_discovery(c, p["out_root"], backend_run)
    except RecomputeError as e:
        raise ValueError(f"{type(e).__name__}: {e}") from e
    ran = calc.get("status") in ("ok", "partial")
    checks.append({"check": "뒷단 실행 확인 (승인·해시·미확정 없음·격리 실행)", "ok": ran,
                   "problems": [] if ran else [calc.get("error") or calc.get("status")]})
    (p["base"] / "recompute").mkdir(exist_ok=True)
    (p["base"] / "recompute" / "backend_run.json").write_text(json.dumps(
        {"backend_run_id": backend_run, "handoff_dir": str(hdir), "at": _now(), "status": calc.get("status"),
         "execution_sha256": calc.get("execution_sha256"), "calc_log": rel(p["out_root"] / "runs" / backend_run
                                                                            / "calc_log.json")},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return {"calc": calc, "rows": discovery_rows(calc), "checks": checks, "backend_run_id": backend_run,
            "handoff": rel(hdir / "confirmed_exec.json"), "warnings": b["warnings"]}


def run(run_id: str, respondent: str, bundle_sha256: str, report: str | None = None,
        client=None, model: str | None = None) -> dict:
    """사람이 본 항목 묶음(bundle_sha256)을 봉인하고, 4단계 실행에 결합해 5→6 을 실행한다(재계산 없음).

    이미 감사한 4단계 실행을 다시 감사하면 4단계를 새로 실행한다 — 한 뒷단 실행 = 계산 한 번 + 감사 한 번.
    """
    from measuretrace.backend.pipeline import run_validate_audit
    from measuretrace.backend.recompute import RecomputeError
    from measuretrace.backend.validate import BlindnessError
    respondent = (respondent or "").strip()
    if not respondent:
        raise ValueError("승인자 이름이 필요함")
    p = _paths(run_id)
    s4 = _step4(run_id)
    if s4 is None:
        raise ValueError("4 RECOMPUTE 를 먼저 실행해야 함")
    step_dir = p["out_root"] / "runs" / s4["backend_run_id"]
    reaudit = (step_dir / "blind_log.json").exists() or (step_dir / "calc_log_discover.json").exists()
    if reaudit:
        from measuretrace.recompute.run import run_recompute as rerun_step4
        again = rerun_step4(run_id)
        if again.get("status") != "ok":
            raise ValueError(f"다시 감사하려고 4 RECOMPUTE 를 새로 실행했지만 실패함: {again.get('reason')}")
    b = build(run_id)
    s4 = b["step4"]
    c = b["confirmed"]
    if bundle_sha(c) != bundle_sha256:
        raise ValueError("미리보기 이후 인계 내용이 바뀜 — 화면을 새로 고쳐 다시 확인한 뒤 승인")
    if c.problems():
        raise ValueError("인계 형식 문제: " + "; ".join(c.problems()))
    if not b["reports"]:
        raise ValueError("최종 보고서 초안(docx·pdf·txt·md)이 없음 — 1단계 '최종 보고서 초안' 칸에 넣은 실행이어야 함")
    report = report or b["reports"][0]
    if report not in b["reports"]:
        raise ValueError(f"보고서 {report!r} 는 이 실행의 보고서가 아님")
    report_path = workspace.run_dir(run_id) / "report" / report
    # 1 INGEST 가 기록한 해시와 대조 — 같은 실행에 다른 보고서가 들어가지 않게 (RAW 는 _assemble 에서 대조)
    ingest_sha = next((f.get("sha256") for f in _read(p["snapshot"])["files"]
                       if f["zone"] == "report" and f["path"] == report), None)
    if not ingest_sha:
        raise ValueError(f"보고서 {report!r} 의 1 INGEST 해시 기록이 없음 — 1단계부터 새 실행")
    if not report_path.is_file() or file_fingerprint(report_path)["sha256"] != ingest_sha:
        raise ValueError(f"보고서 {report!r} 가 1 INGEST 이후 바뀜 — 1단계부터 새 실행")

    backend_run = s4["backend_run_id"]
    hdir = Path(s4["handoff_dir"])
    code_path = hdir / c.code.path if c.code.path else None   # 승인 코드가 없으면 파일도 없음(계산 안 함)
    if code_path and (not code_path.is_file() or hashlib.sha256(code_path.read_bytes()).hexdigest() != c.code.sha256):
        raise ValueError("4단계 인계 코드 파일이 없거나 바뀜 — 4 RECOMPUTE 를 다시 실행")
    c.base_dir = str(hdir)
    c.seal_approval(approved_by=respondent)
    conf_path = hdir / "confirmed_v4.json"
    c.save(conf_path)
    if client is None and model is None:
        client, model = _client()
    try:
        result = run_validate_audit(conf_path, report_path, p["out_root"], backend_run, client=client,
                                    model=model or "", previous_run="auto", expected_report_sha256=ingest_sha)
    except (RecomputeError, BlindnessError) as e:
        raise ValueError(f"{type(e).__name__}: {e}") from e

    run_dir = p["out_root"] / "runs" / backend_run
    view = {"stage": "5 VALIDATE · 6 AUDIT", "run_id": run_id, "backend_run_id": backend_run, "at": _now(),
            "approved_by": respondent, "bundle_sha256": bundle_sha256, "report": report,
            "handoff": rel(conf_path), "code_path": rel(code_path) if code_path else None, "backend_run_dir": rel(run_dir),
            "report_md": rel(run_dir / "audit_report.md"), "model": model,
            "execution": {"backend_run_id": backend_run, "executions": 0 if c.code_pending() else 1,
                          "reaudit_new_step4": reaudit,
                          "note": ("계산 코드가 미확정이라 4 RECOMPUTE 는 계산하지 않고 막힌 채 기록 — 5·6 은 항목 없이 "
                                   "보고서 주장을 모두 E06(미확정)으로 판정" if c.code_pending() else
                                   "4 RECOMPUTE 에서 뒷단 엔진이 승인 코드를 한 번 실행 — 5·6 은 같은 계산 로그에 승인된 "
                                   "항목 목록을 결합해 사용(재실행 없음)")},
            "result": result}
    p["audit"].mkdir(exist_ok=True)
    text = json.dumps(view, ensure_ascii=False, indent=2, default=str)
    (p["audit"] / f"audit_view_{backend_run}.json").write_text(text, encoding="utf-8")
    p["view"].write_text(text, encoding="utf-8")
    entry = ledger.record("5·6 VALIDATE·AUDIT", run_id, bundle_sha256, ledger.code_hash(*BRIDGE_CODE),
                          {"backend_run_id": backend_run, "report": report, "approved_by": respondent,
                           "summary": {k: v for k, v in result["summary"].items() if k != "codes"}},
                          [conf_path, run_dir / "audit_result.json"])
    view["lineage"] = entry
    return view


def get(run_id: str) -> dict:
    p = _paths(run_id)
    if not p["view"].exists():
        raise ValueError("아직 5 VALIDATE · 6 AUDIT 를 실행하지 않음")
    return _read(p["view"])
