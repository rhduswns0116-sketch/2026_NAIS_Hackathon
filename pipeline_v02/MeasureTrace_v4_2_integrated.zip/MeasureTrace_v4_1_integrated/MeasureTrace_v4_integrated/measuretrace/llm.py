"""LLM 호출 공통 — 캐시 · 감사 기록(R7) · 구조화 출력(JSON 스키마) · 거절 처리.

  키: 환경 변수 LLM_API_KEY / ANTHROPIC_API_KEY, 없으면 practice_v4/.env → ../mt/.env 의 LLM_API_KEY (값은 출력하지 않음)
  모델: LLM_MODEL_STRONG (없으면 claude-opus-5-5)
  MEASURETRACE_OFFLINE=1 → 캐시만 쓰고 API 는 부르지 않음 (토큰 0)

R2: 이 모듈은 받은 글을 그대로 보낸다 — 측정값을 빼는 것은 부르는 쪽(extract/*)의 책임이다.
같은 (모델, 지시문, 입력, 스키마, effort) 이면 캐시를 쓴다 → 같은 입력에 같은 답 (재현성).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import threading
from datetime import datetime
from pathlib import Path

from measuretrace.paths import OUTPUTS_DIR, ROOT, WORKSPACE

CACHE_DIR = WORKSPACE / "llm_cache"
AUDIT_LOG = OUTPUTS_DIR / "llm_audit.jsonl"
ENV_FILES = [ROOT / ".env", ROOT.parent / "mt" / ".env"]
DEFAULT_MODEL = "claude-opus-5-5"
_lock = threading.Lock()


class LLMError(RuntimeError):
    pass


def _settings() -> tuple[str, str, str]:
    """(키, 모델, 키 출처). 키 값은 어디에도 출력하지 않는다."""
    key = os.environ.get("LLM_API_KEY") or os.environ.get("ANTHROPIC_API_KEY") or ""
    model = os.environ.get("LLM_MODEL_STRONG", "")
    source = "환경 변수" if key else ""
    if not key or not model:
        from dotenv import dotenv_values
        for env in ENV_FILES:
            if env.exists():
                values = dotenv_values(env)
                if not key and values.get("LLM_API_KEY"):
                    key, source = values["LLM_API_KEY"].strip(), env.relative_to(ROOT.parent).as_posix()
                model = model or (values.get("LLM_MODEL_STRONG") or "").strip()
    return key, model or DEFAULT_MODEL, source


def _audit(event: dict) -> None:
    AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps({"ts": datetime.now().astimezone().isoformat(timespec="seconds"), **event}, ensure_ascii=False)
    with _lock, AUDIT_LOG.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _corrupt(data) -> int:
    """출력 문자열 안의 제어 문자 수. 정상 출력에는 탭·줄바꿈 말고는 없다 — 한글이 '\\f'+'f' 로 깨져 온 응답
    (2-1c 코드 초안, 요청 msg_011CfYH2xU6yuhWJPEAUA8pn)을 캐시·승인 화면으로 넘기지 않으려고 본다."""
    if isinstance(data, str):
        return len(_CONTROL.findall(data))
    if isinstance(data, dict):
        return sum(_corrupt(v) for v in data.values())
    if isinstance(data, list):
        return sum(_corrupt(v) for v in data)
    return 0


class LLM:
    """client 를 넘기면 그것을 쓴다(시험용 가짜 클라이언트). 없으면 설정에서 만든다."""

    def __init__(self, client=None, model: str | None = None, offline: bool | None = None):
        key, env_model, self.key_source = _settings()
        self.model = model or env_model
        self.offline = os.environ.get("MEASURETRACE_OFFLINE") == "1" if offline is None else offline
        self.client = client
        if client is None and key and not self.offline:
            import anthropic
            self.client = anthropic.Anthropic(api_key=key, max_retries=3, timeout=600)
        self.stats = {"calls": 0, "cache_hits": 0, "errors": 0, "input_tokens": 0, "output_tokens": 0}

    @property
    def available(self) -> bool:
        return self.client is not None or self.offline

    def status(self) -> dict:
        return {"available": self.available, "model": self.model, "offline": self.offline,
                "key_source": self.key_source or None}

    def json(self, kind: str, system: str, user: str, schema: dict, *, effort: str = "high",
             max_tokens: int = 32000) -> tuple[dict, dict]:
        """구조화 출력 한 번 — (데이터, 메타). 메타에는 캐시 여부·입력 해시·지시문 지문·요청 ID 가 들어간다."""
        prompt_fp = _sha(system + json.dumps(schema, sort_keys=True, ensure_ascii=False))[:16]
        input_sha = _sha(user)[:16]
        key = _sha(json.dumps([self.model, system, user, schema, effort], sort_keys=True, ensure_ascii=False))
        cache = CACHE_DIR / f"{kind}-{key[:24]}.json"
        meta = {"kind": kind, "model": self.model, "effort": effort, "prompt_fingerprint": prompt_fp,
                "input_sha256": input_sha, "cache_file": cache.name}
        if cache.exists():
            stored = json.loads(cache.read_text(encoding="utf-8"))
            if not _corrupt(stored["data"]):
                self.stats["cache_hits"] += 1
                _audit({**meta, "event": "cache_hit", "request_id": stored["meta"].get("request_id")})
                return stored["data"], {**stored["meta"], "cached": True}
            _audit({**meta, "event": "cache_corrupt_ignored", "request_id": stored["meta"].get("request_id")})
        if self.offline or self.client is None:
            _audit({**meta, "event": "skipped", "reason": "오프라인 모드" if self.offline else "API 키 없음"})
            raise LLMError("LLM 을 부를 수 없음 — " + ("오프라인 모드(캐시에 없음)" if self.offline else "API 키 없음"))
        for attempt in (1, 2):   # 깨진 글자로 온 응답만 한 번 다시 부른다
            data, call_meta, text = self._call(meta, system, user, schema, effort, max_tokens)
            bad = _corrupt(data)
            if not bad:
                break
            _audit({**call_meta, "event": "corrupt_text", "control_chars": bad, "attempt": attempt})
        else:
            raise LLMError(f"모델 출력에 깨진 글자(제어 문자 {bad}개)가 있어 두 번 모두 버림 — 다시 실행하세요")
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps({"meta": call_meta, "data": data}, ensure_ascii=False, indent=2), encoding="utf-8")
        _audit({**call_meta, "event": "call", "output_sha256": _sha(text)[:16]})
        return data, {**call_meta, "cached": False}

    def _call(self, meta: dict, system: str, user: str, schema: dict, effort: str,
              max_tokens: int) -> tuple[dict, dict, str]:
        try:
            with self.client.beta.messages.stream(
                model=self.model, max_tokens=max_tokens, system=system,
                messages=[{"role": "user", "content": user}],
                output_config={"effort": effort, "format": {"type": "json_schema", "schema": schema}},
                betas=["server-side-fallback-2026-07-01"], fallbacks="default",
            ) as stream:
                msg = stream.get_final_message()
        except Exception as e:
            self.stats["errors"] += 1
            _audit({**meta, "event": "error", "error": f"{type(e).__name__}: {e}"})
            raise LLMError(f"LLM 호출 실패: {type(e).__name__}: {e}") from e
        usage = getattr(msg, "usage", None)
        call_meta = {**meta, "request_id": getattr(msg, "_request_id", None) or getattr(msg, "id", None),
                     "model_reported": getattr(msg, "model", None), "stop_reason": msg.stop_reason,
                     "input_tokens": getattr(usage, "input_tokens", None), "output_tokens": getattr(usage, "output_tokens", None)}
        self.stats["calls"] += 1
        self.stats["input_tokens"] += call_meta["input_tokens"] or 0
        self.stats["output_tokens"] += call_meta["output_tokens"] or 0
        if msg.stop_reason == "refusal":
            _audit({**call_meta, "event": "refusal"})
            raise LLMError("모델이 요청을 거절함 (refusal)")
        if msg.stop_reason == "max_tokens":
            _audit({**call_meta, "event": "truncated"})
            raise LLMError("출력이 max_tokens 에서 잘림")
        text = next((b.text for b in msg.content if b.type == "text"), None)
        try:
            data = json.loads(text)
        except (TypeError, json.JSONDecodeError) as e:
            _audit({**call_meta, "event": "bad_json"})
            raise LLMError("모델 출력이 JSON 이 아님") from e
        return data, call_meta, text
