"""2-3 데이터 구조화 [PY] — 파이썬만 값을 읽어 단위 누락·모호(E01), 결측·사양 범위 이탈(E02)을 찾는다.

사양(2-2)은 아직 승인 전이므로 범위 이탈은 모두 '잠정'이다(v4 결정 9) — 3-2 에서 사양이 그대로면 확정, 바뀌면 다시 계산.
도구는 어떤 값도 지우거나 제외하지 않는다. 파일·줄·열·값을 보여 줄 뿐이며 결정은 3-3 에서 사람이 한다.
"""
from __future__ import annotations

from pathlib import Path

from measuretrace.extract.tables import MISSING_TOKENS, NUMBER_WITH_UNIT, as_number, read_table
from measuretrace.extract.units import parse_unit, unit_in_header

SKIP_ROLES = {"sample_id", "condition", "replicate"}
MAX_DETAILS_PER_GROUP = 50   # (파일, 열, 종류) 묶음마다 상세는 50건까지 — 건수는 모두 센다


def _norm(s: str) -> str:
    return "".join(s.lower().replace("µ", "u").split())


def _spec_entries(spec_items: list[dict]) -> tuple[list[dict], list[dict]]:
    entries, overflow = [], []
    for item in spec_items:
        a = item.get("analysis") or {}
        for e in a.get("entries", []):
            parsed = parse_unit(e.get("unit") or "")
            if parsed and e.get("max") is not None:
                entries.append({**e, "file": item["file"], "_dim": parsed[0], "_factor": parsed[1]})
        overflow += [{**o, "file": item["file"]} for o in a.get("overflow_values", [])]
    return entries, overflow


def _pick_range(column: str, dim: str, entries: list[dict], plan: dict | None) -> tuple[dict | None, str]:
    same = [e for e in entries if e["_dim"] == dim]
    if not same:
        return None, "같은 차원의 사양 항목 없음 — 범위 비교 안 함"
    hints = [m.get("instrument_range", "") for m in ((plan or {}).get("analysis") or {}).get("matching", [])
             if column in (m.get("data_columns") or []) and m.get("instrument_range")]
    for hint in hints:
        for e in same:
            if _norm(hint) and (_norm(hint) in _norm(e["range_label"]) or _norm(e["range_label"]) in _norm(hint)):
                return e, f"계획서가 정한 범위 '{hint}' ↔ 사양 '{e['range_label']}'"
    widest = max(same, key=lambda e: e["max"] * e["_factor"])
    why = f"계획서의 사용 범위와 맞는 사양 항목이 없어 가장 넓은 범위 '{widest['range_label']}'로 비교" if hints else \
          f"계획서에 사용 범위가 없어 가장 넓은 범위 '{widest['range_label']}'로 비교"
    return widest, why


def check(raw_files: list[tuple[str, Path]], header_groups: list[dict], spec_items: list[dict], plan: dict | None,
          units: dict | None = None) -> dict:
    """units: 3-3 에서 연구자가 확정한 열 단위 {열 이름: 단위} — 헤더 표기보다 우선."""
    units = units or {}
    roles: dict[str, dict] = {}
    for g in header_groups:
        for c in ((g.get("analysis") or {}).get("columns") or []):
            for f in g["files"]:
                roles[f"{f}\0{c['name']}"] = c
    entries, overflow = _spec_entries(spec_items)
    e01: dict[tuple, dict] = {}
    e02: list[dict] = []
    e02_count = {"결측": 0, "숫자가 아닌 값": 0, "사양 범위 밖": 0, "오버플로 표시값": 0}
    columns_info: dict[str, dict] = {}

    group_count: dict[tuple, int] = {}
    decimal_comma_files: set[str] = set()

    def flag(kind: str, **kw) -> None:
        e02_count[kind] += 1
        key = (kw["file"], kw["column"], kind)
        group_count[key] = group_count.get(key, 0) + 1
        if group_count[key] <= MAX_DETAILS_PER_GROUP:
            e02.append({"code": "E02", "kind": kind, "status": "잠정" if kind in ("사양 범위 밖", "오버플로 표시값") else "탐지", **kw})

    for rel, path in raw_files:
        table = read_table(path) if path.suffix.lower() in (".csv", ".tsv", ".txt", ".dat") else None
        if table is None:
            continue
        cols, rows, lines, dc = table["columns"], table["rows"], table["lines"], table["decimal_comma"]
        for c, name in enumerate(cols):
            cells = [r[c] for r in rows]
            present = [x for x in cells if x.lower() not in MISSING_TOKENS]
            numeric = present and sum(as_number(x, dc) is not None for x in present) / len(present) >= 0.5   # 이상값이 섞여도 숫자 열로 본다
            for i, x in enumerate(cells):
                if x.lower() in MISSING_TOKENS:
                    flag("결측", file=rel, line=lines[i], column=name, value=x or "(빈 칸)")
            if not numeric:
                if present and sum(bool(NUMBER_WITH_UNIT.match(x)) for x in present) / len(present) >= 0.5:
                    key = (name, "셀 안에 단위")   # '5.1 nA' 처럼 값마다 단위가 붙음 — 열 단위를 확정해야 비교 가능
                    item = e01.setdefault(key, {"code": "E01", "kind": "셀 안에 단위", "column": name, "header_unit": None,
                                                "suggestion": "", "files": []})
                    item["files"].append(rel)
                continue
            if dc:
                decimal_comma_files.add(rel)
            info = roles.get(f"{rel}\0{name}", {})
            for i, x in enumerate(cells):
                if x.lower() not in MISSING_TOKENS and as_number(x, dc) is None:
                    flag("숫자가 아닌 값", file=rel, line=lines[i], column=name, value=x)
            if info.get("role") in SKIP_ROLES:
                continue
            unit = units.get(name) or unit_in_header(name)
            parsed = parse_unit(unit) if unit else None
            if unit is None or parsed is None:
                key = (name, "단위 없음" if unit is None else "모호한 단위")
                item = e01.setdefault(key, {"code": "E01", "kind": key[1], "column": name, "header_unit": unit,
                                            "suggestion": info.get("unit_guess", ""), "files": []})
                item["files"].append(rel)
                continue
            dim, factor = parsed
            spec, why = _pick_range(name, dim, entries, plan)
            columns_info.setdefault(name, {"column": name, "unit": unit, "dimension": dim, "files": 0,
                                           "unit_source": "3-3 확정" if name in units else "헤더",
                                           "spec": None if spec is None else {k: spec.get(k) for k in (
                                               "file", "range_label", "min", "max", "unit", "page", "quote", "verified")},
                                           "why": why})["files"] += 1
            if spec is not None:
                hi = spec["max"] * spec["_factor"]
                lo = spec["min"] * spec["_factor"] if spec.get("min") is not None else (-hi if dim in ("current", "voltage") else None)
            for i, x in enumerate(cells):
                v = as_number(x, dc)
                if v is None:
                    continue
                hit = next((o for o in overflow if abs(v - o["value"]) <= 1e-9 * max(1.0, abs(o["value"]))), None)
                if hit:   # 오버플로 표시값은 범위 밖으로 한 번 더 세지 않는다
                    flag("오버플로 표시값", file=rel, line=lines[i], column=name, value=x,
                         spec_ref={"file": hit["file"], "page": hit["page"], "quote": hit["quote"]})
                elif spec is not None:
                    si = v * factor
                    tol = 1e-12 * max(abs(hi), abs(lo or 0.0))
                    if si > hi + tol or (lo is not None and si < lo - tol):
                        flag("사양 범위 밖", file=rel, line=lines[i], column=name, value=x,
                             limit=f"{spec.get('min')} ~ {spec['max']} {spec['unit']}",
                             spec_ref={"file": spec["file"], "page": spec["page"], "quote": spec["quote"],
                                       "range_label": spec["range_label"]})
    return {"e01": list(e01.values()), "e02": e02, "e02_counts": e02_count,
            "e02_truncated": sum(e02_count.values()) > len(e02),
            "e02_groups": [{"file": f, "column": c, "kind": k, "count": n} for (f, c, k), n in group_count.items()],
            "columns": list(columns_info.values()),
            "decimal_comma_files": sorted(decimal_comma_files),
            "note": "사양(2-2)이 승인 전이므로 범위 이탈·오버플로는 잠정. 어떤 값도 제외하지 않음 — 결정은 3-3."}
