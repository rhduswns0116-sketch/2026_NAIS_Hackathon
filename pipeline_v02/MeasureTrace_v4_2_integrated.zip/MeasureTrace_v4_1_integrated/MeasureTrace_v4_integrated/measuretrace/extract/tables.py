"""표 읽기 [PY] — Ingest 와 같은 규칙(인코딩·정규화·구분자)으로 CSV 를 읽는다. 값은 파이썬만 읽는다(R2).

숫자 읽기 규칙 (추측으로 값을 바꾸지 않는다)
  - 소수점 쉼표(1,23): 구분자가 쉼표가 아니고, 그 파일의 숫자 칸이 '정수,정수' 꼴만 쓰고 '.' 소수는 안 쓸 때만 쉼표를 소수점으로 본다.
  - 그 밖에 쉼표가 든 칸(1,234 등)은 천 단위인지 소수점인지 알 수 없으므로 숫자로 읽지 않는다(→ 2-3 '숫자가 아닌 값').
"""
from __future__ import annotations

import csv
import re
from pathlib import Path

from measuretrace.ingest.hashing import decode_text, detect_delimiter

MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "-", "--", "#n/a"}
_DEC_COMMA = re.compile(r"^[-+]?\d+,\d+(?:[eE][-+]?\d+)?$")
_DEC_POINT = re.compile(r"^[-+]?\d*\.\d+(?:[eE][-+]?\d+)?$")
# 숫자 + 단위 표기가 한 칸에 든 값 (예: '5.1 nA', '-3e-9A', '12 %') — 측정값이므로 LLM 에 보내지 않는다
NUMBER_WITH_UNIT = re.compile(r"^[-+±]?\d+(?:[.,]\d+)?(?:[eE][-+]?\d+)?\s*[A-Za-zµμΩ%°/□]+[A-Za-z0-9/²³□]*$")
HAS_DECIMAL = re.compile(r"\d[.,]\d|\d[eE][-+]?\d")


def read_table(path: Path) -> dict | None:
    """{'columns', 'rows': [[셀...]], 'lines': [파일 줄 번호], 'delimiter', 'decimal_comma'} — 표가 아니면 None."""
    decoded = decode_text(path.read_bytes())
    if decoded is None:
        return None
    raw_lines = decoded[0].replace("\r\n", "\n").replace("\r", "\n").split("\n")
    numbered = [(i + 1, l.rstrip()) for i, l in enumerate(raw_lines) if l.strip()]
    delim = detect_delimiter([l for _, l in numbered])
    if delim is None or not numbered:
        return None
    columns = [c.strip() for c in next(csv.reader([numbered[0][1]], delimiter=delim))]
    rows, lines = [], []
    for n, line in numbered[1:]:
        cells = [c.strip() for c in next(csv.reader([line], delimiter=delim))]
        rows.append(cells + [""] * (len(columns) - len(cells)))
        lines.append(n)
    comma = point = 0
    if delim != ",":
        for r in rows[:500]:
            for c in r:
                comma += bool(_DEC_COMMA.match(c))
                point += bool(_DEC_POINT.match(c))
    return {"columns": columns, "rows": rows, "lines": lines, "delimiter": delim,
            "decimal_comma": comma > 0 and point == 0}


def as_number(cell: str, decimal_comma: bool = False) -> float | None:
    s = cell.strip()
    if not s:
        return None
    if "," in s:
        if not decimal_comma or not _DEC_COMMA.match(s):
            return None
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def looks_like_measurement(cell: str) -> bool:
    """글자 칸이지만 측정값일 수 있는 것 — 숫자+단위, 또는 소수·지수 표기가 든 글."""
    return bool(NUMBER_WITH_UNIT.match(cell.strip()) or HAS_DECIMAL.search(cell))
