"""2-1a 데이터 내용 파악 [LLM] — 행·열 헤더만 보고 무엇을 측정한 데이터인지 판단한다. 측정값은 보내지 않는다(R2).

LLM 에 보내는 것: 파일 경로, 열 이름, 행 수, 숫자 열인지 여부, 글자 열(시료·조건·위치 같은 행 머리)의 고유 표기.
숫자 열의 값은 한 칸도 보내지 않는다. 같은 열 구성의 파일은 한 묶음으로 한 번만 묻는다.
보낸 글 전체를 결과에 남겨(sent) 무엇이 나갔는지 확인할 수 있게 한다.
"""
from __future__ import annotations

import json
from pathlib import Path

from measuretrace.extract.tables import NUMBER_WITH_UNIT, as_number, looks_like_measurement, read_table

MAX_LABELS = 30

SYSTEM = """당신은 실험 데이터 파일의 구조를 파악하는 보조자입니다.
주어진 것은 파일 경로, 열 이름, 행 수, 그리고 글자로 된 열의 고유 표기뿐입니다. 측정값은 받지 않습니다.
- 열 이름과 표기만으로 판단하고, 알 수 없는 것은 추측으로 채우지 말고 unknown 또는 빈 문자열로 두세요.
- unit_in_header 에는 열 이름에 실제로 적힌 단위 표기만 옮겨 적으세요(없으면 빈 문자열).
- unit_guess 는 헤더에 단위가 없을 때 무엇일 가능성이 큰지 제안만 하세요(확정 아님, 모르면 빈 문자열).
- 확인이 필요한 점은 questions 에 한국어로 짧게 적으세요."""

SCHEMA = {
    "type": "object",
    "properties": {
        "measurement": {"type": "string", "description": "무엇을 측정한 데이터인가 — 한두 문장"},
        "layout": {"type": "string", "enum": ["long", "wide", "other"]},
        "columns": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "role": {"type": "string", "enum": ["sample_id", "condition", "replicate", "independent_variable",
                                                   "measured_value", "metadata", "unknown"]},
                "quantity": {"type": "string"},
                "unit_in_header": {"type": "string"},
                "unit_guess": {"type": "string"},
                "meaning": {"type": "string"},
            },
            "required": ["name", "role", "quantity", "unit_in_header", "unit_guess", "meaning"],
            "additionalProperties": False}},
        "row_keys": {"type": "array", "items": {"type": "string"}},
        "questions": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["measurement", "layout", "columns", "row_keys", "questions"],
    "additionalProperties": False,
}


def describe_file(path: Path) -> dict | None:
    """헤더 요약 — 숫자 열은 이름만, 글자 열은 고유 표기(최대 30개)."""
    table = read_table(path)
    if table is None:
        return None
    cols = table["columns"]
    dc = table["decimal_comma"]
    numeric, unit_cells = [], []
    labels: dict[str, list[str]] = {}
    withheld = 0
    for c, name in enumerate(cols):
        cells = [r[c] for r in table["rows"] if r[c].strip()]
        nums = sum(as_number(x, dc) is not None for x in cells)
        meas = sum(bool(NUMBER_WITH_UNIT.match(x.strip())) for x in cells)
        if cells and nums / len(cells) >= 0.5:   # 과반이 숫자면 숫자 열 — 값은 보내지 않음
            numeric.append(name)
        elif cells and (nums + meas) / len(cells) >= 0.5:   # '5.1 nA' 처럼 숫자+단위가 칸에 든 열 — 측정값, 보내지 않음
            unit_cells.append(name)
        else:
            seen: list[str] = []
            for x in cells:
                if as_number(x, dc) is not None or looks_like_measurement(x):
                    withheld += 1        # 측정값일 수 있는 표기는 보내지 않는다(R2)
                elif x not in seen:
                    seen.append(x)
            labels[name] = seen
    return {"columns": cols, "n_rows": len(table["rows"]), "numeric_columns": numeric, "unit_cell_columns": unit_cells,
            "labels": labels, "withheld": withheld}


def group_files(raw_files: list[tuple[str, Path]]) -> tuple[list[dict], list[dict]]:
    """열 구성이 같은 파일끼리 묶는다. (묶음들, 읽지 못한 파일들)"""
    groups: dict[tuple, dict] = {}
    unread = []
    for rel, path in raw_files:
        d = describe_file(path) if path.suffix.lower() in (".csv", ".tsv", ".txt", ".dat") else None
        if d is None:
            unread.append({"file": rel, "reason": "구분자로 나뉜 표가 아님 — 2-1a 헤더 분석 미지원(엑셀은 CSV 로 내보내기)"})
            continue
        key = (tuple(d["columns"]), tuple(d["numeric_columns"]), tuple(d["unit_cell_columns"]))
        g = groups.setdefault(key, {"columns": d["columns"], "numeric_columns": d["numeric_columns"],
                                    "unit_cell_columns": d["unit_cell_columns"],
                                    "files": [], "n_rows": [], "labels": {}, "withheld": 0})
        g["files"].append(rel)
        g["n_rows"].append(d["n_rows"])
        g["withheld"] += d["withheld"]
        for name, vals in d["labels"].items():
            bucket = g["labels"].setdefault(name, [])
            for v in vals:
                if v not in bucket:
                    bucket.append(v)
    out = []
    for i, g in enumerate(groups.values(), 1):
        g["group_id"] = f"G{i}"
        out.append(g)
    return out, unread


def payload(g: dict) -> str:
    """LLM 에 보낼 글 — 측정값 없음."""
    labels = {k: (v if len(v) <= MAX_LABELS else v[:MAX_LABELS] + [f"… 외 {len(v) - MAX_LABELS}개"])
              for k, v in g["labels"].items()}
    files = g["files"] if len(g["files"]) <= 40 else g["files"][:40] + [f"… 외 {len(g['files']) - 40}개"]
    return json.dumps({
        "파일 수": len(g["files"]), "파일 경로": files,
        "행 수(파일별 최소~최대)": [min(g["n_rows"]), max(g["n_rows"])],
        "열 이름": g["columns"],
        "숫자 열(값은 보내지 않음)": g["numeric_columns"],
        "숫자와 단위가 한 칸에 든 열(값은 보내지 않음)": g["unit_cell_columns"],
        "글자 열의 고유 표기": labels,
        "측정값일 수 있어 보내지 않은 글자 칸 수": g["withheld"],
    }, ensure_ascii=False, indent=1)


def analyze(raw_files: list[tuple[str, Path]], llm) -> dict:
    groups, unread = group_files(raw_files)
    results = []
    for g in groups:
        sent = payload(g)
        item = {"group_id": g["group_id"], "files": g["files"], "columns": g["columns"],
                "numeric_columns": g["numeric_columns"], "n_rows": [min(g["n_rows"]), max(g["n_rows"])], "sent": sent}
        try:
            data, meta = llm.json("2-1a_headers", SYSTEM, sent, SCHEMA, effort="medium", max_tokens=16000)
            item.update(analysis=data, llm=meta)
        except Exception as e:
            item.update(analysis=None, error=str(e))
        results.append(item)
    return {"groups": results, "unread": unread}
