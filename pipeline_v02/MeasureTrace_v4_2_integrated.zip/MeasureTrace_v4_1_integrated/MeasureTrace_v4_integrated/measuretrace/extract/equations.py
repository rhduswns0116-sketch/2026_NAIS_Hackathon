"""2-1b 계획서 수식 변환 [PY] — docx 의 Word 수식(m:oMath)을 dwml 로 LaTeX 로 바꾼다 (v4 §9).

수식마다 앞 문장 · 수식 XML 해시 · 계획서 파일 해시를 함께 남긴다(equations.json). 변환 실패는 수식 단위로 잡아
'직접 적어 달라'는 3-1 질문 후보로 남긴다. 같은 김에 계획서 본문(수식 자리는 [EQnn] 표시)도 만든다 — 2-1c·2-4 의 LLM 입력.
"""
from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path

from lxml import etree

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"


def _text(p) -> str:
    """문단 글자 — 수식 안의 글자(m:t)는 빼고 본문(w:t)만."""
    return "".join(t.text or "" for t in p.iter(W + "t")).strip()


def extract_equations(path: Path, plan_sha256: str) -> dict:
    try:
        from dwml.omml import oMath2Latex
    except ImportError:
        oMath2Latex = None
    root = etree.fromstring(zipfile.ZipFile(path).read("word/document.xml"))
    equations, lines = [], []
    last_text = ""
    for p in root.iter(W + "p"):
        if p.getparent() is not None and p.getparent().tag == M + "oMath":
            continue
        text = _text(p)
        maths = [om for om in p.iter(M + "oMath") if om.getparent().tag != M + "oMath"]
        parts = [text] if text else []
        for om in maths:
            eq_id = f"EQ{len(equations) + 1:02d}"
            xml = etree.tostring(om, method="c14n")
            item = {"id": eq_id, "sentence": text or last_text, "omml_sha256": hashlib.sha256(xml).hexdigest(),
                    "plan_sha256": plan_sha256}
            if oMath2Latex is None:
                item.update(latex=None, status="failed", error="dwml 미설치 — pip install dwml")
            else:
                try:
                    item.update(latex=str(oMath2Latex(om)).strip(), status="ok")
                except Exception as e:   # v4 §9: 속성 요소가 없으면 KeyError 등 — 수식 단위로 잡는다
                    item.update(latex=None, status="failed", error=f"{type(e).__name__}: {e}")
            equations.append(item)
            parts.append(f"[{eq_id}] " + (f"$ {item['latex']} $" if item["latex"] else "(변환 실패 — 원문 확인 필요)"))
        if parts:
            lines.append(" ".join(parts))
        if text:
            last_text = text
    return {"plan_sha256": plan_sha256, "converter": "dwml.omml.oMath2Latex" if oMath2Latex else None,
            "equations": equations, "failed": [e["id"] for e in equations if e["status"] != "ok"],
            "plan_text": "\n".join(lines)}
