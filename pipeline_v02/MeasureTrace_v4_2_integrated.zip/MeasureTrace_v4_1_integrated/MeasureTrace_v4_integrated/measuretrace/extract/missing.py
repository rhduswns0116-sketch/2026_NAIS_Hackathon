"""2-4 누락 점검 [LLM]→[PY] — LLM 은 계획서만 읽고 결론에 필요한 시료·파일·측정 목록을 뽑는다.
파이썬이 그 목록을 실제 파일과 대조한다(v4 결정 10: 비결정성 제거). → E03 후보, 확정은 3-1.

LLM 에는 실제 파일 목록을 보여 주지 않는다 — 있는 파일에 맞춰 목록을 줄이지 않도록.
"""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

from measuretrace.extract.tables import read_table

SYSTEM = """당신은 연구 계획서에서 결론을 내는 데 필요한 데이터 목록을 뽑는 보조자입니다.
- 계획서에 적힌 것만 옮기세요. 시료 이름이 범위로 적혀 있으면(예: S01–S10) 하나하나 풀어서 적으세요.
- per_sample 은 시료 하나의 데이터 파일 안에 있어야 할 것입니다. 계획서에 없으면 빈 값·null 로 두세요.
  id_column 은 한 시료 파일 안에서 측정 위치·반복을 구분하는 열 이름입니다(시료 ID 열이 아님).
  expected_ids 는 그 열에 나와야 할 표기들입니다(예: 위치 P1–P7 이면 P1 … P7).
- 모호한 점은 questions 에 한국어로 적으세요."""

_NULL_INT = {"anyOf": [{"type": "integer"}, {"type": "null"}]}
SCHEMA = {
    "type": "object",
    "properties": {
        "conditions": {"type": "array", "items": {"type": "object", "properties": {
            "name": {"type": "string"}, "samples": {"type": "array", "items": {"type": "string"}},
            "source_quote": {"type": "string"}},
            "required": ["name", "samples", "source_quote"], "additionalProperties": False}},
        "file_naming": {"type": "string"},
        "per_sample": {"type": "object", "properties": {
            "id_column": {"type": "string"}, "expected_ids": {"type": "array", "items": {"type": "string"}},
            "points_per_id": _NULL_INT, "rows_per_file": _NULL_INT, "source_quote": {"type": "string"}},
            "required": ["id_column", "expected_ids", "points_per_id", "rows_per_file", "source_quote"],
            "additionalProperties": False},
        "other_required": {"type": "array", "items": {"type": "object", "properties": {
            "what": {"type": "string"}, "kind": {"type": "string", "enum": ["plan", "spec", "raw", "other"]}},
            "required": ["what", "kind"], "additionalProperties": False}},
        "questions": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["conditions", "file_naming", "per_sample", "other_required", "questions"],
    "additionalProperties": False,
}


def _tokens(rel: str) -> set[str]:
    return {t.lower() for t in re.split(r"[\\/_.\-\s]+", rel) if t}


def _id_column(table: dict, id_col: str, expected: list[str]) -> str | None:
    """위치 id 가 들어 있는 열 — LLM 이 고른 열에 기대 표기가 하나라도 있으면 그 열, 아니면 표기가 가장 많이 맞는 열."""
    def hits(name: str) -> int:
        c = table["columns"].index(name)
        values = {r[c] for r in table["rows"]}
        return sum(1 for e in expected if e in values)
    if id_col in table["columns"] and hits(id_col):
        return id_col
    scored = sorted(((hits(n), n) for n in table["columns"]), reverse=True)
    return scored[0][1] if scored and scored[0][0] else None


def _value_key(v: str) -> str:
    """표 칸 값 비교용 — '1' 과 '1.0' 을 같게."""
    v = str(v).strip().lower()
    try:
        f = float(v)
        return str(int(f)) if f.is_integer() else repr(f)
    except ValueError:
        return v


def _row_matches(sid: str, raw_files: list[tuple[str, Path]], tables: dict) -> list[tuple[str, str]]:
    """시료가 파일이 아니라 공유 표의 행일 때 (예: 'Tank 1' → Tank 열의 값 1). [(파일, 열)].

    열 이름이 시료 표기의 앞부분과 같고 그 열에 나머지 표기가 값으로 있어야 한다. 열 이름 없이 값만 맞는 경우
    (숫자 1 은 어느 열에나 있을 수 있음)는 시료 표기 전체('Tank 1', 'S01')가 값으로 있을 때만 인정한다."""
    s = sid.strip()
    m = re.fullmatch(r"(.*?[^\d\s._-])[\s._-]*(\d+)", s)
    prefix, number = (m.group(1).lower(), _value_key(m.group(2))) if m else ("", "")
    whole = _value_key(s) if re.search(r"[^\d\s.,+-]", s) else None   # 숫자만인 표기는 열 이름 없이 인정하지 않음
    hits = []
    for rel, p in raw_files:
        if rel not in tables:
            tables[rel] = read_table(p) if p.suffix.lower() in (".csv", ".tsv", ".txt", ".dat") else None
        t = tables[rel]
        if not t:
            continue
        for i, col in enumerate(t["columns"]):
            values = {_value_key(r[i]) for r in t["rows"] if i < len(r)}
            if (prefix and str(col).strip().lower() == prefix and number in values) or (whole and whole in values):
                hits.append((rel, col))
                break
    return hits


def compare(required: dict, raw_files: list[tuple[str, Path]], categories: Counter) -> dict:
    """계획서 목록 ↔ 실제 파일. 시료 파일 유무, 파일 안의 위치(id)별 측정점 수.
    시료마다 파일이 없으면 공유 표의 행(시료 ID 열)으로도 찾는다 — 한 표에 시료가 행으로 든 설계."""
    e03, found, used = [], [], set()
    tables: dict = {}
    per = required.get("per_sample") or {}
    id_col, expected_ids = per.get("id_column") or "", per.get("expected_ids") or []
    points, rows_per_file = per.get("points_per_id"), per.get("rows_per_file")
    for cond in required.get("conditions", []):
        for sid in cond["samples"]:
            matches = [(rel, p) for rel, p in raw_files if Path(rel).stem.lower() == sid.lower()] or \
                      [(rel, p) for rel, p in raw_files if sid.lower() in _tokens(rel)]
            rows = [] if matches else _row_matches(sid, raw_files, tables)
            if rows:
                used.update(rel for rel, _ in rows)
                found.append({"sample": sid, "condition": cond["name"], "file": rows[0][0],
                              "note": "공유 표의 행: " + ", ".join(f"{rel} 의 열 {col}" for rel, col in rows)})
                continue
            if not matches:
                e03.append({"code": "E03", "kind": "시료 파일 없음", "condition": cond["name"], "sample": sid,
                            "detail": f"계획서의 시료 {sid}({cond['name']})에 해당하는 RAW 파일이 없음"})
                continue
            if len(matches) > 1:
                e03.append({"code": "E03", "kind": "시료 파일이 여러 개", "condition": cond["name"], "sample": sid,
                            "detail": f"{[m[0] for m in matches]} — 어느 것을 쓸지 3-1 에서 확인"})
            rel, path = matches[0]
            used.add(rel)
            item = {"sample": sid, "condition": cond["name"], "file": rel}
            table = read_table(path) if path.suffix.lower() in (".csv", ".tsv", ".txt", ".dat") else None
            if table is None:
                item["note"] = "텍스트 표가 아니어서 위치·측정점 대조를 못 함 (엑셀은 CSV 로 내보내기)"
            col = _id_column(table, id_col, expected_ids) if table else None
            if table and expected_ids and col is None:
                e03.append({"code": "E03", "kind": "위치 표기를 찾지 못함", "condition": cond["name"], "sample": sid,
                            "file": rel, "detail": f"계획서의 {expected_ids[:3]}… 표기가 어느 열에도 없음 — 3-1 에서 확인"})
            elif table and col is not None:
                c = table["columns"].index(col)
                if col != id_col:
                    item["note"] = f"계획서 목록의 열 '{id_col}' 대신 표기가 맞는 열 '{col}'로 대조"
                counts = Counter(r[c] for r in table["rows"])
                item["rows"] = len(table["rows"])
                item["per_id"] = dict(counts)
                for pid in expected_ids:
                    if pid not in counts:
                        e03.append({"code": "E03", "kind": "측정 위치 없음", "condition": cond["name"], "sample": sid,
                                    "file": rel, "detail": f"{col}={pid} 행이 없음"})
                    elif points and counts[pid] < points:
                        e03.append({"code": "E03", "kind": "측정점 부족", "condition": cond["name"], "sample": sid,
                                    "file": rel, "detail": f"{col}={pid}: {counts[pid]}/{points}점"})
            elif table and rows_per_file and len(table["rows"]) < rows_per_file:
                e03.append({"code": "E03", "kind": "행 부족", "condition": cond["name"], "sample": sid, "file": rel,
                            "detail": f"{len(table['rows'])}/{rows_per_file}행"})
            found.append(item)
    for need in required.get("other_required", []):
        if need["kind"] in ("plan", "spec") and not categories.get(need["kind"]):
            e03.append({"code": "E03", "kind": "필요 문서 없음", "doc_kind": need["kind"],
                        "detail": f"{need['what']} ({need['kind']})"})
    extra = [rel for rel, _ in raw_files if rel not in used]
    n_required = sum(len(c["samples"]) for c in required.get("conditions", []))
    return {"required_samples": n_required, "found": found, "e03": e03, "unlisted_raw_files": extra}


def analyze(plan_text: str, raw_files: list[tuple[str, Path]], categories: Counter, llm) -> dict:
    out = {"sent": plan_text}
    try:
        data, meta = llm.json("2-4_required", SYSTEM, plan_text, SCHEMA, effort="medium", max_tokens=16000)
        out.update(required=data, llm=meta, comparison=compare(data, raw_files, categories))
    except Exception as e:
        out.update(required=None, error=str(e))
    return out
