"""2-1c 연구 내용 추출 [LLM] — 계획서에서 식 · 가공 방법 · 설계 · 검정 방법을 뽑고,
실험 ↔ 데이터 ↔ 식 ↔ 장비 매칭표와 계산 코드 초안을 만든다.

입력: 계획서 본문(수식은 2-1b 의 LaTeX), 2-1a 헤더 분석(열 이름·역할 — 값 없음), 2-2 사양 항목 이름.
계산 코드 초안은 **실행하지 않는다**(R1). 파일로 저장하고 해시만 남긴다 — 3-1 승인 뒤 해시를 고정해 4-1 에서만 실행.
"""
from __future__ import annotations

import hashlib
import json

from measuretrace.recompute import sandbox

SYSTEM = """당신은 연구 계획서를 읽고 재계산에 필요한 내용을 구조화하는 보조자입니다.
원칙
- 계획서에 적힌 것만 옮기세요. 계획서에 없는 식·설계·검정은 만들지 말고, 빠졌거나 모호하면 questions 에 적으세요.
- 식은 [EQnn] 번호로 가리키세요. 계획서의 식을 바꾸거나 더 낫게 고치지 마세요(식의 타당성은 판단하지 않습니다).
- source_quote 에는 근거가 된 계획서 문장을 글자 그대로 옮기세요.
- 데이터는 열 이름과 역할만 주어집니다. 측정값은 모르며, 값을 가정하지 마세요.
- 숫자 칸(replicates_per_unit, points_per_replicate, degrees_of_freedom, alpha)은 계획서에 없으면 0 으로 두세요.
- formulas[].variables 는 '기호: 뜻 [단위] ← 데이터 열' 형식의 문자열로 적으세요(데이터 열이 아니면 ← 부분 생략)."""

CODE_SYSTEM = """당신은 승인된 연구 계획서의 계산 절차를 파이썬 코드 초안으로 옮기는 보조자입니다. 이 코드는 사람이 승인하기 전에는 실행되지 않습니다.
- 파이썬 함수 하나: def compute(files: dict[str, str]) -> dict
  files 는 {실험 폴더 기준 상대 경로: 실제 파일 경로} 이며 RAW 파일만 들어 있습니다.
- 반환: {"results": [{"name": str, "symbol": str, "value": float, "unit": str, "eq_id": str, "condition": str 또는 None}],
         "intermediate": {이름: 값 또는 목록}}
  results 에는 계획서가 보고하도록 정한 최종값(조건별 평균·표준편차·검정 통계량·자유도·p값·증가율 등)을 모두 넣으세요.
- 계획서의 가공 방법과 식을 순서대로 그대로 구현하세요. 식을 바꾸거나 개선하지 마세요. 단위 환산은 계획서의 보고 단위를 따르세요.
- 파일 쓰기·네트워크·주어진 파일 밖 읽기 금지. 측정값을 코드에 적어 넣지 마세요.
- 파일은 csv 모듈로 읽고 열 이름으로 접근하세요. 열 이름은 주어진 헤더 그대로 쓰세요.
- 계획서로 정할 수 없는 부분은 코드 주석에 'TODO(확인 필요):' 로 남기고 explanation 에도 적으세요.
격리 실행 규칙 (어기면 승인할 수 없고 실행되지 않습니다)
""" + sandbox.rules_text()

_STRS = {"type": "array", "items": {"type": "string"}}


def _obj(props: dict) -> dict:
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


_S, _I, _N, _B = {"type": "string"}, {"type": "integer"}, {"type": "number"}, {"type": "boolean"}
SCHEMA = _obj({
    "summary": _S,
    "formulas": {"type": "array", "items": _obj({"eq_id": _S, "purpose": _S, "role": _S, "variables": _STRS, "notes": _S})},
    "processing": {"type": "array", "items": _obj({"step": _I, "description": _S, "input": _S, "output": _S,
                                                   "eq_ids": _STRS, "source_quote": _S})},
    "design": _obj({"conditions": {"type": "array", "items": _obj({"name": _S, "label": _S, "samples": _STRS})},
                    "independent_unit": _S, "technical_replicate": _S, "replicates_per_unit": _I,
                    "points_per_replicate": _I, "degrees_of_freedom": _I, "source_quote": _S}),
    "test": _obj({"present": _B, "method": _S, "alternative": _S, "alpha": _N, "eq_ids": _STRS, "source_quote": _S}),
    "matching": {"type": "array", "items": _obj({"experiment": _S, "data_group": _S, "data_columns": _STRS, "eq_ids": _STRS,
                                                 "instrument": _S, "instrument_range": _S, "outputs": _STRS})},
    "reported_quantities": {"type": "array", "items": _obj({"name": _S, "symbol": _S, "unit": _S, "eq_id": _S, "per": _S})},
    "questions": _STRS,
})
CODE_SCHEMA = _obj({"code": _S, "explanation": _S})


def build_input(plan_text: str, header_groups: list[dict], spec: dict | None) -> str:
    data = []
    for g in header_groups:
        cols = (g.get("analysis") or {}).get("columns") or [{"name": c} for c in g["columns"]]
        data.append({"data_group": g["group_id"], "파일 수": len(g["files"]),
                     "파일 경로 예": g["files"][:6], "행 수": g["n_rows"],
                     "열": [{k: c.get(k) for k in ("name", "role", "quantity", "unit_in_header") if k in c} for c in cols],
                     "무엇을 측정했나(2-1a)": (g.get("analysis") or {}).get("measurement", "")})
    spec_items = [{"range_label": e.get("range_label"), "quantity": e.get("quantity"), "page": e.get("page")}
                  for e in ((spec or {}).get("analysis") or {}).get("entries", [])]
    return ("## 연구 계획서 본문 (수식은 [EQnn] $LaTeX$)\n" + plan_text
            + "\n\n## 데이터 파일 헤더 (측정값 없음)\n" + json.dumps(data, ensure_ascii=False, indent=1)
            + "\n\n## 장비 사양서의 측정 범위 항목 이름\n" + json.dumps(spec_items, ensure_ascii=False))


def analyze(plan_text: str, header_groups: list[dict], spec: dict | None, llm) -> dict:
    """두 번 부른다 — ① 연구 내용(식·가공·설계·검정·매칭) ② 그 결과로 계산 코드 초안."""
    sent = build_input(plan_text, header_groups, spec)
    out = {"sent": sent}
    try:
        data, meta = llm.json("2-1c_plan", SYSTEM, sent, SCHEMA, effort="high", max_tokens=32000)
        out.update(analysis=data, llm=meta)
    except Exception as e:
        out.update(analysis=None, error=str(e))
        return out
    code_input = sent + "\n\n## 연구 내용 추출 결과 (위 ①)\n" + json.dumps(data, ensure_ascii=False, indent=1)
    try:
        code, cmeta = llm.json("2-1c_code", CODE_SYSTEM, code_input, CODE_SCHEMA, effort="high", max_tokens=32000)
        data["code"] = code
        out["llm_code"] = cmeta
        out["code_sha256"] = hashlib.sha256(code["code"].encode("utf-8")).hexdigest()
        out["code_status"] = "초안 — 승인 전, 실행하지 않음 (3-1 승인 후 해시 고정)"
        out["code_static_check"] = sandbox.static_check(code["code"])   # 4-1 과 같은 검사 — 3-1 에서 미리 보여 줌
    except Exception as e:
        data["code"] = None
        out["code_error"] = str(e)
    return out


CODE_HEADER = '''# MeasureTrace 계산 코드 초안 (2-1c, LLM 작성)
# 상태: 승인 전 — 실행하지 않음(R1). 3-1 에서 사람이 승인하면 이 파일의 해시를 고정하고 4-1 에서만 실행한다.
# 코드 해시(sha256, 이 머리말 제외 본문): {sha}
# 모델: {model} · 지시문 지문: {fp}

'''
