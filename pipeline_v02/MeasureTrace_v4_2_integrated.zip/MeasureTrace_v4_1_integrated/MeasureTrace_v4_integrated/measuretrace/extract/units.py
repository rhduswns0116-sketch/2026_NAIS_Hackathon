"""단위 해석 — 열 이름에서 단위 표기를 찾고, (차원, SI 배율)로 바꾼다. 2-3 E01(단위 누락·모호)과 사양 범위 비교에 쓴다.

같은 단위의 다른 표기(ohm/sq, Ω/□ …)는 여기 사전으로 흡수한다(E01 오탐 주의). 모르는 표기는 '모호'로 남긴다.
"""
from __future__ import annotations

import re

PREFIX = {"p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6, "μ": 1e-6, "m": 1e-3, "": 1.0, "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9}
BASE = {  # 표기 → (차원, 배율)
    "A": ("current", 1.0), "amp": ("current", 1.0), "amps": ("current", 1.0),
    "V": ("voltage", 1.0), "volt": ("voltage", 1.0), "volts": ("voltage", 1.0),
    "S": ("conductance", 1.0), "siemens": ("conductance", 1.0),
    "ohm": ("resistance", 1.0), "ohms": ("resistance", 1.0), "Ω": ("resistance", 1.0), "Ohm": ("resistance", 1.0),
    "ohm/sq": ("sheet_resistance", 1.0), "Ω/□": ("sheet_resistance", 1.0), "ohm/square": ("sheet_resistance", 1.0),
    "Ω/sq": ("sheet_resistance", 1.0),
    "s": ("time", 1.0), "sec": ("time", 1.0), "min": ("time", 60.0), "h": ("time", 3600.0),
    "Hz": ("frequency", 1.0), "K": ("temperature_K", 1.0), "°C": ("temperature_C", 1.0), "degC": ("temperature_C", 1.0),
    "%": ("percent", 1.0), "percent": ("percent", 1.0), "nm": ("length", 1e-9), "um": ("length", 1e-6),
    "µm": ("length", 1e-6), "mm": ("length", 1e-3), "cm": ("length", 1e-2), "m": ("length", 1.0),
    "W": ("power", 1.0), "F": ("capacitance", 1.0), "g": ("mass", 1e-3), "kg": ("mass", 1.0), "eV": ("energy_eV", 1.0),
    # 3-3 에서 '단위 없는 수'(개수·번호·비율)를 확정할 때 쓰는 표기
    "무차원": ("dimensionless", 1.0), "dimensionless": ("dimensionless", 1.0), "1": ("dimensionless", 1.0),
    "개": ("count", 1.0), "count": ("count", 1.0), "번호": ("index", 1.0), "index": ("index", 1.0),
}
_BRACKET = re.compile(r"[\(\[\{]\s*([^\)\]\}]+?)\s*[\)\]\}]\s*$")
_SUFFIX = re.compile(r"(?:_|\s|-)([A-Za-zµμΩ°%/□]+)$")


def parse_unit(token: str) -> tuple[str, float] | None:
    """'nA' → ('current', 1e-9). 모르면 None."""
    t = token.strip()
    if t in BASE:
        return BASE[t]
    low = {k.lower(): v for k, v in BASE.items() if len(k) > 1}
    if t.lower() in low:
        return low[t.lower()]
    for base in sorted(BASE, key=len, reverse=True):
        if t.endswith(base) and t[: -len(base)] in PREFIX and t[: -len(base)] != "":
            dim, factor = BASE[base]
            if dim in ("temperature_C", "percent", "time") and base != "s":
                continue
            return dim, factor * PREFIX[t[: -len(base)]]
    return None


def unit_in_header(column: str) -> str | None:
    """열 이름 속 단위 표기 — 'current_A' → 'A', 'Voltage (mV)' → 'mV', 'I [nA]' → 'nA'. 없으면 None."""
    m = _BRACKET.search(column)
    if m:
        return m.group(1)
    m = _SUFFIX.search(column)
    if m and parse_unit(m.group(1)):
        return m.group(1)
    return None   # '_no', '_id' 같은 꼬리말은 단위가 아님 → '단위 없음'으로 (괄호 안의 모르는 표기만 '모호')


def to_si(value: float, unit: str) -> float | None:
    parsed = parse_unit(unit)
    return None if parsed is None else value * parsed[1]


NUMBER = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")
