"""2 EXTRACT — 식·조건·데이터를 파악한다 (LLM 은 측정값을 보지 않음). 파이프라인 v4 확정본 §4-2.

순서: 2-1b 수식 변환[PY] → (2-1a 헤더[LLM] · 2-2 사양[LLM] · 2-4 필요 목록[LLM]) 병렬 → 2-1c 연구 내용[LLM]
      → 2-3 데이터 구조화[PY] (2-1c 가 정한 장비 범위로 비교) → 2-4 대조[PY]
보고서(report 구역)는 열지 않는다(R4). 한 과업이 실패해도 나머지는 계속하고 실패를 기록한다.
산출물마다 1-3 장부에 (입력 해시, 코드 해시, 파라미터) → 출력 해시 를 남긴다.
"""
from __future__ import annotations

import hashlib
import json
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

from measuretrace import ledger
from measuretrace.extract import datacheck, equations, headers, missing, plan, spec
from measuretrace.ingest import workspace
from measuretrace.llm import LLM
from measuretrace.paths import OUTPUTS_DIR, PACKAGE_DIR, rel

EXTRACT_CODE = [PACKAGE_DIR / "extract", PACKAGE_DIR / "llm.py", PACKAGE_DIR / "ledger.py"]


def find_snapshot(run_id: str) -> Path:
    workspace.run_dir(run_id)
    hits = sorted(OUTPUTS_DIR.glob(f"*/{run_id}/ingest_snapshot.json"))
    if not hits:
        raise ValueError("이 실행의 1 INGEST 결과가 없음 — 먼저 INGEST 를 실행")
    return hits[0]


def _hash_of(files: list[dict]) -> str:
    return hashlib.sha256("\n".join(sorted(f"{f['path']}\t{f['sha256']}" for f in files)).encode("utf-8")).hexdigest()


def _timed(steps: dict, key: str, fn):
    t0 = time.time()
    try:
        result = fn()
        steps[key] = {"status": "ok" if not (isinstance(result, dict) and result.get("error")) else "error",
                      "seconds": round(time.time() - t0, 1)}
        if isinstance(result, dict) and result.get("error"):
            steps[key]["error"] = result["error"]
        return result
    except Exception as e:
        steps[key] = {"status": "error", "error": f"{type(e).__name__}: {e}", "seconds": round(time.time() - t0, 1)}
        return None


def run_extract(run_id: str, llm: LLM | None = None, corrections: str = "", units: dict | None = None,
                during_confirm: bool = False) -> dict:
    """corrections: 3 CONFIRM 에서 연구자가 고친 내용 — 2-1c·2-4 입력 끝에 붙인다(2-1a·2-2 는 그대로 → 캐시).
    units: 3-3 에서 확정한 열 단위 {열: 단위} — 2-3 에 반영.
    3 CONFIRM 이 시작된 실행은 CONFIRM 의 수정 반영(during_confirm=True)으로만 다시 돈다 — 확인 중인 내용이 몰래 바뀌지 않게."""
    snap_path = find_snapshot(run_id)
    if (snap_path.parent / "confirm" / "confirm_state.json").exists() and not during_confirm:
        raise ValueError("3 CONFIRM 이 이미 시작된 실행 — 2 EXTRACT 는 CONFIRM 의 '수정 필요' 답으로만 다시 실행됨")
    snap = json.loads(snap_path.read_text(encoding="utf-8"))
    llm = llm or LLM()
    data_root = workspace.run_dir(run_id) / "data"
    data_files = [f for f in snap["files"] if f["zone"] == "data"]          # R4: 보고서는 여기서 쓰지 않음
    by_cat = Counter(f["category"] for f in data_files)
    raw = [f for f in data_files if f["category"] == "raw"]
    raw_paths = [(f["path"], data_root / f["path"]) for f in raw]
    plans = sorted((f for f in data_files if f["category"] == "plan"),
                   key=lambda f: -((f.get("content") or {}).get("equations") or 0))
    specs = [f for f in data_files if f["category"] == "spec"]
    out_dir = snap_path.parent / "extract"
    out_dir.mkdir(exist_ok=True)
    started = datetime.now().astimezone().isoformat(timespec="seconds")
    steps: dict[str, dict] = {}
    notices = []
    if len(plans) > 1:
        notices.append(f"계획서 후보 {len(plans)}개 중 Word 수식이 가장 많은 {plans[0]['path']} 를 사용 — 3-1 에서 확인")

    # 2-1b 수식 변환 [PY]
    eqs = None
    if plans:
        p = plans[0]
        eqs = _timed(steps, "2-1b", lambda: {**equations.extract_equations(data_root / p["path"], p["sha256"]),
                                             "plan_file": p["path"]})
    else:
        steps["2-1b"] = {"status": "error", "error": "연구 계획서(.docx)가 없음"}
    plan_text = (eqs or {}).get("plan_text", "")
    if plan_text and corrections:
        plan_text += "\n\n## 연구자 수정·답변 (3 CONFIRM) — 계획서보다 이 내용을 우선\n" + corrections

    # 2-1a · 2-2 · 2-4(LLM 목록) 병렬
    with ThreadPoolExecutor(max_workers=3) as pool:
        f_head = pool.submit(_timed, steps, "2-1a", lambda: headers.analyze(raw_paths, llm))
        f_spec = pool.submit(_timed, steps, "2-2", lambda: {"items": spec.analyze(
            [(f["path"], data_root / f["path"]) for f in specs], llm)})
        f_miss = pool.submit(_timed, steps, "2-4", (lambda: missing.analyze(plan_text, raw_paths, by_cat, llm))
                             if plan_text else (lambda: {"error": "계획서 본문이 없어 필요 목록을 뽑을 수 없음"}))
        head, spec_res, miss = f_head.result(), f_spec.result(), f_miss.result()
    if spec_res and any(i.get("error") for i in spec_res["items"]):
        steps["2-2"].update(status="error", error="; ".join(f"{i['file']}: {i['error']}" for i in spec_res["items"] if i.get("error")))
    if not specs:
        steps["2-2"] = {"status": "skipped", "error": "장비 사양서(PDF)가 없음"}
    if head and any(g.get("error") for g in head["groups"]):
        steps["2-1a"].update(status="error", error="; ".join(f"{g['group_id']}: {g['error']}" for g in head["groups"] if g.get("error")))
    groups = (head or {}).get("groups", [])
    spec_items = (spec_res or {}).get("items", [])

    # 2-1c 연구 내용 추출 [LLM]
    merged_spec = {"analysis": {"entries": [e for i in spec_items for e in ((i.get("analysis") or {}).get("entries") or [])]}}
    plan_res = _timed(steps, "2-1c", (lambda: plan.analyze(plan_text, groups, merged_spec, llm))
                      if plan_text else (lambda: {"error": "계획서 본문이 없음"}))

    if plan_res and plan_res.get("code_error"):
        steps["2-1c"].update(status="error", error="계산 코드 초안 실패: " + plan_res["code_error"])

    # 2-3 데이터 구조화 [PY]
    checks = _timed(steps, "2-3", lambda: datacheck.check(raw_paths, groups, spec_items, plan_res, units))

    # 산출물 쓰기 + 1-3 장부
    code = ledger.code_hash(*EXTRACT_CODE)
    raw_hash, spec_hash = _hash_of(raw), _hash_of(specs)
    plan_hash = plans[0]["sha256"] if plans else ""
    lineage = []

    def write(name: str, obj, step: str, inputs: list[str], params: dict) -> str:
        path = out_dir / name
        if isinstance(obj, str):
            path.write_text(obj, encoding="utf-8")
        else:
            path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        ih = hashlib.sha256("\n".join(inputs).encode("utf-8")).hexdigest()
        lineage.append(ledger.record(f"{step} EXTRACT", run_id, ih, code, params, [path]))
        return rel(path)

    def llm_params(meta: dict | None) -> dict:
        m = meta or {}
        return {"model": m.get("model", llm.model), "effort": m.get("effort"), "prompt_fingerprint": m.get("prompt_fingerprint"),
                "cached": m.get("cached")}

    files_out = {}
    if eqs:
        files_out["2-1b"] = write("equations.json", eqs, "2-1b", [plan_hash], {"converter": eqs.get("converter")})
    if head is not None:
        files_out["2-1a"] = write("headers.json", head, "2-1a", [raw_hash],
                                  llm_params(next((g.get("llm") for g in groups if g.get("llm")), None)))
    if spec_res is not None and specs:
        files_out["2-2"] = write("spec_conditions.json", spec_res, "2-2", [spec_hash],
                                 llm_params(next((i.get("llm") for i in spec_items if i.get("llm")), None)))
    if plan_res is not None:
        files_out["2-1c"] = write("plan_extraction.json", plan_res, "2-1c", [plan_hash, raw_hash, spec_hash],
                                  llm_params(plan_res.get("llm")))
        if (plan_res.get("analysis") or {}).get("code"):
            body = plan_res["analysis"]["code"]["code"]
            meta = plan_res.get("llm_code") or {}
            files_out["code_draft"] = write(
                "code_draft.py", plan.CODE_HEADER.format(sha=plan_res["code_sha256"], model=meta.get("model"),
                                                         fp=meta.get("prompt_fingerprint")) + body,
                "2-1c", [plan_hash, raw_hash], {**llm_params(meta), "code_sha256": plan_res["code_sha256"]})
    if checks is not None:
        files_out["2-3"] = write("data_checks.json", checks, "2-3", [raw_hash, spec_hash, plan_hash], {"spec_status": "승인 전(잠정)"})
    if miss is not None:
        files_out["2-4"] = write("missing_check.json", miss, "2-4", [plan_hash, raw_hash], llm_params(miss.get("llm")))

    questions = []
    for g in groups:
        questions += [{"from": f"2-1a {g['group_id']}", "q": q} for q in ((g.get("analysis") or {}).get("questions") or [])]
    for i in spec_items:
        questions += [{"from": f"2-2 {i['file']}", "q": q} for q in ((i.get("analysis") or {}).get("questions") or [])]
    questions += [{"from": "2-1c", "q": q} for q in (((plan_res or {}).get("analysis") or {}).get("questions") or [])]
    questions += [{"from": "2-4", "q": q} for q in (((miss or {}).get("required") or {}).get("questions") or [])]
    questions += [{"from": "2-1b", "q": f"{e['id']} 수식을 읽지 못함 — 직접 적어 주세요 ({e.get('error')})"}
                  for e in (eqs or {}).get("equations", []) if e["status"] != "ok"]

    summary = {
        "step": "2 EXTRACT", "run_id": run_id, "project": snap["project"], "started_at": started,
        "finished_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "llm": {**llm.status(), **llm.stats}, "steps": steps, "notices": notices,
        "corrections_applied": bool(corrections),
        "blind": {"report_opened": False, "report_files_not_read": [f["path"] for f in snap["files"] if f["zone"] == "report"]},
        "counts": {
            "equations": len((eqs or {}).get("equations", [])), "equations_failed": len((eqs or {}).get("failed", [])),
            "header_groups": len(groups),
            "spec_entries": sum(len((i.get("analysis") or {}).get("entries", [])) for i in spec_items),
            "spec_unverified": sum(1 for i in spec_items for e in ((i.get("analysis") or {}).get("entries") or []) if not e.get("verified")),
            "E01": len((checks or {}).get("e01", [])), "E02": sum(((checks or {}).get("e02_counts") or {}).values()),
            "E03": len(((miss or {}).get("comparison") or {}).get("e03", [])), "questions": len(questions)},
        "questions": questions, "outputs": files_out,
    }
    summary_path = out_dir / "extract_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return {**summary, "equations": eqs, "headers": head, "spec": spec_res, "plan": plan_res, "checks": checks,
            "missing": miss, "lineage": lineage}


def extract_view(run_id: str) -> dict:
    """저장된 2 EXTRACT 산출물로 결과 화면을 다시 만든다(LLM 다시 안 부름) — 페이지를 새로 열어도 이어서 보기."""
    d = find_snapshot(run_id).parent / "extract"
    if not (d / "extract_summary.json").exists():
        raise ValueError("아직 2 EXTRACT 를 실행하지 않음")
    load = lambda n: json.loads((d / n).read_text(encoding="utf-8")) if (d / n).exists() else None   # noqa: E731
    latest = {}
    for e in ledger.entries(run_id):
        if e.get("step", "").endswith("EXTRACT"):
            latest[(e["step"], e["outputs"][0]["path"])] = e
    return {**load("extract_summary.json"), "equations": load("equations.json"), "headers": load("headers.json"),
            "spec": load("spec_conditions.json"), "plan": load("plan_extraction.json"), "checks": load("data_checks.json"),
            "missing": load("missing_check.json"), "lineage": list(latest.values())}
