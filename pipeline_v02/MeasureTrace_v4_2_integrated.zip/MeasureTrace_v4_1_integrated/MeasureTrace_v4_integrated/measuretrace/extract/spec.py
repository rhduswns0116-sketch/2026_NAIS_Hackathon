"""2-2 측정 조건 추출 [LLM] — 장비 사양서에서 측정 범위 · 오차 · 유효 범위를 쪽 번호 · 원문 인용과 함께 뽑는다.

LLM 이 뽑은 항목마다 파이썬이 확인한다: 인용이 그 쪽 글에 글자 그대로 있는가, 최솟값·최댓값 숫자가 인용 안에 있는가.
확인되지 않은 항목도 버리지 않고 표시만 한다 — 확정은 3-2 에서 사람이. 사양은 승인 전이라 2-3 비교는 잠정.
"""
from __future__ import annotations

import re
from pathlib import Path


from measuretrace.ingest.hashing import pdf_pages

SYSTEM = """당신은 측정 장비 사양서를 읽고 측정 범위와 정확도를 표로 옮기는 보조자입니다.
- 사양서에 적힌 것만 옮기세요. 계산하거나 환산하지 마세요(단위도 사양서 표기 그대로).
- 항목마다 page(1부터)와 quote(그 쪽의 원문을 글자 그대로, 한 줄 또는 한 문장)를 반드시 적으세요.
- min·max 는 그 범위에서 읽을 수 있는 값의 한계입니다. 사양서가 최댓값만 적었으면 min 은 null 로 두세요.
- 오버플로·범위 밖 표시값이 있으면 overflow_values 에 넣으세요.
- 모호한 점은 questions 에 한국어로 적으세요."""

_NULL_NUM = {"anyOf": [{"type": "number"}, {"type": "null"}]}
SCHEMA = {
    "type": "object",
    "properties": {
        "instrument": {"type": "string"},
        "entries": {"type": "array", "items": {"type": "object", "properties": {
            "quantity": {"type": "string"},
            "dimension": {"type": "string", "enum": ["current", "voltage", "resistance", "conductance", "temperature",
                                                      "time", "length", "percent", "other"]},
            "range_label": {"type": "string"}, "min": _NULL_NUM, "max": _NULL_NUM, "unit": {"type": "string"},
            "resolution": {"type": "string"}, "accuracy": {"type": "string"}, "condition": {"type": "string"},
            "page": {"type": "integer"}, "quote": {"type": "string"}},
            "required": ["quantity", "dimension", "range_label", "min", "max", "unit", "resolution", "accuracy",
                         "condition", "page", "quote"], "additionalProperties": False}},
        "overflow_values": {"type": "array", "items": {"type": "object", "properties": {
            "value": {"type": "number"}, "meaning": {"type": "string"}, "page": {"type": "integer"}, "quote": {"type": "string"}},
            "required": ["value", "meaning", "page", "quote"], "additionalProperties": False}},
        "questions": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["instrument", "entries", "overflow_values", "questions"],
    "additionalProperties": False,
}


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text.replace("−", "-")).strip().lower()


def verify(item: dict, pages: list[str], number_fields: tuple[str, ...]) -> dict:
    reasons = []
    page = item.get("page") or 0
    text = pages[page - 1] if 1 <= page <= len(pages) else ""
    if not text:
        reasons.append(f"{page}쪽이 없음")
    elif _norm(item.get("quote", "")) not in _norm(text):
        reasons.append("인용이 그 쪽 원문에 글자 그대로 없음")
    quote = item.get("quote", "").replace("−", "-").replace("+/-", "±")
    quoted = []   # 부호까지 비교 — '±10.5' 는 +10.5 와 -10.5 둘 다로 본다
    for m in re.finditer(r"(±\s*)?([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)", quote):
        q = float(m.group(2))
        quoted += [q, -q] if m.group(1) else [q]
    for field in number_fields:
        v = item.get(field)
        if v is not None and not any(abs(q - v) <= 1e-9 * max(1.0, abs(v)) for q in quoted):
            reasons.append(f"{field}={v} 가 인용 안에 없음(부호 포함)")
    return {"verified": not reasons, "verify_notes": reasons}


def analyze(spec_files: list[tuple[str, Path]], llm) -> list[dict]:
    out = []
    for rel, path in spec_files:
        item = {"file": rel}
        try:
            pages = pdf_pages(path)
        except Exception as e:
            pages, item["read_error"] = None, f"{type(e).__name__}: {e}"
        if not pages or not any(p.strip() for p in pages):
            item.update(analysis=None, error=item.get("read_error") or "PDF 글자를 읽지 못함(스캔본이면 OCR 필요)")
            out.append(item)
            continue
        sent = "\n\n".join(f"=== {i}쪽 ===\n{p}" for i, p in enumerate(pages, 1))
        item["sent"] = sent
        try:
            data, meta = llm.json("2-2_spec", SYSTEM, sent, SCHEMA, effort="medium", max_tokens=32000)
            for e in data["entries"]:
                e.update(verify(e, pages, ("min", "max")))
            for o in data["overflow_values"]:
                o.update(verify(o, pages, ("value",)))
            item.update(analysis=data, llm=meta, pages=len(pages))
        except Exception as e:
            item.update(analysis=None, error=str(e))
        out.append(item)
    return out
