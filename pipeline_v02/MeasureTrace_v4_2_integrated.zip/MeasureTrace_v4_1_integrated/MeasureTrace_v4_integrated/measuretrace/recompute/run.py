"""4 RECOMPUTE — 승인된 코드로 재계산한다 [PY]. 파이프라인 v4 확정본 §4-4.

통합(2026-09-30): 계산은 **뒷단 엔진 한 곳에서 한 번** 한다(measuretrace/bridge.run_step4 → backend run_discovery).
예전에는 앞단 격리 실행과 뒷단 격리 실행이 같은 코드를 두 번 돌렸다. 이 모듈은 화면·시험이 쓰던 4단계 기록 형식을 유지한다.

  4-1 수치 재계산  입력은 RAW 만. 실행 전 확인(승인 코드 해시 · 추출 결과 · RAW 해시 · 정적 점검 · 미확정 없음)은
                   연결 코드와 뒷단 엔진이 하고, 하나라도 어긋나면 실행하지 않는다.
  4-2 계산 로그    뒷단 계산 로그(runs/<뒷단 실행>/calc_log.json)가 근거. 여기는 화면용 요약(결과·중간값·확인 목록).
  E07 미리보기     같은 프로젝트의 이전 4단계 기록과 데이터 해시를 비교해 행·열 차이를 보여 준다. 판정에 붙는 E07 기록은
                   6-2(뒷단)가 이전 감사 실행과 비교해 남긴다.
보고서는 열지 않는다(R4, 블라인드). 계산 시각을 남겨 5-1 의 보고서 열람 시각보다 앞섬을 입증한다.
"""
from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime
from pathlib import Path

from measuretrace import ledger
from measuretrace.confirm.items import phash
from measuretrace.extract.run import find_snapshot
from measuretrace.ingest.hashing import row_diff
from measuretrace.paths import OUTPUTS_DIR, PACKAGE_DIR, rel

# 장부의 '실행한 코드' 해시 — 4단계 요약(여기) + 연결 코드 + 실제로 실행하는 뒷단 엔진
RECOMPUTE_CODE = [PACKAGE_DIR / "recompute", PACKAGE_DIR / "bridge.py", PACKAGE_DIR / "backend" / "recompute",
                  PACKAGE_DIR / "ledger.py"]


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _approved_body(path: Path) -> str:
    """approved_code.py = 머리말(주석 3줄) + 빈 줄 + 본문. 본문만 돌려준다."""
    text = path.read_text(encoding="utf-8")
    return text.split("\n\n", 1)[1] if text.startswith("# MeasureTrace") else text


def _validate(result) -> tuple[list[dict], dict, list[str]]:
    problems = []
    if not isinstance(result, dict) or not isinstance(result.get("results"), list):
        return [], {}, ["compute() 가 {'results': [...]} 형식을 돌려주지 않음"]
    rows = []
    for i, r in enumerate(result["results"]):
        if not isinstance(r, dict):
            problems.append(f"results[{i}] 가 객체가 아님")
            continue
        v = r.get("value")
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(float(v)):
            problems.append(f"results[{i}] '{r.get('name')}' 값이 유한한 숫자가 아님: {v!r}")
        for k in ("name", "unit"):
            if not r.get(k) and r.get(k) != "":
                problems.append(f"results[{i}] 에 {k} 없음")
        rows.append({k: r.get(k) for k in ("name", "symbol", "value", "unit", "eq_id", "condition")})
    return rows, result.get("intermediate") or {}, problems


def _read_log(path: Path) -> dict:
    """이전 계산 로그 하나 — E07 비교에 쓸 모양이 아니면 ValueError."""
    log = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(log, dict) or not isinstance(log.get("run_id"), str) or not isinstance(log.get("inputs"), list) \
            or not all(isinstance(i, dict) and {"path", "sha256", "content_hash"} <= set(i) for i in log["inputs"]):
        raise ValueError("run_id·inputs(path·sha256·content_hash) 형식이 아님")
    return log


def _previous_log(project: str, run_id: str, excluded: list[dict] | None = None) -> tuple[dict, dict] | None:
    """같은 프로젝트의 가장 최근 성공 계산 로그와 그 실행의 1단계 스냅샷.
    읽지 못하는 기록(손상·형식 다름)은 건너뛰고 excluded 에 사유를 남긴다 — 과거 기록 하나 때문에 새 계산이 멈추지 않게."""
    base = OUTPUTS_DIR / project
    if not base.is_dir():
        return None
    ok = []
    for d in sorted(base.iterdir()):
        if not d.is_dir() or d.name == run_id:
            continue
        for path in sorted((d / "recompute" / "history").glob("calc_log_*.json")):
            try:
                log = _read_log(path)
            except (OSError, UnicodeDecodeError, ValueError) as e:   # json.JSONDecodeError 는 ValueError
                if excluded is not None:
                    excluded.append({"file": rel(path), "reason": f"{type(e).__name__}: {e}"})
                continue
            if log.get("status") == "ok":
                ok.append((str(log.get("finished_at") or ""), path.name, path, log))
    if not ok:
        return None
    _, _, latest, log = max(ok, key=lambda x: (x[0], x[1]))
    snap_path = latest.parents[2] / "ingest_snapshot.json"
    try:
        snap = json.loads(snap_path.read_text(encoding="utf-8")) if snap_path.exists() else {}
        if not isinstance(snap, dict):
            raise ValueError("객체가 아님")
    except (OSError, UnicodeDecodeError, ValueError) as e:
        # 스냅샷이 없으면 해시 비교는 하되 표의 행·열 차이는 못 낸다
        if excluded is not None:
            excluded.append({"file": rel(snap_path), "reason": f"{type(e).__name__}: {e} — 행·열 차이 없이 해시만 비교"})
        snap = {}
    return log, snap


def e07_record(prev: tuple[dict, dict] | None, inputs: list[dict], results: list[dict], snap: dict,
               excluded: list[dict] | None = None) -> dict:
    """E07 데이터 버전 변경 — 기록(판정 안 바꿈). 바이트만 다르고 내용 같으면 '형식만 변경'. 표는 행·열 차이.
    excluded: 읽지 못해 비교에서 뺀 이전 기록과 사유."""
    out = _e07(prev, inputs, results, snap)
    if excluded:
        out["excluded"] = excluded
        out["note"] += f" · 읽지 못한 이전 기록 {len(excluded)}개는 제외함"
    return out


def _e07(prev: tuple[dict, dict] | None, inputs: list[dict], results: list[dict], snap: dict) -> dict:
    if prev is None:
        return {"compared_with": None, "note": "첫 계산 — 비교할 이전 계산 로그 없음 (첫 실행 이전 삭제는 알 수 없음)"}
    log, prev_snap = prev
    old = {i["path"]: i for i in log["inputs"]}
    new = {i["path"]: i for i in inputs}
    old_tab = {f["path"]: (f.get("content") or {}).get("table") for f in prev_snap.get("files", []) if f["zone"] == "data"}
    new_tab = {f["path"]: (f.get("content") or {}).get("table") for f in snap["files"] if f["zone"] == "data"}
    changes = []
    for path in sorted(set(old) | set(new)):
        o, n = old.get(path), new.get(path)
        if o is None:
            changes.append({"code": "E07", "file": path, "kind": "추가"})
        elif n is None:
            changes.append({"code": "E07", "file": path, "kind": "삭제"})
        elif o["sha256"] != n["sha256"]:
            if o["content_hash"] == n["content_hash"]:
                changes.append({"code": "E07", "file": path, "kind": "형식만 변경"})
            else:
                d = row_diff(old_tab.get(path), new_tab.get(path))
                item = {"code": "E07", "file": path, "kind": "내용 변경"}
                if d:
                    item["rows"] = {k: d.get(k) for k in ("rows_before", "rows_after", "rows_changed", "rows_added", "rows_removed")}
                    item["columns"] = {"added": d["columns_added"], "removed": d["columns_removed"]}
                    item["detail"] = (f"{d['rows_before']} → {d['rows_after']}행"
                                      + (f" (바뀜 {d.get('rows_changed', 0)} · 추가 {d.get('rows_added', 0)} · 빠짐 {d.get('rows_removed', 0)})"
                                         if "rows_changed" in d else ""))
                changes.append(item)
    key = lambda r: (r.get("name"), r.get("condition"), r.get("eq_id"))   # noqa: E731
    old_res = {key(r): r for r in log.get("results", [])}
    res_changes = [{"name": r["name"], "condition": r.get("condition"), "before": old_res[key(r)]["value"], "after": r["value"]}
                   for r in results if key(r) in old_res and old_res[key(r)]["value"] != r["value"]]
    return {"compared_with": log["run_id"], "input_hash_before": log.get("input_hash"), "changes": changes,
            "result_changes": res_changes, "note": "E07 은 기록 — 판정을 바꾸지 않음(6-2 에서 수정 전·후 비교에 씀)"}


def run_recompute(run_id: str) -> dict:
    snap_path = find_snapshot(run_id)
    base = snap_path.parent
    snap = json.loads(snap_path.read_text(encoding="utf-8"))
    conf_path = base / "confirm" / "confirmed.json"
    if not conf_path.exists():
        raise ValueError("3 CONFIRM 이 끝나지 않음 — confirmed.json 이 없음")
    confirmed = json.loads(conf_path.read_text(encoding="utf-8"))
    out_dir = base / "recompute"
    out_dir.mkdir(exist_ok=True)
    started = _now()
    raw = [f for f in snap["files"] if f["zone"] == "data" and f["category"] == "raw"]
    inputs = [{"path": f["path"], "sha256": f["sha256"], "content_hash": f["content_hash"], "normalization": f["normalization"],
               "rows": ((f.get("content") or {}).get("table") or {}).get("n_rows")} for f in raw]
    input_hash = hashlib.sha256("\n".join(sorted(f"{i['path']}\t{i['sha256']}" for i in inputs)).encode("utf-8")).hexdigest()
    log = {"step": "4 RECOMPUTE", "run_id": run_id, "project": snap["project"], "started_at": started,
           "inputs": inputs, "input_hash": input_hash, "confirmed_sha256": hashlib.sha256(conf_path.read_bytes()).hexdigest(),
           "confirm_status": confirmed["status"], "unresolved": confirmed.get("unresolved", []),
           "remeasure": confirmed.get("remeasure", []),
           "process": [{"step": s.get("step"), "description": s.get("description"), "eq_ids": s.get("eq_ids")}
                       for s in (confirmed.get("processing") or [])],
           "blind": {"report_opened": False, "report_files": [f["path"] for f in snap["files"] if f["zone"] == "report"],
                     "note": "보고서는 5-1 에서 처음 연다 — 그때 열람 시각을 기록해 이 계산 시각보다 뒤임을 남긴다"},
           "checks": []}

    excluded: list[dict] = []
    prev = _previous_log(snap["project"], run_id, excluded)
    log["e07"] = e07_record(prev, inputs, [], snap, excluded)   # 데이터 비교는 계산 성공 여부와 상관없이 기록

    def blocked(reason: str) -> dict:
        log.update(status="blocked", reason=reason, finished_at=_now(), results=[], intermediate={})
        return _finish(log, out_dir, confirmed, None)

    code = confirmed.get("code")
    if code:
        code_path = base / "confirm" / "approved_code.py"
        body = _approved_body(code_path)
        log["code"] = {"sha256": hashlib.sha256(body.encode("utf-8")).hexdigest(), "approved_sha256": code["sha256"],
                       "path": rel(code_path), "approved_by": code.get("approved_by"),
                       "approved_at": code.get("approved_at")}
    # 실행은 뒷단 엔진 한 곳에서 (통합: 앞단·뒷단 두 번 실행하던 것을 한 번으로). 실행 전 확인도 그쪽에서 한다.
    from measuretrace import bridge
    try:
        step = bridge.run_step4(run_id)
    except ValueError as e:
        return blocked(str(e))
    calc = step["calc"]
    log["checks"] = step["checks"]
    log["backend"] = {"run_id": step["backend_run_id"], "handoff": step["handoff"], "mode": calc.get("mode"),
                      "execution_sha256": calc.get("execution_sha256"), "status": calc.get("status"),
                      "note": "뒷단 엔진 탐색 실행 — 5·6 은 이 계산 로그를 그대로 쓴다(재실행 없음)"}
    runner = calc.get("runner") or {}
    try:
        seconds = round((datetime.fromisoformat(calc["finished_at"]) - datetime.fromisoformat(calc["started_at"]))
                        .total_seconds(), 3)
    except (KeyError, TypeError, ValueError):
        seconds = None
    log["sandbox"] = {"mode": "뒷단 격리 실행 (python -I + 감사 훅, RAW 실행 사본)", "seconds": seconds,
                      "timeout_s": runner.get("timeout_s"),
                      "policy": runner.get("execution_policy"), "denied": [], "versions": calc.get("versions"),
                      "stderr": (runner.get("stderr_tail") or "")[-1500:],
                      "limits": "운영체제 수준 격리(컨테이너·VM) 아님 — 로컬 데모용 방어선"}
    if calc.get("status") not in ("ok", "partial"):
        state = "blocked" if calc.get("status") == "blocked" else "error"
        reason = calc.get("error") or calc.get("status")
        if not code:
            reason = "승인된 계산 코드가 없음(3-1 미확정·거부) — 계산하지 않고 기록만 남김. 5·6 에서 모든 수치 주장은 E06(미확정)"
        log.update(status=state, reason=reason, finished_at=_now(),
                   results=[], intermediate={})
        return _finish(log, out_dir, confirmed, (calc.get("code") or {}).get("sha256"))
    rows = [{k: r.get(k) for k in ("name", "symbol", "value", "unit", "eq_id", "condition", "id")} for r in step["rows"]]
    bad = [f"{k}: {v}" for k, v in (calc.get("produced_invalid") or {}).items()]
    log["checks"].append({"check": "결과 형식(유한한 숫자)", "ok": not bad, "problems": bad})
    log.update(status="ok" if not bad else "error", reason=None if not bad else "; ".join(bad), results=rows,
               intermediate=((calc.get("produced_meta") or {}).get("intermediate") or {}), result_hash=phash(rows),
               finished_at=calc.get("finished_at") or _now(), warnings=step.get("warnings", []))
    log["e07"] = e07_record(prev, inputs, rows, snap, excluded)
    return _finish(log, out_dir, confirmed, (calc.get("code") or {}).get("sha256"))


def _finish(log: dict, out_dir: Path, confirmed: dict, code_sha: str | None) -> dict:
    text = json.dumps(log, ensure_ascii=False, indent=2)
    history = out_dir / "history"
    history.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    (history / f"calc_log_{stamp}.json").write_text(text, encoding="utf-8")   # 계산할 때마다 남김 (덮어쓰지 않음)
    path = out_dir / "calc_log.json"   # 가장 최근 것
    path.write_text(text, encoding="utf-8")
    runner = ledger.code_hash(*RECOMPUTE_CODE)
    code = {"sha256": code_sha or "", "files": [log.get("code", {}).get("path", "(승인 코드 없음)")]}
    entry = ledger.record("4 RECOMPUTE", log["run_id"], log["input_hash"], code,
                          {"runner_code_sha256": runner["sha256"], "confirmed_sha256": log["confirmed_sha256"],
                           "status": log["status"], "result_hash": log.get("result_hash")}, [path])
    return {**log, "log_path": rel(path), "lineage": entry}
