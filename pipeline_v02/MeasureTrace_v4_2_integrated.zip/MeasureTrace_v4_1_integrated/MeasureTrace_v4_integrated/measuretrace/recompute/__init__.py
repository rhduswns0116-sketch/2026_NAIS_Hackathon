"""4 RECOMPUTE — 승인된 코드로 재계산한다. 진입점: run_recompute(run_id).

sandbox 는 2-1c(코드 초안 규칙·정적 점검)에서도 쓰므로, 여기서는 run 을 늦게 불러 순환 import 를 피한다.
"""


def run_recompute(run_id: str) -> dict:
    from measuretrace.recompute.run import run_recompute as _run
    return _run(run_id)
