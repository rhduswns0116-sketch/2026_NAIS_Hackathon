"""계산 코드 규칙 [PY] — 2-1c 코드 초안 지시문 · 2-1c/3-1 정적 점검 (R6).

통합(2026-09-30): 실행은 뒷단 엔진(backend/recompute)이 한 번만 한다. 앞단 격리 실행기(runner.py)와 run() 은 없앴다.
정적 점검은 앞단 규칙(허용 import 목록 · 쓰기 open · os.path 밖 os) + **뒷단 실행기 규칙**(backend _runner.static_violations)을
함께 적용한다 — 3-1 에서 승인한 코드가 4단계 실행에서 막히지 않게(규칙 한 곳, 앞단 B7 과 같은 취지).
rules_text() 는 2-1c 코드 초안 지시문에 들어가므로 문구를 바꾸면 LLM 캐시가 무효가 된다 — 뒷단 규칙 문구 추가는 실제 API 로
2단계를 다시 돌릴 수 있을 때 함께 한다. 그 전까지는 정적 점검이 위반 초안의 승인을 막는다.
"""
from __future__ import annotations

import ast
# 계산 코드가 쓸 수 있는 모듈 — 2-1c 코드 초안 지시문도 이 목록을 그대로 쓴다(지시와 검사가 어긋나지 않게)
ALLOWED_IMPORTS = ("csv", "math", "statistics", "collections", "itertools", "functools", "re", "json", "typing",
                   "dataclasses", "decimal", "fractions", "os.path", "pathlib", "numpy", "scipy")
BLOCKED_IMPORTS = {"subprocess", "socket", "ssl", "ctypes", "shutil", "multiprocessing", "requests", "urllib", "http",
                   "ftplib", "smtplib", "importlib", "pickle", "marshal", "winreg", "asyncio", "threading", "concurrent",
                   "webbrowser", "anthropic", "dotenv", "sqlite3", "builtins", "sys", "io", "glob", "tempfile"}
BLOCKED_CALLS = {"eval", "exec", "compile", "__import__", "globals", "locals", "vars", "getattr", "setattr", "delattr",
                 "breakpoint", "input"}
OS_ALLOWED = {"path"}   # os.path.* 만 허용


def rules_text() -> str:
    """코드 초안 지시문에 넣을 규칙 — 정적 점검과 같은 내용."""
    return (f"- import 는 이것만: {', '.join(ALLOWED_IMPORTS)} (os 는 os.path 만).\n"
            f"- 쓰지 말 것: {', '.join(sorted(BLOCKED_IMPORTS))} 모듈, {', '.join(sorted(BLOCKED_CALLS))} 호출, "
            "쓰기 모드 open, 밑줄 두 개로 시작하는 특수 속성.")


def static_check(code: str) -> list[str]:
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return [f"문법 오류: {e}"]
    problems = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] in BLOCKED_IMPORTS:
                    problems.append(f"{node.lineno}줄: import {a.name} 금지")
        elif isinstance(node, ast.ImportFrom):
            mod = (node.module or "").split(".")[0]
            if mod in BLOCKED_IMPORTS:
                problems.append(f"{node.lineno}줄: from {node.module} import 금지")
            if mod == "os" and any(a.name not in OS_ALLOWED for a in node.names):
                problems.append(f"{node.lineno}줄: from os import {[a.name for a in node.names]} — os.path 만 허용")
        elif isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name) and f.id in BLOCKED_CALLS:
                problems.append(f"{node.lineno}줄: {f.id}() 호출 금지")
            if isinstance(f, ast.Name) and f.id == "open":
                mode = node.args[1] if len(node.args) > 1 else next((k.value for k in node.keywords if k.arg == "mode"), None)
                if mode is not None and not (isinstance(mode, ast.Constant) and isinstance(mode.value, str)
                                             and not set(mode.value) & set("wax+")):
                    problems.append(f"{node.lineno}줄: open() 은 읽기 모드 글자로만 허용")
        elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "os":
            if node.attr not in OS_ALLOWED:
                problems.append(f"{node.lineno}줄: os.{node.attr} 금지 — os.path 만 허용")
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__") and node.attr not in ("__name__", "__init__"):
            problems.append(f"{node.lineno}줄: 특수 속성 {node.attr} 접근 금지")
    # 4단계에서 실제로 실행하는 뒷단 실행기의 규칙 — 여기서 통과해야 실행에서도 통과한다
    from measuretrace.backend.recompute._runner import static_violations
    problems += [f"(실행기 규칙) {p}" for p in static_violations(code) if p not in problems]
    return list(dict.fromkeys(problems))
