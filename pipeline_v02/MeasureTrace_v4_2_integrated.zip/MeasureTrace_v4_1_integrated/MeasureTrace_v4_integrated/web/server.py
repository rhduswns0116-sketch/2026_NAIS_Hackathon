"""MeasureTrace v4 웹 화면 — 로컬 서버.

  python web/server.py                 # → http://127.0.0.1:8765 (브라우저 자동으로 열림, 끄기 Ctrl+C)
  python web/server.py --port 9000 --no-browser

흐름: 화면에서 파일·폴더를 끌어다 놓고 [시작] → POST /api/runs (새 실행) → PUT /api/runs/<id>/files (파일마다)
      → POST /api/runs/<id>/ingest → [2 EXTRACT] POST /api/runs/<id>/extract (LLM 사용 — 토큰)
      → [3 CONFIRM] POST /api/runs/<id>/confirm/start · POST /api/runs/<id>/confirm/submit
      → [4 RECOMPUTE] POST /api/runs/<id>/recompute (뒷단 엔진이 승인 코드를 한 번 격리 실행 — 결과 전부 기록)
      → [5·6] GET /api/runs/<id>/handoff (4단계 결과로 만든 인계 묶음 미리보기)
              · POST /api/runs/<id>/audit (승인 봉인 → 같은 계산에 항목 결합(재계산 없음) → 5→6, LLM 사용)
이어서 보기: GET /api/runs (실행 목록) · GET /api/runs/<id>/{ingest,extract,confirm,recompute,audit} (저장된 결과, 다시 실행 안 함)

표준 라이브러리만 쓰고 이 컴퓨터(127.0.0.1)에서만 열린다. 다른 웹사이트가 이 서버를 부르지 못하게
Host·Origin 을 확인하고, 쓰기 요청에는 화면이 붙이는 헤더(X-MeasureTrace)를 요구한다.
"""
from __future__ import annotations

import json
import sys
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

WEB_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(WEB_DIR.parent))
from measuretrace import bridge, confirm, ledger  # noqa: E402
from measuretrace.extract import run_extract  # noqa: E402
from measuretrace.extract.run import extract_view, find_snapshot  # noqa: E402
from measuretrace.ingest import run_ingest, workspace  # noqa: E402
from measuretrace.ingest.run import ingest_view, list_runs  # noqa: E402
from measuretrace.llm import LLM  # noqa: E402
from measuretrace.recompute import run_recompute  # noqa: E402

STATIC = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"),
          "/extract.js": ("extract.js", "text/javascript"), "/confirm.js": ("confirm.js", "text/javascript"),
          "/recompute.js": ("recompute.js", "text/javascript"), "/audit.js": ("audit.js", "text/javascript"),
          "/style.css": ("style.css", "text/css")}
MAX_UPLOAD = 2 * 1024 ** 3
WRITE_HEADER = "X-MeasureTrace"


class Handler(BaseHTTPRequestHandler):
    port = 8765   # main() 이 실제 포트로 바꾼다

    # ── 응답 ────────────────────────────────────────────────────────
    def _send(self, status: int, body: bytes, ctype: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", f"{ctype}; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, data) -> None:
        self._send(status, json.dumps(data, ensure_ascii=False, default=str).encode("utf-8"), "application/json")

    def _route(self) -> tuple[list[str], dict]:
        url = urlparse(self.path)
        return [unquote(p) for p in url.path.strip("/").split("/") if p], parse_qs(url.query)

    def _body(self) -> dict:
        return json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")

    def _guard(self, fn) -> None:
        try:
            fn()
        except ValueError as e:
            self._json(400, {"error": str(e)})
        except Exception as e:
            traceback.print_exc()
            self._json(500, {"error": f"{type(e).__name__}: {e}"})

    # ── 요청 출처 확인 ───────────────────────────────────────────────
    def _trusted(self, write: bool) -> bool:
        """Host 가 이 컴퓨터 주소여야 하고(DNS 리바인딩 차단), Origin 이 있으면 이 화면이어야 한다.
        쓰기 요청(POST·PUT)은 X-MeasureTrace 헤더가 있어야 한다 — 다른 사이트의 단순 요청(form·text/plain)은 이 헤더를
        붙일 수 없고, 붙이려면 사전 요청(OPTIONS)을 거치는데 이 서버는 허락하지 않는다."""
        hosts = {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}
        if self.headers.get("Host") not in hosts:
            return False
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://{h}" for h in hosts}:
            return False
        return not write or self.headers.get(WRITE_HEADER) == "1"

    def _refuse(self) -> None:
        # 거절할 때도 본문은 읽어 버린다(최대 1 MB). 읽지 않은 채 연결을 닫으면 Windows 는 연결을 재설정(RST)해
        # 클라이언트가 403 응답을 못 받고 '연결 중단'으로 끝날 수 있다. 큰 본문은 읽지 않고 연결을 닫는다.
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if 0 < length <= 1 << 20:
            self.rfile.read(length)
        else:
            self.close_connection = True
        self._json(403, {"error": "허용되지 않은 요청 — 이 컴퓨터의 MeasureTrace 화면에서만 쓸 수 있음"})

    def do_OPTIONS(self) -> None:
        self._refuse()

    # ── 읽기 ────────────────────────────────────────────────────────
    def do_GET(self) -> None:
        if not self._trusted(write=False):
            return self._refuse()
        parts, _ = self._route()
        path = "/" + "/".join(parts)
        if path in STATIC:
            name, ctype = STATIC[path]
            return self._send(200, (WEB_DIR / "static" / name).read_bytes(), ctype)
        if path == "/api/ledger":
            return self._json(200, ledger.recent(30))
        if path == "/api/status":
            return self._json(200, {"llm": LLM().status()})
        if parts == ["api", "runs"]:
            return self._guard(lambda: self._json(200, list_runs()))
        if len(parts) == 4 and parts[:2] == ["api", "runs"]:
            rid, what = parts[2], parts[3]
            views = {"ingest": lambda: ingest_view(rid), "extract": lambda: extract_view(rid),
                     "confirm": lambda: confirm.get(rid), "recompute": lambda: _last_calc_log(rid),
                     "handoff": lambda: bridge.preview(rid), "audit": lambda: bridge.get(rid)}
            if what in views:
                return self._guard(lambda: self._json(200, views[what]()))
        self._send(404, b"not found", "text/plain")

    # ── 쓰기 ────────────────────────────────────────────────────────
    def do_POST(self) -> None:
        if not self._trusted(write=True):
            return self._refuse()
        parts, _ = self._route()

        def handle():
            if parts == ["api", "runs"]:
                return self._json(200, {"run_id": workspace.new_run()})
            if len(parts) == 4 and parts[:2] == ["api", "runs"]:
                rid, what = parts[2], parts[3]
                if what == "ingest":
                    return self._json(200, run_ingest(rid, self._body().get("project")))
                if what == "extract":
                    return self._json(200, run_extract(rid))
                if what == "recompute":
                    return self._json(200, run_recompute(rid))
                if what == "audit":
                    body = self._body()
                    return self._json(200, bridge.run(rid, body.get("respondent", ""), body.get("bundle_sha256", ""),
                                                      body.get("report") or None))
            if len(parts) == 5 and parts[:2] == ["api", "runs"] and parts[3] == "confirm":
                if parts[4] == "start":
                    return self._json(200, confirm.start(parts[2]))
                if parts[4] == "submit":
                    body = self._body()
                    return self._json(200, confirm.submit(parts[2], body.get("respondent", ""), body.get("answers") or {}))
            self._send(404, b"not found", "text/plain")
        self._guard(handle)

    def do_PUT(self) -> None:
        if not self._trusted(write=True):
            return self._refuse()
        parts, query = self._route()

        def handle():
            if not (len(parts) == 4 and parts[:2] == ["api", "runs"] and parts[3] == "files"):
                return self._send(404, b"not found", "text/plain")
            length = int(self.headers.get("Content-Length") or 0)
            if length > MAX_UPLOAD:
                raise ValueError("파일이 너무 큼 (2 GB 초과)")
            zone = (query.get("zone") or [""])[0]
            rel = (query.get("path") or [""])[0]
            self._json(200, workspace.save_upload(parts[2], zone, rel, self.rfile, length))
        self._guard(handle)

    def log_message(self, fmt, *args) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")


def _last_calc_log(run_id: str) -> dict:
    p = find_snapshot(run_id).parent / "recompute" / "calc_log.json"
    if not p.exists():
        raise ValueError("아직 4 RECOMPUTE 를 실행하지 않음")
    return json.loads(p.read_text(encoding="utf-8"))


def main() -> int:
    port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else 8765
    Handler.port = port
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}"
    print(f"MeasureTrace v4 화면: {url}   (끄기: Ctrl+C)")
    if "--no-browser" not in sys.argv:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
