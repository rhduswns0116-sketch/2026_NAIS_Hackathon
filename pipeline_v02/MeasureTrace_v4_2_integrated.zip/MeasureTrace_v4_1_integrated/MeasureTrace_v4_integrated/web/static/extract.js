// 2 EXTRACT 화면 — 실행 버튼과 결과 그리기. 계산·판정은 서버(Python)가 하고, 여기서는 결과를 보여 주기만 한다.
(function () {
  const X = (s) => document.querySelector(s);
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const H = (h, n = 12) => (h ? E(String(h).slice(0, n)) : "—");
  const STEP_NAMES = { "2-1a": "데이터 내용 파악", "2-1b": "계획서 수식 변환", "2-1c": "연구 내용 추출", "2-2": "측정 조건 추출", "2-3": "데이터 구조화", "2-4": "누락 점검" };
  const ORDER = ["2-1a", "2-1b", "2-1c", "2-2", "2-3", "2-4"];
  let llmStatus = null;

  async function status() {
    if (llmStatus) return llmStatus;
    try { llmStatus = (await (await fetch("/api/status")).json()).llm; } catch { llmStatus = { available: false }; }
    return llmStatus;
  }

  window.showExtractLauncher = async function (ingest) {
    const el = X("#extract"), s = await status();
    const blocked = ingest.findings.filter((f) => f.level === "bad");
    el.hidden = false;
    el.innerHTML = `<section class="part launcher"><div class="card">
      <div class="row2"><div><b>2 EXTRACT</b> — 식·조건·데이터 파악 <span class="muted">(LLM 은 헤더·계획서·사양서만 보고 측정값은 보지 않음 · 보고서는 열지 않음)</span>
        <div class="m">LLM: ${s.available ? `${E(s.model)}${s.offline ? " · 오프라인(캐시만)" : ""} · 키 ${E(s.key_source || "")}` : `<span class="bad">사용 불가 — API 키 없음 (LLM 과업은 실패로 기록되고 파이썬 과업만 진행)</span>`}
        ${blocked.length ? `<br><span class="warn">1단계 '막힘' ${blocked.length}건이 있어도 실행은 되지만 해당 과업은 실패합니다.</span>` : ""}</div></div>
        <button id="run_extract" type="button">2 EXTRACT 실행</button></div>
      <div id="extract_status" class="m" style="margin-top:8px"></div></div></section>`;
    X("#run_extract").addEventListener("click", () => runExtract(ingest.run_id));
  };

  async function runExtract(runId) {
    const btn = X("#run_extract"), st = X("#extract_status");
    btn.disabled = true;
    const t0 = Date.now();
    const tick = setInterval(() => { st.textContent = `실행 중… ${Math.round((Date.now() - t0) / 1000)}초 (LLM 호출 여러 번 — 1~3분 걸릴 수 있음)`; }, 500);
    try {
      const res = await fetch(`/api/runs/${runId}/extract`, { method: "POST" });
      const r = await res.json();
      if (!res.ok) throw new Error(r.error || res.statusText);
      clearInterval(tick);
      st.textContent = `완료 · ${Math.round((Date.now() - t0) / 1000)}초`;
      window.renderExtract(r);
    } catch (err) {
      clearInterval(tick);
      st.innerHTML = `<span class="bad">오류: ${E(err.message)}</span>`;
    } finally { btn.disabled = false; }
  }

  function tex(latex) {
    if (!latex) return `<span class="bad">변환 실패</span>`;
    if (window.katex) {
      try { return katex.renderToString(latex.replace(/−/g, "-"), { throwOnError: false, displayMode: true }); } catch {}
    }
    return `<code>${E(latex)}</code>`;
  }
  const sent = (text) => (text ? `<details class="sent"><summary>LLM 에 보낸 글 보기 (측정값 없음)</summary><pre>${E(text)}</pre></details>` : "");
  const llmMeta = (m) => (m ? `<span class="m">${E(m.model)} · effort ${E(m.effort)} · ${m.cached ? "캐시" : "호출"}${m.output_tokens != null && !m.cached ? ` · 출력 ${m.output_tokens} 토큰` : ""}</span>` : "");
  const stepBadge = (s) => (!s ? "" : `<span class="sb ${s.status}">${s.status === "ok" ? "완료" : s.status === "skipped" ? "건너뜀" : "실패"}</span>${s.error ? ` <span class="bad small">${E(s.error)}</span>` : ""}`);

  // 2단계 결과 그리기 — 방금 실행한 결과든 저장된 결과든 같은 길. 이어서 3 CONFIRM 칸을 연다.
  window.renderExtract = function (r) {
    render(r);
    document.querySelectorAll(".steps li").forEach((li, i) => li.classList.toggle("on", i <= 1));
    if (window.showConfirmLauncher) window.showConfirmLauncher(r.run_id);
  };

  function render(r) {
    const el = X("#extract");
    const c = r.counts;
    const stepChips = ORDER.map((k) => { const s = r.steps[k] || {}; return `<span class="chip st-${s.status || "none"}">${k} ${E(STEP_NAMES[k])}</span>`; }).join("");
    el.innerHTML = `
      <section class="part"><h2><span class="n">2</span>EXTRACT 결과</h2>
        <div class="tiles">
          <div class="tile"><div class="k">Word 수식</div><div class="v">${c.equations - c.equations_failed} / ${c.equations}</div><div class="m">LaTeX 변환 성공</div></div>
          <div class="tile"><div class="k">E01 단위 · E02 이상 · E03 누락</div><div class="v">${c.E01} · ${c.E02} · ${c.E03}</div><div class="m">E02 범위 이탈은 잠정 (사양 승인 전)</div></div>
          <div class="tile"><div class="k">3 CONFIRM 으로 넘길 질문</div><div class="v">${c.questions}</div><div class="m">사양 항목 확인 안 됨 ${c.spec_unverified}</div></div>
          <div class="tile"><div class="k">LLM</div><div class="v">${r.llm.calls} 호출 · ${r.llm.cache_hits} 캐시</div><div class="m">${E(r.llm.model)} · 입력 ${r.llm.input_tokens} · 출력 ${r.llm.output_tokens} 토큰</div></div>
        </div>
        <div class="chips">${stepChips}</div>
        <p class="m">블라인드: 보고서 ${r.blind.report_files_not_read.length}개를 열지 않음 ✓ ${r.notices.map((n) => `<br><span class="warn">${E(n)}</span>`).join("")}</p>
      </section>
      ${part21a(r)}${part21b(r)}${part21c(r)}${part22(r)}${part23(r)}${part24(r)}${questions(r)}${lineage(r)}`;
  }

  function part21a(r) {
    const groups = (r.headers || {}).groups || [];
    const body = groups.map((g) => {
      const a = g.analysis;
      const cols = a ? a.columns.map((c) => `<tr><td class="mono">${E(c.name)}</td><td>${E(c.role)}</td><td>${E(c.quantity)}</td>
          <td class="mono">${E(c.unit_in_header || "—")}${c.unit_guess ? ` <span class="m">(제안 ${E(c.unit_guess)})</span>` : ""}</td><td>${E(c.meaning)}</td></tr>`).join("") : "";
      return `<div class="card sub"><div class="row2"><b>${E(g.group_id)} · 파일 ${g.files.length}개 · ${g.n_rows[0]}~${g.n_rows[1]}행</b>${llmMeta(g.llm)}</div>
        ${a ? `<p>${E(a.measurement)} <span class="m">(${E(a.layout)} 형식 · 행 키 ${E(a.row_keys.join(", "))})</span></p>
        <div class="tablewrap"><table><thead><tr><th>열</th><th>역할</th><th>물리량</th><th>단위 (헤더)</th><th>의미</th></tr></thead><tbody>${cols}</tbody></table></div>`
          : `<p class="bad">${E(g.error)}</p>`}
        <p class="m">파일: ${g.files.slice(0, 8).map(E).join(", ")}${g.files.length > 8 ? ` … 외 ${g.files.length - 8}개` : ""}</p>${sent(g.sent)}</div>`;
    }).join("");
    const unread = ((r.headers || {}).unread || []).map((u) => `<li>${E(u.file)} — ${E(u.reason)}</li>`).join("");
    return `<section class="part"><h2><span class="n">2-1a</span>데이터 내용 파악 <span class="tag">LLM</span> ${stepBadge(r.steps["2-1a"])}</h2>
      <p class="m">행·열 헤더만 보고 무엇을 측정했는지 판단. 숫자 열의 값은 보내지 않음. 같은 열 구성의 파일은 한 번만 물음.</p>${body}${unread ? `<ul class="m">${unread}</ul>` : ""}</section>`;
  }

  function part21b(r) {
    const q = r.equations;
    if (!q) return `<section class="part"><h2><span class="n">2-1b</span>계획서 수식 변환 <span class="tag py">PY</span> ${stepBadge(r.steps["2-1b"])}</h2></section>`;
    const rows = q.equations.map((e) => `<div class="eq"><div class="eqh"><b>${E(e.id)}</b> <span class="m">${E(e.sentence)}</span></div>
        <div class="eqb">${tex(e.latex)}</div>
        <div class="m mono">${e.latex ? E(e.latex) : E(e.error)} · 수식 XML ${H(e.omml_sha256)}</div></div>`).join("");
    return `<section class="part"><h2><span class="n">2-1b</span>계획서 수식 변환 <span class="tag py">PY</span> ${stepBadge(r.steps["2-1b"])}</h2>
      <p class="m">${E(q.plan_file)} (해시 ${H(q.plan_sha256)}) 의 Word 수식을 ${E(q.converter || "—")} 로 LaTeX 변환. 실패한 식은 3-1 에서 직접 입력받음.</p>
      <div class="card">${rows || "<p class='m'>Word 수식 없음</p>"}</div></section>`;
  }

  function part21c(r) {
    const p = r.plan || {}, a = p.analysis;
    if (!a) return `<section class="part"><h2><span class="n">2-1c</span>연구 내용 추출 <span class="tag">LLM</span> ${stepBadge(r.steps["2-1c"])}</h2></section>`;
    const f = a.formulas.map((x) => `<tr><td><b>${E(x.eq_id)}</b></td><td>${E(x.role)}</td><td>${E(x.purpose)}</td>
        <td>${x.variables.map(E).join("<br>")}</td></tr>`).join("");
    const proc = a.processing.map((s) => `<li><b>${s.step}.</b> ${E(s.description)} <span class="m">(${E(s.input)} → ${E(s.output)} · ${E(s.eq_ids.join(", "))})</span></li>`).join("");
    const d = a.design;
    const match = a.matching.map((m) => `<tr><td>${E(m.experiment)}</td><td>${E(m.data_group)} <span class="mono m">${E(m.data_columns.join(", "))}</span></td>
        <td>${E(m.eq_ids.join(", "))}</td><td>${E(m.instrument)}<div class="m">${E(m.instrument_range)}</div></td><td>${E(m.outputs.join(", "))}</td></tr>`).join("");
    const rep = a.reported_quantities.map((q) => `<li>${E(q.name)} <span class="mono">${E(q.symbol)}</span> [${E(q.unit)}] · ${E(q.eq_id)} · ${E(q.per)}</li>`).join("");
    return `<section class="part"><h2><span class="n">2-1c</span>연구 내용 추출 <span class="tag">LLM</span> ${stepBadge(r.steps["2-1c"])} ${llmMeta(p.llm)}</h2>
      <div class="card"><p>${E(a.summary)}</p>
        <h3>식</h3><div class="tablewrap"><table><thead><tr><th>식</th><th>역할</th><th>목적</th><th>변수 ← 데이터 열</th></tr></thead><tbody>${f}</tbody></table></div>
        <h3>가공 방법 (raw → 계산 입력값)</h3><ol class="plain">${proc}</ol>
        <div class="grid2">
          <div><h3>설계</h3><dl class="kv">
            <dt>조건</dt><dd>${d.conditions.map((c) => `${E(c.label || c.name)}: ${E(c.samples.join(", "))}`).join("<br>")}</dd>
            <dt>독립 단위</dt><dd>${E(d.independent_unit)}</dd><dt>기술적 반복</dt><dd>${E(d.technical_replicate)} × ${d.replicates_per_unit || "?"} (반복당 ${d.points_per_replicate || "?"}점)</dd>
            <dt>자유도</dt><dd>${d.degrees_of_freedom || "—"}</dd><dt>근거</dt><dd class="m">${E(d.source_quote)}</dd></dl></div>
          <div><h3>검정 방법</h3><dl class="kv">
            <dt>있음</dt><dd>${a.test.present ? "예" : "<span class='warn'>없음 — 유의성 주장은 E06</span>"}</dd><dt>방법</dt><dd>${E(a.test.method)} (${E(a.test.alternative)})</dd>
            <dt>유의수준</dt><dd>${a.test.alpha || "—"}</dd><dt>식</dt><dd>${E(a.test.eq_ids.join(", "))}</dd><dt>근거</dt><dd class="m">${E(a.test.source_quote)}</dd></dl></div>
        </div>
        <h3>실험 ↔ 데이터 ↔ 식 ↔ 장비</h3><div class="tablewrap"><table><thead><tr><th>실험</th><th>데이터</th><th>식</th><th>장비 · 범위</th><th>결과</th></tr></thead><tbody>${match}</tbody></table></div>
        <h3>보고할 값</h3><ul class="plain">${rep}</ul>
        <h3>계산 코드 초안 <span class="sb warn">승인 전 · 실행 안 함</span> ${llmMeta(p.llm_code)}</h3>
        ${a.code ? `<p class="m">코드 해시 ${H(p.code_sha256, 16)} · ${E(a.code.explanation)}</p><pre class="code">${E(a.code.code)}</pre>`
          : `<p class="bad">${E(p.code_error || "코드 초안 없음")}</p>`}
        ${sent(p.sent)}</div></section>`;
  }

  function part22(r) {
    const items = (r.spec || {}).items || [];
    const body = items.map((i) => {
      const a = i.analysis;
      if (!a) return `<div class="card sub"><b>${E(i.file)}</b> <span class="bad">${E(i.error)}</span></div>`;
      const rows = a.entries.map((e) => `<tr><td>${E(e.quantity)}<div class="m">${E(e.dimension)}</div></td><td class="mono">${E(e.range_label)}</td>
          <td class="mono">${e.min ?? "—"} ~ ${e.max ?? "—"} ${E(e.unit)}</td><td>${E(e.accuracy)}<div class="m">${E(e.resolution)}</div></td>
          <td>${e.page}쪽<div class="m q">“${E(e.quote)}”</div></td><td>${e.verified ? `<span class="sb ok">원문 확인</span>` : `<span class="sb error">확인 안 됨</span><div class="m">${E(e.verify_notes.join("; "))}</div>`}</td></tr>`).join("");
      const ov = a.overflow_values.map((o) => `<li><span class="mono">${E(o.value)}</span> — ${E(o.meaning)} (${o.page}쪽 “${E(o.quote)}”) ${o.verified ? "✓" : "<span class='bad'>확인 안 됨</span>"}</li>`).join("");
      return `<div class="card sub"><div class="row2"><b>${E(i.file)} — ${E(a.instrument)}</b>${llmMeta(i.llm)}</div>
        <div class="tablewrap"><table><thead><tr><th>물리량</th><th>범위</th><th>최소 ~ 최대</th><th>정확도 · 분해능</th><th>근거</th><th>확인</th></tr></thead><tbody>${rows}</tbody></table></div>
        ${ov ? `<h3>오버플로 표시값</h3><ul class="plain">${ov}</ul>` : ""}${sent(i.sent)}</div>`;
    }).join("");
    return `<section class="part"><h2><span class="n">2-2</span>측정 조건 추출 <span class="tag">LLM</span> ${stepBadge(r.steps["2-2"])}</h2>
      <p class="m">LLM 이 뽑은 항목마다 파이썬이 인용이 그 쪽에 글자 그대로 있는지, 최솟값·최댓값이 인용 안에 있는지 확인. 확정은 3-2.</p>${body}</section>`;
  }

  function part23(r) {
    const k = r.checks;
    if (!k) return `<section class="part"><h2><span class="n">2-3</span>데이터 구조화 <span class="tag py">PY</span> ${stepBadge(r.steps["2-3"])}</h2></section>`;
    const cols = k.columns.map((c) => `<tr><td class="mono">${E(c.column)}</td><td class="mono">${E(c.unit)}</td><td>${E(c.dimension)}</td>
        <td>${c.spec ? `${E(c.spec.range_label)} (${c.spec.min ?? "—"} ~ ${c.spec.max} ${E(c.spec.unit)}, ${c.spec.page}쪽)` : "—"}<div class="m">${E(c.why)}</div></td><td>${c.files}</td></tr>`).join("");
    const e01 = k.e01.map((e) => `<li><span class="code">E01</span> ${E(e.kind)} — <span class="mono">${E(e.column)}</span>${e.header_unit ? ` (표기 '${E(e.header_unit)}')` : ""}${e.suggestion ? ` · 제안 ${E(e.suggestion)}` : ""} <span class="m">파일 ${e.files.length}개</span></li>`).join("");
    const e02 = k.e02.map((e) => `<tr><td><span class="code">E02</span> ${E(e.kind)} ${e.status === "잠정" ? `<span class="sb warn">잠정</span>` : ""}</td>
        <td class="mono">${E(e.file)}:${e.line}</td><td class="mono">${E(e.column)}</td><td class="mono">${E(e.value)}</td><td>${E(e.limit || "")}${e.spec_ref ? `<div class="m">${e.spec_ref.page}쪽</div>` : ""}</td></tr>`).join("");
    const cnt = Object.entries(k.e02_counts).map(([n, v]) => `${E(n)} ${v}`).join(" · ");
    return `<section class="part"><h2><span class="n">2-3</span>데이터 구조화 <span class="tag py">PY</span> ${stepBadge(r.steps["2-3"])}</h2>
      <p class="m">${E(k.note)}</p>
      <div class="card"><h3 style="margin-top:0">측정값 열의 단위와 비교한 사양</h3>
        <div class="tablewrap"><table><thead><tr><th>열</th><th>단위</th><th>차원</th><th>비교한 사양 범위</th><th>파일</th></tr></thead><tbody>${cols || "<tr><td colspan=5 class='m'>단위를 읽은 측정값 열 없음</td></tr>"}</tbody></table></div>
        <h3>E01 단위 누락·모호</h3>${e01 ? `<ul class="plain">${e01}</ul>` : `<p class="ok">없음</p>`}
        <h3>E02 측정값 이상 <span class="m">${cnt}</span></h3>
        ${e02 ? `<div class="tablewrap"><table><thead><tr><th>종류</th><th>위치</th><th>열</th><th>값</th><th>사양 한계</th></tr></thead><tbody>${e02}</tbody></table></div>${k.e02_truncated ? "<p class='m'>일부만 표시</p>" : ""}` : `<p class="ok">없음</p>`}
      </div></section>`;
  }

  function part24(r) {
    const m = r.missing || {}, q = m.required, c = m.comparison;
    if (!q) return `<section class="part"><h2><span class="n">2-4</span>누락 점검 <span class="tag">LLM→PY</span> ${stepBadge(r.steps["2-4"])}</h2></section>`;
    const conds = q.conditions.map((x) => `<li><b>${E(x.name)}</b>: ${E(x.samples.join(", "))}</li>`).join("");
    const p = q.per_sample;
    const e03 = c.e03.map((e) => `<li><span class="code">E03</span> ${E(e.kind)} — ${e.sample ? `${E(e.sample)} ` : ""}${E(e.detail)}</li>`).join("");
    const found = c.found.map((f) => `<tr><td>${E(f.sample)}</td><td>${E(f.condition)}</td><td class="mono">${E(f.file)}</td><td>${f.rows ?? "—"}</td>
        <td class="mono small">${f.per_id ? Object.entries(f.per_id).map(([k, v]) => `${E(k)}:${v}`).join(" ") : E(f.note || "")}</td></tr>`).join("");
    return `<section class="part"><h2><span class="n">2-4</span>누락 점검 <span class="tag">LLM→PY</span> ${stepBadge(r.steps["2-4"])} ${llmMeta(m.llm)}</h2>
      <p class="m">LLM 은 계획서만 읽고 필요한 목록을 뽑음(실제 파일 목록은 보여 주지 않음) → 파이썬이 실제 파일과 대조.</p>
      <div class="card"><div class="grid2"><div><h3 style="margin-top:0">계획서가 요구하는 시료 (${c.required_samples}개)</h3><ul class="plain">${conds}</ul></div>
        <div><h3 style="margin-top:0">시료 파일 하나에 있어야 할 것</h3><p>${E(p.id_column)}: ${E(p.expected_ids.join(", "))}<br>id 당 ${p.points_per_id ?? "—"}점 · 파일당 ${p.rows_per_file ?? "—"}행</p><p class="m">${E(p.source_quote)}</p></div></div>
        <h3>E03 필요 데이터 누락</h3>${e03 ? `<ul class="plain">${e03}</ul>` : `<p class="ok">없음 — 계획서의 시료·위치·측정점이 모두 있음</p>`}
        ${c.unlisted_raw_files.length ? `<p class="warn">계획서 목록에 없는 RAW 파일: ${E(c.unlisted_raw_files.join(", "))}</p>` : ""}
        <details><summary>시료별 대조 (${c.found.length})</summary><div class="tablewrap"><table><thead><tr><th>시료</th><th>조건</th><th>파일</th><th>행</th><th>위치별 행 수</th></tr></thead><tbody>${found}</tbody></table></div></details>
      </div></section>`;
  }

  function questions(r) {
    return `<section class="part"><h2><span class="n">→3</span>CONFIRM 으로 넘길 질문</h2><div class="card">${r.questions.length
      ? `<ol class="plain">${r.questions.map((q) => `<li><span class="m">[${E(q.from)}]</span> ${E(q.q)}</li>`).join("")}</ol>` : `<p class="muted">없음</p>`}</div></section>`;
  }

  function lineage(r) {
    const rows = (r.lineage || []).map((x) => `<tr><td>${E(x.step)}</td><td class="hash">${H(x.input_hash)}</td><td class="hash">${H(x.code_hash)}</td>
        <td class="mono small">${E(Object.entries(x.params).filter(([, v]) => v != null).map(([k, v]) => `${k}=${v}`).join(" · "))}</td>
        <td class="hash">${x.outputs.map((o) => `${H(o.sha256)} <span class="m">${E(o.path.split("/").pop())}</span>`).join("<br>")}</td></tr>`).join("");
    return `<section class="part"><h2><span class="n">1-3</span>산출물 이력 장부 — 2단계 기록</h2>
      <div class="tablewrap"><table><thead><tr><th>과업</th><th>입력 해시</th><th>코드 해시</th><th>파라미터</th><th>출력 해시</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
  }
})();
