// 5 VALIDATE · 6 AUDIT 화면 — 인계 묶음(3 → 5·6)을 보여 주고 사람이 승인하면 뒷단(4단계 계산에 항목 결합 → 5-1 보고서 첫 열람 → 5-2 → 5-3 → 6)을 돌린다.
// 계산은 4단계에서 뒷단 엔진이 한 번만 했다 — 여기서는 다시 계산하지 않는다(다시 감사할 때만 4단계를 새로 실행).
// 판정·숫자는 서버(Python)가 정한다. 화면은 그리기만 한다.
(function () {
  const X = (s) => document.querySelector(s);
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const H = (h, n = 12) => (h ? E(String(h).slice(0, n)) : "—");
  const num = (v) => (typeof v === "number" ? (Math.abs(v) >= 1e5 || (Math.abs(v) < 1e-3 && v !== 0) ? v.toExponential(6) : v.toPrecision(10).replace(/\.?0+$/, "")) : E(v ?? "—"));
  const KIND_KO = { value: "값", difference: "차이", ratio: "비", percent_change: "변화율", test_statistic: "검정 통계량", p_value: "p 값", df: "자유도", n: "표본 수" };
  const VERDICT = { Supported: "ok", Unsupported: "error" };
  let preview = null;

  window.showAuditLauncher = async function (runId) {
    const el = X("#audit");
    el.hidden = false;
    el.innerHTML = `<section class="part launcher"><div class="card"><b>5 VALIDATE · 6 AUDIT</b> <span class="muted">— 인계 묶음을 만드는 중…</span></div></section>`;
    const [pv, prev] = await Promise.all([fetch(`/api/runs/${runId}/handoff`), fetch(`/api/runs/${runId}/audit`)]);
    const p = await pv.json();
    if (!pv.ok) {
      el.innerHTML = `<section class="part launcher"><div class="card"><b>5 VALIDATE · 6 AUDIT</b><p class="bad">${E(p.error)}</p></div></section>`;
      return;
    }
    preview = p;
    el.innerHTML = launcher(p) + `<div id="audit_body"></div>`;
    X("#run_audit").addEventListener("click", () => run(runId));
    try { X("#audit_by").value = localStorage.getItem("mt4_respondent") || ""; } catch {}
    if (prev.ok) render(await prev.json());
  };

  function launcher(p) {
    const outs = p.outputs.map((o) => `<tr><td class="mono">${E(o.id)}</td><td>${E(o.name)}${o.condition ? ` <span class="m">(${E(o.condition)})</span>` : ""}</td>
      <td>${E(KIND_KO[o.kind] || o.kind)}</td><td class="mono">${E(o.unit ?? "—")}</td>
      <td>${E(o.groups.join(" − ") || "—")}${o.group_note ? `<div class="m">${E(o.group_note)}</div>` : ""}</td>
      <td>${E(o.equation || "—")}</td><td>${o.terms.length ? E(o.terms.join(", ")) : `<span class="m">대조 안 함</span>`}</td><td class="m">${E(o.depends_on)}</td></tr>`).join("");
    const t = p.tests.map((x) => `${E(x.id)} ${E(x.name)} · 집단 ${E(x.groups.join("/"))} · α ${x.alpha} · p=${E(x.p_output || "—")} 통계량=${E(x.stat_output || "—")} 자유도=${E(x.df_output || "—")}<div class="m">${E(x.description)}</div>`).join("") || "없음";
    const flags = p.flags.length ? `<ul class="plain">${p.flags.map((f) => `<li><span class="code">${E(f.code)}</span> ${E(f.target)} — ${E(f.detail)} <span class="m">(${E(f.decision)})</span></li>`).join("")}</ul>` : `<span class="muted">없음</span>`;
    const pend = p.pending.length ? `<ul class="plain">${p.pending.map((x) => `<li>${E(x.target)} — ${E(x.what)}</li>`).join("")}</ul>` : `<span class="muted">없음</span>`;
    const probs = [...p.problems, ...p.approval_problems_before_seal];
    const blocked = p.blocked_dependencies.map((b) => b.reason);
    const reports = p.reports.length ? `<select id="audit_report">${p.reports.map((r) => `<option>${E(r)}</option>`).join("")}</select>`
      : `<span class="bad">보고서 없음 — 1단계 '최종 보고서 초안' 칸에 넣은 실행이어야 함</span>`;
    const llm = p.llm || {};
    return `<section class="part"><h2><span class="n">3→5</span>인계 묶음 <span class="m">confirmed-v4.0 · 규칙으로 만듦(LLM 없음) — 확인 후 승인</span></h2>
      <div class="card">
        <p class="m" style="margin-top:0">3 CONFIRM 확정 기록 + 4 RECOMPUTE(뒷단 엔진 한 번 실행) 결과 목록으로 뒷단이 읽는 형식을 만들었습니다. 승인하면 이 항목 목록이 4단계 계산 값에 결합됩니다(다시 계산하지 않음). 재계산 항목의 <b>종류·집단·지표 용어</b>는 5단계에서 보고서 주장과 짝지을 때 씁니다. 틀렸으면 3 CONFIRM 으로 돌아가 고쳐야 합니다.</p>
        <div class="tablewrap"><table><thead><tr><th>id</th><th>재계산 항목</th><th>종류</th><th>단위</th><th>집단</th><th>식</th><th>지표 용어</th><th>의존</th></tr></thead><tbody>${outs}</tbody></table></div>
        <div class="grid2" style="margin-top:12px">
          <dl class="kv"><dt>설계</dt><dd>독립 단위 ${E(p.design.independent_unit || "—")} · 집단 ${E(Object.entries(p.design.groups).map(([k, v]) => `${k}=${v}`).join(", ") || "—")} · 기술적 반복 ${E(p.design.replicates_per_unit ?? "—")}</dd>
            <dt>검정</dt><dd>${t}</dd><dt>데이터</dt><dd>RAW ${p.data_count}개 · 식 ${E(p.equations.join(", "))}</dd>
            <dt>코드</dt><dd class="mono">인계 ${H(p.code.sha256, 16)} ← 승인 본문 ${H(p.code.front_code_sha256, 16)} (${E(p.code.front_approved_by)})</dd></dl>
          <dl class="kv"><dt>기록 (E02·E03)</dt><dd>${flags}</dd><dt>미확정</dt><dd>${pend}</dd>
            <dt>묶음 지문</dt><dd class="mono">${H(p.bundle_sha256, 16)}</dd></dl>
        </div>
        ${p.warnings.length ? `<ul class="plain warn">${p.warnings.map((w) => `<li>${E(w)}</li>`).join("")}</ul>` : ""}
        ${probs.length ? `<p class="bad">형식 문제: ${E(probs.join("; "))}</p>` : ""}
        ${blocked.length ? `<p class="warn">미확정 의존 — 뒷단 재계산 전체가 막힘(blocked): ${E(blocked.join("; "))}</p>` : ""}
      </div>
      <div class="card submitbar" style="margin-top:10px">
        <label>보고서 ${reports}</label>
        <label>승인자 <input id="audit_by" placeholder="이름"></label>
        <span class="m">LLM ${llm.available ? `${E(llm.model)}${llm.offline ? " (오프라인 — 캐시만)" : ""}` : `<span class="bad">키 없음 — 캐시에 있는 것만</span>`} · 5-1 주장 추출 · 6-1 설명 (토큰 사용)</span>
        <button id="run_audit" type="button" ${probs.length || !p.reports.length ? "disabled" : ""}>승인하고 5·6 실행</button>
      </div><div id="audit_status" class="m"></div></section>`;
  }

  async function run(runId) {
    const b = X("#run_audit"), s = X("#audit_status"), who = X("#audit_by").value.trim();
    if (!who) { s.innerHTML = `<span class="bad">승인자 이름을 적어 주세요</span>`; return; }
    try { localStorage.setItem("mt4_respondent", who); } catch {}
    b.disabled = true; s.textContent = "뒷단 실행 중 — 4단계 계산에 승인한 항목 결합(재계산 없음) → 5-1 보고서 첫 열람(LLM) → 5-2 비교 → 5-3 오류 코드 → 6 출력…";
    try {
      const res = await fetch(`/api/runs/${runId}/audit`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ respondent: who, bundle_sha256: preview.bundle_sha256, report: X("#audit_report")?.value }) });
      const r = await res.json();
      if (!res.ok) throw new Error(r.error || res.statusText);
      s.textContent = `끝남 · 뒷단 실행 ${r.backend_run_id}`;
      render(r);
      X("#audit_body").scrollIntoView({ behavior: "smooth" });
    } catch (e) { s.innerHTML = `<span class="bad">${E(e.message)}</span>`; }
    finally { b.disabled = false; }
  }

  function recomputedText(rec) {
    rec = rec || {};
    if ("rounded" in rec) return `${E(rec.rounded)} ${E(rec.rounded_unit || "")} <span class="m">(원값 ${num(rec.raw)})</span>`;
    if ("difference" in rec) return `차이 ${num(rec.difference)} ${E(rec.unit || "")}`;
    if ("p" in rec) return `p = ${num(rec.p)} (${rec.significant ? "유의" : "비유의"}, α=${E(rec.alpha)})`;
    if ("raw" in rec) return num(rec.raw);
    return "—";
  }

  function claimRow(c) {
    const codes = c.codes.map((k) => `<span class="code" title="${E(k.name)}">${E(k.code)}${k.effect === "record" ? "·기록" : ""}</span>`).join(" ") || "—";
    const detail = `<tr class="detail" hidden><td colspan="6"><div class="card" style="padding:12px">
      <p style="margin:0 0 6px"><b>문장</b> ${E(c.sentence)}</p>
      <p style="margin:0 0 6px"><b>설명</b> ${E(c.explanation)} <span class="m">(${c.explanation_source === "llm" ? "핵심 Python · 안내 LLM" : "Python 템플릿"})</span></p>
      ${c.codes.map((k) => `<div><span class="code">${E(k.code)}</span> <b>${E(k.name)}</b> <span class="m">[${k.effect === "record" ? "기록" : "Unsupported"}${k.reason_type ? " · " + E(k.reason_type) : ""}]</span> ${E(k.reason)}
        ${(k.evidence || []).length ? `<ul class="plain m">${k.evidence.map((e) => `<li>${E(e)}</li>`).join("")}</ul>` : ""}</div>`).join("")}
      ${c.checks.length ? `<p class="m">수행한 검사: ${E(c.checks.join(", "))}</p>` : ""}
      ${[...c.notes, ...c.extraction_notes].length ? `<ul class="plain m">${[...c.notes, ...c.extraction_notes].map((n) => `<li>${E(n)}</li>`).join("")}</ul>` : ""}
      <p class="m">재계산 항목 ${E(c.outputs_used.join(", ") || "—")} · 식 ${E(c.equations.map((e) => e.id).join(", ") || "—")} · 데이터 ${c.data.length}개 · 코드 <span class="mono">${H(c.code_sha256)}</span></p>
    </div></td></tr>`;
    return `<tr class="f"><td class="mono">p.${E(c.page)}·${E(c.no_in_page)}</td><td>${E(c.source_text)}<div class="m">${E(c.category_ko)}</div></td>
      <td class="mono">${E(c.reported ?? "—")}</td><td class="mono">${recomputedText(c.recomputed)}</td>
      <td><span class="sb ${VERDICT[c.verdict] || ""}">${E(c.verdict)}</span></td><td>${codes}</td></tr>${detail}`;
  }

  function render(v) {
    const r = v.result, s = r.summary, b = r.blind, rc = r.recompute, cc = v.cross_check, ex = v.execution;
    // 통합 뒤: 4단계에서 뒷단 엔진이 한 번 계산하고 5·6 은 그 값을 쓴다. 통합 전에 저장된 결과는 교차 확인 표를 그대로 보여 준다.
    const bound = Object.entries(rc.outputs || {}).map(([id, o]) => `<tr><td class="mono">${E(id)}</td><td class="mono num">${num(o.value)}</td><td>${E(o.unit || "")}</td><td>${o.status === "ok" ? `<span class="ok">ok</span>` : `<span class="bad">${E(o.status)}${o.error ? " — " + E(o.error) : ""}</span>`}</td></tr>`).join("");
    const codeCounts = Object.entries(s.codes || {}).map(([k, n]) => `<span class="code">${E(k)}</span>×${n}`).join(" ") || "없음";
    const nonTarget = (r.non_target || []).map((x) => `<li><span class="m">p.${E(x.page)}·${E(x.no_in_page)} ${E(x.category_ko)}</span> ${E(x.sentence)}${(x.literature_values || []).length ? ` <span class="m">문헌값 ${E(x.literature_values.join(", "))}</span>` : ""}</li>`).join("");
    const unstructured = (r.unstructured || []).map((x) => `<li><span class="m">p.${E(x.page)}·${E(x.no_in_page)}</span> ${E(x.sentence)} — <span class="warn">${E(x.reason)}</span></li>`).join("");
    const rej = (r.rejected_extractions || []).map((x) => `<li>${E(x.source_text)} — <span class="m">${E(x.reason)}</span></li>`).join("");
    const cross = (cc ? cc.rows : []).map((x) => `<tr><td class="mono">${E(x.id)}</td><td class="mono num">${num(x.front)}</td><td class="mono num">${num(x.backend)}</td><td>${x.same ? `<span class="ok">같음</span>` : `<span class="bad">다름 (${E(x.status)})</span>`}</td></tr>`).join("");
    const rr = r.rerun;
    const rerun = !rr ? `<p class="m">같은 프로젝트의 이전 감사 실행이 없음 — 다음에 같은 프로젝트 이름으로 다시 돌리면 데이터 변경(E07)과 판정 변화를 보여 줍니다.</p>`
      : `<p class="m">이전 실행 ${E(rr.data.previous_run)}${rr.data.code_changed ? " · <span class='warn'>코드 바뀜</span>" : ""}</p>
        ${(rr.data.changes || []).length ? `<ul class="plain">${rr.data.changes.map((c) => `<li><span class="code">E07</span> <span class="kind">${E(c.change)}</span> ${E(c.summary)}</li>`).join("")}</ul>` : `<p class="ok">데이터 변경 없음</p>`}
        ${(rr.verdicts || []).filter((x) => x.change !== "변화 없음").length ? `<div class="tablewrap"><table><thead><tr><th>주장</th><th>이전</th><th>지금</th><th>변화</th></tr></thead><tbody>${rr.verdicts.filter((x) => x.change !== "변화 없음").map((x) => `<tr><td>${E(x.source_text)}</td><td>${E(x.before ?? "—")} <span class="m">${E((x.codes_before || []).join(","))}</span></td><td>${E(x.after ?? "—")} <span class="m">${E((x.codes_after || []).join(","))}</span></td><td>${E(x.change)}</td></tr>`).join("")}</tbody></table></div>` : `<p class="m">판정 변화 없음</p>`}`;
    X("#audit_body").innerHTML = `
      <section class="part"><h2><span class="n">5·6</span>감사 결과 <span class="sb ${rc.status === "ok" ? "ok" : "error"}">재계산 ${E(rc.status)}</span></h2>
        <div class="tiles">
          <div class="tile"><div class="k">Supported</div><div class="v ok">${s.Supported}</div><div class="m">판정한 주장</div></div>
          <div class="tile ${s.Unsupported ? "bad" : ""}"><div class="k">Unsupported</div><div class="v">${s.Unsupported}</div><div class="m">오류 코드 ${codeCounts}</div></div>
          <div class="tile"><div class="k">검사 대상 아님</div><div class="v">${s["검사 대상 아님"]}</div><div class="m">문장 수 (인용·정성·제목)</div></div>
          <div class="tile ${s["구조화 실패"] ? "bad" : ""}"><div class="k">구조화 실패</div><div class="v">${s["구조화 실패"]}</div><div class="m">문장 수 — 판정 없음</div></div>
        </div>
        ${rc.status !== "ok" ? `<p class="bad">뒷단 재계산 ${E(rc.status)}: ${E(rc.error)}</p>` : ""}
        <p class="m">${E(r.scope_note)}</p></section>
      <section class="part"><h2><span class="n">5</span>주장별 판정 <span class="m">행을 누르면 근거</span></h2>
        <div class="tablewrap"><table id="claims_tbl"><thead><tr><th>위치</th><th>주장 원문</th><th>보고값</th><th>재계산값 (보고 자릿수)</th><th>판정</th><th>오류 코드</th></tr></thead>
        <tbody>${r.claims.map(claimRow).join("") || `<tr><td colspan="6" class="muted">판정한 주장 없음</td></tr>`}</tbody></table></div>
        ${unstructured ? `<h3>구조화 실패 <span class="muted">— LLM 분류 누락·원문 검증 실패 (판정 없음)</span></h3><ul class="plain">${unstructured}</ul>` : ""}
        ${rej ? `<details><summary class="m">거절한 주장 후보 ${(r.rejected_extractions || []).length}개 (원문에 없는 수치·단위 등)</summary><ul class="plain">${rej}</ul></details>` : ""}
        ${nonTarget ? `<details><summary class="m">검사 대상 아님 ${(r.non_target || []).length}문장</summary><ul class="plain">${nonTarget}</ul></details>` : ""}
        ${(r.llm_failures || []).length ? `<p class="bad">LLM 호출 실패: ${E(r.llm_failures.map((f) => f.error).join("; "))}</p>` : ""}
      </section>
      ${ex ? `<section class="part"><h2><span class="n">4</span>재계산 값 (4단계 한 번 실행) <span class="m">뒷단 실행 ${E(ex.backend_run_id)}${ex.reaudit_new_step4 ? " · 다시 감사해 4단계 새로 실행" : ""}</span></h2><div class="card">
        <p class="m" style="margin-top:0">${E(ex.note)}</p>
        <div class="tablewrap"><table><thead><tr><th>항목</th><th>재계산값</th><th>단위</th><th>상태</th></tr></thead><tbody>${bound}</tbody></table></div></div></section>`
      : cc ? `<section class="part"><h2><span class="n">4↔4</span>재계산 교차 확인 (통합 전 기록) <span class="m">${cc.same}/${cc.total} 같음</span></h2><div class="card">
        <p class="m" style="margin-top:0">${E(cc.note)}</p>
        <div class="tablewrap"><table><thead><tr><th>항목</th><th>앞단 4 RECOMPUTE</th><th>뒷단 4-1</th><th></th></tr></thead><tbody>${cross}</tbody></table></div></div></section>` : ""}
      <section class="part"><h2><span class="n">6</span>근거·재평가</h2><div class="card">
        <dl class="kv"><dt>블라인드</dt><dd>계산 완료 ${E(b.calc_finished_at)} &lt; 보고서 첫 열람 ${E(b.report_opened_at)} → ${b.blind_ok ? `<span class="ok">확인</span>` : `<span class="bad">실패</span>`}</dd>
          <dt>해시</dt><dd class="mono">보고서 ${H(b.report_sha256, 16)} · 코드 ${H(rc.code_sha256, 16)} · 결과 ${H(rc.results_sha256, 16)}</dd>
          <dt>승인</dt><dd>${E(v.approved_by)} · 묶음 <span class="mono">${H(v.bundle_sha256, 16)}</span> · 보고서 ${E(v.report)}</dd>
          <dt>리포트</dt><dd class="mono">${E(v.report_md)}</dd><dt>인계 파일</dt><dd class="mono">${E(v.handoff)}</dd>
          <dt>쪽 번호</dt><dd>${E(r.page_mode)}</dd></dl>
        <h3>6-2 이전 실행과 비교</h3>${rerun}</div></section>`;
    X("#claims_tbl").querySelectorAll("tr.f").forEach((tr) => tr.addEventListener("click", () => { tr.nextElementSibling.hidden = !tr.nextElementSibling.hidden; }));
    document.querySelectorAll(".steps li").forEach((li) => li.classList.add("on"));
  }
})();
