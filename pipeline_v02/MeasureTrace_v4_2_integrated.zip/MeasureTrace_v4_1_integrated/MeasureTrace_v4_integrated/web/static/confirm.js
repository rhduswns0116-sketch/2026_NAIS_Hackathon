// 3 CONFIRM 화면 — 확인 항목을 보여 주고 답을 모아 제출한다. 상태·판단은 서버(Python)가 갖고, 여기서는 그리기만 한다.
(function () {
  const X = (s, el = document) => el.querySelector(s);
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const H = (h, n = 12) => (h ? E(String(h).slice(0, n)) : "—");
  const LABEL = { approve: "맞음", correct: "수정 필요", reject: "거부 — 다시 작성", proceed: "그대로 진행", upload: "추가 업로드 (새 실행)",
                  remeasure: "재측정 (새 실행)", value: "단위 입력", answer: "답하기", skip: "넘어가기" };
  const STATUS = { pending: ["대기", "warn"], approved: ["승인", "ok"], corrected: ["수정 요청", "warn"], corrected_applied: ["수정 반영", "ok"],
                   decided: ["결정", "ok"], answered: ["답함", "ok"], skipped: ["넘어감", ""], unresolved: ["미확정", "error"], remeasure: ["재측정 필요", "error"] };
  let st = null;          // 서버 상태
  let draft = {};         // 이번 제출 답 {item_id: {choice, text, value, fields}}
  let runId = null;

  const who = () => { try { return localStorage.getItem("mt4_respondent") || ""; } catch { return ""; } };

  window.showConfirmLauncher = async function (rid) {
    runId = rid;
    const el = X("#confirm");
    el.hidden = false;
    const res = await fetch(`/api/runs/${rid}/confirm`);
    if (res.ok) { st = await res.json(); draft = {}; return render(); }
    el.innerHTML = `<section class="part launcher"><div class="card"><div class="row2">
      <div><b>3 CONFIRM</b> — 사람이 확정한다 <span class="muted">(피드백 최대 3회 · 답변은 응답자·시각과 함께 기록 · 보고서 수치는 나오지 않음)</span></div>
      <button id="start_confirm" type="button">3 CONFIRM 시작</button></div></div></section>`;
    X("#start_confirm").addEventListener("click", async () => {
      const r = await fetch(`/api/runs/${rid}/confirm/start`, { method: "POST" });
      const body = await r.json();
      if (!r.ok) { el.insertAdjacentHTML("beforeend", `<p class="bad">${E(body.error)}</p>`); return; }
      st = body; draft = {}; render();
      document.querySelectorAll(".steps li").forEach((li, i) => li.classList.toggle("on", i <= 2));
    });
  };

  function tex(latex) {
    if (latex && window.katex) { try { return katex.renderToString(latex.replace(/−/g, "-"), { throwOnError: false, displayMode: true }); } catch {} }
    return latex ? `<code>${E(latex)}</code>` : `<span class="bad">변환 실패</span>`;
  }

  function proposal(i) {
    const p = i.proposal;
    switch (i.kind) {
      case "equation":
        return `<div class="eqb">${tex(p.latex)}</div><p class="m">${E(p.sentence)}</p>
          ${p.purpose ? `<p><b>${E(p.role)}</b> · ${E(p.purpose)}</p>` : ""}${p.variables?.length ? `<ul class="plain small">${p.variables.map((v) => `<li>${E(v)}</li>`).join("")}</ul>` : ""}`;
      case "processing":
        return `<ol class="plain">${p.steps.map((s) => `<li>${E(s.description)} <span class="m">(${E(s.input)} → ${E(s.output)} · ${E((s.eq_ids || []).join(", "))})</span></li>`).join("")}</ol>`;
      case "design":
        return `<dl class="kv"><dt>조건</dt><dd>${(p.conditions || []).map((c) => `${E(c.label || c.name)}: ${E(c.samples.join(", "))}`).join("<br>")}</dd>
          <dt>독립 단위</dt><dd>${E(p.independent_unit)}</dd><dt>기술적 반복</dt><dd>${E(p.technical_replicate)} × ${p.replicates_per_unit || "?"} (반복당 ${p.points_per_replicate || "?"}점)</dd>
          <dt>자유도</dt><dd>${p.degrees_of_freedom || "—"}</dd><dt>근거</dt><dd class="m">${E(p.source_quote)}</dd></dl>`;
      case "test":
        return `<dl class="kv"><dt>방법</dt><dd>${p.present ? E(p.method) + " · " + E(p.alternative) : "<span class='warn'>계획서에 검정 없음</span>"}</dd>
          <dt>유의수준</dt><dd>${p.alpha || "—"}</dd><dt>식</dt><dd>${E((p.eq_ids || []).join(", "))}</dd><dt>근거</dt><dd class="m">${E(p.source_quote)}</dd></dl>`;
      case "matching":
        return p.rows.map((m) => `<div class="flow"><span class="fb">${E(m.experiment)}</span><span class="fa">→</span>
          <span class="fb">데이터 ${E(m.data_group)}<br><span class="mono small">${E(m.data_columns.join(", "))}</span></span><span class="fa">→</span>
          <span class="fb">식 ${E(m.eq_ids.join(", "))}</span><span class="fa">→</span>
          <span class="fb">${E(m.instrument)}<br><span class="small">${E(m.instrument_range)}</span></span><span class="fa">⇒</span>
          <span class="fb out">${E(m.outputs.join(" · "))}</span></div>`).join("");
      case "code":
        if (!p.code) return `<p class="bad">${E(p.error)}</p>`;
        return `${i.reuse ? `<p class="ok small">같은 입력으로 승인된 코드가 있음 (해시 ${H(i.reuse.sha256)}, ${E(i.reuse.approved_by)})</p>` : ""}
          ${p.static_problems?.length ? `<p class="bad">격리 실행 규칙 위반 — 승인할 수 없음: ${E(p.static_problems.join("; "))}</p>`
            : `<p class="ok small">격리 실행 규칙 점검 통과 (4-1 과 같은 검사)</p>`}
          <p class="m">코드 해시 <span class="mono">${H(p.sha256, 16)}</span> · ${E(p.explanation)}</p><pre class="code">${E(p.code)}</pre>`;
      case "plan_missing":
        return `<p class="bad">${E(p.error)}</p>`;
      case "missing":
        return p.e03.length ? `<ul class="plain">${p.e03.map((e) => `<li><span class="code">E03</span> ${E(e.kind)} — ${e.sample ? E(e.sample) + " " : ""}${E(e.detail)}</li>`).join("")}</ul>`
          : `<p class="ok">누락 없음 — 시료 ${p.required_samples}개</p>${p.unlisted_raw_files.length ? `<p class="warn small">계획서 목록에 없는 RAW: ${E(p.unlisted_raw_files.join(", "))}</p>` : ""}`;
      case "spec":
        return `<dl class="kv"><dt>범위</dt><dd class="mono">${E(p.range_label)}: ${p.min ?? "—"} ~ ${p.max ?? "—"} ${E(p.unit)}</dd>
          <dt>정확도</dt><dd>${E(p.accuracy || "—")} <span class="m">${E(p.resolution || "")}</span></dd><dt>근거</dt><dd>${p.page}쪽 <span class="m q">“${E(p.quote)}”</span>
          ${p.verified ? `<span class="sb ok">원문 확인</span>` : `<span class="sb error">원문 확인 안 됨</span> <span class="m">${E((p.verify_notes || []).join("; "))}</span>`}</dd></dl>`;
      case "overflow":
        return `<p><span class="mono">${E(p.value)}</span> — ${E(p.meaning)} <span class="m">(${p.page}쪽 “${E(p.quote)}”)</span></p>`;
      case "unit":
        return p.confirmed ? `<p>확정: <b class="mono">${E(p.confirmed)}</b></p>`
          : `<p class="m">헤더 표기 ${E(p.header_unit || "없음")} · 파일 ${p.files.length}개${p.suggestion ? ` · 제안 <b>${E(p.suggestion)}</b>` : ""}</p>`;
      case "anomaly":
        return `<p><span class="sb ${p.state.startsWith("확정") ? "error" : "warn"}">${E(p.state)}</span> <span class="m">${p.count}건${p.count > p.rows.length ? ` (앞 ${p.rows.length}건 표시)` : ""}</span></p>
          <div class="tablewrap small"><table><thead><tr><th>줄</th><th>값</th><th>사양 한계</th></tr></thead><tbody>
          ${p.rows.map((r) => `<tr><td class="mono">${r.line}</td><td class="mono">${E(r.value)}</td><td>${E(r.limit || "")}${r.spec_ref ? ` <span class="m">${r.spec_ref.page}쪽</span>` : ""}</td></tr>`).join("")}</tbody></table></div>`;
      default:
        return "";
    }
  }

  function controls(i) {
    const d = draft[i.id] || {};
    const radios = i.inputs.filter((c) => c !== "value").map((c) =>
      `<label class="opt"><input type="radio" name="c_${E(i.id)}" value="${c}" ${d.choice === c ? "checked" : ""}> ${LABEL[c]}</label>`).join("");
    let extra = "";
    if (i.inputs.includes("value")) {
      extra = `<label class="opt">단위 <input class="unit" data-f="value" value="${E(d.value ?? i.proposal.suggestion ?? "")}" placeholder="예: A, mA, V"></label>`;
    } else if (["correct", "reject", "answer"].includes(d.choice)) {
      const spec = i.kind === "spec" && d.choice === "correct";
      extra = `${spec ? `<div class="fields">최소 <input data-f="min" value="${E(d.fields?.min ?? "")}"> 최대 <input data-f="max" value="${E(d.fields?.max ?? "")}"> 단위 <input data-f="unit" value="${E(d.fields?.unit ?? "")}"></div>` : ""}
        <textarea data-f="text" rows="2" placeholder="${d.choice === "answer" ? "답" : "무엇이 틀렸고 어떻게 고쳐야 하는지"}">${E(d.text || "")}</textarea>`;
    } else if (["proceed", "upload", "remeasure"].includes(d.choice)) {
      extra = `<textarea data-f="text" rows="1" placeholder="이유 (선택)">${E(d.text || "")}</textarea>`;
    }
    return `<div class="ctl" data-id="${E(i.id)}">${radios}${i.inputs.includes("value") ? `<label class="opt"><input type="checkbox" data-f="use" ${d.choice === "value" ? "checked" : ""}> 이 단위로 확정</label>` : ""}${extra}</div>`;
  }

  function answerText(i) {
    const a = i.answer;
    if (!a) return "";
    const bits = [a.choice ? LABEL[a.choice] || a.choice : "", a.value ? `단위 ${a.value}` : "", a.text || "",
                  a.fields && Object.keys(a.fields).length ? JSON.stringify(a.fields) : "", a.note || ""].filter(Boolean);
    return `<p class="m">답: ${E(bits.join(" · "))}${a.respondent ? ` — ${E(a.respondent)} · ${E(a.at)}` : ""}${i.carried_from ? ` <span class="sb">이전 실행 ${E(i.carried_from)} 에서 이어받음</span>` : ""}</p>`;
  }

  function card(i) {
    const [label, cls] = STATUS[i.status] || [i.status, ""];
    const open = st.status === "open" && ["pending", "corrected"].includes(i.status);
    const hist = (i.history || []).length ? `<details class="hist"><summary>기록 ${i.history.length}</summary><ul class="plain small">${i.history.map((h) =>
      `<li>${h.round}회 · ${E(h.at)} · ${E(h.event)}${h.old_hash ? ` (해시 ${E(h.old_hash)} → ${E(h.new_hash)})` : ""}${h.respondent ? " · " + E(h.respondent) : ""}</li>`).join("")}</ul></details>` : "";
    return `<div class="citem ${i.changed ? "changed" : ""} st-${i.status}" id="ci_${E(i.id)}">
      <div class="row2"><div><b>${E(i.title)}</b> ${i.required ? "" : `<span class="sb">선택</span>`} ${i.changed && st.round ? `<span class="sb warn">다시 확인</span>` : ""}</div><span class="sb ${cls}">${label}</span></div>
      <p>${E(i.question)}</p>${proposal(i)}${answerText(i)}${open ? controls(i) : ""}${hist}</div>`;
  }

  function render() {
    const el = X("#confirm"), c = st.counts;
    const bySec = {};
    st.items.forEach((i) => (bySec[i.section] = bySec[i.section] || []).push(i));
    const nDraft = Object.keys(draft).length;
    const done = st.status !== "open";
    const secHtml = Object.entries(st.sections).map(([k, title]) => {
      const list = bySec[k] || [];
      if (!list.length) return "";
      const pend = list.filter((i) => ["pending", "corrected"].includes(i.status)).length;
      const bulk = !done && pend ? `<span class="bulk">${list.some((i) => i.inputs.includes("approve") && i.status === "pending") ? `<button class="ghost" data-bulk="${k}" data-choice="approve">대기 항목 모두 맞음</button>` : ""}
        ${list.some((i) => i.inputs.includes("proceed") && i.status === "pending") ? `<button class="ghost" data-bulk="${k}" data-choice="proceed">대기 항목 모두 그대로 진행</button>` : ""}
        ${k === "Q" ? `<button class="ghost" data-bulk="Q" data-choice="skip">모두 넘어가기</button>` : ""}</span>` : "";
      return `<section class="part"><h2><span class="n">${k}</span>${E(title)} <span class="m">${list.length}개 · 남은 것 ${pend}</span> ${bulk}</h2>
        <div class="card">${list.map(card).join("")}</div></section>`;
    }).join("");
    const conf = st.confirmed;
    el.hidden = false;
    el.innerHTML = `
      <section class="part"><h2><span class="n">3</span>CONFIRM <span class="sb ${st.status === "complete" ? "ok" : st.status === "closed" ? "error" : "warn"}">${
        { open: "진행 중", complete: "확정", closed: "마감 (미확정 포함)" }[st.status]}</span></h2>
        <div class="tiles">
          <div class="tile"><div class="k">피드백</div><div class="v">${st.round} / ${st.max_rounds}회</div><div class="m">${done ? "끝남" : `다음 제출이 ${st.round + 1}회째`}</div></div>
          <div class="tile"><div class="k">남은 필수 항목</div><div class="v">${c.required_open}</div><div class="m">승인 ${c.approved} · 결정 ${c.decided} · 수정 반영 ${c.corrected_applied}</div></div>
          <div class="tile ${c.unresolved ? "bad" : ""}"><div class="k">미확정 · 재측정</div><div class="v">${c.unresolved} · ${c.remeasure}</div><div class="m">미확정 항목에 의존하는 주장은 Unsupported(E06)</div></div>
          <div class="tile"><div class="k">사양</div><div class="v">${st.spec_settled ? "확정" : "확인 전"}</div><div class="m">${st.spec_settled ? "E02 범위 이탈 확정" : "E02 범위 이탈은 잠정"}</div></div>
        </div>
        ${(st.messages || []).map((m) => `<p class="warn">${E(m)}</p>`).join("")}
        ${conf ? `<div class="card done"><b>${conf.status === "확정" ? "✓ 확정 — 4 RECOMPUTE 준비됨" : "마감 — 미확정 항목이 있음"}</b>
          <p class="m">${E(conf.path)} · 계산 코드 ${conf.code ? `<span class="mono">${H(conf.code.sha256, 16)}</span> 고정 (${E(conf.code.path)})` : "<span class='bad'>승인 안 됨</span>"}</p>
          ${conf.unresolved.length ? `<p class="bad">미확정: ${E(conf.unresolved.map((u) => u.title).join(", "))}</p>` : ""}
          ${conf.remeasure.length ? `<p class="warn">재측정·추가 업로드: ${E(conf.remeasure.map((u) => u.title).join(", "))} — 파일을 다시 올려 새 실행(1단계부터)</p>` : ""}</div>` : ""}
      </section>
      ${secHtml}
      ${done ? "" : `<section class="part"><div class="card submitbar">
        <label>응답자 <input id="respondent" value="${E(who())}" placeholder="이름"></label>
        <span class="m">${nDraft}개 답 준비됨${Object.values(draft).some((d) => ["correct", "reject"].includes(d.choice)) ? " · 3-1 수정이 있으면 2 EXTRACT 를 다시 실행(LLM, 1~2분)" : ""}</span>
        <button id="submit_confirm" type="button" ${nDraft ? "" : "disabled"}>제출 — 피드백 ${st.round + 1}/${st.max_rounds}회</button>
        <div id="confirm_status" class="m"></div></div></section>`}`;
    wire(el);
    if (st.confirmed && window.showRecomputeLauncher) window.showRecomputeLauncher(runId, st.confirmed);
  }

  function wire(el) {
    el.querySelectorAll(".ctl").forEach((ctl) => {
      const id = ctl.dataset.id;
      ctl.querySelectorAll("input[type=radio]").forEach((r) => r.addEventListener("change", () => {
        draft[id] = { ...(draft[id] || {}), choice: r.value }; render(); X(`#ci_${CSS.escape(id)}`)?.scrollIntoView({ block: "nearest" });
      }));
      ctl.querySelectorAll("[data-f]").forEach((f) => f.addEventListener(f.type === "checkbox" ? "change" : "input", () => {
        const d = draft[id] = draft[id] || {};
        if (f.dataset.f === "use") { if (f.checked) { d.choice = "value"; d.value = X("input.unit", ctl).value; } else delete draft[id]; render(); return; }
        if (f.dataset.f === "value") { d.value = f.value; if (d.choice !== "value") return; }
        else if (["min", "max", "unit"].includes(f.dataset.f)) { d.fields = { ...(d.fields || {}), [f.dataset.f]: f.value }; }
        else d[f.dataset.f] = f.value;
        const n = X("#submit_confirm"); if (n) n.disabled = !Object.keys(draft).length;
      }));
    });
    el.querySelectorAll("[data-bulk]").forEach((b) => b.addEventListener("click", () => {
      st.items.filter((i) => i.section === b.dataset.bulk && i.status === "pending" && i.inputs.includes(b.dataset.choice))
        .forEach((i) => { if (!draft[i.id]) draft[i.id] = { choice: b.dataset.choice }; });
      render();
    }));
    const btn = X("#submit_confirm");
    if (btn) btn.addEventListener("click", submit);
  }

  async function submit() {
    const respondent = X("#respondent").value.trim();
    try { localStorage.setItem("mt4_respondent", respondent); } catch {}
    const s = X("#confirm_status"), btn = X("#submit_confirm");
    btn.disabled = true;
    const t0 = Date.now();
    const tick = setInterval(() => { s.textContent = `처리 중… ${Math.round((Date.now() - t0) / 1000)}초`; }, 500);
    try {
      const res = await fetch(`/api/runs/${runId}/confirm/submit`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ respondent, answers: draft }) });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || res.statusText);
      clearInterval(tick);
      st = body; draft = {}; render();
      X("#confirm").scrollIntoView({ behavior: "smooth" });
    } catch (e) {
      clearInterval(tick);
      s.innerHTML = `<span class="bad">${E(e.message)}</span>`; btn.disabled = false;
    }
  }
})();
