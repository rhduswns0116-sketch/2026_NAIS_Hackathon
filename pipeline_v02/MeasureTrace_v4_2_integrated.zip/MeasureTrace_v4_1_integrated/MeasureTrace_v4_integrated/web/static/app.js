// MeasureTrace v4 — 1 INGEST 화면. 파일을 모아 서버에 사본으로 올리고, 결과 JSON 을 그린다. 판정·계산은 서버(Python)가 한다.
const $ = (s, el = document) => el.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const short = (h, n = 12) => (h ? esc(h.slice(0, n)) : "—");
const size = (b) => (b == null ? "—" : b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(1)} KB` : `${(b / 1048576).toFixed(1)} MB`);

// 쓰기 요청(POST·PUT)에는 서버가 요구하는 헤더를 붙인다 — 다른 웹사이트가 이 로컬 서버를 부르지 못하게 하는 장치
const _fetch = window.fetch.bind(window);
window.fetch = (url, opts = {}) => {
  const method = (opts.method || "GET").toUpperCase();
  if (method !== "GET") opts = { ...opts, headers: { ...(opts.headers || {}), "X-MeasureTrace": "1" } };
  return _fetch(url, opts);
};

const queue = { data: new Map(), report: new Map() };   // 상대 경로 → File
let pickZone = "data";
let view = { result: null, filter: null, open: new Set() };

// ── 프로젝트 이름 기억 (이 브라우저에만) ───────────────────────────
try { $("#project").value = localStorage.getItem("mt4_project") || ""; } catch {}

// ── 파일 모으기: 끌어다 놓기(폴더 포함) · 파일 선택 · 폴더 선택 ─────────
async function readEntry(entry, prefix, out) {
  if (entry.isFile) {
    out.push(await new Promise((res, rej) => entry.file((f) => res([prefix + f.name, f]), rej)));
  } else if (entry.isDirectory) {
    const reader = entry.createReader();
    for (;;) {
      const batch = await new Promise((res, rej) => reader.readEntries(res, rej));
      if (!batch.length) break;
      for (const e of batch) await readEntry(e, `${prefix}${entry.name}/`, out);
    }
  }
}

function add(zone, pairs) {
  for (const [path, file] of pairs) queue[zone].set(path, file);
  renderQueue();
}

document.querySelectorAll(".zone").forEach((zoneEl) => {
  const zone = zoneEl.dataset.zone, drop = $(".drop", zoneEl);
  ["dragenter", "dragover"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add("hover"); }));
  ["dragleave", "drop"].forEach((t) => drop.addEventListener(t, () => drop.classList.remove("hover")));
  drop.addEventListener("drop", async (e) => {
    e.preventDefault();
    const entries = [...e.dataTransfer.items].map((i) => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
    const out = [];
    if (entries.length) for (const en of entries) await readEntry(en, "", out);
    else for (const f of e.dataTransfer.files) out.push([f.name, f]);
    add(zone, out);
  });
  zoneEl.querySelectorAll("[data-pick]").forEach((b) => b.addEventListener("click", () => {
    pickZone = zone;
    (b.dataset.pick === "folder" ? $("#pick_folder") : $("#pick_files")).click();
  }));
});
["#pick_files", "#pick_folder"].forEach((id) => $(id).addEventListener("change", (e) => {
  add(pickZone, [...e.target.files].map((f) => [f.webkitRelativePath || f.name, f]));
  e.target.value = "";
}));
$("#clear").addEventListener("click", () => { queue.data.clear(); queue.report.clear(); renderQueue(); });

function renderQueue() {
  for (const zone of ["data", "report"]) {
    const ul = $(`.zone[data-zone="${zone}"] .list`);
    ul.innerHTML = [...queue[zone]].map(([p, f]) =>
      `<li><span class="p">${esc(p)}</span><span class="s">${size(f.size)}</span><button class="x" data-zone="${zone}" data-path="${esc(p)}" title="빼기">×</button></li>`).join("");
  }
  document.querySelectorAll(".list .x").forEach((b) => b.addEventListener("click", () => { queue[b.dataset.zone].delete(b.dataset.path); renderQueue(); }));
  const n = queue.data.size + queue.report.size;
  $("#picked").textContent = n ? `연구 자료 ${queue.data.size}개 · 보고서 ${queue.report.size}개` : "넣은 파일 없음";
  $("#start").disabled = queue.data.size === 0;
}

// ── 시작: 새 실행 → 파일마다 업로드 → INGEST ─────────────────────────
async function api(method, url, body, headers) {
  const res = await fetch(url, { method, body, headers });
  const data = await res.json().catch(() => ({ error: res.statusText }));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

$("#start").addEventListener("click", async () => {
  const project = $("#project").value.trim();
  try { localStorage.setItem("mt4_project", project); } catch {}
  const all = [...[...queue.data].map((x) => ["data", ...x]), ...[...queue.report].map((x) => ["report", ...x])];
  const total = all.reduce((s, [, , f]) => s + f.size, 0) || 1;
  const bar = $("#progress"), fill = $(".fill", bar), ptext = $(".ptext", bar), st = $("#status");
  bar.hidden = false; st.hidden = true; $("#start").disabled = true;
  let sent = 0;
  try {
    const { run_id } = await api("POST", "/api/runs");
    for (const [zone, path, file] of all) {
      ptext.textContent = `사본 올리는 중 ${path}`;
      await api("PUT", `/api/runs/${run_id}/files?zone=${zone}&path=${encodeURIComponent(path)}`, file);
      sent += file.size; fill.style.width = `${(sent / total) * 100}%`;
    }
    ptext.textContent = "1 INGEST 실행 중 — 분류·해시·이력 기록";
    const result = await api("POST", `/api/runs/${run_id}/ingest`, JSON.stringify({ project }), { "Content-Type": "application/json" });
    view = { result, filter: null, open: new Set() };
    bar.hidden = true; st.hidden = false; st.className = "status";
    st.textContent = `완료 · 실행 ${result.run_id} · 프로젝트 ${result.project}`;
    queue.data.clear(); queue.report.clear(); renderQueue();   // 이 실행은 봉인됨 — 다음 시작은 새 실행
    loadRuns();
    render();
    $("#result").scrollIntoView({ behavior: "smooth" });
  } catch (err) {
    bar.hidden = true; st.hidden = false; st.className = "status err";
    st.textContent = err.message.includes("Failed to fetch") ? "서버에 연결할 수 없음 — python web/server.py 가 켜져 있는지 확인" : `오류: ${err.message}`;
  } finally {
    $("#start").disabled = queue.data.size === 0;
  }
});

// ── 결과 그리기 ─────────────────────────────────────────────────
function render() {
  const r = view.result, el = $("#result");
  el.hidden = false;
  el.innerHTML = summary(r) + part11(r) + part12(r) + part13(r);
  if (window.showExtractLauncher) window.showExtractLauncher(r);
  el.querySelectorAll(".chip[data-cat]").forEach((c) => c.addEventListener("click", () => {
    view.filter = view.filter === c.dataset.cat ? null : c.dataset.cat; render();
  }));
  el.querySelectorAll("tr.f").forEach((tr) => tr.addEventListener("click", () => {
    const k = tr.dataset.key; view.open.has(k) ? view.open.delete(k) : view.open.add(k); render();
  }));
}

function summary(r) {
  const used = r.files.filter((f) => f.used).length;
  const bad = r.findings.filter((f) => f.level === "bad").length;
  return `<div class="tiles">
    <div class="tile"><div class="k">받은 파일</div><div class="v">${r.files.length}</div><div class="m">다음 단계로 ${used}개</div></div>
    <div class="tile"><div class="k">입력 해시</div><div class="v mono">${short(r.input_hash, 16)}</div><div class="m">실행 ${esc(r.run_id)}</div></div>
    <div class="tile"><div class="k">이전 실행 대비</div><div class="v">${r.previous_run_id ? r.changes.length + "건" : "—"}</div><div class="m">${r.previous_run_id ? "이전 " + esc(r.previous_run_id) : "첫 실행"}</div></div>
    <div class="tile ${bad ? "bad" : ""}"><div class="k">다음 단계 진행</div><div class="v">${bad ? "막힘 " + bad : "가능"}</div><div class="m">${bad ? "아래 빨간 항목 확인" : "2 EXTRACT 로"}</div></div>
  </div>`;
}

function part11(r) {
  const icon = (ok) => (ok === true ? `<span class="ic ok">✓</span>` : ok === false ? `<span class="ic bad">✕</span>` : `<span class="ic info">–</span>`);
  const checks = r.checks.map((c) => `<li>${icon(c.ok)}<span class="t">${esc(c.label)}</span><span class="d">${esc(c.detail)}</span></li>`).join("");
  const chips = Object.entries(r.categories).map(([k, label]) => {
    const n = r.counts[k] || 0;
    return n ? `<span class="chip ${view.filter === k ? "on" : ""}" data-cat="${k}"><span class="sw c-${k}"></span>${esc(label)} <b>${n}</b></span>` : "";
  }).join("");
  const finds = r.findings.length ? r.findings.map((f) =>
    `<details class="fd ${f.level}" ${f.level === "bad" ? "open" : ""}><summary><span class="lv">${{ bad: "막힘", warn: "확인", info: "참고" }[f.level]}</span>${esc(f.title)}${f.items.length ? ` <b>${f.items.length}</b>` : ""}</summary>
      ${f.items.length ? `<ul>${f.items.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>` : ""}</details>`).join("")
    : `<p class="ok">특이 사항 없음</p>`;
  return `<section class="part"><h2><span class="n">1-1</span>입력 격리·분류</h2>
    <div class="card"><ul class="checks">${checks}</ul>
      <h3>분류 <span class="muted">— 누르면 아래 표를 거름 · 규칙으로 정한 후보이며 확정은 3 CONFIRM</span></h3><div class="chips">${chips}</div>
      <h3>점검</h3><div class="finds">${finds}</div></div></section>`;
}

function contentSummary(f) {
  const c = f.content || {};
  if (c.table) return `표 ${c.table.columns.length}열 × ${c.table.n_rows}행`;
  if (c.equations != null) return `문단 ${c.paragraphs} · Word 수식 ${c.equations}`;
  if (c.pages != null) return `PDF ${c.pages}쪽`;
  if (c.sheets) return `시트 ${c.sheets.length}개`;
  if (c.n_lines != null) return `텍스트 ${c.n_lines}줄`;
  return "—";
}

function part12(r) {
  const files = r.files.filter((f) => !view.filter || f.category === view.filter);
  const rows = files.map((f) => {
    const key = `${f.zone}/${f.path}`, open = view.open.has(key);
    const content = f.content_hash === f.sha256 ? `<span class="muted">= 원본</span>` : short(f.content_hash);
    return `<tr class="f ${f.used ? "" : "unused"}" data-key="${esc(key)}">
      <td class="path"><span class="zn ${f.zone}">${f.zone === "report" ? "보고서" : "자료"}</span>${esc(f.path)}<div class="m">${size(f.bytes)}</div></td>
      <td><span class="cat"><span class="sw c-${f.category}"></span>${esc(r.categories[f.category])}</span><div class="m">확신도 ${f.confidence.toFixed(2)}</div></td>
      <td class="hash">${short(f.sha256)}<br>${content}</td>
      <td class="m2">${esc(f.normalization.split(" — ")[0])}<div class="m">${esc(contentSummary(f))}</div></td>
    </tr>${open ? `<tr class="detail"><td colspan="4">${detail(f)}</td></tr>` : ""}`;
  }).join("");
  const ch = !r.previous_run_id
    ? `<p class="muted">첫 실행입니다. 같은 프로젝트 이름으로 다시 실행하면 해시를 비교해 추가·삭제·형식만 변경·내용 변경(표는 행·열 차이)을 보여 줍니다.</p>`
    : r.changes.length ? `<ul class="changes">${r.changes.map((c) => `<li><span class="kind k-${esc(c.kind)}">${esc(c.kind)}</span><code>${esc(c.file)}</code> ${esc(c.detail)}
        ${c.table && c.table.spans && c.table.spans.length ? `<ul class="spans">${c.table.spans.map((s) => `<li>${esc(s.kind)} · ${esc(s.where)}</li>`).join("")}</ul>` : ""}</li>`).join("")}</ul>`
    : `<p class="ok">이전 실행(${esc(r.previous_run_id)})과 모든 파일의 원본 해시가 같음</p>`;
  return `<section class="part"><h2><span class="n">1-2</span>해시 2종</h2>
    <div class="tablewrap"><table><thead><tr><th>파일</th><th>분류</th><th>원본 해시<br>내용 해시</th><th>정규화 · 내용</th></tr></thead>
    <tbody>${rows || `<tr><td colspan="4" class="muted">해당 분류의 파일 없음</td></tr>`}</tbody></table></div>
    <p class="muted small">행을 누르면 분류 근거·전체 해시·열 이름을 봅니다. 흐린 행은 다음 단계에서 쓰지 않는 파일. 내용 해시가 "= 원본"이면 그 파일은 정규화하지 않음(보고서는 열지 않으므로 항상 원본 해시만).</p>
    <h3>이전 실행과 비교</h3><div class="card">${ch}</div></section>`;
}

function detail(f) {
  const c = f.content || {}, t = c.table;
  const row = (k, v, mono) => (v ? `<dt>${k}</dt><dd${mono ? ' class="mono"' : ""}>${v}</dd>` : "");
  return `<dl class="kv">
    ${row("분류 근거", esc(f.evidence))}
    ${row("주의", f.warning ? `<span class="warn">${esc(f.warning)}</span>` : "")}
    ${row("읽기 오류", f.read_error ? `<span class="bad">${esc(f.read_error)}</span>` : "")}
    ${row("원본 해시", esc(f.sha256), true)}
    ${row("내용 해시", esc(f.content_hash), true)}
    ${row("정규화", esc(f.normalization))}
    ${row("인코딩", esc(c.encoding))}
    ${t ? row("표", `구분자 ${esc(JSON.stringify(t.delimiter))} · 머리글 ${t.header_line}줄 · ${t.n_rows}행 · 숫자 열 ${(t.numeric_columns || []).length}개${t.row_hashes_note ? " · " + esc(t.row_hashes_note) : ""}`) : ""}
    ${t ? row("열", t.columns.map(esc).join(", "), true) : ""}
    ${c.sheets ? row("시트", c.sheets.map((s) => `${esc(s.name)}(${s.n_rows}행)`).join(", ")) : ""}
  </dl>`;
}

function part13(r) {
  const e = r.lineage;
  const params = Object.entries(e.params).map(([k, v]) => `${esc(k)} = ${esc(v ?? "없음")}`).join("<br>");
  const recent = r.ledger_recent.map((x) => `<tr><td class="mono">${esc(x.ts)}</td><td>${esc(x.step)}</td><td class="mono">${esc(x.run_id)}</td>
      <td class="hash">${short(x.input_hash)}</td><td class="hash">${short(x.code_hash)}</td>
      <td class="hash">${(x.outputs || []).map((o) => short(o.sha256)).join("<br>")}</td></tr>`).join("");
  return `<section class="part"><h2><span class="n">1-3</span>산출물 이력 장부</h2>
    <div class="card">
      <div class="lineage">
        <div class="box"><div class="k">입력 해시</div><div class="mono">${short(e.input_hash, 24)}…</div>
          <div class="k">코드 해시</div><div class="mono">${short(e.code_hash, 24)}…</div><div class="m">${e.code_files.map(esc).join(", ")}</div>
          <div class="k">파라미터</div><div class="mono small">${params}</div></div>
        <div class="arrow">→</div>
        <div class="box"><div class="k">출력 해시</div>${e.outputs.map((o) => `<div class="mono">${short(o.sha256, 24)}…</div><div class="m">${esc(o.path)}</div>`).join("")}</div>
      </div>
      <p class="muted small">장부 <code>${esc(r.ledger_path)}</code> — 앞으로 파이프라인이 만드는 모든 중간 산출물이 여기에 한 줄씩 붙습니다. 연구자가 가져온 파일은 파이프라인이 만든 것이 아니라 적지 않습니다.</p>
      <h3>장부 최근 기록</h3>
      <div class="tablewrap"><table><thead><tr><th>시각</th><th>단계</th><th>실행</th><th>입력 해시</th><th>코드 해시</th><th>출력 해시</th></tr></thead><tbody>${recent}</tbody></table></div>
    </div></section>`;
}

// ── 이전 실행 열기 — 저장된 결과를 단계 순서대로 다시 그린다 (다시 실행하지 않음) ─────────────
async function loadRuns() {
  const sel = $("#runs");
  try {
    const runs = await (await fetch("/api/runs")).json();
    const stage = (r) => (r.audit ? `6 AUDIT ${r.audit}` : r.recompute ? `4 RECOMPUTE ${r.recompute}` : r.confirm ? `3 CONFIRM ${r.confirm}` : r.extract ? "2 EXTRACT" : "1 INGEST");
    sel.innerHTML = `<option value="">${runs.length ? "— 실행을 고르세요 —" : "저장된 실행 없음"}</option>` +
      runs.map((r) => `<option value="${esc(r.run_id)}">${esc(r.project)} · ${esc(r.run_id)} · 파일 ${r.files} · ${esc(stage(r))}</option>`).join("");
  } catch { sel.innerHTML = `<option value="">목록을 불러오지 못함</option>`; }
}
$("#runs").addEventListener("change", async (e) => {
  const rid = e.target.value;
  if (!rid) return;
  const st = $("#status");
  st.hidden = false; st.className = "status"; st.textContent = `실행 ${rid} 불러오는 중…`;
  ["#extract", "#confirm", "#recompute", "#audit"].forEach((s) => { const el = $(s); if (el) { el.hidden = true; el.innerHTML = ""; } });
  try {
    const res = await fetch(`/api/runs/${rid}/ingest`);
    const result = await res.json();
    if (!res.ok) throw new Error(result.error);
    view = { result, filter: null, open: new Set() };
    render();                                   // 1단계 + 2단계 실행 버튼
    const ex = await fetch(`/api/runs/${rid}/extract`);
    if (ex.ok && window.renderExtract) window.renderExtract(await ex.json());   // 2단계 결과 + 3단계(있으면 이어서)
    st.textContent = `실행 ${rid} (${result.project}) 을 불러옴`;
  } catch (err) { st.className = "status err"; st.textContent = `불러오기 실패: ${err.message}`; }
});

renderQueue();
loadRuns();
