// 4 RECOMPUTE 화면 — 승인된 코드 격리 실행 버튼과 계산 로그(4-2) 그리기. 계산은 서버(Python)가 한다.
(function () {
  const X = (s) => document.querySelector(s);
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const H = (h, n = 12) => (h ? E(String(h).slice(0, n)) : "—");
  const num = (v) => (typeof v === "number" ? (Math.abs(v) >= 1e5 || (Math.abs(v) < 1e-3 && v !== 0) ? v.toExponential(6) : v.toPrecision(10).replace(/\.?0+$/, "")) : E(v));

  window.showRecomputeLauncher = async function (runId, confirmed) {
    const el = X("#recompute");
    el.hidden = false;
    const prev = await fetch(`/api/runs/${runId}/recompute`);
    const noCode = !confirmed.code;
    el.innerHTML = `<section class="part launcher"><div class="card"><div class="row2">
      <div><b>4 RECOMPUTE</b> — 승인된 코드로 재계산 <span class="muted">(입력은 RAW 만 · 격리 실행 · 보고서는 아직 열지 않음)</span>
        <div class="m">${noCode ? `<span class="bad">승인된 코드가 없음 — 실행하면 '재계산 불가'로 기록되고 모든 수치 주장은 E06(미확정)</span>`
          : `실행할 코드 <span class="mono">${H(confirmed.code.sha256, 16)}</span> · 승인 ${E(confirmed.code.approved_by)}`}
          ${confirmed.unresolved.length ? `<br><span class="warn">미확정 ${confirmed.unresolved.length}개 — 의존하는 주장은 5단계에서 E06</span>` : ""}</div></div>
      <button id="run_recompute" type="button">${prev.ok ? "다시 계산" : "4 RECOMPUTE 실행"}</button></div>
      <div id="recompute_status" class="m"></div></div></section><div id="recompute_body"></div>`;
    X("#run_recompute").addEventListener("click", () => run(runId));
    if (prev.ok) render(await prev.json());
  };

  async function run(runId) {
    const b = X("#run_recompute"), s = X("#recompute_status");
    b.disabled = true; s.textContent = "격리 실행 중…";
    try {
      const res = await fetch(`/api/runs/${runId}/recompute`, { method: "POST" });
      const r = await res.json();
      if (!res.ok) throw new Error(r.error || res.statusText);
      s.textContent = `끝남 · ${E(r.finished_at)}`;
      render(r);
      document.querySelectorAll(".steps li").forEach((li, i) => li.classList.toggle("on", i <= 3));
      X("#recompute_body").scrollIntoView({ behavior: "smooth" });
    } catch (e) { s.innerHTML = `<span class="bad">${E(e.message)}</span>`; }
    finally { b.disabled = false; }
  }

  function interm(obj) {
    return Object.entries(obj || {}).map(([k, v]) => {
      let body;
      if (v && typeof v === "object" && !Array.isArray(v)) {
        const rows = Object.entries(v);
        const flat = rows.every(([, x]) => typeof x !== "object" || x === null);
        body = flat ? `<div class="tablewrap small"><table><tbody>${rows.slice(0, 60).map(([a, x]) => `<tr><td class="mono">${E(a)}</td><td class="mono">${num(x)}</td></tr>`).join("")}</tbody></table></div>${rows.length > 60 ? `<p class="m">… 외 ${rows.length - 60}개</p>` : ""}`
          : `<pre>${E(JSON.stringify(v, null, 1).slice(0, 4000))}</pre>`;
      } else body = `<pre>${E(JSON.stringify(v, null, 1).slice(0, 2000))}</pre>`;
      return `<details><summary class="mono">${E(k)}</summary>${body}</details>`;
    }).join("");
  }

  function render(r) {
    const ok = r.status === "ok";
    const sb = r.sandbox || {};
    const checks = (r.checks || []).map((c) => `<li>${c.ok ? `<span class="ic ok">✓</span>` : `<span class="ic bad">✕</span>`}<span class="t">${E(c.check)}</span>
        <span class="d">${E((c.problems || []).join("; ") || (c.changed || []).join(", "))}</span></li>`).join("");
    const results = (r.results || []).map((x) => `<tr><td>${E(x.name)}</td><td class="mono">${E(x.symbol)}</td><td>${E(x.condition ?? "")}</td>
        <td class="mono num">${num(x.value)}</td><td>${E(x.unit)}</td><td>${E(x.eq_id)}</td></tr>`).join("");
    const e07 = r.e07 || {};
    const e07html = !e07.compared_with ? `<p class="m">${E(e07.note || "")}</p>`
      : `<p class="m">이전 계산 ${E(e07.compared_with)} 과 데이터 해시 비교 · ${E(e07.note)}</p>${(e07.changes || []).length
        ? `<ul class="plain">${e07.changes.map((c) => `<li><span class="code">E07</span> <span class="kind k-${E(c.kind)}">${E(c.kind)}</span> <span class="mono">${E(c.file)}</span> ${E(c.detail || "")}</li>`).join("")}</ul>`
        : `<p class="ok">데이터 변경 없음</p>`}
        ${(e07.result_changes || []).length ? `<h3>결과값 변화</h3><ul class="plain">${e07.result_changes.map((c) => `<li>${E(c.name)} ${E(c.condition ?? "")}: <span class="mono">${num(c.before)} → ${num(c.after)}</span></li>`).join("")}</ul>` : ""}`;
    const inputs = (r.inputs || []).map((i) => `<tr><td class="mono">${E(i.path)}</td><td class="hash">${H(i.sha256)}</td><td class="hash">${i.content_hash === i.sha256 ? "= 원본" : H(i.content_hash)}</td><td>${i.rows ?? "—"}</td></tr>`).join("");
    X("#recompute_body").innerHTML = `
      <section class="part"><h2><span class="n">4</span>RECOMPUTE <span class="sb ${ok ? "ok" : "error"}">${ok ? "계산 완료" : r.status === "blocked" ? "실행 안 함" : "실패"}</span></h2>
        ${ok ? "" : `<p class="bad">${E(r.reason)}</p>${r.traceback ? `<pre>${E(r.traceback)}</pre>` : ""}`}
        <div class="tiles">
          <div class="tile"><div class="k">결과</div><div class="v">${(r.results || []).length}개</div><div class="m">결과 해시 <span class="mono">${H(r.result_hash)}</span></div></div>
          <div class="tile"><div class="k">입력 (RAW 만)</div><div class="v">${(r.inputs || []).length} 파일</div><div class="m">입력 해시 <span class="mono">${H(r.input_hash)}</span></div></div>
          <div class="tile"><div class="k">코드</div><div class="v mono">${H((r.code || {}).sha256)}</div><div class="m">승인 ${E((r.code || {}).approved_by || "—")}</div></div>
          <div class="tile"><div class="k">블라인드</div><div class="v">${r.blind.report_opened ? "<span class='bad'>열림</span>" : "보고서 미개봉"}</div><div class="m">계산 ${E(r.finished_at)}</div></div>
        </div>
        ${r.unresolved?.length ? `<p class="warn">3 CONFIRM 미확정 ${r.unresolved.length}개: ${E(r.unresolved.map((u) => u.title).join(", "))} — 의존 주장은 5단계에서 E06</p>` : ""}
        ${r.remeasure?.length ? `<p class="warn">재측정 결정: ${E(r.remeasure.map((u) => u.title).join(", "))}</p>` : ""}
      </section>
      <section class="part"><h2><span class="n">4-1</span>수치 재계산</h2><div class="card">
        <h3 style="margin-top:0">실행 전 확인</h3><ul class="checks">${checks}</ul>
        ${results ? `<h3>최종값</h3><div class="tablewrap"><table><thead><tr><th>이름</th><th>기호</th><th>조건</th><th>값 (반올림 전)</th><th>단위</th><th>식</th></tr></thead><tbody>${results}</tbody></table></div>` : ""}
        ${Object.keys(r.intermediate || {}).length ? `<h3>중간값 (raw → 중간값)</h3>${interm(r.intermediate)}` : ""}
        ${(r.process || []).length ? `<h3>승인된 가공 순서</h3><ol class="plain">${r.process.map((p) => `<li>${E(p.description)} <span class="m">${E((p.eq_ids || []).join(", "))}</span></li>`).join("")}</ol>` : ""}
      </div></section>
      <section class="part"><h2><span class="n">4-2</span>계산 로그</h2><div class="card">
        <dl class="kv"><dt>로그</dt><dd class="mono">${E(r.log_path || "")}</dd>
          <dt>격리 실행</dt><dd>${E(sb.mode || "—")} · ${sb.seconds ?? "—"}초 · 제한 ${sb.timeout_s ?? "—"}초 · ${E(sb.limits || "")}</dd>
          <dt>막은 동작</dt><dd>${(sb.denied || []).length ? `<span class="bad">${E(sb.denied.join(", "))}</span>` : "없음"}</dd>
          <dt>환경</dt><dd class="mono small">${E(JSON.stringify(sb.versions || {}))} · 환경 변수 ${E((sb.env || []).join(", "))}</dd>
          <dt>확정 기록</dt><dd class="mono">${H(r.confirmed_sha256, 16)} (${E(r.confirm_status)})</dd>
          ${sb.stdout ? `<dt>코드 출력</dt><dd><pre>${E(sb.stdout)}</pre></dd>` : ""}</dl>
        <details><summary>입력 데이터 해시 2종 (${(r.inputs || []).length})</summary><div class="tablewrap"><table><thead><tr><th>파일</th><th>원본 해시</th><th>내용 해시</th><th>행</th></tr></thead><tbody>${inputs}</tbody></table></div></details>
        <h3>E07 데이터 버전 변경 (기록)</h3>${e07html}
        ${r.lineage ? `<p class="m">1-3 장부: 입력 <span class="mono">${H(r.lineage.input_hash)}</span> · 코드 <span class="mono">${H(r.lineage.code_hash)}</span> → 출력 <span class="mono">${H(r.lineage.outputs[0].sha256)}</span></p>` : ""}
      </div></section>`;
    // 5 VALIDATE · 6 AUDIT 로 이어짐 — 막힌 기록(승인 코드 없음 등)도 뒷단 기록이 있으면 인계 화면이 가능 여부·사유를 보여 줌
    if ((ok || r.backend) && window.showAuditLauncher) window.showAuditLauncher(r.run_id);
  }
})();
