"""승인된 계산 코드 (LLM 초안 → 3-1 승인). 계획서 식 EQ01~EQ03."""
from scipy import stats


def compute(data, params):
    df = data["raw"].copy()
    df["G_S"] = 1.0 / df["resistance_ohm"]                         # EQ01 G = 1/R
    per_sample = df.groupby(["condition", "sample_id"])["G_S"].mean()  # 기술적 반복 → 시료 평균
    an = per_sample.loc["annealed"].to_numpy()
    ad = per_sample.loc["as_deposited"].to_numpy()
    g_an, g_ad = float(an.mean()), float(ad.mean())                 # EQ02 집단 평균
    t, p = stats.ttest_ind(an, ad, equal_var=True)                  # EQ03 2표본 t
    return {
        "outputs": {
            "G_mean_annealed": g_an,
            "G_mean_as_deposited": g_ad,
            "G_diff": g_an - g_ad,
            "G_pct_change": (g_an - g_ad) / g_ad * 100.0,
            "t_stat": float(t),
            "p_value": float(p),
            "df": len(an) + len(ad) - 2,
            "n_annealed": len(an),
            "n_as_deposited": len(ad),
        },
        "steps": [
            {"name": "행 수", "value": len(df)},
            {"name": "시료 수 (어닐링 후)", "value": len(an)},
            {"name": "시료 수 (어닐링 전)", "value": len(ad)},
        ],
    }
