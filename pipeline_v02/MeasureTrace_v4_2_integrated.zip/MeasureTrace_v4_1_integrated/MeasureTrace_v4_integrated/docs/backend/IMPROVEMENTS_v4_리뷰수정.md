# MeasureTrace v4 원안 대비 개선·리뷰 수정 기록

작성: 2026-09-29. 대상: `v4_55/measuretrace`의 4 RECOMPUTE → 5 VALIDATE → 6 AUDIT.

기준은 [파이프라인 v4 확정본](../MeasureTrace_파이프라인_v4_확정.md)과 [오류코드 v4](../MeasureTrace_오류코드_v4.md)다. 두 원안은 수정하지 않는다. 이 문서는 **무엇을 추가·구체화·수정했는지와 이유·검증**을 기록한다. 친구가 바로 연동할 계약·코드 예시·오류 처리·수용 기준은 [인수인계 변경 기록](HANDOFF_v4_변경기록.md) 2장과 11장을 따른다.

## 1. 구분과 현재 상태

| 구분 | 의미 |
|---|---|
| 원안 준수 수정 | 원안이 요구한 동작이 구현에서 깨지던 문제를 고침. 새 제품 정책으로 보지 않음 |
| 구체화 | 원안이 지정하지 않은 입력 형식·계산 경계·기록 방식을 정함 |
| 신설 | 실행 추적·연동을 위해 필드·산출물·검증을 추가 |
| 팀 합의 사항 | 원안 예시만으로 일반화하기 어려운 해석. 구현한 규칙을 기록하되 팀 결정 완료로 단정하지 않음 |
| 남은 과제 | 구현되지 않았거나 이번 검증에서 확인하지 못한 부분 |

초기 리뷰 수정 검증: **100 passed / 실패 0 / 83.51초**, Windows·Python 3.13.6. 기존 60개 + 초기 리뷰 회귀 40개. 측정용 파일은 합성 데이터이고 LLM은 가짜 클라이언트다. 초기 리뷰 작업에서 실제 API 호출·친구의 앞단 실행·실제 PDF/Excel 검증은 하지 않았다.

> **추가 (2026-09-29 22:24)**: 리뷰 수정 후 실제 API 로 돌리자 5-1 스키마가 거절됨 → FIX-18 로 고친 뒤 **102 passed**, 실제 API 전체 실행 + 재평가 성공. 친구 앞단 실행·실제 PDF/Excel 검증은 여전히 하지 않았다.
>
> **추가 (2026-09-29 22:50)**: VALIDATE 집중 리뷰 → FIX-19~21 (2-2절) 후 **109 passed**.
>
> **추가 (2026-09-29 23:06)**: AUDIT 집중 리뷰 → FIX-22~24 (2-3절). 관련 테스트 88개 통과. 전체는 133 통과 / 1 실패 — 실패 1건은 다른 세션이 작업 중인 RECOMPUTE 테스트(`test_recompute_guards.py`).
>
> **추가 (2026-09-29 23:21)**: RECOMPUTE 수정 반영 후 전체 재확인 **135 passed / 실패 0**. 가짜 LLM 데모 + 재평가 정상.

**RECOMPUTE 수정 당시 검증: 135 passed / 실패 0 / 107.63초.** RC-01~06 수정과 24개 회귀를 기존·VALIDATE·AUDIT 테스트 111개와 함께 검사했다. 위 중간 실패의 runner 인코딩 문제도 고쳤다. 테스트 중 소스 변경은 없었으며 이 수정에서 유료 API를 호출하지 않았다. [RECOMPUTE 수정·검증 기록](../outputs/recompute_fixes_2026-09-29/Recompute_Fixes.md)은 8장과 함께 읽는다. 후속 AUDIT AD-01~07은 10장에서 실제 수정 상태를 확인한다.

**현재 최종 검증(2026-09-30): 177 passed / 실패 0 / 190.69초.** AUDIT AD-01~07 수정과 새 회귀 42개를 기존 135개와 함께 확인했다. 테스트 중 소스 변경 없음. [AUDIT 수정·검증 기록](../outputs/audit_fixes_2026-09-29/Audit_Fixes.md)을 보존하며 유료 API를 호출하지 않았다.

증거: [전체 테스트 로그](../outputs/improvements_v4_2026-09-29/pytest_full.txt), [JUnit 결과](../outputs/improvements_v4_2026-09-29/pytest_full.xml). 이전 [리뷰 보고서](../outputs/code_review_v4_2026-09-29/MeasureTrace_v4_Review.md)와 재현 결과는 **수정 전 이력**으로 유지한다. 당시 24개 재현 중 17개 실패를 지금 상태의 실패 수로 읽지 않는다.

최종 [검증·파일 지문 기록](../outputs/improvements_v4_2026-09-29/verification.json)과 [작업 전후 변경 diff](../outputs/improvements_v4_2026-09-29/changes.patch)도 보존한다. 코드·테스트 100개 결과, 문서 링크 유효성, 전체 테스트 이후 소스 변경이 없음을 확인했다.

## 2. 이번 리뷰에서 실제 고친 문제

테스트 이름은 [test_review_regressions.py](tests/test_review_regressions.py)를 기준으로 한다. 기존 비교 규칙과 전체 파이프라인 테스트도 함께 통과했다.

| ID / 구분 | 원안 근거 | 수정 전 재현 / 영향 | 현재 동작 | 구현·검증 |
|---|---|---|---|---|
| FIX-01 원안 준수 | R1, 5-1 | `13.20`에서 `3.20`, 음수에서 부호 제거, 지수값에서 지수 생략이 원문 수치로 인정됨 | 숫자 전체 토큰·부호·지수·표시 자릿수를 대조. 원문과 다른 후보는 거절 | `claims.verify_item`; `test_number_token_keeps_sign_exponent_and_digits` 7사례 |
| FIX-02 원안 준수 | R1, E04/E05 | 원문 `p > 0.05`를 `<`로 바꾸거나 `t(28)`에서 df 8만 추출하면 잘못 비교 | p 숫자와 원문 부등호를 묶어 검증. `t(...)`/`F(...)`, `n=` 표기는 원문에서 읽고 LLM 후보와 대조 | `claims.verify_item`; `test_p_and_df_bound_to_original_statistical_notation` |
| FIX-03 원안 준수 | R1/E01 | 다른 주장에 있는 단위를 빌려 수치에 붙임 | 단위가 해당 `source_text`에 있어야 후보 인정 | `test_unit_cannot_be_borrowed_from_other_claim` |
| FIX-04 원안 준수 | Supported 정의, E06 | 설계·Welch 자유도·재계산 n이 없는데 비교 생략 후 Supported | 비교 불가에 E06. n 결과를 지정했다면 실제 결과 누락/실패도 확인. 검사 이름만 남기고 성공 처리하지 않음 | `compare.check_n/check_df`, `codes.classify`; `test_unavailable_n_df_comparison_cannot_support` |
| FIX-05 원안 준수 | R7, E01/E02/E03/E06/E07 의존 전파 | Welch df를 읽고도 `outputs_used`에서 빠져 자유도 미확정·데이터 오류가 관련 주장에 안 붙음 | df Output을 사용 목록에 넣어 의존 오류·해시·식 근거를 전파 | `compare._compare_numeric/_compare_significance`; `test_welch_df_propagates_pending_dependency` |
| FIX-06 원안 준수·구체화 | E04 | 어느 집단 n이든 또는 A+B 합이면 통과, 대응 검정 쌍 수를 두 배로 인정 | group/total/pairs 범위를 구분. 검정에 연결된 다집단 n이 모호하면 E06, 대응 n은 쌍 수 | `compare.allowed_n/check_n`; `test_paired_n_counts_pairs_and_unscoped_two_group_n_is_ambiguous` |
| FIX-07 원안 준수 | R1/R3 | 승인자·시각이 비거나 `pending code`여도 실행 | 승인 정보·ISO 시각·코드 미확정·묶음 지문 변경이면 실행하지 않고 모든 항목 `blocked` | `contract.approval_problems`, `engine.run_recompute`; `test_unapproved_code_never_executes` 3사례 |
| FIX-08 원안 준수·신설 | R5/R7 | 해시를 확인한 원본을 별도 프로세스가 다시 읽어, 사이에 바뀐 값으로 계산할 수 있음 | 한 번 읽은 RAW 바이트로 해시와 실행 사본 생성. runner도 사본을 읽은 **같은 바이트**를 재검증한 뒤 pandas에 제공 | `hashing.fingerprint_bytes`, `engine._check_data`, `_runner._load_verified_table`; `test_raw_change_after_hash_check_uses_verified_snapshot` |
| FIX-09 원안 준수 | R1/R7 | 고정 코드 사본이 확인 후 바뀌면 새 해시를 runner에 전달할 수 있음 | engine이 확인한 승인 해시를 그대로 runner에 전달. 실행 직전 사본 바이트가 다르면 실패 | `engine._run_sandboxed`; `test_snapshot_tampering_before_runner_is_rejected` 코드·데이터 2사례 |
| FIX-10 원안 준수·구체화 | R4/R5/R6 | 별도 Python 프로세스에서도 RAW 쓰기·보고서 읽기·프로세스/네트워크 접근 가능 | 코드 AST 검사 + Python 감사 훅으로 허용 파일/작업 폴더 밖 접근·네트워크·프로세스 생성 제한. RAW 폴더 안 코드 거부. **OS 격리 구현은 아님** | `_runner._restrict_execution`, `engine._fixed_code`; `test_approved_python_cannot_access_report_or_mutate_raw` 5사례 |
| FIX-11 원안 준수 | R1/R7 | 동일 run_id의 과거 결과가 실패 실행의 새 해시와 함께 남을 수 있음 | run_id 경로 문법 검사, 기존 id 거부, 실행 폴더 새로 생성. 비정상 종료·잘못된 응답은 현재 실패로 처리 | `engine.run_recompute/_run_sandboxed`; `test_reused_run_id_rejected_before_stale_result_can_be_used` |
| FIX-12 원안 준수·신설 | E06/R7 | 문장 후보 일부만 거절되면 요약·리포트에 실패 0으로 보임 | 통과 주장은 판정하고 거절 후보와 부분 실패 문장을 따로 출력. 문장 단위 구조화 실패 요약에도 포함 | `claims.extract_claims`, `audit.report`; `test_partial_rejection_visible_in_summary_and_markdown` |
| FIX-13 원안 준수·구체화 | 6-2 재평가 | 보고값을 고치면 원문/숫자 키가 달라져 새 주장·삭제된 주장으로 나뉨. 같은 키 반복은 하나로 덮어씀 | 항목/검정 중심 의미 키, 반복은 목록으로 보존하고 등장 순서 대응, 전·후 원문 기록 | `audit.rerun.claim_key/verdict_changes`, `audit.report._claim_record`; `test_corrected_claim_and_duplicates_stay_linked` |
| FIX-14 원안 준수·구체화 | 6-2/R7 | 다른 프로젝트 실행 또는 run_id 정렬상 가까운 실행과 비교 | 같은 프로젝트·현재 계산 시작 전 완료한 실행 중 최신 생성 시각 선택. 타 프로젝트 직접 지정은 계산/LLM 호출 전 거부 | `audit.rerun.find_previous_run`, `pipeline.run_backend`; 이전 실행/타 프로젝트 회귀 2개 |
| FIX-15 원안 준수 | R4/R7 | 계산 후 인계 내용이 바뀌거나 보고서 해시와 읽은 내용이 달라질 수 있음 | 현재 인계 지문이 계산 로그와 같은지 확인, 보고서 바이트로 해시·사본을 생성하고 그 사본을 추출. 보고서가 RAW 등록 파일과 같으면 계산 전 거부 | `claims.open_report`, `pipeline.run_backend`; `test_report_same_as_raw_and_changed_contract_break_blindness` |
| FIX-16 원안 준수·구체화 | 수치 재계산/E06 | bool·NaN·Inf·숫자 문자열·잘못된 n/p/df가 계산값으로 흘러들 수 있음 | 유한한 실수/정수만 인정. 문자열 숫자를 자동 계산값으로 바꾸지 않음. n≥0 정수, p∈[0,1], df≥0 | `engine._check_outputs`, `_runner._plain`; 숫자 범위 6사례 + 문자열 실제 runner 검증 |
| FIX-17 원안 준수 | R7 | `zip`으로 결과 개수 차이를 숨김. 데이터/식/검정 id 중복은 결과 연결을 덮어씀 | 주장/비교 개수·id 일치 강제. 인계 id 중복·없는 의존 열·알파·설계/반복 수 오류는 시작 전 거부 | `codes.classify`, `contract.problems`; 검사 표식/zip 회귀, 중복/설계 회귀 |

### 2-1. 리뷰 수정 이후 실제 API 확인에서 추가로 고친 문제

| ID / 구분 | 원안 근거 | 수정 전 재현 / 영향 | 현재 동작 | 구현·검증 |
|---|---|---|---|---|
| FIX-18 원안 준수 | 5-1 (LLM 주장 추출) | 이번 리뷰에서 `n_scope`·`n_group` 을 추가해 5-1 스키마의 null 허용 필드가 17개가 됨 → 실제 API 가 400 "union 필드 한도 16개 초과"로 거절, **모든 문장이 구조화 실패**. 가짜 클라이언트 테스트 100개로는 드러나지 않음 | 자유 문자열 필드 12개는 '없음'을 `""` 로 받고 파이썬이 None 으로 되돌림. null 허용 필드 5개 | `claims.TEXT_FIELDS`·`_blank_to_none`; `test_schemas_within_union_field_limit`, `test_blank_text_fields_become_none` → **102개 통과**. 실제 API 전체 실행 + 재평가 성공 (인수인계 10장) |

### 2-2. VALIDATE 집중 리뷰에서 고친 문제 (2026-09-29 22:50)

수정 전 상태를 실제 호출로 재현한 뒤 고쳤다. 테스트는 `tests/test_compare_rules.py` 끝의 "리뷰(2026-09-29)" 절. 전체 **109개 통과**.

| ID / 구분 | 원안 근거 | 수정 전 재현 / 영향 | 현재 동작 | 구현·검증 |
|---|---|---|---|---|
| FIX-19 원안 준수 | E05 (수치·방향) | 변화량 주장 "12 % 감소"를 부호 없는 `12` 로 비교. 재계산 −12(실제 감소)면 **E05 오탐**, 재계산 +12(실제 증가)면 **잘못된 Supported** | 원문(없으면 그 절)의 증가·감소 표현으로 부호를 정함. 부호 명시는 그대로, 방향어 없으면 크기만 비교(메모), 증가·감소 동시 표현은 E06. 영어 방향어는 단어 경계로(`comprise` 의 `rise` 오인 방지). 사유 문장에 "12 감소(= -12)" 로 표시 | `compare.change_direction`, `CHANGE_KINDS`; `test_decrease_word_sets_sign`, `test_increase_word_and_english`, `test_no_direction_word_compares_magnitude_only`, `test_both_direction_words_is_e06`, `test_explicit_sign_used_as_is` |
| FIX-20 원안 준수 | R1 (짝 검증) | 승인 용어를 **문장 전체**에서 찾아, "면저항은 12 % 감소하였고 전도도는 증가하였다"의 면저항 수치가 전도도 변화율과 짝지어짐 | 주장 원문이 든 **절**에서만 용어를 찾음 (경계: `…였고`·`…했으며` 등 동사 연결 어미, `;`). 명사 끝 '고'(최고)는 경계 아님 | `compare.claim_clause`, `mapping_problem`; `test_term_must_be_in_claim_clause` |
| FIX-21 원안 준수 | 5-1, E05 (유의성) | `p값 < 0.05`, `p 값 < 0.05`, `P-value = 0.003` 에서 원문 p 부등호를 못 찾아 **유의성 주장이 5-1 에서 거절** (구조화 실패) | p 원문 패턴이 `p값`·`p-value`·`pvalue` 를 받음 | `claims._SOURCE_P`; `test_korean_and_english_p_notation_accepted` |

남긴 것 (인수인계 7장 #19~22): 변화량 틀(기준·대상) 뒤집힘 가정, 쉼표로만 이어진 두 지표, 범위 표기 `10-20`, 유의성 부분 검사 하나로 전체 Unsupported 되는 정책.

### 2-3. AUDIT 집중 리뷰에서 고친 문제 (2026-09-29 23:06)

| ID / 구분 | 원안 근거 | 수정 전 재현 / 영향 | 현재 동작 | 구현·검증 |
|---|---|---|---|---|
| FIX-22 원안 준수 | 6-1 "설명 문장은 LLM, 숫자는 파이썬" [판단], R1 | 설명 문장 검사가 아라비아·한자 숫자만 봐서 "재계산값은 보고값의 **두 배**", "**twice**" 가 통과 — 파이썬이 계산하지 않은 수치 관계를 LLM 이 지어냄 | "두 배·절반·twice·half·thousand" 등 말로 쓴 수량이 있으면 LLM 문장을 버리고 템플릿. 프롬프트에도 금지 명시 | `explain._NUM_WORDS`, `check`; `test_explanation_rejects_number_words_and_wrong_direction` |
| FIX-23 원안 준수 | 6-1 (판정과 근거를 나란히) | Unsupported 주장에 "보고값이 재계산값과 **일치합니다**" 가 통과 — 리포트가 판정과 반대 설명을 보여 줄 수 있음 | Unsupported 인데 부정 표현이 없거나, Supported 인데 "지지되지 않·불일치" 등이 있으면 LLM 문장을 버림. 주장 40개씩 나눠 호출해 응답 잘림으로 전부 템플릿이 되는 것 방지 | `explain.check(verdict)`, `EXPLAIN_BATCH`; 같은 테스트 + `test_explanations_batched` |
| FIX-24 원안 준수 | 6-2 수정 전·후 판정 비교 | 데이터를 고치면 모든 관련 주장에 E07 기록이 붙어 **"코드 변화" 7행 중 6행이 E07 뿐** — 실제 변화(E01 → E05) 1건이 묻힘 | 변화 종류를 `코드 변화`(판정을 바꾸는 코드) / `기록 변화`(기록 코드만)로 나눔. 리포트 표는 판정·코드 변화만, 기록 변화는 건수 한 줄 | `rerun.verdict_changes`, `report.render_markdown`; `test_rerun_e07_and_verdict_diff` 보강 |

그 밖에 `audit_result.json` 의 `references` 기본값을 목록으로 고침 (딕셔너리였음). 당시 남긴 것: 인수인계 7장 #23(판정 방향 검사는 표현 목록 기반), #24(Markdown 특수문자 미처리). #23은 후속 AD-02에서 Python 핵심/검증된 안내 정책으로 수정했다(10장).

## 3. 원안에 없던 형식·산출물·실행 규칙

| 추가/구체화 | 형식 / 실제 위치 | 이유 / 호환성 |
|---|---|---|
| `confirmed.json` | `contract.Confirmed` | 3→4 인계 계약. 보고서 본문은 넣지 않음. 실제 RAW 경로와 코드 경로 기준이 다르므로 인수인계 11장 준수 |
| 승인 지문 | 선택 `code.approval_hash`, `seal_approval()` | 코드 해시만으로 잡지 못하는 식·단위·설계·읽기 옵션·params·매칭 변경을 차단. 빈 지문은 legacy-code로 읽되 보장 범위가 좁음 |
| 승인 용어 | 선택 `outputs[].terms` | 같은 단위/변화형의 다른 지표로 잘못 짝짓는 경우 방지. 비어 있으면 대조 생략 메모. 이번 리뷰 전에 들어온 개선을 유지 |
| n 범위 | 추출 응답 `n_scope`, `n_group` | n의 집단/전체/쌍 의미를 구분. 인계 Output에는 `groups`를 사용. 가짜 응답/옛 결과에서 빠진 필드는 `.get`으로 처리 |
| 실제 비교 표시 | 비교 결과 `compared: bool` | `checks` 문구의 존재와 실제 비교를 구분. false이고 다른 Unsupported 근거가 없으면 E06 |
| RAW 실행 사본 | `runs/<id>/input_snapshot/<번호>.<확장자>` | 확인한 데이터 바이트와 계산한 데이터 바이트를 일치시킴. 기록에 `snapshot_path` |
| 보고서 사본 | `runs/<id>/report_snapshot.<확장자>` | 보고서 해시와 주장 추출의 입력을 일치시킴. `blind_log.snapshot_path` |
| 재계산 로그 판본 | `stage_version="recompute-v4.2"`, runner `execution_policy="python-audit-v2"` | 미확정 실행 차단·작업 파일 해시·별칭 검사 변경을 과거 로그와 구분. 인계 스키마 `confirmed-v4.0` 유지 |
| 인계 실행 사본·미확정 게이트 | `confirmed_snapshot.json`, `calc.confirmed_snapshot_path`, `calc.execution_gate` | 실행 시작에 캡처한 인계로 승인·계산·로그를 일치시킴. 관련 미확정 대상·영향 Output·사유를 기록하며 단일 compute 전체를 차단 |
| 작업 파일 지문 | `runner.job_sha256` | runner가 JSON 파싱 전에 전달된 SHA-256과 바이트를 대조. params·읽기 옵션·진입점의 실행 직전 변경 차단 |
| 새 실행 id만 사용 | 영문/숫자 시작, 이후 영문·숫자·`_.-`, 최대 128자 | 디렉터리 탈출·과거 결과 혼용 방지. 같은 코드/LLM 캐시 재사용은 가능하지만 실행 폴더 재사용은 거부 |
| 구조화 실패 목록 | `unstructured`, `rejected_extractions`, `llm_failures` | 판정 대상 후보를 검사하지 못한 사실을 숨기지 않음. 제3의 판정 등급이 아님 |
| 재평가 의미 필드 | 감사 주장에 Output/Test/방향/n 필드, 전·후 원문 | 과거 결과는 남아 있는 사용 항목/검정 근거로 키를 재구성. 반복·값 수정 연결 |
| 범위/형식 검증 | `Confirmed.problems`, 결과 상태 invalid/missing/blocked/failed | 실패를 성공값으로 읽지 않게 하고 원인을 구분. JSON 필드 구조가 호환돼도 이전에 잘못 통과하던 입력은 거절될 수 있음 |

해시와 사본은 동시 파일 변경에서 **실제로 계산한 버전**을 고정한다. 계산 사본을 만든 직후 원본이 바뀌어도 현재 결과는 기록된 사본에 대한 결과다. 다음 실행은 바뀐 원본 해시를 잡아 재확인한다. 원본 폴더 전체를 OS에서 잠그는 기능은 아니다.

## 4. 팀에서 확인할 정책 해석

이미 구현된 아래 규칙은 원안 자체를 고쳐 확정한 결정으로 취급하지 않는다.

| 사항 | 현재 규칙 | 확인할 이유 |
|---|---|---|
| 10^k 크기 차이 | 정확히 지원하는 10의 거듭제곱 배이면 환산 누락 의심 E01 | 원안 E01 예시를 일반화. 실제 단위 오류의 원인을 자동 증명하는 것은 아님 |
| 보고 단위 없음 | 재계산값에 차원이 있으면 E01, 수치 비교를 수행하지 않음 | 단위 없는 숫자를 임의 크기로 읽지 않기 위한 정책 |
| 정수 끝 0 | `1200`은 100 단위 반올림. n/일반 df는 정확 비교, Welch df는 보고 자릿수 비교 | 정수 유효숫자의 모호성을 구현에서 한 규칙으로 정함 |
| 비교 불가 | n 범위 불명·지원 없는 자유도 규칙은 E06 '데이터 없음' | 원안의 Supported 조건을 지키는 보수적 처리. E06 하위 사유를 더 세분할지 팀 결정 가능 |
| 검정 하나 자동 연결 | 검정이 하나면 test_id 미표기 주장을 해당 검정에 연결하고 메모 | 보고서가 검정을 생략한 경우의 매칭 편의. 다중 검정은 특정하지 못하면 E06 |
| 대응 n | 검정에 연결된 n은 쌍 수로 대조하며 A+B 합을 독립 n으로 인정하지 않음 | 보고서의 총 관측 수 표기와 독립 쌍 수를 별개로 지원할지 확인 필요. 현재 대응 검정에서는 `total`도 쌍 수 규칙이 우선 |
| 구조화 실패 | 판정과 다른 문장 목록. 일부 실패 문장에는 판정한 주장도 남음 | UI가 "전부 검사 완료"로 오해하게 합산하지 않도록 합의 필요 |

## 5. 아직 완료하지 않은 부분과 실제 영향

| 우선순위 | 남은 과제 | 현재 보장 / 한계 | 담당·다음 검증 |
|---|---|---|---|
| 후속 계약 확장 | 미확정 항목을 제외한 **부분 실행** | R3 실행 차단은 RC-01에서 구현. 관련 미확정이 있으면 현재 단일 compute 전체 blocked. 같은 코드의 다른 승인 항목도 계산하지 않음 | 앞/뒷단 공동. 미확정 경로를 제외한 새 코드를 승인하거나 항목/그룹별 코드 계약 마련 후 부분 실행 검증 |
| 합치기 전 | 앞단의 실제 사용자 승인·승인 지문 연결 | `seal_approval` 도구는 있음. 과거 파일의 legacy-code는 코드 외 해석 변경을 감지하지 못함 | 앞단. 승인 화면 완료 후에만 지문 생성, 식·단위·설계 변경 재승인 테스트 |
| 실행 환경 결정 전 | OS 수준 실행 격리 | Python 감사 훅/정적 제한만. 네이티브 확장, 시스템 수준 우회까지 격리했다고 말할 수 없음 | 실행 환경 담당. 컨테이너/OS 권한·네트워크/파일시스템 제한 후 독립 검증 |
| 합치기 전 | 전체 1→6 및 수정 후 1단계 재진입 | 뒷단은 새로운 Confirmed를 받아 4부터 실행. E02/E03 탐지는 앞단 담당 | 공동. 계획서/사양 실물부터 데이터 수정·재승인까지 통합 사례 |
| 형식 지원 확정 전 | 실제 PDF·Excel 입력 | 파서 코드 존재. 이번 100개 검증은 TXT/DOCX/CSV 중심 | 실물 fixture와 해당 엔진 의존성 확인 |
| 정확도 평가 | LLM 의미 분류·추출 누락 | 원문 숫자/부등호/단위 대조는 강화. 문장 의미 자체·미추출 주장의 완전성은 보장하지 않음 | 실제 보고서 코퍼스에 정답 라벨을 달아 평가 |
| 후속 개선 | 반복 주장 순서 변경, 빈 terms/동의어 | 같은 의미 키는 등장 순서 매칭. 용어 누락은 E06 또는 대조 생략 | 안정 주장 ID, 승인 용어 목록 보강 |
| 후속 개선 | 설명 숫자 표시 단위, E06 코드 중복 집계, 세부 열 diff | 판정 핵심과 별개. 현재 행 해시 diff는 수정 행을 삭제+추가로 셈 | 리포트 표시/집계 정책·열 단위 diff 요구를 따로 합의 |

## 6. 파일 변경과 검증을 다시 확인하는 방법

핵심 수정 파일: `contract.py`, `pipeline.py`, `common/hashing.py`, `recompute/engine.py`, `recompute/_runner.py`, `validate/claims.py`, `validate/compare.py`, `validate/codes.py`, `audit/rerun.py`, `audit/report.py`. 새 회귀 파일: `tests/test_review_regressions.py`. 기존 `terms` 검증·참고문헌·API 처리 개선은 보존했다.

프로젝트 최상위 PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pytest v4_55/tests -q
.\.venv\Scripts\python.exe -m pytest v4_55/tests/test_review_regressions.py -q
```

`v4_55`에서 기존 환경의 `python`을 쓰면 `python -m pytest -q`, `python scripts/demo.py --rerun`으로 가짜 LLM 데모를 실행할 수 있다. 실제 API 데모는 별도 검증이며 호출 비용과 환경 설정이 필요하다. 현재 최종 통과 결과에는 실제 API 성공을 포함하지 않는다.

작업 전 소스 사본은 `../outputs/improvements_v4_2026-09-29/before/`, 파일 지문은 `before_manifest.json`, 문서 편집 전 사본은 `HANDOFF_before_doc_update.md`에 있다. 문서 작성 중 다른 작업에서 들어온 코드도 있으므로 모든 차이를 한 사람의 수정이라고 단정하지 않는다. 인계할 때는 최종 코드와 문서를 같은 시점으로 전달한다.

검증 중 기술적 반복 수를 실제 필드 `replicates_per_unit` 대신 존재하지 않는 이름으로 참조한 변경이 발견되어 수정했다. 중간 실패 기록은 `pytest_full_before_field_fix.*`로 남기고 전체를 다시 실행해 100개 통과를 확인했다. 최종 통과 이후 코드 변경이 있으면 새 검증 결과로 이 문서와 인수인계 10장을 함께 갱신한다.

## 7. 후속 RECOMPUTE 집중 리뷰 — 발견 당시 기록

사용자 요청으로 recompute만 다시 검토했다. **이 절은 수정 전 리뷰 이력이며 후속 수정은 8장이다.** 당시 운영 소스는 변경하지 않았으며 기존 100개 통과의 의미를 새 경계 사례까지 확대하지 않았다. 기존 recompute 테스트 7개 통과 후 추가 합성 실행에서 미확정 의존 계산, 실행 직전 params 변경, RAW/Output 빈 목록, AST import 별칭 문제를 확인했고, Windows junction으로 RAW 내부 산출물 작성도 재현했다.

상세: [RECOMPUTE 집중 리뷰](../outputs/recompute_review_2026-09-29/Recompute_Review.md). 새 발견은 인수인계 7장 #15~18에 추가했고, 기존 #12의 미확정 실행 문제도 근거를 보강했다. 그 문서의 재현 실패 수는 수정 전 증거다. 현재 수정 적용·검증은 다음 절을 따른다.

검토 중 VALIDATE 병행 변경도 확인했으며 그 변경과 109개/실제 API 기록은 별도 작업의 검증으로 보존한다. 이번 집중 리뷰에서는 전체 테스트를 새로 실행하지 않았고, recompute 테스트 7개와 recompute/contract 지문 일치만 독립적으로 확인했다.

## 8. RECOMPUTE RC-01~06 수정 완료

사용자의 전체 수정 요청에 따라 재현한 여섯 문제를 구현에 반영했다. [상세 수정 기록](../outputs/recompute_fixes_2026-09-29/Recompute_Fixes.md)에 문제별 전·후 동작, 인계 계약·로그 변경, 합칠 때 주의할 실행 정책을 적었다.

| ID | 실제 수정 | 분류 |
|---|---|---|
| RC-01 | 미확정 식·열·Output·단위/E01·E02 의존 검사 후 단일 compute 실행 전 차단 | R3 준수·보수적인 실행 정책 구체화 |
| RC-02 | Confirmed 깊은 사본, params 사본, 인계 지문·로그·lineage 고정. backend 4~6도 같은 캡처 사용 | R1/R4/R7 준수·실행 사본 신설 |
| RC-03 | 각 출력 경로의 실제 경계 확인, RAW/외부 경로 junction·symlink와 기존 파일 hard link 거부 | R5 준수 |
| RC-04 | 빈 data 인계 계약을 실행 폴더 생성 전에 거부 | 필수 입력 검증 구체화 |
| RC-05 | 빈 outputs 인계 계약을 거부하여 빈 결과 성공 방지 | 승인 결과 계약 구체화 |
| RC-06 | import 별칭의 원래 이름·wildcard·금지 속성 검사 | R6/Python 실행 정책 보강 |

작업 파일 변조도 SHA-256으로 차단하고 Windows runner를 `-I -X utf8`로 실행한다. 새 회귀는 [test_recompute_guards.py](tests/test_recompute_guards.py) 24개다. 기존·VALIDATE·AUDIT 테스트를 함께 실행해 **135개 통과, 107.63초**를 확인했다. [전체 로그](../outputs/recompute_fixes_2026-09-29/pytest_full.txt), [JUnit](../outputs/recompute_fixes_2026-09-29/pytest_full.xml), [최종 지문·문서 링크 검증](../outputs/recompute_fixes_2026-09-29/verification.json)을 보존한다. 테스트 중·후 소스 변경을 확인하여 검증 시점과 전달 시점을 연결한다.

원안 두 문서와 친구의 앞단 코드는 수정하지 않았다. 관련 미확정이 하나라도 있으면 모든 Output이 blocked되므로 부분 실행 지원과 구분해야 한다. 정확한 의존 선언과 승인 화면 연결은 앞단과 함께 확인한다. OS 격리·네이티브 확장 우회 방어·검사 직후 파일시스템 변경의 원자성은 별도 과제다. 다른 세션의 VALIDATE/AUDIT 변경과 실제 API 이력은 그대로 보존했다.

## 9. 후속 AUDIT 집중 리뷰 — 발견 당시 기록

사용자 요청으로 결과 출력·설명 생성·수정 후 재평가를 추가 리뷰했다. **이 절은 수정 전 리뷰 이력이며 후속 AD-01~07 구현은 10장이다.** 리뷰 당시 운영 소스/기존 테스트는 수정하지 않았다. [AUDIT 리뷰](../outputs/audit_review_2026-09-29/Audit_Review.md)에 우선순위와 재현 조건·수정 수용 기준을 기록했다. 이전 FIX-22~24의 해결 범위를 아래 새 경계 사례까지 확대하지 않았다.

| ID | 추가 확인 | 발견 당시 상태 / 영향 |
|---|---|---|
| AD-01 / P1 | AUDIT JSON/Markdown에 RAW hard link가 준비되면 write_text로 원본을 덮어씀 | 미수정. RECOMPUTE 경로 보호를 후속 단계 쓰기에도 적용해야 함 |
| AD-02 / P1 | 판정과 반대인 설명·부여하지 않은 오류 코드가 통과 | 미수정. 인수인계 #23의 표현 목록 한계를 실제 오설명으로 재현 |
| AD-03 / P2 | 유니코드 숫자·two times가 숫자 제한을 통과 | 미수정. 설명에 계산하지 않은 수치 관계 생성 가능 |
| AD-04 / P2 | 문자열 아닌 설명 응답에서 TypeError로 AUDIT 중단 | 미수정. 캐시/규약 위반 응답의 항목별 타입 검증·대체 필요 |
| AD-05 / P2 | 손상된 이력은 선택 중단, 미완료 JSON은 이전 실행으로 선택 | 미수정. 필수 로그가 없으면 현재 파일을 추가로 오인. 게시 완료·비교 근거 검증 필요 |
| AD-06 / P2 | ISO 시각 문자열 정렬로 다른 시각대의 이전/미래 실행을 오선택 | 미수정. 실제 UTC 시각 비교 필요 |
| AD-07 / P3 | 설명 거절 사유가 최종 주장 JSON에서 빠짐 | 기록 개선 미적용. 미사용/호출 실패/검증 거절 구분을 보존할 필요 |

기존 관련 테스트 **12개 통과 / 55개 제외 / 36.71초**, [추가 재현](../outputs/audit_review_2026-09-29/review_results.json)은 **19사례 중 정상 대조 3 + 문제 재현 16**이다. 문제 재현 사례 수를 버그 개수로 읽지 않는다. [JUnit](../outputs/audit_review_2026-09-29/pytest_audit.xml)과 [리뷰 지문 검증](../outputs/audit_review_2026-09-29/review_verification.json)을 보존한다. 실제 API를 호출하지 않았고 다른 세션의 실제 API 성공/서버 장애 이력을 수정하지 않았다. 후속 구현 시 이 절과 인수인계 #23·25~30의 상태를 함께 갱신한다.

## 10. AUDIT AD-01~07 수정 반영 (2026-09-30)

사용자의 수정 요청에 따라 일곱 항목을 운영 구현에 반영했다. [상세 수정 기록](../outputs/audit_fixes_2026-09-29/Audit_Fixes.md)에 문제별 전·후 동작·회귀와 신규 로그/호환성을 기록한다. 운영 파일은 audit/storage.py(신설), report.py, explain.py, rerun.py, audit/__init__.py, pipeline.py다. 새 회귀는 tests/test_audit_guards.py이며 기존 가짜 LLM/이전 실행 fixture도 새 계약에 맞췄다.

| ID | 실제 구현 | 원안 대비 구분 |
|---|---|---|
| AD-01 | AUDIT 쓰기 경계·RAW 제외·기존 연결 검사, 임시 파일/개별 교체 | R5 준수 수정·게시 방식 구체화 |
| AD-02 | Python 핵심 설명 고정, LLM 보조 안내 text enum 선택·정확 일치 검증 | 6-1/R1 준수 수정·설명 정책 구체화 |
| AD-03 | Unicode isnumeric/수량 검사와 목록 밖 안내 거부 | R1 준수 수정 |
| AD-04 | 캐시 포함 응답 컨테이너·항목/id/text·중복 검증, 항목별 대체 | 오류 처리 보강 |
| AD-05 | audit_complete.json·필수 파일 지문/내용 일관성, 자동 제외 사유, 명시 지정 사전 검사 | 완료 산출물 신설·E07 근거 준수 수정 |
| AD-06 | UTC 완료 시각 비교, generated_at과 completed_at 분리, 미래/naive/invalid 제외 | 이전 실행 선택 정확성 수정·legacy 시각 정책 구체화 |
| AD-07 | explanation 정책·핵심/안내·검증 상태/대체 사유 보존 | 추적 기록 신설 |

인계 스키마 confirmed-v4.0은 유지한다. 감사 stage_version은 audit-v4.1, 설명 정책은 python-core-advice-v1이다. 새 완료 표식과 설명 필드/출처 해석, 표식 없는 과거 실행의 제한된 호환성은 인수인계 13장에서 확인한다. 실제 API는 이번 수정에서 호출하지 않았고 이전 실제 API/서버 장애 이력은 보존한다. **전체 177개 통과 / 실패 0 / 190.69초**, 새 AUDIT 회귀 42개. 테스트 중·후 소스 지문과 원안 파일 불변·문서 링크는 [최종 검증](../outputs/audit_fixes_2026-09-29/verification.json)에 기록한다.
