# MeasureTrace v4 뒷단 — 인수인계 변경 기록

| 항목 | 내용 |
|---|---|
| 기준 문서 | `MeasureTrace_파이프라인_v4_확정.md` (이하 **파이프라인**), `MeasureTrace_오류코드_v4.md` (이하 **오류코드**) — 둘 다 2026-09-29 확정본 |
| 대상 범위 | 뒷단 4 RECOMPUTE · 5 VALIDATE · 6 AUDIT (앞단 1~3은 친구 담당) |
| 코드 위치 | `v4_55/measuretrace/` |
| 기준 시점 | 2026-09-29 리뷰 수정 반영본. 21:55 작업 중 기록을 현재 구현에 맞게 갱신. 최신 검증은 10장, 개별 변경 이유·회귀 테스트는 `IMPROVEMENTS_v4_리뷰수정.md` 참조. 기존 실제 API 기록과 이번 가짜 LLM 검증은 구분한다 |
| 원칙 | 확정본 두 문서는 **고치지 않는다.** 확정본과 다른 점은 전부 이 문서에 적는다. 코드를 바꾸면 이 문서도 같이 고친다. |

**구분 표기**

| 표기 | 뜻 |
|---|---|
| `[신설]` | 확정본에 없는 것을 새로 만듦 |
| `[구체화]` | 확정본이 방향만 정한 것을 구체적인 규칙·형식으로 정함 (내용은 같음) |
| `[변경]` | 확정본과 다르게 동작함 — **팀 확인 필요** |
| `[미구현]` | 확정본에 있으나 뒷단에서 하지 않음 (이유 적음) |
| `[주의]` | 알려진 문제·한계 |

---

## 1. 한눈에 보기

| # | 구분 | 무엇 | 위치 |
|---|---|---|---|
| 1 | `[신설]` | 앞단 → 뒷단 인계 파일 **`confirmed.json`** 형식 | 2장 |
| 2 | `[신설]` | 승인 지표 용어 `terms` — 주장 ↔ 재계산 항목 짝 검증에 사용 | 2장, 4-5-2 |
| 3 | `[신설]` | 승인 지문 `approval_hash` — 승인 뒤 식·단위·설계가 바뀌면 계산 차단 | 2장, 4-4-1 |
| 4 | `[구체화]` | 4-1 승인 코드 실행 방식 (별도 프로세스, 입력 사본, 해시 확인) | 4-4-1 |
| 5 | `[구체화]` | 5-1 LLM 결과를 파이썬이 원문과 대조해 거르는 규칙 | 4-5-1 |
| 6 | `[구체화]` | 5-2 유효 자릿수 반올림 규칙 (정수 끝 0, 지수 표기, 사사오입) | 5장 |
| 7 | `[변경]` | 10^k 배 차이는 E05 가 아니라 **E01** | 4-E01 |
| 8 | `[변경]` | 보고 수치에 단위가 없으면 **E01** | 4-E01 |
| 9 | `[변경]` | 비교를 **할 수 없는** 경우(n 범위 불명, 자유도 규칙 없음 등)는 넘어가지 않고 **E06** | 4-E06 |
| 10 | `[신설]` | "구조화 실패" 목록 — 판정이 아니라 "검사하지 못한 문장" 목록 | 4-6-1 |
| 11 | `[신설]` | 6-1 설명 문장: LLM 은 자리표시자로만 쓰고 숫자는 파이썬이 채움, 숫자가 섞이면 버림 | 4-6-1 |
| 12 | `[구체화]` | 6-2 를 둘로 나눔 — 데이터 비교(E07)는 5-3 앞, 판정 비교는 6-1 뒤 | 4-6-2 |
| 13 | `[미구현]` | "1부터 재실행"의 1~3 단계 — 앞단 연결 후 가능 | 4-6-2 |
| 14 | `[주의]` | 승인 코드 격리는 OS 샌드박스가 아님 (파이썬 수준 제한만) | 7장 |
| 15 | `[구체화]` | 재평가 호출 연결 완료: 같은 프로젝트의 완료 시각 기준 이전 실행, 수치가 수정된 주장도 연결, 반복 주장 보존 | 4-6-2, 8장 |

별도 개선 기록: [IMPROVEMENTS_v4_리뷰수정.md](IMPROVEMENTS_v4_리뷰수정.md). 합칠 때 필요한 코드 예시·작업 순서·수용 기준은 이 문서 11장에 있다.

---

## 2. `[신설]` 앞단 → 뒷단 인계 형식 — `confirmed.json`

확정본에는 3 CONFIRM 결과를 4 RECOMPUTE 에 **어떤 형식으로** 넘기는지 없다. 뒷단은 이 파일 하나만 읽는다.

- 형식 정의: `measuretrace/contract.py` (`Confirmed` 클래스)
- 예시: `examples/confirmed.example.json`, `examples/approved_code.example.py`
- 보고서 내용은 이 파일에 넣지 않는다 (R4 — 보고서는 5-1에서 처음 연다)
- `schema_version` = `confirmed-v4.0`. 이번 `approval_hash`·`terms`는 기본값이 있는 선택 필드로 추가해 기존 파일을 계속 읽는다. **읽기 호환성과 동작 호환성은 다르다**: 빈 승인 정보·비교 불가는 이제 차단한다. 필수 필드 변경은 버전을 올리고 팀에 공지

### 2-1. 필드와 앞단 담당 과업

| 필드 | 채우는 과업 | 내용 | 뒷단에서 쓰는 곳 |
|---|---|---|---|
| `input_root` | 1-1 | RAW 입력 폴더 (읽기 전용) | 4-1 |
| `data[].path`, `sha256`, `content_hash` | 1-2 | RAW 파일 경로, **원본 바이트 해시**, 내용 정규화 해시(선택) | 4-1 데이터 변경 확인, 4-2, E07 |
| `data[].read` | 2-3 / 3-1 | pandas 읽기 옵션. 허용 키: `sep, header, skiprows, encoding, decimal, comment, sheet_name` | 4-1 |
| `data[].columns{열: meaning, unit, unit_status}` | 2-3 → 3-3 | 열 의미·단위. 3회 뒤에도 미확정이면 `unit_status="unresolved"` | E01 ① |
| `equations[]` | 2-1b | `id, latex, context(앞 문단 문장), eq_hash` | 6-1 리포트 "사용한 식" |
| `code.path`, `code.sha256` | 2-1c → 3-1 | 승인된 계산 코드 파일(confirmed.json 기준 상대 경로)과 **승인 시점 해시** | 4-1 |
| `code.approved_by`, `approved_at` | 3-1 | 승인자, ISO 시각 — **없으면 계산하지 않음** | 4-1 |
| `code.approval_hash` | 3-1 | 선택. `Confirmed.seal_approval()` 로 만듦 (2-3절) | 4-1 |
| `outputs[]` | 2-1c → 3-1 | 코드가 내야 하는 재계산값 목록 (2-2절) | 4-1, 5-1, 5-2 |
| `design` | 2-1c → 3-1 | 독립 단위, 집단별 독립 단위 수, 기술적 반복 수, 검정 목록 | E04, 유의성 |
| `design.tests[]` | 2-1c → 3-1 | `id, name(student_t·welch_t·paired_t·one_sample_t·one_way_anova·other), groups, alpha, p_output, stat_output, df_output` | 5-2 유의성·자유도 |
| `flags[]` | 2-3, 2-4, 3-2, 3-3 | 앞단이 확정한 E01·E02·E03 기록. `decision`: `proceed` / `unresolved` / `missing` | 5-3 |
| `pending[]` | 3 CONFIRM | 3회 뒤에도 미확정인 항목 (`target` = 참조 표기 또는 Output id) | E06 '미확정' |
| `confirm_rounds` | 3 CONFIRM | 1~3. 범위 밖이면 계산하지 않음 | 형식 검사 |

### 2-2. `outputs[]` — 재계산 항목

코드는 **숫자만** 낸다. 이름·단위·의미·짝 검증 기준은 여기서 정하고 3-1에서 승인한다.

| 필드 | 내용 |
|---|---|
| `id` | 코드가 돌려주는 키 |
| `description` | 5-1 LLM 이 주장과 짝지을 때 보는 설명 (값은 보지 않음) |
| `kind` | `value · difference · ratio · percent_change · test_statistic · p_value · df · n` |
| `unit` | pint 로 읽을 수 있는 단위 (무차원이면 null) |
| `equations` | 사용한 식 id |
| `depends_on` | 의존 대상 (참조 표기) — **E01·E02·E03·미확정이 어느 주장에 붙을지 이것으로 정함** |
| `groups` | 집단. difference·ratio 는 `[대상, 기준]` 순서 |
| `terms` `[신설]` | 승인 지표 용어 (예: `["전도도", "conductance"]`). 주장 문장에 이 중 하나가 있어야 짝지을 수 있음. 비우면 대조 생략 |

**참조 표기** (`depends_on`, `flags[].target`, `pending[].target` 공통)

| 표기 | 뜻 |
|---|---|
| `raw` | 데이터 파일 전체 (그 파일의 모든 열 포함) |
| `raw#resistance_ohm` | 데이터 파일의 한 열 |
| `item:<id>` | 계획서가 요구한 파일·시료·측정 항목 (2-4 누락 점검) |
| `eq:<id>` / `code` | 식 / 계산 코드 |

### 2-3. 승인 지문 `approval_hash` `[신설]`

- 앞단이 사용자 승인을 받은 뒤 `confirmed.seal_approval(approved_by)` 를 호출하면, 데이터 정의·식·Output·설계·코드 해시·파라미터를 묶은 지문이 저장된다.
- 뒷단은 계산 직전에 지문을 다시 떠서 다르면 **계산하지 않는다** (모든 Output 상태 `blocked` → 관련 주장 E06 '미확정').
- 지문이 비어 있으면(`approval_scope: legacy-code`) 코드 해시만 확인한다.
- `legacy-code`도 승인자·승인 시각은 필요하다. 코드 외 식·단위·설계의 승인 후 변경은 지문이 없으면 확인할 수 없다. 새 앞단은 `seal_approval()`를 연결할 것.
- 지문은 데이터 정의·읽기 옵션·열 단위·식·Output·용어·설계·코드 해시·진입점·파라미터를 묶는다. 사용자 인증용 전자서명은 아니며, 승인 화면과 실제 사용자 승인 기록은 앞단 책임이다. `flags`·`pending`은 이 지문에 포함되지 않는다.
- 이유: 파이프라인 R3 "승인되지 않은 식·가공 방법·코드·단위·사양은 계산에 쓰지 않는다" — 코드 해시만으로는 승인 뒤 단위·설계가 바뀐 것을 잡을 수 없다.

### 2-4. 승인 코드 규약

```python
def compute(data: dict[str, pandas.DataFrame], params: dict) -> dict:
    return {"outputs": {"<Output id>": 숫자, ...},
            "steps": [{"name": "...", "value": ...}, ...]}   # 계산 과정 (4-2 로그에 남음)
```

---

## 3. 원칙(R1~R7) 구현 위치

| 원칙 | 구분 | 구현 | 위치 |
|---|---|---|---|
| R1 LLM 숫자를 계산 입력으로 쓰지 않음, 승인 + 해시 고정 후 실행 | `[구체화]` | 코드 해시·승인자·승인 시각·승인 지문 확인 후 실행. 5-1 LLM 이 낸 수치·단위·자유도·p 부등호는 원문과 글자 대조. 설명 문장 속 숫자 거절 | `recompute/engine.py`, `validate/claims.py verify_item`, `audit/explain.py check` |
| R2 측정값은 LLM 에 넣지 않음 | `[구체화]` | 5-1: 재계산 항목의 이름·설명·단위·집단·용어만. 6-1: 재계산값 대신 자리표시자 이름과 뜻만 | `claims.catalog_text`, `explain.explain_all` — 테스트 `test_llm_never_sees_measured_values` |
| R3 승인 안 된 것은 계산에 안 씀 | `[구체화]` | 코드 미확정·승인 정보 누락·지문 불일치 및 승인 Output의 식/열/항목/단위 의존 미확정은 **실행 전 차단**. 단일 compute이므로 관련 미확정이 있으면 전체 계산 blocked. 무관한 pending·E02 proceed는 이 사유로 차단하지 않음 (7장 #12) | `contract.approval_problems/unconfirmed_dependencies`, `engine.run_recompute` |
| R4 블라인드 | `[구체화]` | RECOMPUTE 함수는 보고서 경로를 받지 않음. 5-1이 `계산 로그 완료 시각 < 보고서 열람 시각` 을 확인하고 `blind_log.json` 기록, 아니면 중단 | `claims.open_report` |
| R5 입력 읽기 전용, 산출물은 입력 밖 | `[구체화]` | RECOMPUTE와 AUDIT는 개별 쓰기 대상의 실제 경계/RAW 제외·기존 연결을 검사. AUDIT의 기존 symlink·hard link는 거부하고 임시 쓰기 후 파일을 교체. RAW는 실행별 사본으로 제공 | `engine._output_path`, `_check_data`, `audit.storage.output_path`; AD-01 수정 13장 |
| R6 입력 폴더 스크립트 실행 안 함 | `[구체화]` | 승인 코드가 RAW 입력 폴더 안에 있으면 거부 | `engine._fixed_code` |
| R7 근거·LLM 감사 로그 | `[구체화]` | 주장마다 쪽·문장, 보고값, 재계산값, 식, 데이터 해시, 코드 해시. LLM 호출·캐시 적중은 `llm_audit_log.jsonl` | `audit/report.py`, `common/llm.py` |

---

## 4. 과업별 변경 (파이프라인 4장 대비)

### 4-4-1. 4-1 수치 재계산 — `recompute/engine.py`, `_runner.py`

| 확정본 | 구현 | 구분 |
|---|---|---|
| 입력은 RAW 만 | `confirmed.data[]` 파일만 읽음 | 동일 |
| 승인된 코드로 계산 | 인계 깊은 사본 고정 → 형식/필수 목록 검사 → run_id·실제 출력 경로 검증 → 데이터 해시 → 승인·미확정 의존 확인 → 코드 해시 → 실행. params와 job 파일도 사본·해시로 고정 | `[구체화]` |
| "격리된 환경에서 실행" [판단] | 별도 프로세스 `python -I -X utf8`, API 키 등 환경변수 제거, 120초 시간 제한, 작업 폴더·TEMP 를 출력 폴더 안으로. runner 안에서 ① 작업 파일·코드·데이터 사본 해시 재확인 ② 코드 정적 검사(`ctypes`·`pickle`·`importlib`·`threading` 등 모듈, `eval`·`exec`·`getattr`·`__import__` 등 이름, `_` 로 시작하는 속성 금지). import 별칭도 원래 이름으로 확인하고 wildcard는 거부 ③ 파이썬 감사 훅으로 작업 폴더 밖 파일 쓰기·읽기(라이브러리·입력 사본 제외), 폴더 탐색, 네트워크·프로세스 생성 차단. **OS 샌드박스 아님** (7장) | `[구체화]` `[주의]` |
| 승인된 코드는 해시 고정·재사용 | `<출력>/approved_code/<sha256>.py` 로 고정, 같은 해시면 재사용, 고정본이 변조되면 거부. runner에도 **승인 때 확인한 해시**를 전달해 실행 직전 바이트와 대조 | `[구체화]` |
| — | RAW 를 실행별 사본으로 복사해 코드에 넘김 (확인한 바이트와 계산한 바이트를 같게) | `[신설]` |
| — | 코드 결과 검사: 수치가 아니거나 유한하지 않으면 `invalid`, p 값은 0~1, n 은 0 이상 정수, df 는 0 이상 | `[신설]` |
| — | 실패 구분: 해시 불일치·데이터 변경·형식 문제는 **예외(계산 안 함)**, 코드 실행 실패·시간 초과는 **로그에 `failed`** 로 남기고 5단계 진행(관련 주장 E06 '데이터 없음'), 승인 문제는 `blocked`(관련 주장 E06 '미확정') | `[신설]` |
| — | run_id 는 영문·숫자·`_-.` 만, 이미 있는 id 는 거부 | `[신설]` |

### 4-4-2. 4-2 계산 로그 — `runs/<id>/calc_log.json`

| 확정본 | 구현 | 구분 |
|---|---|---|
| 데이터 해시 2종 | `sha256` + `content_hash`(텍스트 표: BOM 제거·개행 통일·줄 끝 공백 제거·끝 빈 줄 제거, 방법 `text-lines-v1`) | 동일 |
| 계산 과정 | 코드가 돌려준 `steps` | 동일 |
| 결과값·결과 해시·코드 해시 | `outputs`, `results_sha256`, `code.sha256` (+ 승인자·시각·지문) | 동일 |
| — | 행별 해시 `data_rows.json` (E07 행 수 차이용) | `[신설]` |
| — | 산출물 이력 장부 `lineage.jsonl` 에 `(입력 해시, 코드 해시, 파라미터) → 결과 해시` 한 줄 (파이프라인 1-3 정의를 4-1 산출물에도 적용) | `[신설]` |
| — | `report_opened: false` — 이 시점까지 보고서를 열지 않았음 | `[신설]` |

### 4-5-1. 5-1 주장 추출·분류 — `validate/claims.py`, `report_reader.py`

| 확정본 | 구현 | 구분 |
|---|---|---|
| 보고서를 처음 연다 | `open_report`가 계산 로그·현재 인계 파일 지문·열람 순서를 확인한 뒤 한 번 읽은 바이트로 해시와 **보고서 사본**을 만든다. 5-1은 이 사본을 읽음. 보고서와 RAW 등록 파일이 같으면 계산 전 중단. RAW 폴더 안 별도 파일이면 주의 문구 | `[구체화]` |
| 쪽 번호·문장 번호 | DOCX: Word 저장 쪽 표시(`lastRenderedPageBreak`) → 없으면 명시적 쪽 나눔 → 둘 다 없으면 전부 1쪽. PDF: 쪽 번호. 텍스트: 폼피드. 방식은 `page_mode` 로 리포트에 남김 | `[구체화]` `[주의]` |
| 문장 분류 7종 | `numeric · direction · significance · degree · mixed · citation · qualitative` + 제목·설명용 `none` | `[구체화]` (`none` 신설) |
| 문헌 인용: 인용 번호·참고문헌 원문 기록 | 보고서의 "참고문헌/References" 절을 따로 떼어 번호로 원문을 찾아 붙임. 참고문헌 절은 주장 목록에 넣지 않음 | 동일 |
| 혼합: 우리 값만 검사, 문헌값은 기록 | `literature_values` 로 기록 | 동일 |
| — | LLM 이 **주장 ↔ 재계산 항목 짝 후보**도 냄 (항목 설명만 보고) — 확정본은 5-2에서 "대응하는 재계산값"이라고만 함 | `[신설]` |
| — | LLM 결과 검증(R1). 하나라도 어긋나면 그 주장 후보를 버리고 `rejected`·"구조화 실패"에 이유를 남김: ① 원문이 문장에 글자 그대로 있나 ② 수치가 원문에 **숫자 토큰 전체로** 있나(부호·지수·자릿수 생략 불가) ③ 단위가 **그 주장 원문**에 있나 ④ p 부등호가 원문과 같은가 (`"< 0.001"` 처럼 숫자 칸에 온 부등호는 분리) ⑤ `t(28)`·`n = 10` 표기와 LLM 이 낸 자유도·n 이 같은가 ⑥ 모르는 항목 id·검정 id 는 비움 | `[신설]` |
| — | n 범위 필드 `n_scope`(group/total/pairs)·`n_group` — 보고 n 이 어느 집단의 수인지 | `[신설]` |
| — | 40문장씩 나눠 호출. 한 묶음이 실패해도 나머지는 계속, 실패는 `llm_failures` | `[신설]` |

### 4-5-2. 5-2 재계산값과 비교 — `validate/compare.py`, `rounding.py`

| 확정본 | 구현 | 구분 |
|---|---|---|
| 수치: 보고 유효 자릿수로 반올림 | 5장 규칙 | `[구체화]` |
| 단위 환산 | pint + 표기 정규화 사전(`Ω/□`, `ohm/sq`, `%`, `°C` …) — `common/units.py` | `[구체화]` |
| 방향: 차이 부호 | `lhs − rhs` 부호. 두 항목 단위가 다르면 환산 후 비교 | 동일 |
| 유의성: 계획서 검정으로 재계산 | 재계산 p < α. 보고 p 값·부등호도 대조. 검정이 하나뿐이면 보고서가 검정을 특정하지 않아도 그 검정으로 봄(메모 남김) | `[구체화]` |
| 보고 n·자유도 vs 설계 | 기대 자유도: student_t `n1+n2−2`, paired/one-sample `n−1`(대응은 집단 크기가 같아야), 일원 분산분석 `(k−1, N−k)`, welch_t 는 재계산 자유도를 보고 자릿수로 반올림해 비교 | `[구체화]` |
| 대응 재계산값 없으면 E06 | 아래 짝 검증을 통과하지 못해도 E06 '식 없음' | `[구체화]` |
| — | **짝 검증** (LLM 후보를 그대로 믿지 않음): ① 주장 통계량 ↔ 항목 종류 (p↔p_value, t·F·χ²↔test_statistic, n↔n, df↔df, 평균·중앙값·SD↔value, 차이↔difference, 변화율↔percent_change) ② 통계량이 없는 주장은 p_value·df·n 항목과 짝지을 수 없음 ③ value·difference·ratio·percent_change 는 **주장이 든 절에 승인 용어(`terms`)가 있어야** 함 — 절 경계는 동사 연결 어미(`…였고`·`…했으며` 등)와 `;`. "면저항은 12 % 감소하였고 전도도는 증가하였다"에서 면저항 수치를 전도도 항목과 짝지을 수 없음 ④ 방향 주장은 value 항목끼리만 ⑤ `[변경 2026-09-30]` 승인 용어가 **문장과 다른 언어**라 용어로 확인할 수 없으면(한국어 계획서 용어 ↔ 영어 보고서, 약어·기호 용어 NEP·D~NEP 는 언어 무관으로 봄) ③ 대신 **값 유일성**: 보고값이 유효 2자리 이상이고, 이 항목과 보고 자릿수로 맞고, 같은 종류의 다른 승인 항목과는 맞지 않을 때만 짝 인정. 안 맞으면 E05 가 아니라 E06(짝 확인 불가). 방향 주장은 두 항목이 같은 지표의 두 조건이고 그 두 조건에 값 항목을 가진 지표가 하나뿐일 때만. 같은 언어 보고서는 ③ 그대로 | `[신설]` |
| — | **변화량(difference·percent_change) 주장의 방향어**: 보고서는 "12 % 감소"처럼 부호 없는 크기 + 방향어로 쓴다. 파이썬이 주장 원문(없으면 그 절)에서 증가·감소 표현을 읽어 부호를 정함 — 감소 → 음수, 증가 → 양수, 보고값에 부호가 있으면 그대로, 방향어가 없으면 **크기만** 비교(메모), 증가·감소가 함께 있으면 E06 '데이터 없음'. 재계산 부호는 Output `groups` 의 `대상 − 기준` | `[신설]` |
| — | 실제 비교를 한 번이라도 한 주장만 Supported 가능 (`compared` 표시) | `[신설]` |

### 4-5-3. 5-3 오류 코드 분류 — `validate/codes.py`

| 확정본 | 구현 | 구분 |
|---|---|---|
| 주장마다 판정 + 코드 + 사유 | 5-2 코드 + 의존 관계(`depends_on`·식·코드)를 따라 앞단 기록(E01①·E02·E03·미확정)과 E07 을 붙임 | `[구체화]` |
| 판정을 바꾸는 코드가 하나라도 있으면 Unsupported | 각 코드에 `effect`(`unsupported`/`record`) | 동일 |
| — | E03 이 붙으면 같은 주장의 E06 '데이터 없음'은 뺌 (원인이 겹침) | `[신설]` |
| — | 비교를 하나도 못 했고 다른 Unsupported 코드도 없으면 E06 '데이터 없음' (근거 없는 Supported 방지) | `[신설]` |

### 4-6-1. 6-1 결과 출력 — `audit/report.py`, `explain.py`

| 확정본 | 구현 | 구분 |
|---|---|---|
| Supported / Unsupported / 검사 대상 아님 목록 | `audit_report.md` + `audit_result.json` | 동일 |
| 원문(쪽·문장)·보고값·재계산값·식·데이터 해시 나란히 | 표 + 주장별 상세 (코드 해시·수행한 검사·근거 포함) | 동일 |
| 설명 문장은 LLM이 쓸 수 있고 숫자는 파이썬 [판단] | **AD-02/03/04/07 수정**: 판정·숫자·코드·핵심 사유는 Python 템플릿. LLM은 text enum의 보조 안내 한 문구만 선택하며 캐시도 동일 검증. 자유 문장·숫자·배수·임의 코드·타입/중복 오류는 해당 주장만 대체. 최종 JSON에 핵심/안내·정책·상태·대체 사유 보존. 40개씩 호출 | `[구체화]` 설명 정책·UI 표시 변경은 13장 |
| — | **구조화 실패** 목록: LLM 이 분류하지 못했거나 검증을 통과하지 못한 문장. 판정이 아니며 "검사하지 못함"으로 표시 — 안 한 검사를 한 것처럼 보이지 않게 | `[신설]` |
| — | 블라인드 입증 절 (두 시각, 보고서·코드·결과 해시) | `[신설]` (파이프라인 5장 [판단]을 리포트에 표시) |
| — | 판정 범위 문구 ("과학적 진실이 아니라 제출 자료가 주장을 지지하는가") | `[신설]` |

### 4-6-2. 6-2 수정 후 재평가 — `audit/rerun.py`, `pipeline.py`

| 확정본 | 구현 | 구분 |
|---|---|---|
| 1부터 재실행 | 뒷단은 새 `confirmed.json` 으로 4부터 다시 실행. **1~3 재실행은 앞단 몫** | `[미구현]` (앞단 연결 후) |
| 수정 전·후 판정 비교 | 수치 주장은 Output, 방향은 항목 쌍, 유의성은 검정 중심의 **의미 키**로 연결. 보고값·쪽 번호가 바뀌어도 연결. 같은 키가 반복되면 보고서 등장 순서대로 대응하고 수정 전·후 원문을 저장. 변화 종류: 새 주장 / 사라진 주장 / **판정 변화** / **코드 변화**(판정을 바꾸는 코드가 달라짐) / **기록 변화**(E02 진행·E07 등 기록만 달라짐) / 변화 없음. 리포트 표에는 기록 변화를 빼고 건수만 적음 — 데이터를 고치면 모든 주장에 E07 이 붙어 진짜 변화가 묻히기 때문 | `[구체화]` |
| 이전 실행 데이터 해시와 비교(E07) | 4-E07 | 동일 |
| — | 실행 순서를 둘로 나눔: **데이터 비교는 5-3 앞**(E07 기록을 주장에 붙이려고), **판정 비교는 6-1 결과를 만든 뒤** | `[구체화]` |
| — | 이전 실행은 기본값으로 **같은 `project_id`**의 감사 결과까지 끝난 실행 중 현재 계산 시작 전 완료한 최신 실행을 선택. run_id 문자열 순서에 의존하지 않음. 경로 지정·비교 안 함도 가능. 타 프로젝트 지정은 계산·LLM 호출 전 거부 | `[신설]` |

---

## 4-E. 오류 코드별 변경 (오류코드 v4 대비)

| 코드 | 확정본 | 뒷단 구현 | 구분 |
|---|---|---|---|
| **E01** ① | 3회 뒤에도 단위 미확정인 열을 쓰는 주장 Unsupported | `columns[].unit_status="unresolved"` 또는 `flags` E01 `unresolved` 가 주장의 의존 열에 걸리면 | `[구체화]` |
| **E01** ② | 보고 단위 환산이 어긋난 주장 | 환산 불가(차원 다름·해석 불가) → E01 | 동일 |
| E01 | 예시 "3.2 mS vs 3.2 S → 1000배(환산 누락)" | 반올림 불일치이면서 **재계산값 × 10^k 가 보고값과 반올림 일치**(k = ±2, 3, 6, 9, 12)면 E05 가 아니라 **E01 '환산 누락 의심'** | `[변경]` 팀 확인 |
| E01 | — | 재계산 단위가 있는데 **보고 수치에 단위가 없으면 E01**, 값 비교는 하지 않음 | `[변경]` 팀 확인 |
| **E02** | '그대로 진행'이면 기록, 3회 뒤 미결정이면 Unsupported | `flags` E02 `proceed` → 기록(파일·행·열·결정자·시각을 근거로), 그 밖 → Unsupported | `[구체화]` — **탐지는 앞단** |
| **E03** | 누락 데이터가 필요한 주장 Unsupported | `flags` E03 이 주장의 의존 대상에 걸리면 | `[구체화]` — **탐지는 앞단** |
| **E04** | 보고 n·자유도 vs 설계, 결론이 유지되어도 Unsupported | 4-5-2 기대 자유도 규칙. 보고값이 `독립 단위 수 × 기술적 반복 수 (−1, −2, −집단 수)` 와 같으면 사유에 **pseudoreplication 의심** 표시. n 은 `n_scope`/`n_group` 에 맞는 설계값과 대조, n 항목과 짝지어졌으면 재계산 n 과도 대조 | `[구체화]` |
| **E05** | 수치·방향·유의성, "크게"는 판정 제외 | 수치는 5장, 방향은 부호, 유의성은 p<α + 보고 p 대조. 정도 표현은 메모로 "판정 제외" | 동일 |
| **E06** | 사유 4종: 식 없음 / 데이터 없음 / 미확정 / 검정 방법 없음 | `reason_type` 에 4종 중 하나. 아래 경우를 각 사유에 넣음 | `[구체화]` |
| E06 '식 없음' | 계획서에 없는 지표 | + LLM 짝 후보가 짝 검증을 통과하지 못함 | `[구체화]` |
| E06 '데이터 없음' | 데이터 없음 | + 코드 실행 실패·값 누락·범위 오류, 보고 수치를 읽지 못함, 비교를 하나도 못 함 | `[구체화]` |
| E06 '미확정' | CONFIRM 3회 뒤 미확정에 의존 | `pending` 이 의존 대상에 걸림 + **승인 확인 실패로 계산이 막힘**(`blocked`) | `[구체화]` |
| E06 '검정 방법 없음' | 유의성 주장인데 계획서에 검정 없음 | + 검정이 여러 개인데 어느 것인지 특정 못함, 자유도 주장에 대응 검정 없음 | `[구체화]` |
| E06 | — | **비교할 수 없는 경우**(자유도 규칙 없는 검정, n 이 어느 집단인지 불명, 대응 설계의 집단 크기 불일치, 자유도·n·p 표기를 읽지 못함)는 조용히 넘어가지 않고 E06 '데이터 없음' | `[변경]` 팀 확인 |
| **E07** | 이전 실행 계산 로그 해시 vs 현재, 기록, 몇 행 바뀌었는지 | 파일 추가·삭제 / 바이트만 다르고 내용 해시 같음 → "형식만 변경"(E07 아님) / 내용 변경 → 행별 해시로 추가·삭제 행 수 ("3행 감소 (추가 0행, 삭제 3행)"). 값이 바뀐 행은 "삭제 1 + 추가 1"로 셈. 승인 코드 해시가 바뀌면 함께 표시 | `[구체화]` |
| 판정 체계 | Supported / Unsupported, Review Required·경고 폐지 | 그대로. 판정이 아닌 목록 2개: "검사 대상 아님", **"구조화 실패"** | `[신설]` (구조화 실패) |

---

## 5. `[구체화]` 허용오차 (파이프라인 6장, 오류코드 3장) — `validate/rounding.py`

| 구분 | 규칙 |
|---|---|
| ① 도구 정확도 | `tool_accuracy_ok(재계산, 정답)`: 상대 오차 ≤ 1e-6. 정답이 0 이면 재계산도 정확히 0 |
| ② 주장 판정 — 소수점 있는 보고값 | 그 소수 자릿수로 반올림 (`7.6` → 0.1 단위, `7.60` → 0.01 단위) |
| ② 정수 보고값 | **끝의 0 은 유효숫자로 보지 않음** (`1200` → 100 단위, `140` → 10 단위) `[판단]` |
| ② 지수 표기 | `3.2e-5`, `3.2×10⁻⁵`, `3.2×10^-5` 지원 |
| ② 천 단위 쉼표 | `1,234` 지원 |
| ② 반올림 방식 | 사사오입(ROUND_HALF_UP). float 는 최단 표현(repr)으로 Decimal 변환 |
| n·자유도 | 반올림 없이 **정확히 같아야** 함 (welch 자유도만 반올림 비교) |
| p 값 부등호 | `p < 0.001` 은 재계산 p < 0.001 인지로 판정 |

---

## 6. `[신설]` LLM 사용 — `common/llm.py`

| 항목 | 내용 |
|---|---|
| 호출 지점 | 5-1 주장 추출 (40문장 묶음마다 1회), 6-1 설명 문장 (실행마다 1회) |
| 모델 | `.env` 의 `LLM_MODEL_STRONG` (없으면 `claude-opus-5-5`). 키는 `LLM_API_KEY` 또는 `ANTHROPIC_API_KEY` |
| 출력 형식 | 구조화 출력(`output_config.format` JSON 스키마). 실제 호출 400 으로 확인한 API 제약 두 가지 — 둘 다 테스트로 재발 방지 (`test_claims_schema_has_no_enum_with_type_list`, `test_schemas_within_union_field_limit`) ① `"type": [..., "null"]` 와 `enum` 을 같이 쓸 수 없음 → `anyOf` ② **null 허용 필드(type 목록·anyOf)는 스키마 전체 16개까지** → 5-1 의 자유 문자열 필드 12개(`value_text`·`unit`·`output_id`·`lhs_output`·`rhs_output`·`degree_word`·`test_id`·`test_name`·`df_text`·`n_text`·`p_text`·`n_group`)는 '없음'을 빈 문자열 `""` 로 받고 파이썬이 None 으로 되돌림 (`claims._blank_to_none`). null 은 `statistic`·`relation`·`significant`·`p_comparator`·`n_scope` 5개만. **5-1 스키마에 필드를 추가할 때 이 한도를 확인할 것** |
| 캐시 | `<출력>/llm_cache/` — 키 = (종류, 프롬프트·스키마 지문, 입력). 프롬프트가 바뀌면 다시 호출. 실패는 캐시하지 않음 |
| 감사 기록 (R7) | `<출력>/llm_audit_log.jsonl` — 호출·캐시 적중·오류·fallback 거절 |
| 거절·잘림 | `stop_reason` 이 `refusal`·`max_tokens` 면 실패 처리 |
| 서버 측 fallback | 기본으로 켬 (거절 시 다른 모델로 재시도). fallback 인자 자체를 거절한 400 일 때만 끄고 한 번 더 부름. `MT_LLM_FALLBACK=0` 이면 항상 끔 |
| 오프라인 | `MEASURETRACE_OFFLINE=1` 이면 캐시만 (토큰 0) |
| 키 없음 | 5-1 은 캐시에 있는 것만 가능, 나머지 문장은 "구조화 실패". 6-1 설명은 템플릿 |

---

## 7. `[주의]` 알려진 문제·한계

| # | 문제 | 영향 | 제안 |
|---|---|---|---|
| 1 | 승인 코드 격리는 **OS 수준 샌드박스가 아님** — 파이썬 감사 훅·정적 검사로 막으므로, 네이티브 확장(C 코드)을 거친 접근은 막지 못함 | 승인된(사람이 읽은) 코드만 실행하므로 해시 확인이 1차 방어 | 본선 전 필요하면 컨테이너 실행 검토 |
| 2 | runner 정적 검사가 `getattr`·`_` 로 시작하는 속성 등을 금지 — 정상적인 계산 코드도 걸릴 수 있음 (예: `df._values`, `getattr(obj, name)`) | 걸리면 4-1 `failed` → 관련 주장 E06 | 2-1c LLM 코드 초안 프롬프트에 금지 목록을 알려 줄 것 (앞단) |
| 3 | 용어 목록(`terms`)에 없는 동의어를 보고서가 쓰면 E06 | 잘못된 Supported 보다 안전한 쪽을 택함 | 3-1 에서 용어를 넉넉히 받기 |
| 4 | 10^k 판정은 **정확히** 10^k 배일 때만 — 단위도 틀리고 값도 다르면 E05 로만 보임 | 재평가 데모에서 데이터가 바뀌자 E01 → E05 로 바뀜 | — |
| 5 | 같은 문장에서 E06 이 두 번 나올 수 있음 ("면저항 12 % 감소" → 수치 주장 + 방향 주장) | 판정은 맞지만 코드 집계가 부풀려짐 | 같은 문장의 같은 사유 E06 을 묶기 |
| 6 | 설명 문장에 재계산 원값이 `9.52019e-09 S` 처럼 나옴 | 읽기 불편 (판정과 무관) | 표시 단위로 환산해 자리표시자 채우기 |
| 7 | LLM 은 입력이 조금만 달라도 주장을 다르게 나눌 수 있음 (실제 실행에서 13개 → 프롬프트 수정 후 10개) | 같은 입력이면 캐시로 같은 결과 | — |
| 8 | PDF 보고서 읽기는 코드만 있고 **테스트 못 함** (PDF 생성 도구 없음) | DOCX·텍스트는 확인 | 실제 PDF 로 한 번 확인 |
| 9 | DOCX 쪽 번호는 근사값 (Word 저장 쪽 표시가 없으면 명시적 쪽 나눔만) | 리포트에 방식 표시 | — |
| 10 | E02·E03 **탐지는 앞단** — `flags` 가 비어 있으면 뒷단은 알 수 없음 (재평가 데모에서 시료가 9개로 줄어도 E03 이 붙지 않은 것은 이 때문) | 앞단 연결 후 확인 | 친구와 `flags` 형식 확인 |
| 11 | **해결됨**: 재평가 함수가 `project_id` 인자를 받고 호출부와 일치 | 기존 인자 불일치 설명은 작업 중 중간 상태였음 | `test_rerun_e07_and_verdict_diff`, `test_previous_run_uses_project_and_time_not_run_id_sort` |
| 12 | **실행 차단 수정 완료 / 부분 계산은 후속**: 승인 Output의 미확정 의존이 있으면 단일 compute 전체 blocked | R3 계산 금지는 지킴. 같은 compute의 다른 확정 항목도 계산되지 않으므로 관련 감사 주장이 E06으로 바뀔 수 있음 | 미확정 경로를 제외한 코드를 새로 승인하거나 항목별 코드 계약으로 부분 실행 지원. 수정 근거는 RECOMPUTE 수정 기록 |
| 13 | 동일 의미 키의 반복 주장은 등장 순서로 연결 | 수정 과정에서 같은 항목 문장들의 순서를 바꾸면 대응이 모호할 수 있음 | 안정적인 주장 식별자를 도입하기 전에는 전·후 원문을 함께 확인 |
| 14 | 원문 숫자·단위·p 표기는 검증하지만 LLM이 문장 의미 자체를 정확히 분류했는지 완전히 증명하지 않음 | 누락·의미 오분류가 가능하며 `terms`가 비면 지표 대조도 생략 | 실제 보고서 코퍼스로 추출 정확도 평가, 승인 용어 보강 |
| 15 | **수정 완료**: 실행용 인계 깊은 사본·승인 지문·params·로그·lineage 고정, backend 4~6도 같은 사본 사용 | 원객체 변경에도 승인한 계산/근거 유지. job 파일 해시도 runner가 검증 | RC-02 회귀. 앞단은 캡처 중 잠금 또는 불변 인계 유지 |
| 16 | **수정 완료**: runs/approved_code 및 개별 쓰기 경로의 실제 연결과 hard link 검사 | 준비된 RAW/외부 연결을 쓰기 전에 거부 | RC-03 Windows junction·hard link 회귀. 악의적 동시 파일시스템 변경의 원자성은 OS 과제 |
| 17 | **수정 완료**: data/outputs 빈 목록은 형식 오류 | 실행 전 RecomputeError, runner 미호출 | RC-04/05 회귀. RAW 없는 감사 모드는 별도 계약 필요 |
| 18 | **수정 완료**: ImportFrom의 금지 원래 이름·wildcard와 금지 속성 접근 검사 | eval/exec/getattr·modules 별칭 및 builtins.eval 차단 | RC-06 회귀. OS 격리의 대체는 아님 |

| 19 | 변화량 방향어 처리는 **주장이 재계산 항목과 같은 틀(기준 대비 대상)로 쓰였다고 가정** — "어닐링 전이 12 % 높았다"처럼 기준·대상을 뒤집어 쓰면 부호가 반대로 읽혀 E05 가 될 수 있음 (잘못된 Supported 쪽이 아니라 오탐 쪽) | 5-1 항목 목록에 집단 순서를 보여 주지만 LLM 이 틀을 바꿔 주면 파이썬은 모름 | 필요하면 5-1 에 '틀 뒤집힘' 필드 추가 — 단 null 허용 필드 16개 한도(6장) 확인 |
| 20 | 절 경계는 동사 연결 어미와 `;` 만 봄 — 쉼표로만 이어진 두 지표("면저항은 12 % 감소, 전도도는 증가")는 한 절로 봐서 용어를 빌릴 수 있음 | 쉼표는 괄호 안 통계 표기(`t(28) = 6.10, p < 0.001`)에도 쓰여 경계로 쓰지 않음 | 실제 보고서로 사례를 모아 판단 |
| 21 | 범위 표기 "10-20 nS" 의 `-` 를 음수 부호로 읽어 `20` 주장을 5-1 에서 거절 | 구조화 실패로 남음 (판정 오류 아님) | 범위 표기 인식 추가 |
| 22 | 유의성 주장의 부분 검사 하나(예: n 범위 불명 → E06)만 못 해도 **주장 전체 Unsupported** — p·자유도가 맞아도 | "비교 불가 → E06" 정책(4-E E06 행, 팀 확인)의 결과. 흔한 표기라 Unsupported 가 많아질 수 있음 | p·자유도·n 을 각각 별도 주장으로 판정할지 팀 결정 |
| 23 | **AD-02 수정 완료**: 핵심 판정·코드·사유는 Python, LLM은 허용 안내 enum 선택 | 반대 판정 설명과 부여하지 않은 코드 문장을 최종 설명에 채택하지 않음 | 정상 안내와 양방향 반대 설명 회귀. 정책/출처 표시 13장 |
| 24 | 리포트는 보고서 문장을 Markdown 에 그대로 넣음 (`|`·줄바꿈만 처리) — 보고서에 HTML·Markdown 기호가 있으면 표시가 깨질 수 있음 | 판정과 무관, 표시 문제 | 필요하면 Markdown 특수문자 이스케이프 |
| 25 | **AD-01 수정 완료**: AUDIT JSON/Markdown/완료 표식의 쓰기 경계·RAW 제외·기존 연결 검사 | 준비된 hard link·외부/RAW junction을 쓰기 전에 거부. 원본 바이트 보존 | 임시 파일/개별 교체/표식 최후 게시. 악의적 동시 파일시스템 교체의 OS 원자성은 별도 |
| 26 | **AD-03 수정 완료**: Unicode 숫자·영어 수량 검사 및 최종 안내 enum 검증 | `٢배`, `²배`, `two times`, `사 배` 등 목록 밖 수량 표현 거절 | 핵심 수치 관계는 Python만 작성 |
| 27 | **AD-04 수정 완료**: 응답 컨테이너·항목/id/text 및 캐시 타입 검증 | 잘못된 항목만 템플릿 대체. 다른 정상 안내/감사 결과 보존 | 중복·누락·알 수 없는 id, 타입·컨테이너·실제 캐시 회귀 |
| 28 | **AD-05 수정 완료**: 새 실행 완료 표식/파일 해시, legacy 필수 로그·Markdown·내용 일관성 검사 | 자동 선택에서 손상/미완료 이력을 제외·사유 기록. 누락 로그를 빈 데이터로 가정하지 않음. 명시 지정은 계산 전에 AuditError | 과거 표식 없는 로그의 보장 범위와 게시 실패는 13장 |
| 29 | **AD-06 수정 완료**: 시각대 포함 datetime·UTC 완료 시각 비교 | 최신 실제 이전 완료 실행만 선택. 미래·naive·invalid 시각은 제외. 새 표식 completed_at 사용 | legacy는 generated_at으로 대체. 생성과 완료가 다른 경우도 회귀 |
| 30 | **AD-07 수정 완료**: 정책·핵심/안내·검증 상태·대체 사유를 최종 주장에 보존 | 미사용/호출 실패/응답 오류/누락/검증 거절을 구분 | JSON과 Markdown 대체 사유 회귀 |

발견 당시 근거: [RECOMPUTE 집중 리뷰](../outputs/recompute_review_2026-09-29/Recompute_Review.md). 후속 구현: [RC-01~06 수정 기록](../outputs/recompute_fixes_2026-09-29/Recompute_Fixes.md). 이번 수정에서 #12·15~18을 구현하고 회귀 테스트를 추가했다. 원안 R3를 지키는 **단일 compute 전체 차단의 동작 변경**은 합칠 때 확인해야 한다.

집중 리뷰 중 VALIDATE 병행 변경도 확인했다. 기존 100개 및 다른 작업에서 추가한 109개/실제 API 기록과, 이번 recompute 7개 검증을 구분한다. recompute/contract 지문은 추가 재현 시점과 동일하게 유지되었다.

---

## 8. 리뷰 수정 반영 기록 (2026-09-29)

이 표는 기존 21:55 작업 중 기록을 실제 코드·회귀 테스트에 맞춰 갱신한 것이다. 용어 짝 검증·참고문헌·API 응답 처리 등 앞서 들어온 개선은 유지했다. 이번 리뷰의 상세 전·후 사례와 검증 범위는 별도 개선 기록을 따른다.

| 파일 | 변경 요지 |
|---|---|
| `common/hashing.py` | `fingerprint_bytes` — 같은 바이트에서 해시·행 해시를 한 번에 계산 (입력 사본과 로그가 같은 바이트를 가리키게) |
| `contract.py` | `approval_hash`·`seal_approval`·`approval_problems` (2-3절), 형식 검사 강화 (데이터·식·검정 id 중복, 의존 열 존재, α 범위, 검정 집단이 설계에 있는지, 집단 크기 양의 정수) |
| `recompute/engine.py` | 승인 확인 실패 시 `blocked`, RAW 입력 사본, RAW 폴더 안 코드 거부, 내용 해시 대조, 결과 범위 검사, 실행 실패를 예외 대신 로그로, run_id 검증 (4-4-1) |
| `validate/claims.py` | 원문 대조 강화(숫자 토큰 전체, 단위는 주장 원문, p 부등호·자유도·n 원문 대조), `n_scope`·`n_group`, 일부 후보가 거절된 문장도 "구조화 실패"에 표시 (4-5-1) |
| `validate/compare.py` | `compared` 표시, 비교 불가 → E06, `blocked` → E06 '미확정', n 범위(`n_scope`), 대응 t 집단 크기 확인, p 범위 확인, welch 자유도 항목 사용 (4-5-2) |
| `validate/codes.py` | 주장·비교 결과 개수·id 일치 확인, `compared` 기준으로 E06 보충 |
| `recompute/_runner.py` | 코드·데이터 사본 해시 재확인, 코드 정적 검사, 감사 훅으로 파일·네트워크·프로세스 제한 (4-4-1) |
| `pipeline.py` | 보고서 경로가 RAW 계산 입력 파일과 같으면 중단(R4), 이전 실행을 같은 `project_id`로 한정. 명시적 타 프로젝트 지정은 계산·LLM 호출 전 거부. `rerun.py`와 호출 인자 연결 완료 |
| `audit/rerun.py` | 완료 시각과 프로젝트로 이전 실행 선택, 항목·검정 중심 의미 키, 수정된 수치 주장 연결, 반복 주장 보존 |
| `audit/report.py` | 재평가용 항목·검정·n 범위 필드 보존, 일부 후보만 거절된 문장도 요약·Markdown에 표시 |
| `tests/test_review_regressions.py` | 원문 숫자·통계 표기, 승인 차단, 입력·코드 사본 변경, 파일·네트워크·프로세스 제한, n/df, 구조화 실패, 재평가를 재현하는 테스트 |

---

## 9. 파일·산출물 지도

**코드**

| 파일 | 과업 |
|---|---|
| `measuretrace/contract.py` | 인계 형식 (2장) |
| `measuretrace/recompute/engine.py`, `_runner.py` | 4-1, 4-2 |
| `measuretrace/validate/report_reader.py`, `claims.py` | 5-1 |
| `measuretrace/validate/compare.py`, `rounding.py` | 5-2 |
| `measuretrace/validate/codes.py` | 5-3 |
| `measuretrace/audit/report.py`, `explain.py` | 6-1 |
| `measuretrace/audit/rerun.py` | 6-2 |
| `measuretrace/pipeline.py` | 실행 순서, 명령줄 실행 |
| `measuretrace/common/` | 해시, 단위, LLM, 이력 장부 |

**실행 산출물** (`<출력>/runs/<run_id>/`)

| 파일 | 만드는 과업 |
|---|---|
| `input_snapshot/` | 4-1 (계산에 쓴 RAW 사본) |
| `confirmed_snapshot.json` | 4-1 (실행·승인·로그에 사용한 인계 깊은 사본) |
| `calc_log.json`, `data_rows.json` | 4-2 |
| `blind_log.json`, `claims.json` | 5-1 |
| `report_snapshot.<원본 확장자>` | 5-1 (해시를 기록하고 추출에 사용한 보고서 사본) |
| `audit_result.json`, `audit_report.md` | 6-1 (+ 6-2 재평가 절) |
| `audit_complete.json` | audit-v4.1의 완료 표식. 결과/계산/행별 근거 파일 해시, 프로젝트·실행 id·게시 완료 시각 |

출력 폴더 공통: `approved_code/`, `lineage.jsonl`, `llm_cache/`, `llm_audit_log.jsonl`

---

## 10. 검증 기록

| 날짜 | 무엇 | 결과 |
|---|---|---|
| 2026-09-29 21:30 기존 작성 기록 | 당시 단위 테스트·실제 API 데모 | 기존 작성자가 확인한 테스트 60개 및 아래 실제 API 기록. 이번 리뷰에서 유료 API를 다시 호출하지 않음 |
| 2026-09-29 리뷰 반영 후 | 전체 테스트 (가짜 LLM, 토큰 0) | **100개 통과, 83.51초**. 기존 60개 + 리뷰 회귀 40개. `../outputs/improvements_v4_2026-09-29/pytest_full.txt`, `pytest_full.xml` |
| 2026-09-29 22:19 다른 세션 종료 후 재확인 | 전체 테스트 + `scripts/demo.py --rerun` (가짜 LLM, 토큰 0) | **100개 통과 (78.63초)**. 데모 1차 Supported 4 · Unsupported 5 · 검사 대상 아님 3 (E01·E04·E05×2·E06), 재평가 2차에서 E07 "3행 감소" 기록 — 리뷰 수정 전 결과와 같음. 리뷰 수정 후 코드로 **실제 API 는 아직 다시 돌리지 않음** |
| 2026-09-29 22:21 | 리뷰 수정 후 코드로 실제 API (`claude-opus-5`) 실행 | **실패** — 5-1 스키마 400 "null 허용 필드 17개 > 한도 16개" (`n_scope`·`n_group` 추가로 초과). 주장 추출 0, 전 문장 구조화 실패. 호출 2회 모두 400 |
| 2026-09-29 22:23 | 스키마 수정(6장) 후 전체 테스트 | **102개 통과** (한도 검사·빈 문자열 변환 테스트 2개 추가) |
| 2026-09-29 23:26 | 최신 코드로 실제 API 재확인 시도 (`demo.py --real --rerun --dir demo_real_2330`) | **확인 못 함** — Anthropic 서버가 모든 요청에 `500 InternalServerError: credential validation failed` (토큰 안 쓰는 모델 조회도 동일). 키 소진(400 credit)·키 오류(401)가 아닌 서버 쪽 인증 확인 장애로 판단. 파이프라인은 설계대로 멈추지 않고 10문장 전부 "구조화 실패" + LLM 실패 원인을 리포트에 기록. **최신 코드(VALIDATE·AUDIT·RECOMPUTE 수정 후)의 실제 API 확인은 아직 남음** |
| 2026-09-29 23:21 | RECOMPUTE 수정(다른 세션, 23:06) 반영 후 전체 재확인 | **135개 통과 / 실패 0** (185.6초). 23:06 에 실패했던 `test_recompute_guards.py` 24개 모두 통과. 가짜 LLM 데모 + 재평가 결과 이전과 같음 (1차 Supported 4 · Unsupported 5 · 검사 대상 아님 3, 2차 E07 기록) |
| 2026-09-29 23:06 | AUDIT 집중 리뷰 → 수정 (IMPROVEMENTS FIX-22~24) | 관련 테스트 88개 통과 (`test_llm`·`test_pipeline`·`test_compare_rules`·`test_review_regressions`), 전체는 **133 통과 / 1 실패** — 실패는 다른 세션이 작업 중인 `test_recompute_guards.py::test_job_params_tampering_is_detected_by_runner` (runner 오류 메시지 인코딩, RECOMPUTE 영역). 수정 전 재현: 설명에 "두 배"·"twice" 통과, Unsupported 인데 "일치합니다" 통과, 재평가 표 7행 중 6행이 E07 기록만 붙은 행. 가짜 LLM 데모 재평가 표가 실제 변화 1건(1.83 mS E01 → E05)만 보이는 것 확인. 실제 API 는 다시 돌리지 않음 (6-1 설명 프롬프트가 바뀌어 다음 실제 실행 때 새로 호출됨) |
| 2026-09-29 22:50 | VALIDATE 집중 리뷰 → 수정 (IMPROVEMENTS FIX-19~21) 후 전체 테스트 | **109개 통과** (회귀 7개 추가: 감소·증가·영문 방향어, 방향어 없음, 방향어 충돌, 부호 명시, 절 단위 용어, p 표기). 수정 전 재현: 재계산 −12 에 "12 % 감소" → E05 오탐, 재계산 +12 에 "12 % 감소" → **잘못된 Supported**, "p값 < 0.05"·"P-value = 0.003" → 5-1 거절, 두 지표 문장에서 다른 지표 용어로 짝 통과. 실제 API 는 이 수정 뒤 다시 돌리지 않음 (5-1 스키마는 그대로, 프롬프트 변경 없음) |
| 2026-09-29 RECOMPUTE 최종 수정 | RC-01~06 반영 후 전체 테스트, VALIDATE/AUDIT 병행 수정 포함 | **135개 통과 / 실패 0 / 107.63초**. 기존·VALIDATE·AUDIT 111개 + RECOMPUTE 회귀 24개. 중간 실패의 Windows runner 인코딩도 수정. 테스트 중 소스 변경 없음. 합성 입력·가짜 LLM, 이번 수정에서 실제 API 호출 없음. [수정 상세](../outputs/recompute_fixes_2026-09-29/Recompute_Fixes.md), [전체 로그](../outputs/recompute_fixes_2026-09-29/pytest_full.txt), [JUnit](../outputs/recompute_fixes_2026-09-29/pytest_full.xml), [최종 지문·링크 검증](../outputs/recompute_fixes_2026-09-29/verification.json) |
| 2026-09-29 후속 AUDIT 집중 리뷰 | 운영 코드 미수정, 관련 테스트 + 추가 경계 재현 | **관련 12개 통과 / 55개 제외 / 36.71초**. 추가 19사례 중 정상 대조 3개·문제 재현 16개, 재현 실패 0. 기능 문제 6개·기록 개선 1개는 **미수정**. [리뷰](../outputs/audit_review_2026-09-29/Audit_Review.md), [재현 결과](../outputs/audit_review_2026-09-29/review_results.json), [검증·지문](../outputs/audit_review_2026-09-29/review_verification.json). 유료 API 호출 없음 |
| 2026-09-30 AUDIT 최종 구현 | AD-01~07 수정 후 전체 테스트 | **177개 통과 / 실패 0 / 190.69초**. 기존 135개 + 새 AUDIT 회귀 42개. 최종 검사 중 소스 변경 없음. 합성 입력·가짜 LLM, 유료 API 호출 없음. [수정·호환성 기록](../outputs/audit_fixes_2026-09-29/Audit_Fixes.md), [전체 로그](../outputs/audit_fixes_2026-09-29/pytest_full.txt), [JUnit](../outputs/audit_fixes_2026-09-29/pytest_full.xml), [최종 파일·원안 지문 검증](../outputs/audit_fixes_2026-09-29/verification.json) |
| 2026-09-29 22:24 | 스키마 수정 후 실제 API 전체 실행 + 재평가 (`demo.py --real --rerun`, 호출 3회 + 캐시 1회) | **성공**. 1차 Supported 5 · Unsupported 6 · 검사 대상 아님 3 · 구조화 실패 0 (E01·E04·E05×2·E06×2 — E06 두 개는 7장 #5 중복 집계). p 부등호 `p < 0.001` 원문대로 대조, 참고문헌 [3] 원문 기록. 재평가 2차 E07 "3행 감소 (추가 0행, 삭제 3행)" 및 판정 변화 표 출력 |
| 2026-09-29 | 합성 케이스 (어닐링 전후 전도도, 시료 10 × 위치 3) — 보고서에 E01·E04·E05·E06, 문헌 인용, 정성 문장, 정도 표현을 넣음 | 모든 오류가 해당 주장에 맞는 코드로 탐지 |
| 2026-09-29 | 실제 Claude API (`claude-opus-5`) 전체 실행 + 재평가 | Supported 5 · Unsupported 5 · 검사 대상 아님 3. 재평가에서 E07 "3행 감소"와 판정 변화 표 출력 |
| 2026-09-29 | 실제 API 실행에서 찾아 고친 문제 | ① 스키마 400(`type` 목록 + `enum`) ② 다른 400 도 fallback 재시도하던 문제 ③ p 부등호가 숫자 칸에 와서 p 대조 생략 ④ 자유도·p 가 중복 주장으로 나뉘어 E04 중복 집계 ⑤ 단위 없는 수치에 E01 두 번 ⑥ 참고문헌 원문 미기록 |

다시 확인하는 방법 (`v4_55` 폴더에서 실행)

```bash
python -m pytest                        # 토큰 0
python scripts/demo.py --rerun          # 합성 케이스 + 재평가, 토큰 0
python scripts/demo.py --real --rerun   # 실제 API (호출 약 3회)
```

이번 리뷰는 Windows·Python 3.13.6·로컬 `.venv`에서 확인했다. 초기 검사 중 반복 수 필드 이름을 잘못 참조한 수정은 바로 고쳤고 100개를 다시 통과했다. 해당 중간 로그는 `../outputs/improvements_v4_2026-09-29/pytest_full_before_field_fix.*`에 있다. 후속 RECOMPUTE 검사에서 Windows stderr 인코딩 실패를 고친 뒤 현재 135개를 통과했고, 그 중간 결과는 `../outputs/recompute_fixes_2026-09-29/pytest_full_before_utf8.*`에 보존했다. PDF·Excel 실물 입력, 친구의 앞단과 전체 1~6 통합, 네이티브 코드 OS 격리는 현재 테스트 통과만으로 확인됐다고 보지 않는다.

---

## 11. 친구와 합칠 때 사용하는 절차

### 11-1. 책임과 경로

| 담당 | 반드시 넘겨야 하는 것 / 해야 할 일 |
|---|---|
| 앞단 1~3 | RAW 분류·해시, 계획서 식·단위·설계·검정, 승인 코드, 사용자 승인 기록, 이상·누락·미확정 기록을 `Confirmed` 형식으로 저장 |
| 뒷단 4~6 | 인계 형식·승인·해시 확인, RAW 재계산, 보고서 첫 열람·추출, 비교·의존 오류·근거 출력, 이전 실행 비교 |
| 공통 | `project_id`와 Data/Equation/Output/Test id를 수정 전·후에도 안정적으로 유지. 승인 없이 id·식·설계를 갈아끼우지 않음 |

- `input_root`는 절대 경로로 넘긴다. `data[].path`는 그 안의 상대 경로이며 `../`로 빠져나가면 거부한다.
- `code.path`는 `confirmed.json`이 있는 폴더 기준 상대 경로다. `Confirmed` 객체를 직접 만들 때는 `base_dir`를 그 폴더로 지정한다. RAW 폴더 안 코드는 거부한다.
- `out_root`는 RAW 입력 폴더 밖이다. 보고서는 별도 경로로 넘기며 `confirmed.json`에 보고서 내용·측정값을 넣지 않는다.
- 기술적 반복 수의 실제 JSON 필드명은 **`design.replicates_per_unit`**이다. `technical_repeats`라는 필드는 없다. 모르거나 해당하지 않으면 `null`, 지정하면 양의 정수.
- `Column.unit_status`는 `approved` 또는 `unresolved`이다. 의미·단위·집단 해석을 앞단이 확정해야 하며 뒷단은 계획서를 다시 해석하지 않는다.

### 11-2. 승인·저장·실행 코드 예시

아래 승인을 호출하기 전에 **화면에서 실제 사용자 승인이 끝나야 한다**. 값을 자동으로 채워 승인으로 간주하는 코드를 만들지 않는다.

```python
from pathlib import Path
from measuretrace.common.hashing import file_fingerprint, sha256_file
from measuretrace.contract import Confirmed
from measuretrace.pipeline import run_backend

confirmed_path = Path("front_out/confirmed.json").resolve()
c = Confirmed.load(confirmed_path)  # 앞단 초안은 contract.py와 같은 형식

for d in c.data:
    fp = file_fingerprint(Path(c.input_root) / d.path)
    d.sha256, d.content_hash = fp["sha256"], fp["content_hash"]
c.code.sha256 = sha256_file(c.code_path())
assert not c.problems(), c.problems()

# 여기까지의 코드·식·단위·설계·params·terms를 사용자에게 보여 주고 승인받은 뒤:
c.seal_approval(approved_by="승인 사용자 식별자")
c.save(confirmed_path)

# 보고서는 이 호출 이전에 열지 않는다. client/model은 기존 LLM 설정으로 주입.
result = run_backend(confirmed_path, Path("report_inbox/report.docx"),
                     Path("backend_out"), client=client, model=model,
                     previous_run="auto")
```

해시를 새로 찍는 것은 **새 CONFIRM 절차의 일부**다. 기존 승인을 통과시키려고 뒷단 실행 직전에 바뀐 파일의 해시만 덮어쓰면 안 된다. 승인 후 내용이 바뀌면 승인 화면으로 돌아가 새 묶음을 승인하고 새 `run_id`로 실행한다.

### 11-3. 오류 의존 관계와 표본 수

| 사례 | 앞단 인계 / 보고서 추출 | 결과 |
|---|---|---|
| 단위 불명인 열 | `raw#current`의 `unit_status="unresolved"`, 그 열을 쓰는 Output의 `depends_on`에 같은 ref | 단일 compute 전체 blocked. 해당 의존 주장 E01과 계산 차단 E06 근거 표시 |
| 이상값 그대로 진행 | `Flag("E02", "raw#current", ..., "proceed", location, decided_by, decided_at)` | 관련 주장에 E02 기록, 비교가 맞으면 Supported 가능 |
| 필요한 측정 자체 없음 | `Flag("E03", "item:sample_B", ..., "missing")` + 관련 Output의 `depends_on=["item:sample_B", ...]` | 관련 주장 E03. 단지 없는 파일을 `data[]`에 등록하면 `DataChangedError`로 실행 중단됨 |
| 식/항목 미확정 | `Pending("eq:EQ1", ...)` 또는 `Pending("output_id", ...)`, Output의 `equations`와 `depends_on` 정확히 기재 | 단일 compute 전체 blocked, 계산값을 요구한 주장은 E06 '미확정'. 무관한 pending은 이 조건으로 차단하지 않음 |
| 코드 미확정 | `Pending("code", ...)` | 계산 전체 `blocked`, 실행하지 않음 |
| 한 집단 n | n Output에 `groups=["A"]`, 추출에는 `n_scope="group", n_group="A"` | A의 독립 단위 수로 비교 |
| 두 집단 전체 n | 보고서가 총 표본 수를 명시해 추출 `n_scope="total"` | 집단 수 합으로 비교. 검정이 지정된 다집단 n에 범위 정보가 없으면 E06 |
| 대응 검정 n | `paired_t`, 같은 크기의 두 집단, 추출 `n_scope="pairs"` | 쌍 수로 비교. A+B를 n으로 세지 않음 |
| Welch 자유도 | 검정에 `df_output`, 실제 Output 정의·의존 관계·재계산값 | 해당 자유도도 `outputs_used`와 E01/E02/E03/E06/E07 근거에 포함 |

`n_scope`·`n_group`은 **5-1 주장 구조화 필드**이며 `Confirmed.Output`에 직접 넣는 필드가 아니다. 3-1에서는 `Output.groups`와 `Design.groups/tests`를 정한다. 보고서가 어느 집단인지 명확하지 않으면 LLM이 임의로 추측하지 않도록 한다.

### 11-4. 상태와 예외를 앞단에서 받는 방식

| 결과 | 의미 | 앞단/화면 처리 |
|---|---|---|
| `calc.status="ok"` | 승인 항목 모두 유효한 숫자로 계산 | 판정·구조화 실패까지 함께 표시 |
| `partial` | 일부 결과 누락·범위 오류·비수치 | 성공한 항목은 비교, 실패 항목 관련 E06. 전체 성공으로 표시하지 않음 |
| `blocked` | 승인 정보 누락·코드 미확정·승인 지문 변경 | 사용자에게 승인 필요 원인을 표시. 뒷단이 승인 정보를 자동 생성하지 않음 |
| `failed` | 코드 오류·Python 실행 제한 위반·시간 초과 | 계산 로그와 오류를 유지, 관련 주장은 E06. 과거 실행값을 대체 결과로 쓰지 않음 |
| `DataChangedError` | CONFIRM 이후 RAW 변경·파일 없음·내용 해시 불일치 | INGEST부터 다시 진행, 재확인·재승인 |
| `CodeHashMismatch` | 승인 코드/고정본 변조 | 코드 초안·승인부터 다시 확인 |
| `RecomputeError` | 형식·경로·run_id·입력 폴더 안 코드 문제 | 인계 파일/경로를 고친 뒤 **새 실행 id** 사용 |
| `BlindnessError` | 계산 전 보고서 열람 시도·RAW와 같은 파일·계산 후 인계 변경 | 순서를 고친 뒤 새 계산부터 실행 |
| `ValueError` (타 프로젝트 재평가) | 이전 실행 지정 프로젝트가 다름 | 올바른 이전 실행 선택 또는 `previous_run=None` |
| `AuditError` (ValueError 하위) | AUDIT 출력의 RAW/외부 연결, 이미 완료한 실행 재작성, 명시 이전 실행의 손상/미완료/근거 불일치 | 연결·근거를 확인하고 새 실행. 자동 제외는 previous_run_selection에 사유 기록 |

`summary["구조화 실패"]`는 **문장 수**다. 한 문장의 수치 후보가 거절되고 방향 후보는 통과하면 방향 판정과 구조화 실패가 함께 남는다. Supported+Unsupported는 판정한 **주장 수**, 검사 대상 아님은 제외한 **문장 수**이므로 이 네 숫자를 합쳐 전체 문장 수로 계산하면 안 된다.

### 11-5. 합치기 완료 수용 기준

1. 친구의 앞단으로 실제 합성 RAW·계획서·사양을 처리해 승인 화면까지 가고, `Confirmed.load()`와 `problems()`를 통과하는 파일을 만든다.
2. `code.approval_hash`가 있는 실제 승인 흐름을 연결하고, 승인 뒤 params/단위/설계를 변경하면 `blocked`인지 확인한다.
3. E02 진행·미결정, E03 항목 누락, 열 단위 미확정, 코드 미확정 사례를 각각 넘겨 올바른 사유가 표시되는지 확인한다. 관련 미확정 의존/E01·E02 unresolved 또는 코드 미승인은 현재 **단일 compute 전체를 차단**하여 모든 계산 Output이 blocked된다. 무관한 pending/미사용 열의 미확정 단위와 E02 proceed는 그 사유로 실행을 차단하지 않는다. E03 누락의 의존 전파와 전체 실행 차단을 구분한다.
4. 값·p·n·df·방향·혼합/인용을 포함한 보고서로 4→5→6을 실행하고, 측정값/재계산값이 LLM 요청에 섞이지 않는지 확인한다.
5. RAW를 수정하면 해시 오류로 1단계 재진입하고 새 승인 뒤 E07이 기록되는지, 보고값만 수정하면 같은 주장의 판정 변화로 연결되는지 확인한다.
6. 아래 177개 테스트와 앞단 통합 테스트를 통과시킨다. 실제 PDF/Excel 지원·OS 격리·항목별 부분 실행은 해당 검증을 추가하기 전에는 완료로 표시하지 않는다. 미확정 의존 계산의 실행 차단과 AUDIT AD-01~07은 구현·회귀 확인됐다. 일부 Output만 계산하는 기능과 다르다.

프로젝트 최상위 PowerShell에서 현재 검증을 재현하는 명령:

```powershell
.\.venv\Scripts\python.exe -m pytest v4_55/tests -q
```

실행 산출물을 버전 관리에 통째로 넣기보다 코드·예시·문서·필요한 검증 요약을 전달한다. 실제 RAW·보고서·`.env`·LLM 캐시·API 키는 친구와 전달 범위를 따로 정한다. 현재 폴더에 있는 이전 skeleton/practice 구현은 비교 참고용이며 `v4_55/measuretrace`의 의존 코드가 아니다.

---

## 12. 후속 AUDIT 집중 리뷰 — 발견 당시 기록

상세 근거·재현 조건·수정 수용 기준은 [AUDIT 리뷰](../outputs/audit_review_2026-09-29/Audit_Review.md)에 적었다. **이 절은 수정 전 이력이며 AD-01~07 후속 구현은 13장이다.** 정상 흐름의 당시 테스트 통과와 추가 경계의 문제 재현을 구분한다.

당시 우선 수정 대상으로 **AUDIT 출력의 RAW 보호(AD-01)**와 **판정·코드·사유에 일치하는 설명(AD-02)**을 정했다. 캐시 응답 타입 오류, 이전 실행의 완료 여부·근거 유효성, 다른 시각대의 정렬, 설명 검증 사유 보존도 재현했다. 당시 audit_result.json 존재만으로 완료라고 판단하던 구현은 후속 수정에서 완료 표식·필수 근거 검증으로 바뀌었다.

앞단 친구와 공유할 내용은 인계 계약을 바꾸는 새 기능과 기존 원칙 위반의 수정을 구분한다. RAW 원본 보호·파이썬 판정과 설명의 일치·정확한 이전 실행 선택은 기존 원칙을 지키기 위한 수정이다. 완료 표식·설명 검증 기록 등 후속 구현에서 추가한 파일/필드의 호환성은 아래 절을 따른다.

## 13. AUDIT AD-01~07 구현 수정 (2026-09-30)

[상세 수정 기록](../outputs/audit_fixes_2026-09-29/Audit_Fixes.md)에 전·후 동작과 회귀 근거를 적었다. 원안·confirmed-v4.0·compute(data, params)는 유지하며 AUDIT 산출물/설명 정책을 보강했다. 새 회귀는 `tests/test_audit_guards.py` 42개다. **최종 전체 177개 통과(190.69초)**와 파일 지문 검증을 10장에 기록했다.

앞단/화면 연동에서 확인할 변경:

- 감사 결과 `stage_version="audit-v4.1"`, 완료 파일 `audit_complete.json`. JSON/Markdown 저장 뒤 표식을 마지막에 게시한다. 필수 네 파일과 선택 confirmed_snapshot의 SHA-256을 대조하고 이미 완료한 실행의 재작성은 거부한다.
- 설명 정책 `python-core-advice-v1`. Python 핵심과 LLM enum 안내를 분리해 `explanation_core`, `explanation_advice`, `explanation_policy`, `explanation_status`, `explanation_llm_rejected`를 최종 주장에 추가한다. source=llm은 안내 출처이며 핵심까지 LLM이 썼다는 뜻으로 표시하지 않는다.
- `previous_run_selection`의 mode/selected/excluded 목록에 제외한 실행 id·사유를 기록한다. 자동 선택은 손상/미완료 후보를 제외하고 명시 지정은 계산·LLM 전에 `AuditError`(ValueError 하위)로 알린다.
- 새 실행은 completed_at을 UTC로 비교한다. 과거 표식 없는 기록은 필수 로그/Markdown/내용 일관성이 맞을 때만 읽고 generated_at을 완료 시각의 대체값으로 쓴다. offset 없는 시각을 임의로 추정하지 않는다.
- 직접 write_outputs를 부르는 별도 도구는 input_root를 넘기거나 정상 confirmed_snapshot이 있는 실행 폴더를 사용한다. pipeline은 input_root/out_root를 명시적으로 전달한다.

기존 자유 설명 캐시는 새 prompt/schema 지문에서 재사용하지 않는다. 유료 API는 이번 수정에서 호출하지 않았으며 기존 실제 API 성공·서버 장애 이력은 10장에 보존한다. OS 원자성·Markdown 특수문자 표시·실제 앞단/PDF/Excel 통합은 별도 검증으로 유지한다.

## 14. 통합본 RECOMPUTE 한 곳으로 합침 (2026-09-30)

### 14-1. 왜

통합본(`MeasureTrace_v4_integrated`)은 앞단 4단계(`measuretrace/recompute`)와 뒷단 4-1(`backend/recompute`)이 **같은 승인 코드를
두 번** 실행하고 값을 교차 확인했다. 파이프라인 v4 는 "4-1 한 번 → 4-2 계산 로그 하나 → 5 VALIDATE" 이다. 두 번 실행의 문제:

| 문제 | 내용 |
|---|---|
| 규칙이 다른 두 격리 실행기 | 앞단 검사를 통과한 코드가 5·6 직전 뒷단 검사에서 막힐 수 있음 (앞단 B7 과 같은 종류) |
| 근거 두 벌 | 계산 로그·E07 이 둘, 비교 방식도 다름. 화면 4단계는 앞단 값, 판정은 뒷단 값 |
| 승인 순서 | 항목 목록(Output)을 앞단 계산 결과에서 뽑아 5·6 직전에 승인 |

### 14-2. 선택지와 결정

`[결정]` 사용자와 합의: **뒷단 엔진으로 통일, 한 번 실행 + 계산 뒤 항목 승인(D안)**.
처음 제안(2-1c `reported_quantities` 로 계산 전에 항목 목록 만들기)은 데모에서 확인해 버렸다 — 보고 목록에 **n·자유도·p 가 빠져 있고**
(실제 결과 11개 중 3개) 이름도 다르다("조건 표본 표준편차" ↔ "조건 표준편차"). 그대로 쓰면 유의성·E04 가 모두 E06 이 된다.
코드가 결과 목록을 미리 선언하게 하는 안(H)은 2-1c 프롬프트가 바뀌어 LLM 캐시가 무효 → 실제 API 가 필요해 보류.

### 14-3. 지금 흐름

```
3-1 코드 승인 ─▶ 4 RECOMPUTE  bridge.run_step4
                   실행 묶음(confirmed_exec.json: RAW·식·설계·기록·코드, 항목 목록 없음)
                   → backend run_discovery = run_recompute(discover=True)  ← 승인 코드 실행 (유일)
                   calc_log.json: produced(결과 전부)·produced_meta(id·이름·기호·단위·조건·식)·execution_sha256
               ─▶ 인계 미리보기 bridge.preview — 탐색 결과로 항목 목록(전체 묶음) → 사람이 확인
               ─▶ 5·6 bridge.run → seal_approval → backend run_validate_audit
                   bind_outputs: 실행 지문 같음·봉인 확인 → produced 값을 항목에 결합(재실행 없음)
                   → 5-1 보고서 첫 열람 → 5-2 → 5-3 → 6-1·6-2
```

| 변경 | 위치 | 내용 |
|---|---|---|
| `[신설]` 실행 지문 | `contract.execution_payload/execution_sha256` | RAW(경로·해시·읽기 옵션)+코드(해시·진입점·파라미터)만. 항목 목록·설계·기록은 제외(계산을 바꾸지 않음) |
| `[신설]` 탐색 실행 | `engine.run_recompute(discover=True)` | 항목 목록 없이 실행해 결과 전부 기록. `problems(discover=True)` 는 항목 목록이 **비어 있어야** 함. `discovery_blockers()` — 미확정·단위 미확정·E01/E02 미결정이 **하나라도** 있으면 실행 전체 차단(항목을 몰라 범위를 좁힐 수 없음, R3) |
| `[신설]` 항목 결합 | `engine.bind_outputs` | 이미 결합했는지·탐색 로그인지·프로젝트·**실행 지문**·승인 지문(approval_hash 필수) 확인 → `_check_outputs` 로 범위 검사, 미확정 의존 항목은 값을 쓰지 않고 `blocked`. 결합 전 `calc_log_discover.json`·`confirmed_snapshot_discover.json` 보존, `calc_log.json`·`confirmed_snapshot.json` 을 결합 결과로 교체(5·6 의 기존 블라인드·인계 확인이 그대로 동작). **계산 시각(finished_at)은 그대로** |
| `[신설]` 파이프라인 진입점 | `pipeline.run_discovery`·`run_validate_audit` | `run_backend`(단독 뒷단)는 그대로. `run_validate_audit` 는 이미 보고서를 연 실행이면 거부 |
| `[변경]` 실행기 | `_runner.py` | 정적 검사를 `static_violations()` 로 분리(앞단 3-1 검사가 같은 함수를 씀), 결과 `meta`·라이브러리 버전 전달, 스레드 1개 환경 변수(앞단에서 가져옴) |
| `[변경]` 연결 코드 | `bridge.py` | `_assemble` 로 실행 묶음(`build_exec`)과 전체 묶음(`build`)을 같은 코드·파라미터로 만듦. 어댑터는 결과를 전부 보고(id = 기호/이름 slug, 겹치면 `_2`). 추출 결과 변경 검사(앞단 B11)를 여기로 옮김. 교차 확인 → `execution: {executions: 1}`. 이미 감사한 실행을 다시 감사하면 4단계를 새로 실행 |
| `[변경]` 앞단 4단계 | `measuretrace/recompute/run.py` | 실행은 `bridge.run_step4` 로. 화면·시험 기록 형식과 E07 **미리보기**(행·열 차이)는 유지. `runner.py`·`sandbox.run()` 삭제, `sandbox.static_check` = 앞단 규칙 + 뒷단 실행기 규칙 |
| `[변경]` 화면 | `web/static/audit.js` | 교차 확인 표 → "재계산 값 (4단계 한 번 실행)". 통합 전 저장 결과는 교차 확인 표를 그대로 보여 줌 |
| `[수정]` 로컬 서버 | `web/server.py _refuse` | 403 거절 때 요청 본문을 읽지 않아 Windows 가 연결을 재설정 → 보안 시험이 간헐 실패하던 문제. 본문(≤1 MB)을 읽고 응답 |

### 14-4. 남은 것

| # | 내용 | 영향 | 제안 |
|---|---|---|---|
| 1 | 항목 목록 승인이 **계산 뒤**. 보고서는 여전히 닫혀 있어 블라인드는 유지되지만, 원안의 "승인 → 계산" 순서와 다르다 | 사람이 재계산값을 본 뒤 항목 목록을 승인(값이 인계 묶음에 들어가지는 않음) | API 복구 뒤 H안(코드가 결과 목록을 미리 선언)으로 계산 전 승인 가능 |
| 2 | 탐색 실행은 미확정이 하나라도 있으면 **전체** 차단 | 기존 단일 실행의 "관련 항목만 차단"보다 보수적 | 항목을 계산 전에 알게 되면(H안) 범위를 좁힐 수 있음 |
| 3 | 2-1c 코드 초안 지시문(`sandbox.rules_text`)에 뒷단 실행기 규칙(밑줄 속성 등)이 아직 없음 | 초안이 규칙을 어기면 3-1 정적 점검이 승인을 막음(실행에서 막히지는 않음) | 지시문 수정은 LLM 캐시를 무효화하므로 실제 API 로 2단계를 다시 돌릴 때 함께 |
| 4 | E07 이 두 곳에 보임 — 4단계 미리보기(앞단, 이전 4단계와 비교)와 6-2 기록(뒷단, 이전 감사와 비교) | 판정에 붙는 것은 6-2 하나. 비교 대상이 달라 숫자가 다를 수 있음 | 앞단 행·열 차이(줄 번호)를 뒷단 `data_changes` 로 옮기면 하나로 합칠 수 있음 |
| 5 | 통합본 폴더에 `.env` 가 없으면 기본 모델(`claude-opus-5-5`)로 잡혀 데모 LLM 캐시(`claude-opus-5`)를 못 씀 | 리허설이 캐시 0 으로 실패 | `.env` 에 `LLM_MODEL_STRONG=claude-opus-5` 또는 실행 때 환경 변수 |

### 14-5. 검증 (2026-09-30, 가짜 LLM·LLM 캐시, 토큰 0)

| 무엇 | 결과 |
|---|---|
| 뒷단 테스트 | **183개 통과** (기존 177 + 탐색·결합 6: 항목 없이 결과 전부 기록, 결합 때 재실행 없음·근거 보존·재결합 거부, 실행 지문 변경·미봉인 거부, 미확정 시 전체 차단, 결합 때 추가된 미확정 항목 값 보류, `run_validate_audit` 가 `run_backend` 와 같은 판정 + 실행 1회 + 재감사 거부) |
| 앞단·연결 테스트 | **17개 통과** (두 번 연속). `dwml`(2-1b 수식 변환)이 가상환경에 없어 처음엔 9개 오류 → 설치 뒤 해결 |
| 리허설 1→4 (데모, 캐시) | 뒷단 엔진 한 번 실행, 도구 정확도 ① **10/10** (상대 오차 ≤ 1.3e-14) |
| 1→6 전체 (데모, 5-1 오프라인) | 4단계 확인 6개 통과 → 항목 11개(n·df·p 포함, 검정 T1 연결)·문제 0 → 5·6 이 **같은 뒷단 실행**에 결합(`executions: 1`), 블라인드 확인. 5-1 은 API 없이 18문장 구조화 실패(예상) |
| 6-2 재평가 (같은 프로젝트 2회차, 가짜 LLM) | `annealing_demo_rerun` 으로 1→6 다시: 4단계 E07 미리보기와 6-2 E07 기록 모두 S07 "내용 변경(3행 빠짐)"·S12 "형식만 변경", 이전 실행 = 1회차 뒷단 실행. (2회차는 입력이 달라 2-1c 캐시가 없으므로 오프라인으로는 불가 — 가짜 LLM 사용) |
| 사이트 (웹 화면) 전체 흐름 | 임시 작업 폴더로 `web/server.py` 를 띄워 화면이 보내는 요청 그대로 HTTP 로 1→6: 화면 파일 7개·상태 200, 업로드 27개 → 1 INGEST → 2 EXTRACT(캐시 5) → 3 CONFIRM complete → 4 RECOMPUTE ok(결과 11·확인 전부 통과) → 인계 미리보기(항목 11·문제 0) → 5·6 같은 뒷단 실행에 결합(실행 1회) → 저장 결과 다시 열기·실행 목록·이어서 보기 6개 API 200 |
| 정리 | 확인 스크립트가 가짜 LLM 응답 8개를 실제 `workspace/llm_cache` 에 남긴 것을 지움(모델 `fake` — 실제 실행 키와 겹치지 않았음). 실제 캐시 14개 그대로 |
| 실제 API — 사이트로 1→6 (1차 시도) | `claude-opus-5`, 원래 데모: 2단계 캐시(호출 0) · 5-1·6-1 실제 호출. Supported 12 · **Unsupported 1(E06) · 구조화 실패 1** — 깨끗한 보고서에서 오탐 2건: ① "우리 어닐링 시료의 **값** 12.1 nS" 에 지표 용어(전도도)가 없어 짝 거절 ② "평균 전도도는 12.1 ± 0.7 nS" 에서 LLM 이 원문을 12.1 까지만 잘라 단위(± 뒤) 검증 실패 |
| 수정 | ① `compare._unit_identifies_metric` — 보고 단위가 차원 있는 재계산 단위로 환산되면(nS→S) 단위로 지표 확인, 용어 대조 생략(메모). %·무차원·단위 없는 방향 주장은 여전히 용어 필요 ② `claims._pm_unit` — 문장에 "값 ± 숫자 단위" 가 바로 이어지면 그 단위 인정(다른 주장의 단위 빌리기는 계속 거절). 회귀 2개 → 뒷단 **185개 통과** |
| 수정 (앞단) | `confirm.start` — 같은 입력 재실행에서 필수 항목을 **모두 이어받으면** 확정할 방법이 없던 문제(확정은 제출 때만, 빈 제출은 거절). 이어받은 답으로 바로 확정. 회귀 1개 → 앞단·연결 **18개 통과** |
| 실제 API — 사이트로 1→6 (수정 뒤) | **1회차** Supported 14 · Unsupported 0 · 구조화 실패 0 (깨끗한 보고서의 정답), 6-1 안내 14개 모두 LLM. **2회차**(수정 데이터, 2단계 실제 호출 3회·입력 17k·출력 14k 토큰) Supported 12 · E07 기록 12 · 6-2 가 S07 "내용 변경 3행 빠짐"·S12 "형식만 변경" 탐지, 이전 실행 연결 정상. 두 회차 모두 4단계 한 번 실행·같은 뒷단 실행에 결합 |
| 관찰 | 2회차는 2단계 응답이 달라 5-1 항목 목록 문구가 바뀌어 주장 추출을 다시 했고, LLM 이 문장을 다르게 나눠 6-2 판정 비교에 "사라진 주장/새 주장" 쌍이 생김(판정은 전부 Supported 로 같음). 7장 #7·#13(LLM 추출 변동, 반복 주장 대응)과 같은 한계 |
| 초기화 도구 | `tools/reset_workspace.py` — 실행 기록(inputs·outputs) 삭제, `--all` 이면 LLM 캐시까지. 사용자가 화면에서 돌린 기록(실행 2개·파일 349개)을 이것으로 지움 |

### 14-6. 범용성 시험 — 새 실험 ex2 (2026-09-30, 실제 API)

**사례**: 공개 자료 Hart & Jenkins 2023 수생 메조코즘(`ex2/mesocosm.xlsx`, 보고서 PDF). 계획서는 없어서 **시험용 계획서 docx 를 생성형 AI 로 만듦**(Word 수식 5개: pᵢ, H′, D = exp(H′), 이차 회귀, R²). 엑셀은 앞단이 읽지 못해 두 시트를 CSV 로 내보냄. 정답은 계획서 식으로 따로 계산(보고서를 보지 않음) → 보고서 수치와 전부 일치.
데모(어닐링)와 다른 점: 시료가 **파일이 아니라 표의 행**(수조 37개 = 37행), **집단 비교 없음**(연속 변수 NEP·교란 비율), 검정 없이 **기술통계·회귀**, 보고서 **영어 PDF**(계획서는 한국어).

**결과 요약**

| 회차 | Supported | Unsupported | 원인 |
|---|---|---|---|
| 수정 전 | 0 | 21 | 아래 ①~⑤ |
| ①~⑥·⑧ 수정 뒤 (사이트 실제 실행) | 8 | 19 (전부 E06) | ⑦ 용어 대조가 언어를 넘지 못함 |
| ⑦ 수정 뒤 (저장된 주장으로 5-2 다시 비교) | **27/27** | 0 | — |

4 RECOMPUTE 는 처음부터 **20~22개 값을 정답과 모두 일치**하게 계산. 문제는 전부 계산 뒤의 연결·판정 규칙에 있었음.

**발견과 조치**

| # | 발견 | 위치 | 조치 |
|---|---|---|---|
| ① | 2-4 누락 점검이 "시료 = 파일" 만 가정 → 수조 38개 전부 "시료 파일 없음" E03, 모든 항목에 의존으로 붙어 전부 Unsupported | 앞단 `extract/missing.compare` | `[수정]` 시료 파일이 없으면 **공유 표의 행**으로 찾음(열 이름 = 시료 표기 앞부분, 값 = 번호 — 'Tank 1'·'Tank1' → Tank 열 1, '4.0'=4). 숫자만인 표기는 열 이름 없이 인정 안 함. 실제로 빠진 수조 12 는 그대로 E03 로 잡음 |
| ② | 설계 조건에 연속 변수(Distproport·NEP)가 같은 시료 "Tank(37개)" 로 들어가 집단 {Distproport:1, NEP:1} → 보고 n=37 이 E04 | `bridge._assemble` | `[수정]` 조건들이 시료를 공유하면 집단이 아님 → 2-4 가 풀어 적은 시료 목록(겹치지 않으면)을 집단으로 사용, 아니면 집단 없이 인계(경고) |
| ③ | 이름에 '비율'이 든 결과(교란 비율 평균·교란 비율 회귀 계수)를 ratio(두 집단의 비)로 분류 → 짝 거절 E06 | `bridge.output_kind` | `[수정]` ratio 는 집단 ≥ 2 이고 기술통계·회귀 낱말(평균·최솟값·계수·절편…)이 없을 때만 |
| ④ | 코드가 적은 단위 '모형 단위'·'미기재' 를 해석 못해 E01 | `bridge._assemble` | `[수정]` 한글 낱말뿐인 단위 표기는 설명으로 보고 단위 없이 인계(경고). 영문·기호가 든 해석 불가 단위는 그대로(E01 가능) |
| ⑤ | PDF 표가 한 줄로 풀려 "37 2.176" 을 공백 제거 뒤 **372.176** 으로 읽어 원문 검증 실패. 식의 "+ 0.1391" 도 실패 | 뒷단 `validate/claims._number_in` | `[수정]` 공백을 숫자 경계로 두고 부호 뒤·지수 표기 주변 공백만 붙임, 앞의 '+' 는 부호 없는 수와 같게 |
| ⑥ | **모델 응답 깨짐**: 2-1c 코드 초안 1회(요청 `msg_011CfYH2xU6yuhWJPEAUA8pn`)가 한글을 전부 '\f'+'f' 로 보냄(stop_reason 정상). 캐시에 저장되고 승인 코드 이름·단위가 깨진 채 5·6 까지 감 | 앞단 `llm.py` | `[신설]` 출력 문자열에 제어 문자(탭·줄바꿈 제외)가 있으면 **캐시하지 않고 한 번 다시 부름**, 두 번 모두 깨지면 실패. 캐시에 남은 깨진 응답은 쓰지 않음 |
| ⑦ | 남은 19건: LLM 짝은 전부 맞는데, 승인 용어가 한국어(유효·다양도·교란·회귀)이고 보고서가 영어라 절에 용어가 없음. "It ranged from 1.14" 처럼 대명사로 앞 문장 지표를 받는 경우도 있음 | 뒷단 `compare` | `[수정 — 아래 "⑦ 결정"]` 다른 언어일 때 값 유일성으로 짝 확인 |
| ⑧ | 2-4 LLM 이 "계획서 본문의 식" 을 사양서(spec) 필요 문서로 분류 → E03 "필요 문서 없음", 모든 항목에 의존 | 앞단 2-4 / `bridge` | `[수정]` 사양서 누락 E03 은 재계산 항목의 의존으로 걸지 않음(사양서는 2-2 → E02 범위 판정에만 쓰임, 경고로 남김). `[제안 — 앞단]` 3-1 누락 항목에 "누락 아님(오탐)" 선택지가 없어 연구자가 거짓 후보를 지울 수 없음 |
| ⑨ | PDF 위첨자 손실("R²"→"R", "(NEP)²"→"(NEP)"), 영어 수사("Thirty-seven") 원문 검증 실패 | 5-1 보고서 읽기 | `[한계]` 짝·값 비교에는 영향 없었음. 수사는 구조화 실패로 드러남 |

**⑦ 결정 (2026-09-30)** — 보고서는 대부분 영어로 받으므로 언어 차이는 예외가 아니라 기본 상황. 용어 규칙(`[신설]`, 파이프라인 v4 원문은 "대응 재계산값이 없으면 E06" 만 정함)은 같은 언어를 은연중에 가정했음. 낱말을 늘리는 대신 확인 방식을 바꿈:
- 필수(언어 무관): 통계량 ↔ 항목 종류. 같은 언어면 기존 용어 규칙 그대로(면저항 ↔ 전도도 거절 유지).
- 용어가 문장과 다른 언어면 `compare.term_evidence` → "cross" → `_value_identifies`: 보고값 유효 2자리 이상 + 이 항목과 일치 + 같은 종류 다른 항목과 불일치일 때만 짝 인정. 방향 주장은 `_pair_identifies`(같은 지표의 두 조건, 그 조건쌍의 지표가 하나뿐).
- 대가: 용어 증거가 없는 문장에서 값이 틀리면 E05 대신 E06(짝 확인 불가) — 둘 다 Unsupported 라 잘못된 Supported 방향은 아님.
- 함께: 한글 낱말 + 괄호 설명뿐인 단위('비율(0~1)')도 설명으로 봄(④ 확장).
- 효과: ex2 마지막 실행의 저장된 주장 27개를 새 규칙으로 다시 비교 → **27/27 Supported**(5-2 비교만 다시 함, 사이트 5·6 전체 재실행은 안 함). 테스트: 뒷단 **190개**(+4: 값 유일성 인정·불일치는 E06·자릿수 부족·두 항목 모호·같은 언어 이중 용어는 엄격 유지·방향 지표 유일성), 앞단·연결 24개 통과.

**⑦ 당시 검토한 선택지 (기록)**
- A. 계산 뒤 항목 승인 화면에서 연구자가 **보고서 언어 별칭**(예: 유효 다양도 = "Effective diversity")을 추가 → 승인 용어에 합침. 사람 승인이라 R1 유지. 화면·인계 형식 작업 필요.
- B. 결과의 기호·데이터 열 이름(D, NEP, Distproport, β₂)을 용어에 추가. 작업 적음. 하지만 "Disturbance"≠"Distproport", 한 글자 기호 "D" 는 오탐 위험, 대명사 문장은 그대로.
- C. LLM 이 용어를 번역. 짝 검증이 다시 LLM 판단에 기대게 되어 가드 의미가 약해짐.
- 대명사("It ranged…")는 A·B 로도 풀리지 않음 — 앞 문장까지 절 범위를 넓히면 가드가 약해짐. 현재는 E06 로 보수적으로 둠.

**테스트**: 앞단·연결 **24개 통과**(새 `tests/test_generality.py` 6개: 표의 행 시료·숫자만 표기·조건 공유·ratio 규칙·깨진 응답 재호출·두 번 깨지면 실패), 뒷단 **186개 통과**(표 칸·'+' 부호 회귀 1개).
**토큰**: ex2 전체 실제 호출 — 2단계 약 10회, 5-1·6-1 회차당 2~3회.
### 14-7. 외부 리뷰 피드백 4건 반영 (2026-09-30)

| # | 피드백 | 확인 | 조치 | 위치 |
|---|---|---|---|---|
| 1 (높음) | 승인 코드가 없으면 인계 미리보기가 실패해 5·6 에 못 감. 화면은 "모든 수치 주장 E06" 이라 안내 | 맞음 — 통합 때 만든 흐름의 누락 | `[수정]` 코드 없음(또는 3회 뒤 코드·가공·매칭 미확정) = `pending: code`. 4단계는 계산하지 않고 **막힌 채 기록**(블라인드 입증용 계산 로그), 인계 묶음은 항목 없이 만들고, 5·6 은 보고서 주장을 추출해 **모든 주장 E06(미확정)**. `Confirmed.code_pending()`·`approval_problems(allow_code_pending)`, 코드 미확정이면 빈 항목 목록 허용, `bind_outputs` 는 막힌 탐색 실행에만 코드 없는 결합 허용, `compare_claim` 첫머리에서 E06(미확정). 화면: 4단계가 막혀도 뒷단 기록이 있으면 인계 화면을 열어 가능 여부·사유 표시. 결과 `execution.executions = 0` | `bridge.py`, `backend/contract.py`, `backend/recompute/engine.py`, `backend/validate/compare.py`, `recompute/run.py`, `web/static/recompute.js` |
| 2 (높음) | 이전 실행의 확정 단위를 열 이름만 같으면 그대로 적용 | 맞음 — 조건 없이 복사, 2-3·인계에서 헤더보다 우선, 다시 묻지 않음 | `[수정 — 앞단 3 CONFIRM]` 단위 확정 때 근거(`unit_evidence`: 그 열이 든 RAW 파일의 내용 해시 + 헤더 표기)를 저장. 새 실행은 근거가 같을 때만 이어받고, 다르거나 근거 없는 옛 기록이면 **다시 물음**(메시지에 이전 값 표시, 항목에 `previous_answer`). 질문 문구가 같아도 단위 답을 일반 이어받기로 옮기지 않음 | `confirm/run.py` (`_unit_evidence`·`_carry_units`) |
| 3 (보통) | 보고서가 INGEST 이후 바뀌었는지 대조 안 함 | 맞음 | `[수정]` `bridge.run` 이 1단계 해시와 대조, 뒷단 `open_report(expected_sha256)` 가 실제로 읽은 바이트로 다시 대조 — 다르면 `blind_log` 를 쓰기 **전에** 멈춤(`ReportChangedError`) | `bridge.py`, `backend/validate/claims.py`, `backend/pipeline.py` |
| 4 (보통) | 과거 4단계 기록 하나가 손상되면 새 재계산이 실패 | 맞음 — 예외 처리 없이 읽음 | `[수정]` 읽지 못하는(깨진 JSON·형식 다름) 기록은 건너뛰고 `e07.excluded` 에 파일·사유 기록, 스냅샷이 깨졌으면 해시만 비교 | `recompute/run.py` (`_read_log`·`_previous_log`) |

**테스트**: 앞단·연결 **29개**(+5: 코드 없음 → 5·6 전부 E06 미확정·실행 0회, 보고서 변경 시 열람 전 거절, 깨진 과거 기록 제외·사유, 단위 근거 같으면 이어받기·내용 바뀌면 다시 묻기, 근거 없는 옛 기록은 다시 묻기), 뒷단 **190개** 통과. 실제 API 사용 없음.
**친구에게 알릴 것**: #2 는 앞단 3 CONFIRM 코드(`confirm/run.py`)를 고침 — 확인 상태 파일에 `overrides.unit_evidence` 가 새로 생김(없으면 단위를 이어받지 않고 다시 물음).