# MeasureTrace v4 — 뒷단 (4 RECOMPUTE · 5 VALIDATE · 6 AUDIT)

> 확정본 대비 규칙·연동 계약은 [인수인계 변경 기록](HANDOFF_v4_변경기록.md), 리뷰 수정의 전·후 사례·검증·미완료 사항은 [개선 기록](IMPROVEMENTS_v4_리뷰수정.md)에 적는다. 코드가 바뀌면 두 문서도 함께 갱신한다.

기준 문서: `MeasureTrace_파이프라인_v4_확정.md`, `MeasureTrace_오류코드_v4.md` (2026-09-29 확정본)
앞단(1 INGEST · 2 EXTRACT · 3 CONFIRM)은 친구 담당. 앞단 → 뒷단 인계는 **`confirmed.json` 한 파일**로 한다.

## 과업 ↔ 파일

| 과업 | 주체 | 파일 | 하는 일 |
|---|---|---|---|
| 4-1 수치 재계산 | PY | `recompute/engine.py`, `recompute/_runner.py` | 코드 해시 확인 → 데이터 해시 확인 → 승인 코드를 별도 프로세스에서 실행 → 승인된 Output 목록에 맞춤 |
| 4-2 계산 로그 | PY | `recompute/engine.py` | `calc_log.json`(해시 2종·코드 해시·계산 과정·결과·결과 해시), `data_rows.json`(행별 해시), `lineage.jsonl` |
| 5-1 주장 추출·분류 | LLM | `validate/claims.py`, `validate/report_reader.py` | **보고서 첫 열람**(블라인드 확인·`blind_log.json`), 쪽·문장 번호, 7종 분류, 주장 ↔ 재계산 항목 짝 후보, 원문 검증 |
| 5-2 재계산값과 비교 | PY | `validate/compare.py`, `validate/rounding.py` | 유효 자릿수 반올림, 단위 환산, 방향 부호, 유의성, n·자유도 vs 설계 |
| 5-3 오류 코드 분류 | PY | `validate/codes.py` | 의존 관계를 따라 E01~E07, 판정 |
| 6-1 결과 출력 | PY + LLM | `audit/report.py`, `audit/explain.py`, `audit/storage.py` | JSON·Markdown·완료 표식. 판정·숫자·핵심 사유는 Python, LLM은 검증된 보조 안내 선택 |
| 6-2 수정 후 재평가 | PY | `audit/rerun.py` | 이전 실행과 데이터 비교(E07), 판정 변화 |
| 순서 | — | `pipeline.py` | 4-1 → 4-2 → 5-1 → 5-2 → (6-2 데이터 비교) → 5-3 → 6-1 → (6-2 판정 비교) |

## 앞단이 만들어 줘야 하는 것 — `confirmed.json`

형식 정의: `measuretrace/contract.py` · 예시: `examples/confirmed.example.json`, `examples/approved_code.example.py`

| 필드 | 누가 만드나 | 내용 |
|---|---|---|
| `input_root`, `data[]` | 1-1, 1-2, 2-3, 3-1 | RAW 파일 경로·**원본 바이트 해시(sha256)**·pandas 읽기 옵션·열 의미·단위·`unit_status`(3회 뒤 미확정이면 `unresolved`) |
| `equations[]` | 2-1b | LaTeX, 앞 문단 문장, 수식 해시 |
| `code` | 2-1c 초안 → 3-1 승인 | 코드 파일 경로(confirmed.json 기준)·**승인 시점 sha256**·승인자·ISO 시각·선택 `approval_hash`(새 앞단은 실제 승인 후 `seal_approval()` 연결) |
| `outputs[]` | 2-1c → 3-1 | 코드가 내야 하는 값의 id·설명·종류·단위·식·의존 데이터(`raw#열`)·집단·**승인 지표 용어(`terms`)** |
| `design` | 2-1c → 3-1 | 독립 단위, 집단별 독립 단위 수, 기술적 반복 수, 검정(이름·집단·α·p/통계량/자유도 Output) |
| `flags[]` | 2-3, 2-4, 3-2, 3-3 | E01 단위 / E02 이상값(`proceed` 또는 `unresolved`) / E03 누락(`missing`) — 대상은 ref 표기 |
| `pending[]` | 3 CONFIRM | 3회 뒤에도 미확정인 항목 → 의존하는 주장은 E06 '미확정' |
| `confirm_rounds` | 3 CONFIRM | 1~3 |

승인 코드 규약:
```python
def compute(data: dict[str, pandas.DataFrame], params: dict) -> dict:
    return {"outputs": {"<Output id>": 숫자, ...}, "steps": [{"name": ..., "value": ...}, ...]}
```
코드가 낸 값 중 `outputs[]`에 없는 id 는 쓰지 않는다(R3). 코드 파일이 한 글자라도 바뀌면 실행하지 않는다(R1).
데이터 파일 해시가 CONFIRM 시점과 다르면 실행하지 않는다(INGEST 부터 다시).

## 실행

아래 명령은 `v4_55` 폴더에서 실행한다. 프로젝트 최상위에서는 `.\.venv\Scripts\python.exe -m pytest v4_55/tests -q`로 검증한다.

```bash
pip install -r requirements.txt
python -m pytest                           # 177개 통과 확인, 가짜 LLM — 토큰 0
python scripts/demo.py                     # 합성 케이스 → demo_run/out/runs/<실행>/audit_report.md (토큰 0)
python scripts/demo.py --rerun             # 데이터를 고쳐 한 번 더 → 6-2 재평가(E07·판정 변화)
python scripts/demo.py --real --rerun      # 실제 Claude API (토큰 사용, 호출 약 3회)
python -m measuretrace.pipeline --confirmed <confirmed.json> --report <보고서> --out <출력 폴더>
```

LLM 설정(`.env`): `LLM_API_KEY`(없으면 `ANTHROPIC_API_KEY`), `LLM_MODEL_STRONG`(없으면 `claude-opus-5-5`).
`MEASURETRACE_OFFLINE=1` 이면 캐시만 쓴다. 호출·캐시 적중은 모두 `<출력>/llm_audit_log.jsonl`(R7).
서버 측 fallback(거절 시 다른 모델로 재시도)을 기본으로 켜 두었다. 모델이 받지 않으면 끄고 다시 부른다. `MT_LLM_FALLBACK=0` 이면 항상 끈다.

## 원칙을 코드에서 지키는 곳

| 원칙 | 위치 |
|---|---|
| R1 LLM 숫자를 계산에 쓰지 않음 · 승인 코드 해시 고정 | `engine._fixed_code`, `claims.verify_item`(원문에 없는 수치·단위 거절), `explain.check`(설명 문장 속 숫자 거절) |
| R2 측정값은 LLM 에 안 보냄 | `claims.catalog_text`(항목 이름·설명만), `explain.explain_all`(재계산값 대신 자리표시자) — 테스트 `test_llm_never_sees_measured_values` |
| R4 블라인드 | `recompute` 는 보고서 경로를 받지 않음, `claims.open_report` 가 계산 로그 완료 시각 < 열람 시각 확인 |
| R3 승인 | 코드/승인 묶음 확인과 미확정 식·열·Output 의존 검사. 관련 미확정이 있으면 단일 compute 전체 blocked — 인수인계 7장 #12 |
| R5 입력 읽기 전용 | RAW 실행 사본·Python 접근 제한. RECOMPUTE와 AUDIT 출력의 실제 경계/RAW 제외 및 기존 연결 검사. AUDIT는 임시 쓰기 후 파일 교체·완료 표식 게시 |
| R6 입력 스크립트 실행 안 함 | 승인 코드만 실행, RAW 폴더 안 코드 거부. Python 감사 훅·AST 제한 적용 |
| R7 근거 | 주장마다 쪽·문장, 보고값, 재계산값, 식, 데이터 해시, 코드 해시 |

## 판단한 것 (문서에 없거나 [판단]인 부분 — 팀 확인 필요)

1. **승인 코드 격리**: 별도 프로세스(`python -I -X utf8`, 최소 환경변수, 시간 제한 120초), 승인 코드·RAW 사본·작업 파일 해시 재확인, AST·Python 감사 훅으로 외부 파일 접근·네트워크·프로세스 생성 제한. import 별칭도 원래 이름으로 검사한다. **OS 수준 샌드박스는 아니다**. 네이티브 코드 우회까지 격리됐다고 보지 않는다.
2. **주장 ↔ 재계산 항목 짝짓기**를 5-1 LLM 이 후보로 내고 파이썬이 검증한다. 하나라도 어긋나면 짝 후보를 거절하고 E06 '식 없음'.
   - 항목 id 가 실제로 있는가
   - 주장 통계량과 항목 종류가 맞는가 (p ↔ p_value, t·F ↔ test_statistic, n ↔ n, df ↔ df, 평균 ↔ value …)
   - 주장 문장에 그 항목의 **승인 용어(`terms`)** 가 있는가 — 단위·변화 종류가 같아도 지표가 다른 경우(면저항 % ↔ 전도도 %)를 막는다.
     용어 목록에 없는 동의어를 쓰면 E06 이 나온다(잘못된 Supported 보다 안전한 쪽). `terms` 가 비면 대조를 생략하고 리포트에 적는다.
   - 단위 환산이 되는가 (안 되면 E01)
3. **보고 단위가 없는 수치**(재계산 단위가 있는데)는 E01 로 본다.
4. **10^k 배 차이**(k = ±2, 3, 6, 9, 12)는 E05 가 아니라 E01(환산 누락 의심)으로 본다 — 오류코드 E01 예시("3.2 mS vs 3.2 S").
5. **정수 보고값의 끝 0** 은 유효숫자로 보지 않는다("1200" → 100 단위). n·자유도는 정확히 같아야 한다.
6. **DOCX 쪽 번호**는 Word 가 저장한 쪽 표시 → 없으면 명시적 쪽 나눔 → 둘 다 없으면 1쪽(리포트에 방식 기록).
7. **구조화 실패**(LLM 분류 누락·전체 또는 일부 후보 검증 실패)는 판정이 아니라 별도 문장 목록으로 둔다. 부분 실패 문장은 통과한 주장 판정과 함께 표시한다.
8. 6-2 의 **데이터 비교는 5-3 앞**(E07 기록을 주장에 붙이려고), 판정 비교는 6-1 결과를 만든 뒤에 한다.
9. 이전 실행은 같은 프로젝트의 완료 시각 기준으로 선택한다. 수정된 보고값은 항목·검정 의미 키로 연결하며 반복 주장은 등장 순서대로 대응한다. 같은 `run_id` 재사용은 거부한다.

RECOMPUTE 수정 당시 로컬 검증은 **135개 통과 / 실패 0 / 107.63초**였다. [RECOMPUTE 수정 기록](../outputs/recompute_fixes_2026-09-29/Recompute_Fixes.md)에 재현한 6개 문제의 전·후 동작과 테스트 근거를 적었다. 인계 사본을 실행 시작에 고정하고 `confirmed_snapshot.json`을 남긴다. 관련 미확정 의존 관계가 있으면 현재 단일 compute 전체가 blocked된다.

실제 API 전체 실행·재평가는 2026-09-29 22:24 코드에서 성공한 이력이다(인수인계 10장). 이번 RECOMPUTE 수정 후 유료 API는 다시 호출하지 않았다. 친구 앞단과 전체 1~6 연결, 실제 PDF/Excel, OS 격리, 항목별 부분 실행은 별도 과제다. 상세 연동 절차와 상태/예외 처리는 인수인계 11장을 참조한다.

후속 AUDIT 리뷰의 AD-01~07은 **모두 수정했고 최신 전체 테스트 177개가 통과했다(190.69초)**. 기존 135개 + 새 AUDIT 회귀 42개이며 테스트 중 소스 변경은 없었다. [수정 기록](../outputs/audit_fixes_2026-09-29/Audit_Fixes.md)에 전·후 동작과 인계 영향을 적었다. 새 실행은 `audit-v4.1`·`audit_complete.json`으로 완료와 근거 해시를 확인한다. 손상/미완료 이력은 제외 사유를 기록하고, 명시 지정 오류는 계산 전에 알린다. 설명은 `python-core-advice-v1`로 Python 핵심과 LLM 안내를 분리한다. 이번 AUDIT 수정에서도 유료 API는 호출하지 않았다.

## 기존 코드에서 가져온 것

- `practice_v4/measuretrace/common/llm.py` → 캐시·프롬프트 지문·감사 기록·오프라인 클라이언트 (`common/llm.py`)
- `practice_v4/measuretrace/extract/report_claims.py` → 주장 원문·수치 검증 방식 (`validate/claims.py`)
- `practice_v4/measuretrace/recompute/units.py` → pint 레지스트리·면저항 단위 (`common/units.py`)
- `skeleton_3/mt/lineage.py`, `workspace.py` → 이력 장부, 입력/출력 격리 확인
