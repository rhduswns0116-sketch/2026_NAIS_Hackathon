# MeasureTrace v4 통합본 (1~6단계)

`practice_v4`(앞단 1~4 + 웹 화면)와 동료 뒷단 `v4_55_1`(4~6)을 합친 실행 폴더. 원본 두 폴더는 그대로 두었다.

| 폴더 | 내용 |
|---|---|
| `measuretrace/` | 앞단 ingest · extract · confirm · recompute, 연결 `bridge.py`, 뒷단 `backend/` |
| `web/` | 로컬 웹 화면 (1~6단계) |
| `tests/` | 앞단·연결 시험(`test_pipeline.py`, `test_bridge.py`), 뒷단 시험(`backend/`), 데모 자료(`demo/`) |
| `docs/backend/` | 동료 인수인계·개선 기록, 인계 형식 예시 |
| `workspace/` | 실행 결과 (처음엔 2 EXTRACT LLM 캐시만 — 데모 자료는 토큰 0 으로 재실행 가능) |

기준 문서: `MeasureTrace_파이프라인_v4_확정.md` · `MeasureTrace_오류코드_v4.md`. **1 INGEST · 2 EXTRACT · 3 CONFIRM**(앞단)과
뒷단 **4 RECOMPUTE · 5 VALIDATE · 6 AUDIT**(`measuretrace/backend/` = v4_55_1)를 `measuretrace/bridge.py` 로 이어 1~6 을 한 화면에서 돈다.

> **RECOMPUTE 통합 (2026-09-30)** — 예전에는 앞단 4단계와 뒷단 4-1 이 같은 승인 코드를 **두 번**(규칙이 다른 두 격리 실행기로)
> 돌리고 교차 확인했다. 이제 **뒷단 엔진이 4단계에서 한 번만** 실행하고, 5·6 은 그 계산 로그에 사람이 승인한 항목 목록을 결합해
> 쓴다(재실행 없음). 항목 목록은 계산 전에 정할 수 없어서(2-1c 보고 목록에는 n·자유도·p 가 빠짐) 순서가
> "3-1 코드 승인 → 4 한 번 실행(결과 전부 기록) → 항목 목록 승인 → 5·6" 이다. 자세한 기록은 `docs/backend/HANDOFF_v4_변경기록.md` 14장.

## 실행

> **새 PC·새 폴더에서 처음 설치할 때는 [`새환경_빌드가이드.md`](새환경_빌드가이드.md)(같은 내용 `.docx`)를 따르세요** — 가상환경 · 설치 · `.env` · 시험 · 실행 · 문제 해결.

```bash
python web/server.py        # → http://127.0.0.1:8765 이 브라우저로 열림 (끄기 Ctrl+C)
python tools/reset_workspace.py          # 실행 기록 지우기 (업로드 사본·결과·장부 — LLM 캐시는 남김, 서버를 끈 뒤)
python tools/reset_workspace.py --all    # LLM 캐시까지 전부 지워 완전히 빈 상태로
```

1. 프로젝트 이름을 적는다 (같은 이름으로 다시 돌리면 직전 실행과 비교).
2. **연구 자료** 칸에 RAW 데이터·연구 계획서(.docx)·장비 사양서(PDF)를 파일이나 폴더째 끌어다 놓는다.
3. **최종 보고서 초안** 칸에 보고서를 따로 넣는다 (선택).
4. **시작** — 사본 업로드 → 1-1 · 1-2 · 1-3 결과가 화면에 나온다.
5. **2 EXTRACT 실행** — LLM 을 부른다(토큰 사용, 데모 기준 약 2분·호출 6번). 같은 입력은 캐시를 써서 두 번째부터 토큰 0.
6. **3 CONFIRM 시작** — 항목마다 맞음/수정/결정을 고르고 응답자 이름과 함께 **제출**(= 피드백 1회, 최대 3회).
7. **4 RECOMPUTE 실행** — 확정된 뒤 나타난다. 뒷단 엔진이 승인된 코드를 **한 번** 격리 실행해 결과·중간값·계산 로그를 보여 준다
   (LLM 없음, 토큰 0). 미확정·미결정 항목이 하나라도 있으면 실행하지 않는다.
8. **5 VALIDATE · 6 AUDIT** — 4 가 성공하면 나타난다. 4단계 결과로 만든 인계 묶음(재계산 항목의 종류·단위·집단·지표 용어, 설계·검정,
   E02/E03 기록, 미확정)을 확인하고 보고서·승인자를 골라 **승인하고 5·6 실행**. 뒷단은 **다시 계산하지 않고** 4단계 계산 로그에
   승인한 항목을 결합한 뒤 보고서를 처음 열어 주장별 Supported/Unsupported·오류 코드·근거·재평가(6-2)를 보여 준다
   (LLM 사용 — 5-1 주장 추출·6-1 설명). 같은 실행을 다시 감사하면 4단계를 새로 실행한다(한 뒷단 실행 = 계산 한 번 + 감사 한 번).

### 앞단 ↔ 뒷단 연결 (`measuretrace/bridge.py`)

| 앞단 | → 뒷단 `confirmed-v4.0` | 규칙 |
|---|---|---|
| 1-1 RAW 분류 · 1-2 원본 해시 | `data[]` | 원본 해시가 1-2 와 다르면 거부. 내용 해시는 뒷단 정의로 다시 뜸. 열 뜻 = 2-1a, 단위 = 3-3 확정 > 2-3 헤더, 3회 뒤 미확정 E01 → `unit_status=unresolved` |
| 4 RECOMPUTE(뒷단 탐색 실행) 결과 목록 | `outputs[]` | id 는 어댑터가 기호(없으면 이름)로 붙인 결과 id. 종류(value·p·t·df·n·변화율…)는 이름·기호 규칙, 집단은 설계 조건 이름, 변화량 [대상, 기준]은 승인 식의 첨자 순서, 지표 용어는 이름에서 |
| 3-1 설계·검정 | `design` | 집단별 시료 수, 기술적 반복, 검정 이름 규칙(student/welch/paired/anova…) |
| 3-3 E02 결정 · 3-1 E03 누락 · 3회 뒤 미확정 | `flags[]` · `pending[]` | 그대로 진행 → proceed, 재측정·미확정 → unresolved, 누락 → missing |
| 3-1 승인 코드 `compute(files)` | `code` (`mt_compute(data, params)`) | 승인 본문을 한 글자도 바꾸지 않고 싣고 어댑터만 덧붙임. 본문 해시는 `params.front_code_sha256` 로 함께 봉인 |

- 미리보기(`GET /api/runs/<id>/handoff`)의 묶음 지문을 화면이 들고 있다가, 승인 때 서버가 다시 만든 묶음과 같을 때만 `seal_approval` 한다.
- 4단계 실행 묶음(`confirmed_exec.json`, 항목 목록 없음)과 5·6 전체 묶음(`confirmed_v4.json`)은 같은 RAW·코드·파라미터를 만들어
  **실행 지문**(`execution_sha256`)이 같다. 결합(`bind_outputs`)은 이 지문이 다르면 거부한다 — 4단계 뒤 RAW·코드가 바뀌면 4단계부터.
- 산출물: `outputs/<프로젝트>/<실행>/handoff/<뒷단 실행>/`(실행 묶음·전체 묶음·코드), `outputs/<프로젝트>/<실행>/recompute/backend_run.json`
  (4단계가 만든 뒷단 실행), `outputs/_backend/<프로젝트>/runs/<뒷단 실행>/`(`calc_log_discover.json` 결합 전 계산 로그 ·
  `calc_log.json` 결합 뒤 · 주장 · 감사 리포트 `audit_report.md`), `outputs/<프로젝트>/<실행>/audit/audit_view.json`(화면용).
- 뒷단 변경: `backend/recompute/_runner.py` 가 읽은 표에 해시 확인한 실행 사본 경로를 `attrs["source_path"]` 로 붙인다(파일을 직접 읽는
  앞단 승인 코드용), 결과 메타데이터(`meta`)·라이브러리 버전을 넘기고, 코드 정적 검사를 `static_violations()` 로 분리(앞단 3-1 검사가 같은
  함수를 씀). `engine.run_recompute(discover=True)`·`bind_outputs()`, `pipeline.run_discovery()`·`run_validate_audit()` 추가.
- 시험: `python -m pytest -q tests/test_pipeline.py tests/test_bridge.py tests/test_generality.py`(가짜 LLM) · 뒷단 `python -m pytest -q tests/backend` — 두 번에 나눠 실행(같은 이름의 `test_pipeline.py` 가 두 곳에 있어 한 번에 모으면 멈춤).

**이어서 보기** — 화면 맨 위 '이전 실행 열기'에서 실행을 고르면 저장된 결과로 1~6단계를 다시 그린다(다시 실행하지 않음).
**실행 봉인** — 1 INGEST 를 마친 실행에는 파일을 더하거나 다시 수집할 수 없다(입력이 바뀌면 새 실행). 3 CONFIRM 을 시작한 실행은
2 EXTRACT 를 손으로 다시 돌릴 수 없다(CONFIRM 의 '수정 필요' 답으로만). 4 RECOMPUTE 는 추출 결과가 확정 때와 같은지 확인한다.
**로컬 서버 보호** — Host 가 127.0.0.1/localhost 가 아니거나, 다른 출처(Origin)에서 오거나, 쓰기 요청에 `X-MeasureTrace` 헤더가
없으면 403. 다른 웹사이트가 이 서버로 토큰을 쓰게 하거나 확인 답을 제출하지 못하게 한다.

LLM 설정: 이 폴더의 `.env` 또는 `../mt/.env` 의 `LLM_API_KEY`, `LLM_MODEL_STRONG`(없으면 `claude-opus-5-5`).
`MEASURETRACE_OFFLINE=1` 이면 캐시만 쓴다. `MEASURETRACE_WORKSPACE=<폴더>` 로 작업 폴더를 바꿀 수 있다(리허설·시험용). 설치: `pip install -r requirements.txt -c requirements-lock.txt`(검증된 고정 버전). 설정 예시: `.env.example`. 시험은 위 두 명령(가짜 LLM, 토큰 0).

### 시험 자료

`python tests/demo/make_demo.py` — 가상 연구 한 벌(어닐링에 따른 박막 전도도, 조건 2 × 시료 10 × 위치 7 × 전압 11점).

| 넣을 칸 | 폴더 |
|---|---|
| 연구 자료 | `tests/demo/annealing_demo/data` (계획서 docx — Word 수식 8개 · 사양서 PDF · RAW CSV 20개 + 분류 시험용 가공 CSV·그림·R 스크립트·메모) |
| 최종 보고서 초안 | `tests/demo/annealing_demo/report` (수치·방향·유의성·정도 표현·문헌 인용·혼합·정성 문장 포함) |
| 재실행 비교 | 같은 프로젝트 이름으로 `tests/demo/annealing_demo_rerun/` 을 다시 넣기 → S07 "3행 빠짐(31–33줄)", S12 "형식만 변경" |

정답은 `tests/demo/annealing_demo_answer_key.json`(계획서 식으로 RAW 에서 계산, 반올림 전) — 업로드하지 않는다.
오류는 넣지 않은 깨끗한 자료다. 벤치마크 오류 주입은 규칙을 쓰지 않은 팀원이 한다(v4 §8-4).
모든 문서에 "생성형 AI(Claude)로 작성한 가상 자료" 표시가 있다(v4 §8-5 공개 의무).
작은 연기 시험용 묶음: `python tests/make_samples.py` → `tests/samples/`.
필요한 패키지: 표준 라이브러리만으로 동작. PDF 글자 해시는 `pdfplumber`, 엑셀은 `openpyxl` 이 있으면 쓴다(없으면 원본 해시만).

## 1 INGEST 가 하는 일

| 과업 | 구현 | 위치 |
|---|---|---|
| 1-1 입력 격리 | 브라우저가 파일을 사본으로 보냄(연구자 원본 불변) → `workspace/inputs/<실행>/data` · `/report` 에 저장 후 **읽기 전용**으로 잠금. 산출물은 `workspace/outputs/` (입력 밖). 끝에 입력을 다시 해시해 불변 확인. 스크립트는 실행하지 않음 | `ingest/workspace.py`, `ingest/run.py` |
| 1-1 분류 | RAW / 연구 계획서 / 장비 사양서 / 보고서 + 사용 안 함(가공 데이터·그림·스크립트·시스템) · 미분류. 규칙만(LLM 없음), 근거·확신도 표시, 확정은 3 CONFIRM | `ingest/classify.py` |
| 1-2 해시 2종 | 원본 바이트 해시 + 내용 정규화 해시(CSV: BOM·개행·줄 끝 공백·빈 줄 제거 / docx: 글자 + Word 수식 XML / PDF: 전체 쪽 글자). 표는 **행별 해시**를 저장해 다음 실행에서 행·열 차이(바뀜·추가·빠짐, 줄 번호)를 보여 줌. 바이트만 다르면 "형식만 변경" | `ingest/hashing.py`, `run.compare` |
| 1-3 이력 장부 | `(입력 해시, 코드 해시, 파라미터) → 출력 해시` 를 `workspace/outputs/lineage.jsonl` 에 한 줄씩 추가. 코드 해시 = 실행한 Ingest 소스 파일들의 해시 | `ledger.py` |

지키는 것
- 보고서는 5-1 전까지 열지 않는다(R4) — Ingest 에서는 **원본 바이트 해시만** 남긴다(내용 해시도 만들지 않음).
- 측정 시각은 모으지 않는다(v4 결정 15). 가공 데이터·그림은 목록에만 남기고 다음 단계로 넘기지 않는다.
- 입력 사본은 지우지 않는다. 지우려면 파일의 읽기 전용 속성을 먼저 풀어야 한다.

## 2 EXTRACT 가 하는 일

| 과업 | 주체 | 구현 | 산출물 (`workspace/outputs/<프로젝트>/<실행>/extract/`) |
|---|---|---|---|
| 2-1a 데이터 내용 파악 | LLM | 열 구성이 같은 RAW 파일을 묶어 한 번씩. 보내는 것: 경로·열 이름·행 수·글자 열의 고유 표기. **숫자 열 값은 안 보냄**(R2) | `headers.json` (보낸 글 포함) |
| 2-1b 계획서 수식 변환 | PY | docx 의 `m:oMath` → dwml → LaTeX. 수식마다 앞 문장·수식 XML 해시·계획서 해시. 실패는 수식 단위로 잡아 3-1 질문 | `equations.json` |
| 2-1c 연구 내용 추출 | LLM ×2 | ① 식·가공 방법·설계·검정·매칭표 ② 그 결과로 계산 코드 초안. **코드는 실행하지 않음**(R1) — 해시만 | `plan_extraction.json`, `code_draft.py` |
| 2-2 측정 조건 추출 | LLM | 사양서 전 쪽 → 범위·정확도·오버플로 값(쪽·인용). 파이썬이 인용이 원문에 글자 그대로 있는지, 최솟·최댓값이 인용에 있는지 확인 | `spec_conditions.json` |
| 2-3 데이터 구조화 | PY | 값은 파이썬만 읽음. 헤더 단위 해석(E01 누락·모호), 결측·숫자 아닌 값·오버플로·사양 범위 이탈(E02, 사양 승인 전이라 **잠정**). 사용 범위는 2-1c 매칭표의 장비 범위로 고름 | `data_checks.json` |
| 2-4 누락 점검 | LLM→PY | LLM 은 계획서만 보고 필요한 시료·위치·측정점 목록(실제 파일 목록은 안 보여 줌) → 파이썬이 대조(E03) | `missing_check.json` |

- 보고서는 열지 않는다(R4) — 2단계는 `data` 구역만 쓴다. 결과에 "보고서 열지 않음"을 표시.
- 과업 하나가 실패해도 나머지는 계속하고 실패 이유를 남긴다. LLM 이 없으면 2-1b·2-3 만 돈다.
- 산출물마다 1-3 장부에 `(입력 해시, 코드 해시, 파라미터: 모델·effort·지시문 지문·캐시 여부) → 출력 해시`.
- LLM 호출·캐시 적중은 `workspace/outputs/llm_audit.jsonl`(R7), 응답 캐시는 `workspace/llm_cache/`.
- 각 LLM 과업의 모호한 점은 "3 CONFIRM 으로 넘길 질문"으로 모은다.
- 요청에는 서버 측 `fallbacks: "default"`(거절 시 다른 모델로 재실행)를 켜 두었다. 거절·출력 잘림은 실패로 기록.

## 3 CONFIRM 이 하는 일

| 과업 | 항목 (규칙으로 생성 — LLM 없음) | 답 | 답한 뒤 |
|---|---|---|---|
| 3-1 데이터 해석 승인 | 식(LaTeX·뜻·변수), 가공 방법, 설계, 검정, 실험↔데이터↔식↔장비 흐름, 계산 코드, 누락(E03) | 맞음 / 수정 필요(글) · 코드는 맞음 / 거부 · 누락은 그대로 진행 / 추가 업로드 | 수정이 있으면 고친 내용을 붙여 **2 EXTRACT 재실행**(2-1a·2-2 는 캐시) → 제안이 바뀐 항목만 다시 물음 |
| 3-2 장비 사양 확인 | 사양 항목마다 "N쪽을 읽어 보니 … 맞게 읽었나요?" + 원문 인용, 오버플로 값 | 맞음 / 수정(최소·최대·단위·글) | 모두 끝나면 E02 범위 이탈이 잠정 → **확정**. 수정하면 2-3 을 수정값으로 다시 계산 |
| 3-3 데이터 이상 확인 | E01 열마다 단위(제안값 채워 둠), E02 (파일·열·종류) 묶음마다 줄·값·한계 | 단위 입력(해석 가능한 표기만) / 그대로 진행 / 재측정 | 단위를 확정하면 2-3 재계산 → 새로 드러난 이상값은 새 항목 (v4 피드백 예 ②) |
| 추가 확인 (선택) | 2단계 LLM 이 남긴 질문 | 답하기 / 넘어가기 | 답은 다음 재추출 입력에 붙음 |

- 모든 답은 `confirm/answers.jsonl` 에 (항목, 제안 해시, 답, 응답자, 시각, 회차)로 **추가만** 한다. 항목별 기록(history)에 해시 변화도 남는다.
- **피드백 최대 3회.** 3회째 제출 뒤에도 남은 필수 항목은 **미확정** → 5단계에서 그 항목에 의존하는 주장은 Unsupported(E06 '미확정').
- 같은 프로젝트를 다시 실행하면 이전 실행에서 확정한 항목은 **제안 해시가 같을 때만** 이어받고, 다르면 "이전 실행과 제안이 다름(해시 a→b)"을 기록하고 다시 묻는다.
- 계산 코드는 승인하면 본문 해시를 고정해 `confirm/approved_code.py`(읽기 전용)로 쓰고, `workspace/outputs/approved_code/<해시>.py` + `approved_code_registry.jsonl` 에 등록한다. **같은 입력(계획서 해시·추출 결과·열 구성)** 이면 다음 실행에서 그 코드를 재사용(승인 이어받음). 여기서도 코드는 실행하지 않는다.
- 필수 항목이 모두 끝나면 `confirm/confirmed.json`(승인된 식·가공·설계·검정·매칭·사양(수정 반영)·단위·E02 결정·E03 결정·미확정·재측정 목록·답변 로그 해시)을 쓰고 1-3 장부에 기록 — 4 RECOMPUTE 의 입력.
- 재측정·추가 업로드는 이 실행 안에서 끝낼 수 없다 — 파일을 다시 올려 새 실행(1단계부터). 원본 사본은 지우지 않는다.

## 4 RECOMPUTE 가 하는 일

| 과업 | 구현 |
|---|---|
| 4-1 실행 전 확인 | 연결 코드(`bridge.build_exec`): ① `approved_code.py` 본문 해시 = 3-1 승인 해시 ② 3 CONFIRM 확정 뒤 2 EXTRACT 결과가 그대로인지 ③ RAW 사본을 다시 해시해 1단계 해시와 같은지 ④ 정적 점검(뒷단 실행기 규칙 `static_violations`). 뒷단 엔진: 승인자·승인 시각·실행 묶음 지문, 미확정·미결정 항목 없음(있으면 전체 차단), RAW 폴더 안 코드 거부. 하나라도 어긋나면 **실행하지 않고** 이유를 로그에 남김 |
| 4-1 격리 실행 (R6) | **뒷단 엔진 한 곳**(`backend/recompute`): 별도 프로세스 `python -I`, 최소 환경 변수(API 키 없음, 수치 라이브러리 스레드 1개), RAW 는 해시를 확인한 **실행 사본**만, 코드·데이터 사본 해시 재확인, 정적 검사 + **감사 훅**(작업 폴더 밖 파일 쓰기·허용 밖 읽기·폴더 탐색·네트워크·하위 프로세스 차단), 120초 제한. 앞단 승인 본문의 `compute(files)` 는 어댑터가 호출하고 결과를 전부 보고 |
| 4-2 계산 로그 | 근거: `outputs/_backend/<프로젝트>/runs/<뒷단 실행>/calc_log.json` — 입력 데이터 해시 2종·행별 해시, 코드 해시·승인자, 실행 지문, 결과 전부(`produced`)와 메타데이터, 중간값, 결과 해시, 라이브러리 버전, 계산 시각. 화면용 요약은 `recompute/calc_log.json`(최근) + `recompute/history/` |
| E07 | 4단계 화면에는 같은 프로젝트의 이전 4단계 기록과 비교한 **미리보기**(추가·삭제·형식만 변경·내용 변경, 표는 행·열 차이). 판정에 붙는 E07 **기록**은 6-2(뒷단)가 이전 감사 실행과 비교해 남긴다 |
| 블라인드 | 보고서는 열지 않음. 계산 시각을 남겨 5-1 의 열람 시각보다 앞섬을 입증 |

- 승인 코드가 없으면(3-1 미확정·거부) 계산하지 않고 "모든 수치 주장은 E06(미확정)"으로 기록.
- 감사 훅은 운영체제 수준 격리(컨테이너·VM)가 아니다 — 로컬 데모용 방어선이며 로그에 그 한계를 적는다.
- 리허설: `python tests/demo/rehearse.py` — 임시 작업 폴더에서 1→4 단계를 실제 LLM 캐시(토큰 0)로 돌리고 **도구 정확도 ①**(정답 대비 상대 오차 ≤ 1e-6)을 확인. 실제 작업 폴더·코드 승인 등록부는 건드리지 않음. 데모 결과: 10/10 통과, 최대 상대 오차 약 1e-14.
- 계산 로그 하나를 정답과 비교: `python tests/demo/check_answer.py <calc_log.json>`.

## 1~4단계 검토 (2026-09-29) — 찾은 문제와 고친 것

| # | 문제 | 고침 |
|---|---|---|
| B1 | 소수점 쉼표 CSV(`1,2e-9`)를 1.2e-8 로 10배 잘못 읽음 | 파일 단위로 소수점 쉼표를 판별(구분자가 쉼표가 아니고 '.' 소수가 없을 때만). 그 밖의 쉼표 숫자는 추측하지 않고 '숫자가 아닌 값' |
| B2 | 칸 안의 '5.1 nA', 숫자가 든 메모가 LLM 에 전송됨 (R2 위반) | 숫자+단위 칸·소수가 든 글은 보내지 않고 개수만 알림. 숫자+단위 열은 E01 '셀 안에 단위' |
| B3 | `sample_no`·`run_id` 의 꼬리말을 단위로 오인(E01 '모호') | 알려진 단위일 때만 꼬리말을 단위로 봄 |
| B4 | 사양 인용 검증이 부호를 무시(−10.5 가 '10.5' 로 통과) | 부호까지 비교, '±' 는 양쪽 허용 |
| B5 | 다른 웹사이트가 로컬 서버에 쓰기 요청 가능(토큰 사용·확인 답 제출), Host 미검사 | Host·Origin 확인, 쓰기에 사용자 지정 헤더 요구, OPTIONS 거부 |
| B6 | 새로 고침하면 진행 중인 실행을 다시 열 수 없음(여러 번 오가는 CONFIRM 불가) | 실행 목록·저장된 결과 보기 API, '이전 실행 열기' |
| B7 | 코드 지시문('표준 라이브러리 가능')과 격리 규칙(pathlib·sys·getattr 금지)이 달라, 승인한 코드가 4단계에서야 막힐 수 있음 | 규칙을 한 곳(sandbox)에서 정의해 지시문에 그대로 넣고, 2-1c 직후·3-1 에서 같은 검사. 위반 코드는 승인 불가 |
| B8 | 이전 실행의 확정 단위·사양 수정을 이어받고 2-3 은 다시 계산하지 않음 | 이어받을 때 2-3 재계산 후 항목 생성 |
| B9 | 2-4 가 엑셀 등 텍스트가 아닌 파일도 표로 읽으려 함 | 텍스트 표만 읽고 나머지는 '대조 못 함' 표시 |
| B10 | 1단계 뒤에도 업로드·재수집 가능 → 뒤 단계와 입력이 어긋남 | 실행 봉인 |
| B11 | CONFIRM 중 EXTRACT 수동 재실행으로 확인 내용이 바뀔 수 있음, RECOMPUTE 가 이를 모름 | 재실행 차단, 4단계에서 추출 결과 해시 대조 |
| B12 | 개수·번호 열의 '단위 없음'(무차원)을 입력할 방법 없음 | `무차원`·`개`·`번호` 등 허용 |
| B13 | 코드 초안이 없어도 CONFIRM 이 '완료'됨 | '코드 없음'·'추출 실패'를 필수 항목으로(다시 작성 요청만 가능) |

점검: v3 사례 49개 폴더 강건성(크래시 0), 까다로운 입력 10종, 회귀 시험 13개, 리허설 정확도 10/10(새 지시문으로 다시 만든 코드도 상대 오차 ≤ 1.3e-14).

## 구조

```
measuretrace/
  paths.py        경로 상수 (workspace/inputs · outputs · lineage.jsonl)
  ledger.py       1-3 산출물 이력 장부 · 코드 해시
  llm.py          LLM 호출 공통 (캐시 · 감사 기록 · 구조화 출력 · 거절 처리)
  ingest/         workspace(입력 격리) · classify(1-1) · hashing(1-2) · run(1 INGEST 조립·이전 실행 비교)
  extract/        headers(2-1a) · equations(2-1b) · plan(2-1c) · spec(2-2) · datacheck(2-3) · missing(2-4) · units · tables · run
  confirm/        items(확인 항목 만들기) · run(시작 · 제출 · 피드백 회차 · 확정)
  recompute/      sandbox(코드 규칙 · 정적 점검 = 앞단 규칙 + 뒷단 실행기 규칙) · run(4단계 화면 기록 · E07 미리보기 — 실행은 bridge→backend)
  bridge.py       앞단 → 뒷단 연결: run_step4(4단계 한 번 실행) · preview · run(항목 결합 + 5·6)
  backend/        뒷단 4 RECOMPUTE(유일한 실행기) · 5 VALIDATE · 6 AUDIT (v4_55_1)
web/              server.py(로컬 서버, 127.0.0.1 전용) · static/(index.html · app.js · extract.js · confirm.js · recompute.js · style.css)
tests/            test_pipeline.py(회귀 시험 13개) · fake_llm.py · demo/(make_demo · rehearse · check_answer) · make_samples.py
workspace/        실행하면 생김 — inputs/<실행 ID>/{data,report} · outputs/<프로젝트>/<실행 ID>/ingest_snapshot.json
```

API: `POST /api/runs` → `PUT /api/runs/<id>/files?zone=data|report&path=<상대 경로>`(파일마다) → `POST /api/runs/<id>/ingest {project}` → `POST /api/runs/<id>/extract` → `POST /api/runs/<id>/confirm/start` · `GET /api/runs/<id>/confirm` · `POST /api/runs/<id>/confirm/submit {respondent, answers}` → `POST /api/runs/<id>/recompute` · `GET /api/runs/<id>/recompute` · `GET /api/status`.
