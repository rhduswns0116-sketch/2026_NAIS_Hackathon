"""Markdown 가이드 → Word(.docx) (python-docx). 제목·표·코드 블록·목록·인라인 코드/굵게·인용을 옮긴다.

  python tools/md_to_docx.py 새환경_빌드가이드.md 새환경_빌드가이드.docx     # md 를 고친 뒤 docx 다시 만들기
"""
import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

SRC, DST = Path(sys.argv[1]), Path(sys.argv[2])
KFONT, CODEFONT = "맑은 고딕", "Consolas"
ACCENT = RGBColor(0x1F, 0x3A, 0x5F)

doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
for side in ("left_margin", "right_margin"):
    setattr(sec, side, Cm(2.0))
sec.top_margin, sec.bottom_margin = Cm(2.0), Cm(1.8)
CONTENT_W = 21.0 - 4.0


def set_font(run_or_style, name=KFONT, size=None, bold=None, color=None):
    f = run_or_style.font
    f.name = name
    rpr = run_or_style.element.get_or_add_rPr() if hasattr(run_or_style.element, "get_or_add_rPr") else None
    if rpr is None:
        rpr = run_or_style.element.rPr if run_or_style.element.rPr is not None else run_or_style.element._add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for k in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(k), name)
    if size:
        f.size = Pt(size)
    if bold is not None:
        f.bold = bold
    if color is not None:
        f.color.rgb = color


def shade(el, fill):
    pr = el.get_or_add_tcPr() if el.tag.endswith("}tc") else el.get_or_add_pPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear")
    sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), fill)
    pr.append(sh)


def para_border(p, side="bottom", color="BFC7D5", sz="6"):
    ppr = p._p.get_or_add_pPr()
    bdr = OxmlElement("w:pBdr")
    b = OxmlElement(f"w:{side}")
    b.set(qn("w:val"), "single")
    b.set(qn("w:sz"), sz)
    b.set(qn("w:space"), "4")
    b.set(qn("w:color"), color)
    bdr.append(b)
    ppr.append(bdr)


# 기본 스타일
normal = doc.styles["Normal"]
set_font(normal, size=10)
normal.paragraph_format.space_after = Pt(4)
normal.paragraph_format.line_spacing = 1.15
for name, size, color in (("Title", 20, ACCENT), ("Heading 1", 14, ACCENT), ("Heading 2", 12, ACCENT),
                          ("List Bullet", 10, None)):
    st = doc.styles[name]
    set_font(st, size=size, bold=None if name == "List Bullet" else True, color=color)
doc.styles["Heading 1"].paragraph_format.space_before = Pt(16)
doc.styles["Heading 1"].paragraph_format.space_after = Pt(6)
doc.styles["Heading 2"].paragraph_format.space_before = Pt(10)
doc.styles["Heading 2"].paragraph_format.space_after = Pt(4)

INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))")


def add_inline(p, text, size=None, base_bold=False):
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            add_inline(p, part[2:-2], size, True)
            continue
        if part.startswith("`") and part.endswith("`"):
            r = p.add_run(part[1:-1])
            set_font(r, CODEFONT, size=(size or 10) - 0.5, bold=base_bold or None, color=RGBColor(0x8B, 0x1E, 0x3F))
            continue
        m = re.fullmatch(r"\[([^\]]+)\]\(([^)]+)\)", part)
        if m:
            part = m.group(1)
        r = p.add_run(part)
        set_font(r, size=size, bold=base_bold or None)


def code_block(lines):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.rows[0].cells[0]
    cell.width = Cm(CONTENT_W)
    shade(cell._tc, "F3F5F8")
    cell.paragraphs[0].text = ""
    for i, ln in enumerate(lines):
        p = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        r = p.add_run(ln if ln else " ")
        is_comment = ln.lstrip().startswith("#")
        set_font(r, CODEFONT, size=8.5, color=RGBColor(0x5A, 0x6B, 0x7F) if is_comment else RGBColor(0x1B, 0x1F, 0x24))
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def md_table(rows):
    cells = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
    header, body = cells[0], [r for r in cells[2:]]
    ncol = len(header)
    # 열 너비: 글자 수 비례 (최소·최대 제한)
    lens = [max(len(re.sub(r"[`*]", "", (r[i] if i < len(r) else ""))) for r in [header] + body) for i in range(ncol)]
    weights = [min(max(l, 9), 45) for l in lens]
    total = sum(weights)
    widths = [CONTENT_W * w / total for w in weights]
    t = doc.add_table(rows=1 + len(body), cols=ncol)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for ri, row in enumerate([header] + body):
        for ci in range(ncol):
            cell = t.rows[ri].cells[ci]
            cell.width = Cm(widths[ci])
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.05
            add_inline(p, row[ci] if ci < len(row) else "", size=8.5, base_bold=(ri == 0))
            if ri == 0:
                shade(cell._tc, "DCE4EE")
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


lines = SRC.read_text(encoding="utf-8").splitlines()
DOC_TITLE = next((l[2:].strip().replace("`", "") for l in lines if l.startswith("# ")), SRC.stem)   # 머리말·문서 속성 제목
h2 = [l[3:].strip() for l in lines if l.startswith("## ")]
i, first_title = 0, True
while i < len(lines):
    ln = lines[i]
    if ln.startswith("```"):
        j = i + 1
        block = []
        while j < len(lines) and not lines[j].startswith("```"):
            block.append(lines[j])
            j += 1
        code_block(block)
        i = j + 1
        continue
    if ln.startswith("|"):
        j = i
        rows = []
        while j < len(lines) and lines[j].startswith("|"):
            rows.append(lines[j])
            j += 1
        md_table(rows)
        i = j
        continue
    if ln.startswith("# "):
        p = doc.add_paragraph(style="Title")
        add_inline(p, ln[2:].strip(), size=20, base_bold=True)
        para_border(p, color="1F3A5F", sz="12")
        if first_title:
            first_title = False
        i += 1
        continue
    if ln.startswith("## "):
        if ln[3:].startswith("1. 준비물"):
            # 목차 (제목 목록) — 1장 앞에
            p = doc.add_paragraph()
            r = p.add_run("목차")
            set_font(r, size=12, bold=True, color=ACCENT)
            for h in h2:
                q = doc.add_paragraph(style="List Bullet")
                q.paragraph_format.space_after = Pt(0)
                add_inline(q, h, size=9.5)
        doc.add_heading(level=1).add_run(ln[3:].strip().replace("`", ""))
        set_font(doc.paragraphs[-1].runs[0], size=14, bold=True, color=ACCENT)
        i += 1
        continue
    if ln.startswith("### "):
        doc.add_heading(level=2).add_run(ln[4:].strip().replace("`", ""))
        set_font(doc.paragraphs[-1].runs[0], size=12, bold=True, color=ACCENT)
        i += 1
        continue
    if ln.strip() == "---":
        i += 1
        continue
    if ln.startswith("> ") or ln.strip() == ">":
        # 인용 줄 — 부록의 LLM 지시문처럼 글자 그대로여야 하는 글: 줄 앞 공백을 살리고, ">" 만 있는 줄은 빈 줄
        body = ln[2:].rstrip() if ln.startswith("> ") else ""
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.4)
        p.paragraph_format.space_after = Pt(0)
        shade(p._p, "FFF6E0")
        para_border(p, side="left", color="E0A800", sz="18")
        lead = len(body) - len(body.lstrip(" "))
        if lead:
            r = p.add_run(" " * lead)
            set_font(r, size=9.5)
        add_inline(p, body.lstrip(" ") or " ", size=9.5)
        i += 1
        continue
    m = re.match(r"^(\s*)- (\[ \] )?(.*)$", ln)
    if m:
        p = doc.add_paragraph(style="List Bullet")
        if m.group(1):
            p.paragraph_format.left_indent = Cm(1.2)
        p.paragraph_format.space_after = Pt(2)
        add_inline(p, ("☐ " if m.group(2) else "") + m.group(3))
        i += 1
        continue
    if ln.strip():
        p = doc.add_paragraph()
        add_inline(p, ln.strip())
    i += 1

# 쪽 번호 (바닥글)
fp = sec.footer.paragraphs[0]
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = fp.add_run()
for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
    if tag:
        fc = OxmlElement("w:fldChar")
        fc.set(qn("w:fldCharType"), tag)
        r._r.append(fc)
    else:
        it = OxmlElement("w:instrText")
        it.set(qn("xml:space"), "preserve")
        it.text = text
        r._r.append(it)
set_font(r, size=8, color=RGBColor(0x88, 0x88, 0x88))
hp = sec.header.paragraphs[0]
hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
hr = hp.add_run(DOC_TITLE)
set_font(hr, size=8, color=RGBColor(0x88, 0x88, 0x88))

doc.core_properties.title = DOC_TITLE
doc.core_properties.author = "MeasureTrace"
doc.save(DST)
print("saved", DST)
