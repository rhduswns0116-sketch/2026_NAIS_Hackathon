"""작업 폴더 초기화 — 화면에서 돌린 실행 기록을 지우고 처음 상태로.

  python tools/reset_workspace.py           실행 기록(inputs · outputs)만 지움, LLM 캐시는 남김 (다음 데모 토큰 절약)
  python tools/reset_workspace.py --all     LLM 캐시까지 전부 지움 (완전히 빈 상태 — 다음 2 EXTRACT 는 LLM 을 다시 부름)
  python tools/reset_workspace.py --yes     확인 질문 없이

지우는 것 (MEASURETRACE_WORKSPACE 가 있으면 그 폴더, 없으면 workspace/):
  inputs/    업로드한 파일 사본 — 원본 보호용으로 읽기 전용이라 속성을 풀고 지운다
  outputs/   실행별 결과·확인 기록·계산 로그·감사 리포트, 1-3 이력 장부(lineage.jsonl), LLM 호출 기록, 승인 코드 등록부, 뒷단 실행
  llm_cache/ (--all 일 때만) LLM 응답 캐시
서버(web/server.py)를 끈 뒤에 실행하세요. 연구자 원본 파일은 이 폴더 밖에 있으므로 건드리지 않는다.
"""
from __future__ import annotations

import os
import shutil
import stat
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from measuretrace.paths import WORKSPACE  # noqa: E402


def _writable_then_retry(func, path, _exc):
    os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    func(path)


def main(argv: list[str]) -> int:
    targets = ["inputs", "outputs"] + (["llm_cache"] if "--all" in argv else [])
    ws = WORKSPACE.resolve()
    if ws == ROOT or ws in ROOT.parents:
        print(f"작업 폴더가 이상함: {ws} — 중단")
        return 2
    if not ws.exists():   # 새로 받은 폴더 — 아직 한 번도 실행하지 않음
        print(f"지울 것이 없음 ({ws} 가 아직 없음)")
        return 0
    if not ws.is_dir():
        print(f"작업 폴더가 폴더가 아님: {ws} — 중단")
        return 2
    found = [(name, sum(1 for p in (ws / name).rglob("*") if p.is_file())) for name in targets if (ws / name).exists()]
    if not found:
        print(f"지울 것이 없음 ({ws})")
        return 0
    print(f"작업 폴더 {ws}")
    for name, n in found:
        print(f"  {name}/  파일 {n}개")
    if "llm_cache" not in targets and (ws / "llm_cache").exists():
        print("  (llm_cache/ 는 남김 — 지우려면 --all)")
    if "--yes" not in argv and input("지울까요? [y/N] ").strip().lower() not in ("y", "yes"):
        print("취소")
        return 1
    for name, _ in found:
        shutil.rmtree(ws / name, onerror=_writable_then_retry)
    print("초기화 완료 — 화면을 새로 고치면 '이전 실행' 목록이 비어 있습니다")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
