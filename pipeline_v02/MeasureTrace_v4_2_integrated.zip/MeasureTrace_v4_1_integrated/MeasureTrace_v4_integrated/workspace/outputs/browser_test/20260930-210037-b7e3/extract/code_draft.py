# MeasureTrace 계산 코드 초안 (2-1c, LLM 작성)
# 상태: 승인 전 — 실행하지 않음(R1). 3-1 에서 사람이 승인하면 이 파일의 해시를 고정하고 4-1 에서만 실행한다.
# 코드 해시(sha256, 이 머리말 제외 본문): bbfea85a3df61588f01dde1df3b8b0d2aeb91fbdc02562e4d36411954e362fc0
# 모델: claude-opus-5 · 지시문 지문: 1b22857ed369b232

import csv
import math
import os.path


def _to_float(text):
    """빈 문자열/변환 불가 값은 None 으로 돌려준다."""
    if text is None:
        return None
    s = text.strip()
    if s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _position_key(label):
    """position 값을 가능하면 수치로, 아니면 문자열로 정렬하기 위한 키."""
    v = _to_float(label)
    if v is None:
        return (1, 0.0, str(label))
    return (0, v, str(label))


def _linear_fit(xs, ys):
    """최소제곱 직선 y = a + b*x 의 기울기 b 와 절편 a.

    TODO(확인 필요): 계획서에 'I-V 직선'을 구하는 방법(최소제곱 회귀 여부,
    절편 포함 여부, 이상치 처리)이 명시되어 있지 않다. 여기서는 절편을 포함한
    보통최소제곱(전압 x = voltage_V, 전류 y = current_A)으로 구현했다.
    """
    n = len(xs)
    if n < 2:
        return float("nan"), float("nan")
    mx = sum(xs) / n
    my = sum(ys) / n
    sxx = 0.0
    sxy = 0.0
    for x, y in zip(xs, ys):
        dx = x - mx
        sxx += dx * dx
        sxy += dx * (y - my)
    if sxx == 0.0:
        return float("nan"), float("nan")
    b = sxy / sxx
    a = my - b * mx
    return b, a


def compute(files: dict) -> dict:
    results = []
    intermediate = {}

    # ---- 1단계: 파일(시료)별로 읽고 position 값별로 데이터를 분리 ----
    # (계획서: "시료 2개 x 위치 7개")
    per_sample = {}       # sample -> {position -> {"V": [...], "I": [...]}}
    sample_order = []

    for rel_path in sorted(files.keys()):
        real_path = files[rel_path]
        sample = os.path.basename(rel_path)
        if sample.lower().endswith(".csv"):
            sample = sample[:-4]
        if sample not in per_sample:
            per_sample[sample] = {}
            sample_order.append(sample)

        with open(real_path, "r", newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                pos = (row.get("position") or "").strip()
                v = _to_float(row.get("voltage_V"))
                i = _to_float(row.get("current_A"))
                if pos == "" or v is None or i is None:
                    continue
                slot = per_sample[sample].setdefault(pos, {"V": [], "I": []})
                slot["V"].append(v)
                slot["I"].append(i)

    # ---- 2단계 + 3단계: 위치별 직선 기울기 -> 기울기의 역수 = 전도도 (EQ01/EQ02: 1/R) ----
    slopes = {}
    intercepts = {}
    n_points = {}
    conductivities = {}

    for sample in sample_order:
        for pos in sorted(per_sample[sample].keys(), key=_position_key):
            xs = per_sample[sample][pos]["V"]
            ys = per_sample[sample][pos]["I"]
            slope, intercept = _linear_fit(xs, ys)
            key = sample + "|position=" + str(pos)
            slopes[key] = slope
            intercepts[key] = intercept
            n_points[key] = len(xs)

            # 계획서 본문: "위치별 전도도는 I-V 직선 기울기의 역수로 구한다."
            # 식 [EQ01]/[EQ02]: 1/R  (R 을 위 문장의 '기울기'로 두고 그대로 옮김)
            # TODO(확인 필요): EQ01 과 EQ02 가 동일하게 1/R 로만 표기되어 두 식의
            # 역할 구분이 없고, R 이 기울기인지 기울기의 역수(저항)인지 정의가 없다.
            # 여기서는 본문 서술대로 '기울기의 역수'를 그대로 계산한다.
            if slope is None or (isinstance(slope, float) and math.isnan(slope)) or slope == 0.0:
                cond_value = float("nan")
            else:
                cond_value = 1.0 / slope
            conductivities[key] = cond_value

            results.append({
                "name": "위치별 전도도",
                "symbol": "1/R",
                # TODO(확인 필요): 계획서에 전도도의 보고 단위가 없다(형상/치수 보정 여부도 없음).
                "unit": "",
                "eq_id": "EQ01",
                "condition": key,
            })
            results[-1]["value"] = cond_value

    intermediate["sample_list"] = sample_order
    intermediate["position_list_per_sample"] = {
        s: sorted(per_sample[s].keys(), key=_position_key) for s in sample_order
    }
    intermediate["n_points_per_position"] = n_points
    intermediate["iv_slope_per_position_A_per_V"] = slopes
    intermediate["iv_intercept_per_position_A"] = intercepts
    intermediate["conductivity_per_position"] = conductivities
    intermediate["note_EQ02"] = (
        "EQ02 는 EQ01 과 동일한 1/R 표기로 계획서에 중복 제시되어 별도 계산을 두지 않음"
    )
    # TODO(확인 필요): 장비 사양서 'Measurement range'(전류 측정)의 수치가 없어
    # 측정값의 범위 내 판정은 수행하지 않았다.
    # TODO(확인 필요): 계획서에 통계 검정/유의수준/자유도 기술이 없어 검정 통계량은 산출하지 않았다.

    return {"results": results, "intermediate": intermediate}
