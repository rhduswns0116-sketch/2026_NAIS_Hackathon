# MeasureTrace 감사 리포트 — demo_check

실행 `20260930T195131999165-d82658` · 생성 2026-09-30T19:51:41.872290+09:00

> 판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것. 계산식의 과학적 타당성, 그림, 외부 문헌 수치, 데이터 조작 여부는 판정하지 않음.

## 요약

| Supported | Unsupported | 검사 대상 아님 | 구조화 실패 |
|---|---|---|---|
| 3 | 9 | 13 | 0 |

오류 코드: E03 필요 데이터 누락 ×9

## 블라인드 입증

- 계산 로그 완료 2026-09-30T19:51:34.951658+09:00 < 보고서 첫 열람 2026-09-30T19:51:35.323568+09:00 → 확인
- 보고서 해시 `e0cc002ecf7be0d2` · 코드 해시 `c46751eae67cb3ec` · 결과 해시 `399e6c513bddc534`

## 주장별 판정

| 위치 | 원문 | 보고값 | 재계산값 | 판정 | 오류 코드 |
|---|---|---|---|---|---|
| p.1 문장 11 | 어닐링 시료의 평균 전도도는 12.1 | 12.1 nS | 12.1 nS (원값 12.1015) | **Unsupported** | E03 |
| p.1 문장 11 | ± 0.7 nS | 0.7 nS | 0.7 nS (원값 0.657209) | **Unsupported** | E03 |
| p.1 문장 11 | 대조 시료는 9.9 | 9.9 nS | 9.9 nS (원값 9.8501) | **Supported** | — |
| p.1 문장 11 | ± 1.0 nS | 1.0 nS | 1.0 nS (원값 0.976403) | **Supported** | — |
| p.1 문장 11 | 각 n = 10 | 10 | 10 | **Unsupported** | E03 |
| p.1 문장 11 | 각 n = 10 | 10 | 10 | **Supported** | — |
| p.1 문장 12 | 대조 시료보다 23 % 높았다 | 23 % | 23 % (원값 22.8563) | **Unsupported** | E03 |
| p.1 문장 12 | 어닐링 후 전도도는 대조 시료보다 23 % 높았다 | G_A_bar > G_C_bar | 차이 2.25137 nS | **Unsupported** | E03 |
| p.1 문장 13 | 이 차이는 통계적으로 유의했다(t(18) = 6.05, p < 0.001) | 유의함 df=18 p < 0.001 | p = 1.02e-05 (유의, α=0.05) | **Unsupported** | E03 |
| p.1 문장 13 | t(18) = 6.05 | 6.05 | 6.05  (원값 6.04891) | **Unsupported** | E03 |
| p.1 문장 15 | 우리 어닐링 시료의 값 12.1 nS | 12.1 nS | 12.1 nS (원값 12.1015) | **Unsupported** | E03 |
| p.1 문장 18 | 어닐링은 박막의 전도도를 크게 증가시켰다 | G_A_bar > G_C_bar | 차이 2.25137 nS | **Unsupported** | E03 |

## 주장 상세

### S011-1 · Unsupported · p.1 문장 11 (자기 데이터 수치 주장)

> 어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10).

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 입력 자료와 승인 기록을 함께 보관하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 수치 (보고 유효 자릿수로 반올림)
- 참고: G_A_bar: 문장에 지표 용어는 없지만 보고 단위 'nS' 가 재계산 단위 'nS' 와 같은 차원이라 단위로 지표 확인
- 참고: 수치 일치 (반올림 12.1)
- 참고: 단위 'nS' 를 원문 '12.1 ± … nS' 표기에서 확인
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S011-2 · Unsupported · p.1 문장 11 (자기 데이터 수치 주장)

> 어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10).

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 입력 자료와 승인 기록을 함께 보관하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 수치 (보고 유효 자릿수로 반올림)
- 참고: s_A: 문장에 지표 용어는 없지만 보고 단위 'nS' 가 재계산 단위 'nS' 와 같은 차원이라 단위로 지표 확인
- 참고: 수치 일치 (반올림 0.7)
- 식 EQ05: `s_{c}=\sqrt{\frac{1}{n−1}\sum_{i=1}^{n}\left(G_{i}−\overline{G_{c}}\right)^{2}}` — 식 5. 조건 c의 표준편차(표본 표준편차, n − 1).
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S011-3 · Supported · p.1 문장 11 (자기 데이터 수치 주장)

> 어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10).

- 설명: Supported: 보고값 9.9 nS 은(는) 승인된 계산으로 다시 구한 9.9 nS 과(와) 일치합니다. 보고서의 수치·단위와 승인된 계산 조건을 함께 확인하세요. _(작성: 핵심 Python · 안내 LLM)_
- 수행한 검사: 수치 (보고 유효 자릿수로 반올림)
- 참고: G_C_bar: 문장에 지표 용어는 없지만 보고 단위 'nS' 가 재계산 단위 'nS' 와 같은 차원이라 단위로 지표 확인
- 참고: 수치 일치 (반올림 9.9)
- 참고: 단위 'nS' 를 원문 '9.9 ± … nS' 표기에서 확인
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S011-4 · Supported · p.1 문장 11 (자기 데이터 수치 주장)

> 어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10).

- 설명: Supported: 보고값 1.0 nS 은(는) 승인된 계산으로 다시 구한 1.0 nS 과(와) 일치합니다. 보고서의 수치·단위와 승인된 계산 조건을 함께 확인하세요. _(작성: 핵심 Python · 안내 LLM)_
- 수행한 검사: 수치 (보고 유효 자릿수로 반올림)
- 참고: s_C: 문장에 지표 용어는 없지만 보고 단위 'nS' 가 재계산 단위 'nS' 와 같은 차원이라 단위로 지표 확인
- 참고: 수치 일치 (반올림 1.0)
- 식 EQ05: `s_{c}=\sqrt{\frac{1}{n−1}\sum_{i=1}^{n}\left(G_{i}−\overline{G_{c}}\right)^{2}}` — 식 5. 조건 c의 표준편차(표본 표준편차, n − 1).
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S011-5 · Unsupported · p.1 문장 11 (자기 데이터 수치 주장)

> 어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10).

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 입력 자료와 승인 기록을 함께 보관하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: n·자유도 vs 계획서 설계 (E04)
- 참고: n 일치 (10, 설계: annealed=10 (해당 집단))
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S011-6 · Supported · p.1 문장 11 (자기 데이터 수치 주장)

> 어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10).

- 설명: Supported: 보고값 10 은(는) 승인된 계산으로 다시 구한 10 과(와) 일치합니다. 보고서의 수치·단위와 승인된 계산 조건을 함께 확인하세요. _(작성: 핵심 Python · 안내 LLM)_
- 수행한 검사: n·자유도 vs 계획서 설계 (E04)
- 참고: n 일치 (10, 설계: control=10 (해당 집단))
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S012-1 · Unsupported · p.1 문장 12 (혼합(자기 값 + 문헌값))

> 어닐링 후 전도도는 대조 시료보다 23 % 높았다.

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 입력 자료와 승인 기록을 함께 보관하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 변화량 (증가 → 양수로 보고 유효 자릿수 반올림)
- 참고: 수치 일치 (반올림 23)
- 식 EQ08: `ΔG=\frac{\overline{G_{A}}−\overline{G_{C}}}{\overline{G_{C}}}×100` — 식 8. 어닐링에 따른 전도도 증가율(%).
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S012-2 · Unsupported · p.1 문장 12 (혼합(자기 값 + 문헌값))

> 어닐링 후 전도도는 대조 시료보다 23 % 높았다.

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 입력 자료와 승인 기록을 함께 보관하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 방향 (재계산 차이의 부호)
- 참고: 방향 일치
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S013-1 · Unsupported · p.1 문장 13 (유의성 주장)

> 이 차이는 통계적으로 유의했다(t(18) = 6.05, p < 0.001).

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 보고서의 표현과 승인된 항목의 대응 관계를 확인하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 유의성 (계획서 검정 student_t, α=0.05), p 값 (p < 0.001), df vs 계획서 설계 (E04)
- 참고: 자유도 일치 (18)
- 식 EQ07: `t=\frac{\overline{G_{A}}−\overline{G_{C}}}{s_{p}\sqrt{\frac{1}{n_{A}}+\frac{1}{n_{C}}}}` — 식 7. 두 조건 비교는 독립 2표본 t 검정(등분산 가정)으로 하며, 자유도는 nA + nC − 2 = 18 이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S013-2 · Unsupported · p.1 문장 13 (유의성 주장)

> 이 차이는 통계적으로 유의했다(t(18) = 6.05, p < 0.001).

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 입력 자료와 승인 기록을 함께 보관하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 수치 (보고 유효 자릿수로 반올림)
- 참고: 수치 일치 (반올림 6.05)
- 식 EQ07: `t=\frac{\overline{G_{A}}−\overline{G_{C}}}{s_{p}\sqrt{\frac{1}{n_{A}}+\frac{1}{n_{C}}}}` — 식 7. 두 조건 비교는 독립 2표본 t 검정(등분산 가정)으로 하며, 자유도는 nA + nC − 2 = 18 이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S015-1 · Unsupported · p.1 문장 15 (혼합(자기 값 + 문헌값))

> 우리 어닐링 시료의 값 12.1 nS는 문헌값 11.5 nS [1]와 비슷하다.

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 보고서의 표현과 승인된 항목의 대응 관계를 확인하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 수치 (보고 유효 자릿수로 반올림)
- 참고: G_A_bar: 문장에 지표 용어는 없지만 보고 단위 'nS' 가 재계산 단위 'nS' 와 같은 차원이라 단위로 지표 확인
- 참고: 수치 일치 (반올림 12.1)
- 문헌값(검사 안 함): 11.5 nS
- 인용 1: [1] H. Kim et al., Journal of Thin Film Tests 12, 34 (2024). (가상 문헌)
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

### S018-1 · Unsupported · p.1 문장 18 (정도 표현)

> 어닐링은 박막의 전도도를 크게 증가시켰다.

- 설명: Unsupported: E03 필요 데이터 누락 때문에 지지되지 않습니다. 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점 보고서의 표현과 승인된 항목의 대응 관계를 확인하세요. _(작성: 핵심 Python · 안내 LLM)_
- **E03 필요 데이터 누락** [Unsupported] 필요 데이터 누락: 측정점 부족 어닐링 (A) S07 position=P3: 8/11점
  - 대상 item:어닐링 (A)/S07 (file=raw/annealed/S07.csv)
  - 의존: item:어닐링 (A)/S07
  - 결정: missing — 테스터 2026-09-30T19:44:13+09:00
- 수행한 검사: 방향 (재계산 차이의 부호)
- 참고: 정도 표현 '크게' 는 판정 제외 — 방향만 검사
- 참고: 방향 일치
- 식 EQ04: `\overline{G_{c}}=\frac{1}{n}\sum_{i=1}^{n}G_{i}` — 식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.
- 데이터 `raw/annealed/S01.csv` sha256 `c7ffba821399a338` 내용 `462413ff199d3be2`
- 데이터 `raw/annealed/S02.csv` sha256 `a954961e48bd8c36` 내용 `0f2b68b9a4f665c9`
- 데이터 `raw/annealed/S03.csv` sha256 `2f05029b081d9f71` 내용 `ccfc80049c2d966f`
- 데이터 `raw/annealed/S04.csv` sha256 `94e96882e0df3de7` 내용 `d685f5cef2a9ad11`
- 데이터 `raw/annealed/S05.csv` sha256 `b96f6bff108f5ce2` 내용 `9e7da319c0a15638`
- 데이터 `raw/annealed/S06.csv` sha256 `b7fa907565b5ca63` 내용 `247c4d691bc1e2f8`
- 데이터 `raw/annealed/S07.csv` sha256 `bb87883efb402325` 내용 `db3c8adea554b27d`
- 데이터 `raw/annealed/S08.csv` sha256 `98f4b09b6db153c3` 내용 `9279ba6bc5ce8a48`
- 데이터 `raw/annealed/S09.csv` sha256 `1cd9552c59e1418c` 내용 `5d244e5d9891e104`
- 데이터 `raw/annealed/S10.csv` sha256 `57a49767d07abcc4` 내용 `396a7f7a41da1c7e`
- 데이터 `raw/control/S11.csv` sha256 `940f5323c37dc161` 내용 `28409403b6c09fbc`
- 데이터 `raw/control/S12.csv` sha256 `2010455507aae9a3` 내용 `d8f4a98703465d57`
- 데이터 `raw/control/S13.csv` sha256 `e5d3f69ea51ed65a` 내용 `97a3010c10afc7d8`
- 데이터 `raw/control/S14.csv` sha256 `ce6cdd80e3484c7a` 내용 `5125ae4dc58637ec`
- 데이터 `raw/control/S15.csv` sha256 `3315dd67504e8050` 내용 `46894f85b142ae57`
- 데이터 `raw/control/S16.csv` sha256 `9c0c38a72504c468` 내용 `4025f59f2afca29d`
- 데이터 `raw/control/S17.csv` sha256 `df58e25de7f8d53b` 내용 `8ec0cfa59ce42938`
- 데이터 `raw/control/S18.csv` sha256 `269b4012c01fbc04` 내용 `2011286e9b44277d`
- 데이터 `raw/control/S19.csv` sha256 `1ecdc1911203619d` 내용 `e782c6b2511c4577`
- 데이터 `raw/control/S20.csv` sha256 `ef9ece45a71824e5` 내용 `f36302804f6c8273`

## 검사 대상 아님

- p.1 문장 1 [주장 아님(제목·설명 등)]: 어닐링 처리에 따른 박막 전도도 향상 — 최종 보고서 (초안)
- p.1 문장 2 [주장 아님(제목·설명 등)]: 1.
- p.1 문장 3 [주장 아님(제목·설명 등)]: 서론
- p.1 문장 4 [문헌 인용]: 선행 연구에서 어닐링은 결정립을 키워 박막의 전도도를 높인다고 보고되었다 [1].
  - 인용 1: [1] H. Kim et al., Journal of Thin Film Tests 12, 34 (2024). (가상 문헌)
- p.1 문장 5 [주장 아님(제목·설명 등)]: 2.
- p.1 문장 6 [주장 아님(제목·설명 등)]: 방법
- p.1 문장 7 [주장 아님(제목·설명 등)]: 조건별로 독립 시료 10개를 만들고, 시료마다 위치 7개에서 -0.5 V부터 0.5 V까지 I-V를 측정했다.
- p.1 문장 8 [주장 아님(제목·설명 등)]: 위치별 전도도는 I-V 직선의 기울기로 구하고, 시료 전도도는 위치 7개의 평균으로 했다.
- p.1 문장 9 [주장 아님(제목·설명 등)]: 3.
- p.1 문장 10 [주장 아님(제목·설명 등)]: 결과
- p.1 문장 14 [수치와 연결되지 않는 정성 문장]: 어닐링한 막의 표면은 육안으로 균일하게 형성되었다.
- p.1 문장 16 [주장 아님(제목·설명 등)]: 4.
- p.1 문장 17 [주장 아님(제목·설명 등)]: 결론

## 수정 후 재평가 (이전 실행 `20260930T194413403988-7f7761` 대비)

### E07 데이터 버전 변경 (기록)

- 데이터 변경 없음
- 한계: 첫 실행 이전에 삭제·수정된 데이터는 알 수 없음 (판정 범위 밖)

### 판정 변화

| 원문 | 이전 | 이번 | 변화 |
|---|---|---|---|
| 어닐링 시료의 평균 전도도는 12.1 | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| 우리 어닐링 시료의 값 12.1 nS | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| ± 0.7 nS | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| 각 n = 10 | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| 어닐링 후 전도도는 대조 시료보다 23 % 높았다 | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| 어닐링은 박막의 전도도를 크게 증가시켰다 | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| 이 차이는 통계적으로 유의했다(t(18) = 6.05, p < 0.001) | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |
| t(18) = 6.05 | Supported ['E07'] | Unsupported ['E03'] | 판정 변화 |

- 기록(E02 진행·E07 등)만 달라진 주장 4건 · 변화 없는 주장 0건 — 목록은 `audit_result.json` 의 `rerun.verdicts`
