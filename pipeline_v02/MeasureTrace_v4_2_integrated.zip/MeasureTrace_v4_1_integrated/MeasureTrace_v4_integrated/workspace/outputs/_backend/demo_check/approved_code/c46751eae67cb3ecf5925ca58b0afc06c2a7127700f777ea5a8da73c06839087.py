# MeasureTrace 인계 코드 (bridge-v1) — 3-1 승인 본문(sha256 68813231524d3854fea3ff20b1edf93a57a58974553f06fe7d7c641371de1e7e) + 뒷단 규약 어댑터
# 승인 본문: 테스터 · 2026-09-30T19:44:13+09:00

# ==== 3-1 승인 본문 시작 ====
import csv
import math
import statistics
import os.path
from scipy import stats


# 조건 코드 매핑: 계획서 2절 (어닐링 A, 대조 C)
# condition 열 값 / 폴더명이 'annealed' 이면 A, 'control' 이면 C 로 본다.
def _condition_code(cond_text, path):
    t = (cond_text or "").strip().lower()
    if t in ("annealed", "a", "anneal"):
        return "A"
    if t in ("control", "c", "ctrl"):
        return "C"
    p = path.replace("\\", "/").lower()
    if "annealed" in p:
        return "A"
    if "control" in p:
        return "C"
    # TODO(확인 필요): 조건 표기가 위 목록과 다르면 원문 그대로 반환
    return t or "UNKNOWN"


def _to_float(s):
    if s is None:
        return None
    s = s.strip()
    if s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _slope(vs, cs):
    """EQ01: 최소제곱 직선의 기울기 = sum((V-Vbar)(I-Ibar)) / sum((V-Vbar)^2)"""
    n = len(vs)
    if n < 2:
        return None
    vbar = sum(vs) / n
    cbar = sum(cs) / n
    num = 0.0
    den = 0.0
    for v, c in zip(vs, cs):
        dv = v - vbar
        num += dv * (c - cbar)
        den += dv * dv
    if den == 0.0:
        return None
    return num / den


def compute(files: dict[str, str]) -> dict:
    # ---------------- 1) 원자료 읽기 (계획서 5절 처리단계 1) ----------------
    # 구조: samples[sample_id] = {"condition": 'A'/'C', "positions": {pos: ([V], [I])}}
    samples = {}
    oor_records = []  # 장비 10 nA 범위 이탈 기록 (자동 제외하지 않음, 기록만)
    # TODO(확인 필요): 10 nA 범위의 이탈 판정 기준을 |I| > 10e-9 A 로 가정함
    #                  (instrument_spec.pdf 의 구체 한계/정확도 수치 미확인)
    OOR_LIMIT_A = 10e-9

    for rel_path in sorted(files.keys()):
        if not rel_path.lower().endswith(".csv"):
            continue
        real_path = files[rel_path]
        with open(real_path, "r", newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                sid = (row.get("sample_id") or "").strip()
                pos = (row.get("position") or "").strip()
                v = _to_float(row.get("voltage_V"))
                i_a = _to_float(row.get("current_A"))
                if sid == "" or pos == "":
                    continue
                if v is None or i_a is None:
                    # 값이 비어 있는 행은 계산에 쓸 수 없음 (이상치 제외가 아니라 결측)
                    continue
                code = _condition_code(row.get("condition"), rel_path)
                rec = samples.setdefault(
                    sid, {"condition": code, "positions": {}, "path": rel_path}
                )
                vs_is = rec["positions"].setdefault(pos, ([], []))
                vs_is[0].append(v)
                vs_is[1].append(i_a)
                if abs(i_a) > OOR_LIMIT_A:
                    oor_records.append(
                        {"sample_id": sid, "position": pos,
                         "voltage_V": v, "current_A": i_a}
                    )

    # ---------------- 2) EQ01: 위치별 전도도 G_ij ----------------
    # TODO(확인 필요): 계획서 EQ01 은 k=1~11 (11점) 고정이지만 일부 파일은 행 수가
    #                  74~77 로 점이 부족할 수 있다. 결측 규칙이 계획서에 없어
    #                  여기서는 '해당 위치에 존재하는 점만으로 최소제곱 기울기'를
    #                  계산하였다.
    # TODO(확인 필요): 점 수가 11 미만인 위치를 EQ03 평균에 포함할지 여부도
    #                  계획서에 없어, 여기서는 포함(존재하는 위치 수로 평균)하였다.
    G_ij = {}          # (sample_id, position) -> G [S]
    R_ij = {}          # EQ02 참고값 (보고에는 사용하지 않음)
    n_points_per_pos = {}
    for sid, rec in samples.items():
        for pos, (vs, cs) in rec["positions"].items():
            g = _slope(vs, cs)
            n_points_per_pos["%s|%s" % (sid, pos)] = len(vs)
            if g is None:
                continue
            G_ij[(sid, pos)] = g
            if g != 0.0:
                R_ij["%s|%s" % (sid, pos)] = 1.0 / g  # EQ02

    # ---------------- 3) EQ03: 시료 전도도 G_i (위치 평균) ----------------
    G_i = {}
    n_pos_used = {}
    for sid, rec in samples.items():
        gs = [G_ij[(sid, pos)] for pos in sorted(rec["positions"].keys())
              if (sid, pos) in G_ij]
        n_pos_used[sid] = len(gs)
        if len(gs) == 0:
            continue
        G_i[sid] = sum(gs) / len(gs)

    # ---------------- 4) EQ04, EQ05: 조건별 평균/표본 표준편차 ----------------
    by_cond = {"A": [], "C": []}
    sid_by_cond = {"A": [], "C": []}
    for sid in sorted(G_i.keys()):
        code = samples[sid]["condition"]
        if code in by_cond:
            by_cond[code].append(G_i[sid])
            sid_by_cond[code].append(sid)

    NS = 1e9  # S -> nS (계획서 7절 보고 단위)

    mean_S = {}
    sd_S = {}
    n_c = {}
    for code in ("A", "C"):
        vals = by_cond[code]
        n_c[code] = len(vals)
        mean_S[code] = (sum(vals) / len(vals)) if len(vals) > 0 else float("nan")   # EQ04
        sd_S[code] = statistics.stdev(vals) if len(vals) > 1 else float("nan")      # EQ05

    nA = n_c["A"]
    nC = n_c["C"]

    # ---------------- 5) EQ06: 합동 표준편차 ----------------
    if nA > 1 and nC > 1:
        s_p = math.sqrt(
            ((nA - 1) * sd_S["A"] ** 2 + (nC - 1) * sd_S["C"] ** 2) / (nA + nC - 2)
        )
    else:
        s_p = float("nan")

    # ---------------- 6) EQ07: 독립 2표본 t 통계량, 자유도, 양측 p값 ----------------
    df = nA + nC - 2
    if s_p and not math.isnan(s_p) and s_p != 0.0 and nA > 0 and nC > 0:
        t_stat = (mean_S["A"] - mean_S["C"]) / (s_p * math.sqrt(1.0 / nA + 1.0 / nC))
    else:
        t_stat = float("nan")
    if df > 0 and not math.isnan(t_stat):
        p_value = float(2.0 * stats.t.sf(abs(t_stat), df))  # 양측, alpha=0.05
    else:
        p_value = float("nan")

    # ---------------- 7) EQ08: 증가율(%) ----------------
    if mean_S["C"] not in (0.0,) and not math.isnan(mean_S["C"]):
        delta_G_pct = (mean_S["A"] - mean_S["C"]) / mean_S["C"] * 100.0
    else:
        delta_G_pct = float("nan")

    # ---------------- 8) 결과 정리 (nS 환산) ----------------
    results = [
        {"name": "조건 평균 전도도 (어닐링)", "symbol": "G_A_bar",
         "value": mean_S["A"] * NS, "unit": "nS", "eq_id": "EQ04", "condition": "annealed"},
        {"name": "조건 표본 표준편차 (어닐링)", "symbol": "s_A",
         "value": sd_S["A"] * NS, "unit": "nS", "eq_id": "EQ05", "condition": "annealed"},
        {"name": "조건 시료 수 (어닐링)", "symbol": "n_A",
         "value": float(nA), "unit": "개", "eq_id": "EQ04", "condition": "annealed"},
        {"name": "조건 평균 전도도 (대조)", "symbol": "G_C_bar",
         "value": mean_S["C"] * NS, "unit": "nS", "eq_id": "EQ04", "condition": "control"},
        {"name": "조건 표본 표준편차 (대조)", "symbol": "s_C",
         "value": sd_S["C"] * NS, "unit": "nS", "eq_id": "EQ05", "condition": "control"},
        {"name": "조건 시료 수 (대조)", "symbol": "n_C",
         "value": float(nC), "unit": "개", "eq_id": "EQ04", "condition": "control"},
        {"name": "합동 표준편차", "symbol": "s_p",
         "value": s_p * NS, "unit": "nS", "eq_id": "EQ06", "condition": None},
        {"name": "t 통계량 (독립 2표본, 등분산)", "symbol": "t",
         "value": t_stat, "unit": "무차원", "eq_id": "EQ07", "condition": None},
        {"name": "자유도", "symbol": "df",
         "value": float(df), "unit": "무차원", "eq_id": "EQ07", "condition": None},
        {"name": "양측 p값 (alpha=0.05)", "symbol": "p",
         "value": p_value, "unit": "무차원", "eq_id": "EQ07", "condition": None},
        {"name": "어닐링에 따른 전도도 증가율", "symbol": "dG",
         "value": delta_G_pct, "unit": "%", "eq_id": "EQ08", "condition": None},
    ]

    # ---------------- 중간값 ----------------
    intermediate = {
        "G_ij_nS": {"%s|%s" % (sid, pos): G_ij[(sid, pos)] * NS
                    for (sid, pos) in sorted(G_ij.keys())},
        "G_i_nS": {sid: G_i[sid] * NS for sid in sorted(G_i.keys())},
        "R_ij_ohm_reference": R_ij,  # EQ02 참고값 (보고 미사용)
        "samples_annealed": sid_by_cond["A"],
        "samples_control": sid_by_cond["C"],
        "G_i_nS_annealed": [v * NS for v in by_cond["A"]],
        "G_i_nS_control": [v * NS for v in by_cond["C"]],
        "n_points_per_position": n_points_per_pos,
        "n_positions_used_per_sample": n_pos_used,
        "out_of_range_records_10nA": oor_records,
        "out_of_range_count_10nA": len(oor_records),
        "n_files_read": len([k for k in files if k.lower().endswith(".csv")]),
        "alpha": 0.05,
    }

    return {"results": results, "intermediate": intermediate}
# ==== 3-1 승인 본문 끝 ====


# ==== 뒷단 규약 어댑터 (bridge 가 자동 생성 — 위 승인 본문은 호출만 한다) ====
# 규약: def mt_compute(data: dict[str, DataFrame], params: dict)
#         -> {"outputs": {결과 id: 숫자}, "steps": [...], "meta": {"results": [...], "intermediate": {...}}}
# 승인 본문의 compute(files) 에는 해시를 확인한 RAW 실행 사본 경로를 {실험 폴더 기준 상대 경로: 사본 경로} 로 넘긴다.
# 4단계 탐색 실행(discover): 결과를 전부 보고한다. 결과 id 는 기호(없으면 이름)로 만들고 겹치면 _2, _3 … 을 붙인다.
# 어떤 결과를 판정에 쓸지는 5·6 직전에 사람이 승인하는 항목 목록이 정한다(뒷단 bind_outputs).
import re as mt_re


def mt_slug(text):
    s = mt_re.sub(r"[^0-9A-Za-z_.-]+", "_", "" if text is None else str(text)).strip("_.-")
    return s if s and s[0].isalnum() else ""


def mt_compute(data, params):
    paths = params["data_paths"]
    files = {}
    for data_id, frame in data.items():
        files[paths[data_id]] = frame.attrs["source_path"]
    result = compute(files)
    outputs, rows, used = {}, [], set()
    for row in result.get("results") or []:
        if not isinstance(row, dict):
            continue
        base = mt_slug(row.get("symbol")) or mt_slug(row.get("name")) or "r"
        oid, k = base, 2
        while oid in used:
            oid = base + "_" + str(k)
            k += 1
        used.add(oid)
        outputs[oid] = row.get("value")
        rows.append({"id": oid, "name": row.get("name"), "symbol": row.get("symbol"), "unit": row.get("unit"),
                     "condition": row.get("condition"), "eq_id": row.get("eq_id")})
    steps = []
    for name, value in (result.get("intermediate") or {}).items():
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            steps.append({"name": str(name), "value": value})
        elif isinstance(value, dict):
            for sub, x in list(value.items())[:200]:
                if isinstance(x, (int, float)) and not isinstance(x, bool):
                    steps.append({"name": str(name) + "." + str(sub), "value": x})
    return {"outputs": outputs, "steps": steps,
            "meta": {"results": rows, "intermediate": result.get("intermediate") or {}}}
