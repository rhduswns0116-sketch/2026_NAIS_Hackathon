import csv
import math
import statistics
from collections import OrderedDict, defaultdict

try:
    from scipy import stats as _scipy_stats
except Exception:  # pragma: no cover
    _scipy_stats = None


def _slope_least_squares(vs, is_):
    """EQ01: 평균 중심화 형태의 최소제곱 기울기 (절편 포함 단순선형회귀와 동일)."""
    n = len(vs)
    vbar = sum(vs) / n
    ibar = sum(is_) / n
    num = 0.0
    den = 0.0
    for v, i in zip(vs, is_):
        num += (v - vbar) * (i - ibar)
        den += (v - vbar) ** 2
    if den == 0.0:
        return float("nan")
    return num / den


def compute(files: dict) -> dict:
    # ------------------------------------------------------------------
    # 1단계: 파일 읽기 -> 시료 x 위치별 (V_k, I_ijk) 세트 구성
    # ------------------------------------------------------------------
    # data[sample_id][position] = list of (voltage_V, current_A)
    data = OrderedDict()
    sample_condition = OrderedDict()

    for rel_path in sorted(files.keys()):
        if not rel_path.lower().endswith(".csv"):
            continue
        real_path = files[rel_path]
        with open(real_path, "r", newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                sid = (row["sample_id"] or "").strip()
                cond_raw = (row["condition"] or "").strip()
                pos = (row["position"] or "").strip()
                v_txt = (row["voltage_V"] or "").strip()
                i_txt = (row["current_A"] or "").strip()
                if sid == "" or pos == "" or v_txt == "" or i_txt == "":
                    # TODO(확인 필요): 결측 행 처리 방법이 계획서에 없음. 여기서는 건너뜀.
                    continue
                try:
                    v = float(v_txt)
                    cur = float(i_txt)
                except ValueError:
                    # TODO(확인 필요): 숫자로 변환 불가한 값의 처리 방법이 계획서에 없음.
                    continue
                data.setdefault(sid, OrderedDict()).setdefault(pos, []).append((v, cur))
                sample_condition[sid] = cond_raw

    # 조건 표기 매핑
    # TODO(확인 필요): 파일의 condition 값(annealed/control)과 계획서 표기(A/C)의
    # 매핑 규칙이 명시되지 않아 아래 규칙을 가정함.
    def _map_condition(raw):
        r = raw.strip().lower()
        if r in ("a", "annealed", "anneal", "annealing"):
            return "A"
        if r in ("c", "control", "ctrl", "as-deposited", "as_deposited"):
            return "C"
        return raw.strip()

    # ------------------------------------------------------------------
    # 2~3단계: EQ01 위치별 전도도 G_ij, EQ02 참고용 저항 R_ij
    # ------------------------------------------------------------------
    G_ij = OrderedDict()   # sample -> {position: G [S]}
    R_ij = OrderedDict()   # sample -> {position: R [ohm]} (참고용, 보고하지 않음)
    for sid, pos_map in data.items():
        G_ij[sid] = OrderedDict()
        R_ij[sid] = OrderedDict()
        for pos in sorted(pos_map.keys()):
            pts = sorted(pos_map[pos], key=lambda p: p[0])
            vs = [p[0] for p in pts]
            cs = [p[1] for p in pts]
            g = _slope_least_squares(vs, cs)
            G_ij[sid][pos] = g
            R_ij[sid][pos] = (1.0 / g) if (g == g and g != 0.0) else float("nan")

    # ------------------------------------------------------------------
    # 4단계: EQ03 시료 전도도 G_i = 위치 7개 평균 (독립 단위 값)
    # ------------------------------------------------------------------
    G_i = OrderedDict()
    for sid, pmap in G_ij.items():
        vals = [pmap[p] for p in sorted(pmap.keys())]
        G_i[sid] = sum(vals) / len(vals)

    # 조건별 시료값 모으기
    by_cond = defaultdict(list)          # cond -> [G_i]
    by_cond_samples = defaultdict(list)  # cond -> [sample_id]
    for sid in sorted(G_i.keys()):
        c = _map_condition(sample_condition.get(sid, ""))
        by_cond[c].append(G_i[sid])
        by_cond_samples[c].append(sid)

    # ------------------------------------------------------------------
    # 5단계: EQ04 조건 평균, EQ05 조건 표본 표준편차 (n-1)
    # ------------------------------------------------------------------
    NS = 1e9  # S -> nS (보고 단위)
    results = []
    means = {}
    sds = {}
    ns = {}
    cond_labels = {"A": "annealed (A)", "C": "control (C)"}

    for c in sorted(by_cond.keys()):
        vals = by_cond[c]
        n = len(vals)
        m = sum(vals) / n                                   # EQ04
        if n > 1:
            s = math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1))  # EQ05
        else:
            s = float("nan")
        means[c] = m
        sds[c] = s
        ns[c] = n
        label = cond_labels.get(c, c)
        results.append({
            "name": "조건 평균 전도도",
            "symbol": "G_%s_bar" % c,
            "value": m * NS,
            "unit": "nS",
            "eq_id": "EQ04",
            "condition": label,
        })
        results.append({
            "name": "조건 표준편차",
            "symbol": "s_%s" % c,
            "value": s * NS,
            "unit": "nS",
            "eq_id": "EQ05",
            "condition": label,
        })
        results.append({
            "name": "조건 시료 수",
            "symbol": "n_%s" % c,
            "value": float(n),
            "unit": "개",
            "eq_id": "EQ04",
            "condition": label,
        })

    # ------------------------------------------------------------------
    # 6~8단계: EQ06 합동 표준편차, EQ07 t 검정(df=nA+nC-2), EQ08 증가율
    # ------------------------------------------------------------------
    sp = float("nan")
    t_stat = float("nan")
    df = float("nan")
    p_value = float("nan")
    delta_g = float("nan")

    if "A" in means and "C" in means and ns["A"] > 1 and ns["C"] > 1:
        nA, nC = ns["A"], ns["C"]
        sA, sC = sds["A"], sds["C"]
        sp = math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / (nA + nC - 2))  # EQ06
        t_stat = (means["A"] - means["C"]) / (sp * math.sqrt(1.0 / nA + 1.0 / nC))  # EQ07
        df = float(nA + nC - 2)
        if _scipy_stats is not None:
            # 양측 p값
            p_value = float(2.0 * _scipy_stats.t.sf(abs(t_stat), df))
        if means["C"] != 0.0:
            delta_g = (means["A"] - means["C"]) / means["C"] * 100.0  # EQ08

        results.append({
            "name": "합동 표준편차",
            "symbol": "s_p",
            "value": sp * NS,
            "unit": "nS",
            "eq_id": "EQ06",
            "condition": None,
        })
        results.append({
            "name": "t 통계량",
            "symbol": "t",
            "value": t_stat,
            "unit": "무차원",
            "eq_id": "EQ07",
            "condition": None,
        })
        results.append({
            "name": "자유도",
            "symbol": "df",
            "value": df,
            "unit": "무차원",
            "eq_id": "EQ07",
            "condition": None,
        })
        results.append({
            "name": "p값 (양측)",
            "symbol": "p",
            "value": p_value,
            "unit": "무차원",
            "eq_id": "EQ07",
            "condition": None,
        })
        results.append({
            "name": "전도도 증가율",
            "symbol": "dG",
            "value": delta_g,
            "unit": "%",
            "eq_id": "EQ08",
            "condition": None,
        })

    # ------------------------------------------------------------------
    # 중간값
    # ------------------------------------------------------------------
    intermediate = {}
    intermediate["sample_ids"] = list(G_i.keys())
    intermediate["sample_condition"] = {sid: _map_condition(sample_condition.get(sid, ""))
                                        for sid in G_i.keys()}
    intermediate["G_i_nS"] = {sid: G_i[sid] * NS for sid in G_i.keys()}
    intermediate["G_ij_nS"] = {sid: {p: G_ij[sid][p] * NS for p in sorted(G_ij[sid].keys())}
                               for sid in G_ij.keys()}
    # EQ02: 참고용 저항 (보고에는 사용하지 않음)
    intermediate["R_ij_ohm_reference_only"] = {
        sid: {p: R_ij[sid][p] for p in sorted(R_ij[sid].keys())} for sid in R_ij.keys()
    }
    intermediate["n_points_per_position"] = {
        sid: {p: len(data[sid][p]) for p in sorted(data[sid].keys())} for sid in data.keys()
    }
    intermediate["n_positions_per_sample"] = {sid: len(G_ij[sid]) for sid in G_ij.keys()}
    intermediate["condition_G_by_sample_nS"] = {
        c: [v * NS for v in by_cond[c]] for c in sorted(by_cond.keys())
    }
    intermediate["condition_sample_list"] = {c: by_cond_samples[c] for c in sorted(by_cond_samples.keys())}
    intermediate["alpha"] = 0.05
    # 이상치 자동 제외 없음(계획서 8항). 장비 10 nA 범위 참고용 초과 건수만 집계.
    # TODO(확인 필요): 범위 초과 판정 기준(정확도/오버레인지 규칙)이 명시되지 않아
    # |I| > 10e-9 A 를 단순 참고 지표로만 계산함(계산에서 제외하지 않음).
    over = {}
    for sid, pmap in data.items():
        cnt = 0
        for p, pts in pmap.items():
            for v, cur in pts:
                if abs(cur) > 10e-9:
                    cnt += 1
        over[sid] = cnt
    intermediate["count_abs_current_over_10nA_reference"] = over

    return {"results": results, "intermediate": intermediate}
