"""범용성 회귀 시험 — ex2(메조코즘: 시료가 파일이 아닌 표의 행, 연속 변수 설계)에서 드러난 규칙. LLM 을 부르지 않는다."""
from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from measuretrace.bridge import _overlapping, output_kind  # noqa: E402
from measuretrace.extract.missing import compare  # noqa: E402


class RowSamplesTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        (self.tmp / "gradients.csv").write_text("Tank,NEP\n1,70.1\n2,80.2\n4.0,90.3\n", encoding="utf-8")
        (self.tmp / "cover.csv").write_text("Tank,mnChara\n1,3\n2,5\n4,0\n", encoding="utf-8")
        self.files = [("raw/gradients.csv", self.tmp / "gradients.csv"), ("raw/cover.csv", self.tmp / "cover.csv")]

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_samples_found_as_rows_of_a_shared_table(self):
        req = {"conditions": [{"name": "전체", "samples": ["Tank 1", "Tank 2", "Tank 3", "Tank 4"]}],
               "per_sample": {}, "other_required": []}
        r = compare(req, self.files, Counter())
        self.assertEqual([f["sample"] for f in r["found"]], ["Tank 1", "Tank 2", "Tank 4"])   # 4.0 = 4
        self.assertIn("공유 표의 행", r["found"][0]["note"])
        self.assertEqual([(e["sample"], e["kind"]) for e in r["e03"]], [("Tank 3", "시료 파일 없음")])
        self.assertEqual(r["unlisted_raw_files"], [])

    def test_bare_number_needs_a_matching_column_name(self):
        # 숫자만인 시료 표기는 어느 열에나 있을 수 있어 열 이름 없이 인정하지 않는다
        req = {"conditions": [{"name": "c", "samples": ["3"]}], "per_sample": {}, "other_required": []}
        self.assertEqual(len(compare(req, self.files, Counter())["e03"]), 1)


class DesignRulesTest(unittest.TestCase):
    def test_conditions_sharing_samples_are_not_groups(self):
        self.assertTrue(_overlapping([{"samples": ["Tank(37개 수조)"]}, {"samples": ["Tank(37개 수조)"]}]))
        self.assertFalse(_overlapping([{"samples": ["S1", "S2"]}, {"samples": ["S3", "S4"]}]))

    def test_ratio_kind_only_between_groups(self):
        self.assertEqual(output_kind({"name": "교란 비율 평균"}, 2), "value")
        self.assertEqual(output_kind({"name": "교란 비율 이차 회귀 이차항 계수"}, 2), "value")
        self.assertEqual(output_kind({"name": "어닐링 대비 대조 비율"}, 1), "value")
        self.assertEqual(output_kind({"name": "어닐링 대비 대조 비율"}, 2), "ratio")


class UnitCarryTest(unittest.TestCase):
    """리뷰 피드백: 이전 실행의 확정 단위는 근거(그 열이 든 RAW 파일 내용·헤더)가 같을 때만 이어받는다."""

    @staticmethod
    def _snap(content: str) -> dict:
        return {"files": [{"path": "raw/a.csv", "sha256": "s", "content_hash": content},
                          {"path": "raw/b.csv", "sha256": "t", "content_hash": "B"}]}

    def _prev(self, evidence: dict | None) -> dict:
        ov = {"units": {"NEP": "무차원", "Block": "번호"}}
        if evidence is not None:
            ov["unit_evidence"] = evidence
        return {"overrides": ov}

    def test_same_evidence_carries_changed_content_asks_again(self):
        from measuretrace.confirm.run import _carry_units, _unit_evidence
        ex = {"checks": {"e01": [{"column": "NEP", "files": ["raw/a.csv"], "header_unit": None}]}}
        ev = {"NEP": _unit_evidence(self._snap("A1"), ["raw/a.csv"], None)}
        units, evidence, notes = _carry_units(self._prev(ev), ex, self._snap("A1"))
        self.assertEqual(units, {"NEP": "무차원"})           # Block 은 이번에 물을 필요가 없는 열이라 이어받지 않음
        self.assertEqual(evidence, ev)
        self.assertEqual(notes, [])
        units, _, notes = _carry_units(self._prev(ev), ex, self._snap("A2"))     # 같은 열 이름, 파일 내용이 바뀜
        self.assertEqual(units, {})
        self.assertTrue(notes and "내용이 바뀜" in notes[0] and "무차원" in notes[0])

    def test_legacy_state_without_evidence_asks_again(self):
        from measuretrace.confirm.run import _carry_units
        ex = {"checks": {"e01": [{"column": "NEP", "files": ["raw/a.csv"], "header_unit": None}]}}
        units, _, notes = _carry_units(self._prev(None), ex, self._snap("A1"))
        self.assertEqual(units, {})
        self.assertTrue(notes and "근거가 없음" in notes[0])


class CorruptOutputTest(unittest.TestCase):
    """한글이 '\\f'+'f' 로 깨진 응답은 캐시하지 않고 한 번 다시 부른다. 캐시에 남은 깨진 응답은 쓰지 않는다."""

    def setUp(self):
        from unittest import mock
        from measuretrace import llm
        self.llm, self.tmp = llm, Path(tempfile.mkdtemp())
        self.patches = [mock.patch.object(llm, "CACHE_DIR", self.tmp / "cache"),
                        mock.patch.object(llm, "AUDIT_LOG", self.tmp / "audit.jsonl")]
        for p in self.patches:
            p.start()

    def tearDown(self):
        for p in self.patches:
            p.stop()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _client(self, answers):
        from unittest import mock
        c = self.llm.LLM(client=object(), model="m", offline=False)
        seq = iter(answers)
        c._call = mock.Mock(side_effect=lambda *a, **k: ({"name": next(seq)}, {"request_id": "r"}, "t"))
        return c

    def test_retry_once_and_cache_only_clean(self):
        c = self._client(["\x0cf\x0cf", "유효 다양도"])
        data, meta = c.json("k", "s", "u", {"type": "object"})
        self.assertEqual(data, {"name": "유효 다양도"})
        self.assertEqual(c._call.call_count, 2)
        self.assertEqual(self._client(["x"]).json("k", "s", "u", {"type": "object"})[0], data)   # 캐시

    def test_two_corrupt_answers_fail(self):
        c = self._client(["\x0cf", "\x0cf"])
        with self.assertRaises(self.llm.LLMError):
            c.json("k", "s", "u", {"type": "object"})
        self.assertFalse(any((self.tmp / "cache").glob("*.json")) if (self.tmp / "cache").exists() else False)


if __name__ == "__main__":
    unittest.main()
