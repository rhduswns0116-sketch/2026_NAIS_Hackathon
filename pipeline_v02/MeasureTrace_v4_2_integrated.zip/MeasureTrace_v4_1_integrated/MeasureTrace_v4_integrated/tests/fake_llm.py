"""가짜 LLM 클라이언트 — 실제 API 없이 2 EXTRACT 배선을 시험한다(토큰 0). 데모 자료에 맞춘 고정 답을 돌려준다.

보낸 요청은 self.requests 에 남는다 → R2(측정값을 보내지 않음) 시험에 쓴다.
"""
from __future__ import annotations

import json
from types import SimpleNamespace

FAKE_CODE = '''import csv
import numpy as np


def compute(files):
    by = {}
    for path in files.values():
        with open(path, newline="", encoding="utf-8-sig") as fh:
            for row in csv.DictReader(fh):
                by.setdefault(row["condition"], []).append(float(row["current_A"]))
    results = [{"name": "평균 전류", "symbol": "I", "value": float(np.mean(v)), "unit": "A", "eq_id": "EQ00", "condition": c}
               for c, v in sorted(by.items())]
    return {"results": results, "intermediate": {"n": {c: len(v) for c, v in by.items()}}}
'''
SAMPLES_A = [f"S{i:02d}" for i in range(1, 11)]
SAMPLES_C = [f"S{i:02d}" for i in range(11, 21)]
POS = [f"P{j}" for j in range(1, 8)]


def answer(schema: dict) -> dict:
    req = set(schema.get("required", []))
    if "row_keys" in req:   # 2-1a
        return {"measurement": "시료·위치별 I–V 스윕", "layout": "long", "row_keys": ["sample_id", "position", "voltage_V"],
                "questions": [], "columns": [
                    {"name": "sample_id", "role": "sample_id", "quantity": "", "unit_in_header": "", "unit_guess": "", "meaning": "시료"},
                    {"name": "condition", "role": "condition", "quantity": "", "unit_in_header": "", "unit_guess": "", "meaning": "조건"},
                    {"name": "position", "role": "replicate", "quantity": "", "unit_in_header": "", "unit_guess": "", "meaning": "위치"},
                    {"name": "voltage_V", "role": "independent_variable", "quantity": "전압", "unit_in_header": "V", "unit_guess": "", "meaning": "인가 전압"},
                    {"name": "current_A", "role": "measured_value", "quantity": "전류", "unit_in_header": "A", "unit_guess": "", "meaning": "측정 전류"}]}
    if "overflow_values" in req:   # 2-2
        return {"instrument": "MT-SMU 2400", "questions": [], "entries": [
            {"quantity": "current", "dimension": "current", "range_label": "10 nA", "min": None, "max": 10.5, "unit": "nA",
             "resolution": "10 fA", "accuracy": "0.10 % + 50 pA", "condition": "1 year", "page": 1,
             "quote": "10 nA 10 fA 0.10 % + 50 pA 10.5 nA"},
            {"quantity": "current", "dimension": "current", "range_label": "10 nA (valid)", "min": -10.5, "max": 10.5,
             "unit": "nA", "resolution": "", "accuracy": "", "condition": "", "page": 2,
             "quote": "Valid current readings on the 10 nA range: -10.5 nA to +10.5 nA."}],
            "overflow_values": [{"value": 9.9e37, "meaning": "overflow", "page": 2,
                                 "quote": "Out-of-range readings are reported as the overflow value 9.9E37."}]}
    if "per_sample" in req:   # 2-4
        return {"conditions": [{"name": "annealed", "samples": SAMPLES_A, "source_quote": "A: S01–S10"},
                               {"name": "control", "samples": SAMPLES_C, "source_quote": "C: S11–S20"}],
                "file_naming": "raw/<조건>/<시료>.csv",
                "per_sample": {"id_column": "position", "expected_ids": POS, "points_per_id": 11, "rows_per_file": 77,
                               "source_quote": "위치 7개 × 11점 = 77행"},
                "other_required": [{"what": "장비 사양서", "kind": "spec"}], "questions": []}
    if "explanation" in req:   # 2-1c ② 코드 — 파일을 실제로 읽어 조건별 전류 평균을 낸다(격리 실행 시험용)
        return {"code": FAKE_CODE, "explanation": "가짜 — 조건별 평균 전류"}
    if "summary" in req:   # 2-1c ① 연구 내용
        return {"summary": "가짜 응답", "formulas": [], "processing": [], "reported_quantities": [], "questions": [],
                "design": {"conditions": [], "independent_unit": "시료", "technical_replicate": "위치",
                           "replicates_per_unit": 7, "points_per_replicate": 11, "degrees_of_freedom": 18, "source_quote": ""},
                "test": {"present": True, "method": "독립 2표본 t", "alternative": "양측", "alpha": 0.05, "eq_ids": ["EQ07"], "source_quote": ""},
                "matching": [{"experiment": "I–V", "data_group": "G1", "data_columns": ["voltage_V", "current_A"],
                              "eq_ids": ["EQ01"], "instrument": "MT-SMU 2400", "instrument_range": "10 nA", "outputs": ["G_ij"]}]}
    raise ValueError("모르는 스키마")


class _Stream:
    def __init__(self, text):
        self.text = text

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def get_final_message(self):
        return SimpleNamespace(content=[SimpleNamespace(type="text", text=self.text)], stop_reason="end_turn",
                               usage=SimpleNamespace(input_tokens=0, output_tokens=0), model="fake", id="fake")


class FakeClient:
    def __init__(self):
        self.requests = []
        self.beta = SimpleNamespace(messages=SimpleNamespace(stream=self._stream))

    def _stream(self, **kw):
        self.requests.append(kw)
        return _Stream(json.dumps(answer(kw["output_config"]["format"]["schema"]), ensure_ascii=False))
