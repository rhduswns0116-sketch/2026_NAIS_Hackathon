"""1 INGEST · 2 EXTRACT 회귀 시험 — 가짜 LLM(토큰 0), 임시 작업 폴더.

  python -m unittest discover -s tests
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from fake_llm import FakeClient  # noqa: E402
from measuretrace import bridge, ledger, llm  # noqa: E402
from measuretrace.extract import run as extract_run  # noqa: E402
from measuretrace.ingest import run as ingest_run, workspace  # noqa: E402

DEMO = ROOT / "tests" / "demo"


class PipelineTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not (DEMO / "annealing_demo").exists():
            import make_demo  # noqa: F401 — tests/demo 에 있음
        cls.tmp = Path(tempfile.mkdtemp())
        ws = cls.tmp / "workspace"
        cls.patches = [
            mock.patch.object(workspace, "INPUTS_DIR", ws / "inputs"),
            mock.patch.object(workspace, "OUTPUTS_DIR", ws / "outputs"),
            mock.patch.object(extract_run, "OUTPUTS_DIR", ws / "outputs"),
            mock.patch.object(ledger, "LEDGER_PATH", ws / "outputs" / "lineage.jsonl"),
            # 4단계는 bridge.run_step4 → 뒷단 실행(outputs/_backend/...) — 실제 workspace 에 쓰지 않게
            mock.patch.object(bridge, "OUTPUTS_DIR", ws / "outputs"),
            mock.patch.object(llm, "CACHE_DIR", ws / "llm_cache"),
            mock.patch.object(llm, "AUDIT_LOG", ws / "outputs" / "llm_audit.jsonl"),
        ]
        for p in cls.patches:
            p.start()

    @classmethod
    def tearDownClass(cls):
        for p in cls.patches:
            p.stop()
        for f in cls.tmp.rglob("*"):
            if f.is_file():
                f.chmod(0o666)
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def ingest(self, folder: Path, project: str) -> dict:
        rid = workspace.new_run()
        for zone in ("data", "report"):
            for p in sorted((folder / zone).rglob("*")):
                if p.is_file():
                    with p.open("rb") as f:
                        workspace.save_upload(rid, zone, p.relative_to(folder / zone).as_posix(), f, p.stat().st_size)
        return ingest_run.run_ingest(rid, project)

    def test_ingest_then_extract_and_rerun(self):
        first = self.ingest(DEMO / "annealing_demo", "t")
        self.assertEqual(first["counts"]["raw"], 20)
        self.assertEqual(first["counts"]["plan"], 1)
        self.assertTrue(all(c["ok"] is not False for c in first["checks"]))
        client = FakeClient()
        ex = extract_run.run_extract(first["run_id"], llm.LLM(client=client, model="fake"))
        self.assertTrue(all(s["status"] == "ok" for s in ex["steps"].values()), ex["steps"])
        self.assertEqual(ex["counts"]["equations"], 8)
        self.assertEqual(ex["counts"]["E03"], 0)
        # R2: LLM 에 보낸 글에 전류 측정값(…e-09)이 없어야 한다
        sent = json.dumps([r["messages"] for r in client.requests], ensure_ascii=False)
        self.assertNotIn("e-09", sent)
        # R4: 보고서 파일 이름·내용이 LLM 입력에 없어야 한다
        self.assertNotIn("final_report_draft", sent)

        second = self.ingest(DEMO / "annealing_demo_rerun", "t")
        kinds = {c["file"]: c["kind"] for c in second["changes"]}
        self.assertEqual(kinds["data/raw/annealed/S07.csv"], "내용 변경")
        self.assertEqual(kinds["data/raw/control/S12.csv"], "형식만 변경")
        ex2 = extract_run.run_extract(second["run_id"], llm.LLM(client=FakeClient(), model="fake"))
        e03 = ex2["missing"]["comparison"]["e03"]
        self.assertEqual([(e["sample"], e["kind"]) for e in e03], [("S07", "측정점 부족")])

    def _extracted(self, folder: Path, project: str) -> str:
        r = self.ingest(folder, project)
        extract_run.run_extract(r["run_id"], llm.LLM(client=FakeClient(), model="fake"))
        return r["run_id"]

    def test_confirm_rounds_finalize_and_reuse(self):
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._extracted(DEMO / "annealing_demo", "c")
            v = confirm.start(rid)
            req = [i for i in v["items"] if i["required"]]
            self.assertTrue(req and all(i["status"] == "pending" for i in req))
            with self.assertRaises(ValueError):          # 응답자 없음
                confirm.submit(rid, "", {req[0]["id"]: {"choice": "approve"}})
            with self.assertRaises(ValueError):          # 수정인데 글 없음
                confirm.submit(rid, "tester", {"3-1:design": {"choice": "correct"}})
            # 1회: 설계만 수정, 사양 하나 수정, 나머지 승인 → EXTRACT 재실행, 설계는 다시 물음
            spec_id = next(i["id"] for i in req if i["kind"] == "spec")
            answers = {i["id"]: {"choice": "proceed" if "proceed" in i["inputs"] else "approve"} for i in req}
            answers["3-1:design"] = {"choice": "correct", "text": "기술적 반복은 위치 7개"}
            answers[spec_id] = {"choice": "correct", "fields": {"max": "11", "unit": "nA"}, "text": "시험"}
            v = confirm.submit(rid, "tester", answers, llm=llm.LLM(client=FakeClient(), model="fake"))
            self.assertEqual(v["round"], 1)
            self.assertTrue(v["rounds"][0]["extract_rerun"])
            by = {i["id"]: i for i in v["items"]}
            self.assertEqual(by["3-1:design"]["status"], "pending")
            self.assertEqual(by[spec_id]["status"], "corrected_applied")
            self.assertEqual(by["3-1:code"]["status"], "approved")
            self.assertEqual(v["status"], "open")
            # 2회: 설계 승인 → 완료, 코드 해시 고정
            v = confirm.submit(rid, "tester", {"3-1:design": {"choice": "approve"}})
            self.assertEqual(v["status"], "complete")
            self.assertTrue(v["confirmed"]["code"]["sha256"])
            base = workspace.OUTPUTS_DIR / "c" / rid / "confirm"
            self.assertTrue((base / "confirmed.json").exists())
            self.assertEqual(len((base / "answers.jsonl").read_text(encoding="utf-8").splitlines()), len(answers) + 1)
            # 재실행(S07 3행 적음): 같은 제안은 이어받고, 누락 항목만 다시 묻고, 코드는 재사용
            rid2 = self._extracted(DEMO / "annealing_demo_rerun", "c")
            v2 = confirm.start(rid2)
            by2 = {i["id"]: i for i in v2["items"]}
            self.assertEqual(by2["3-1:code"]["status"], "approved")
            self.assertEqual(by2["3-1:missing"]["status"], "pending")
            self.assertEqual(by2["3-1:eq:EQ01"]["carried_from"], rid)

    def test_confirm_three_rounds_then_unresolved(self):
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._extracted(DEMO / "annealing_demo", "u")
            v = confirm.start(rid)
            eqs = [i["id"] for i in v["items"] if i["kind"] == "equation"]
            for n in range(3):
                v = confirm.submit(rid, "tester", {eqs[n]: {"choice": "approve"}})
            self.assertEqual(v["status"], "closed")
            # 답한 식 3개는 승인, 코드는 같은 입력의 승인 코드가 있으면 재사용 승인, 나머지 필수 항목은 미확정
            for i in v["items"]:
                if i["required"] and i["id"] not in eqs[:3] and not (i["id"] == "3-1:code" and i.get("carried_from")):
                    self.assertEqual(i["status"], "unresolved", i["id"])
            self.assertTrue(v["confirmed"]["unresolved"])
            with self.assertRaises(ValueError):
                confirm.submit(rid, "tester", {eqs[3]: {"choice": "approve"}})

    def test_unit_confirm_reveals_new_anomalies(self):
        """v4 피드백 예 ②: 단위를 확정하자 사양 범위와 비교되어 새 이상치가 드러남."""
        import fake_llm
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        src = self.tmp / "nounit"
        shutil.copytree(DEMO / "annealing_demo", src)
        for f in (src / "data" / "raw").rglob("*.csv"):
            rows = f.read_text().splitlines()
            body = [",".join(r.split(",")[:4] + [f"{float(r.split(',')[4]) * 1e9:.4f}"]) for r in rows[1:]]
            f.write_bytes(("\n".join([rows[0].replace("current_A", "current")] + body) + "\n").encode())
        orig = fake_llm.answer

        def answer(schema):
            a = orig(schema)
            if "row_keys" in schema.get("required", []):
                a["columns"][4] = {"name": "current", "role": "measured_value", "quantity": "전류",
                                   "unit_in_header": "", "unit_guess": "nA", "meaning": "전류"}
            return a
        with mock.patch.object(fake_llm, "answer", answer), \
                mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._extracted(src, "n")
            v = confirm.start(rid)
            unit = next(i for i in v["items"] if i["kind"] == "unit")
            self.assertFalse(any(i["kind"] == "anomaly" for i in v["items"]))
            with self.assertRaises(ValueError):
                confirm.submit(rid, "tester", {unit["id"]: {"choice": "value", "value": "xyz"}})
            v = confirm.submit(rid, "tester", {unit["id"]: {"choice": "value", "value": "A"}})
            anomalies = [i for i in v["items"] if i["kind"] == "anomaly"]
            self.assertEqual(len(anomalies), 20)                      # 파일 20개 모두 (잘리지 않음)
            self.assertTrue(all(i["proposal"]["count"] == 77 for i in anomalies))
            u = next(i for i in v["items"] if i["id"] == unit["id"])
            self.assertEqual((u["status"], u["answer"]["value"]), ("decided", "A"))

    def _confirmed(self, folder: Path, project: str) -> str:
        from measuretrace import confirm
        rid = self._extracted(folder, project)
        v = confirm.start(rid)
        ans = {i["id"]: {"choice": "proceed" if "proceed" in i["inputs"] else "approve"}
               for i in v["items"] if i["required"] and i["status"] == "pending"}
        if ans:
            confirm.submit(rid, "tester", ans)
        return rid

    def test_recompute_runs_approved_code_and_logs(self):
        import os
        import stat
        from measuretrace.confirm import run as confirm_run
        from measuretrace.recompute import run as rc_run
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR), \
                mock.patch.object(rc_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._confirmed(DEMO / "annealing_demo", "r")
            log = rc_run.run_recompute(rid)
            self.assertEqual(log["status"], "ok", log.get("reason"))
            self.assertTrue(all(c["ok"] for c in log["checks"]))
            self.assertEqual({r["condition"] for r in log["results"]}, {"annealed", "control"})
            self.assertEqual(log["intermediate"]["n"], {"annealed": 770, "control": 770})
            self.assertFalse(log["blind"]["report_opened"])
            self.assertEqual(log["sandbox"]["denied"], [])
            self.assertIsNone(log["e07"]["compared_with"])
            # 승인 뒤 코드가 바뀌면 실행하지 않는다
            code = workspace.OUTPUTS_DIR / "r" / rid / "confirm" / "approved_code.py"
            os.chmod(code, stat.S_IWRITE | stat.S_IREAD)
            code.write_text(code.read_text(encoding="utf-8") + "\n# 몰래 고침\n", encoding="utf-8")
            self.assertEqual(rc_run.run_recompute(rid)["status"], "blocked")
            # 재실행본: E07 로 S07 3행 빠짐 · S12 형식만 변경
            rid2 = self._confirmed(DEMO / "annealing_demo_rerun", "r")
            log2 = rc_run.run_recompute(rid2)
            self.assertEqual(log2["status"], "ok", log2.get("reason"))
            kinds = {c["file"]: c["kind"] for c in log2["e07"]["changes"]}
            self.assertEqual(kinds, {"raw/annealed/S07.csv": "내용 변경", "raw/control/S12.csv": "형식만 변경"})
            s07 = next(c for c in log2["e07"]["changes"] if c["file"].endswith("S07.csv"))
            self.assertEqual(s07["rows"]["rows_removed"], 3)

    def test_recompute_blocks_changed_input(self):
        import os
        import stat
        from measuretrace.confirm import run as confirm_run
        from measuretrace.recompute import run as rc_run
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR), \
                mock.patch.object(rc_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._confirmed(DEMO / "annealing_demo", "b")
            f = workspace.run_dir(rid) / "data" / "raw" / "annealed" / "S01.csv"
            os.chmod(f, stat.S_IWRITE | stat.S_IREAD)
            f.write_text(f.read_text() + "S01,annealed,P1,0.6,1e-9\n")
            log = rc_run.run_recompute(rid)
            self.assertEqual(log["status"], "blocked")
            self.assertIn("바뀜", log["reason"])

    def test_sandbox_blocks_dangerous_code(self):
        # 통합 뒤 실행은 뒷단 엔진 한 곳 — 실행 중 차단(파일 쓰기·네트워크·API 키 없음)은 뒷단 시험이 확인한다
        # (tests/backend: test_approved_python_cannot_access_report_or_mutate_raw, test_sandbox_has_no_api_key).
        # 여기서는 3-1 승인 전 정적 점검이 앞단 규칙과 뒷단 실행기 규칙을 함께 적용하는지 본다.
        from measuretrace.recompute import sandbox
        self.assertTrue(sandbox.static_check("import subprocess\ndef compute(f): return {}"))
        self.assertTrue(sandbox.static_check("import os\ndef compute(f):\n    os.remove('x')\n    return {}"))
        self.assertTrue(sandbox.static_check("def compute(f):\n    open('mt_x.txt', 'w')\n    return {}\n"))
        self.assertEqual(sandbox.static_check("import os\ndef compute(f):\n    return {'b': os.path.basename('a/b')}"), [])
        runner_only = sandbox.static_check("def compute(f):\n    x = []\n    return {'k': x._hidden}\n")
        self.assertTrue(any("실행기 규칙" in p for p in runner_only))   # 뒷단 실행기 규칙(밑줄 속성)도 3-1 에서 막음

    # ── 1~4단계 검토에서 찾은 문제들 (B1~B12) ─────────────────────────────
    def test_review_parsing_and_r2(self):
        from measuretrace.extract import datacheck, headers, tables
        from measuretrace.extract.spec import verify
        from measuretrace.extract.units import parse_unit, unit_in_header
        d = self.tmp / "parse"
        d.mkdir(exist_ok=True)
        (d / "semi.csv").write_bytes("s;voltage_V;current_A\nS1;0,1;1,2e-9\nS1;0,2;2,4e-9\n".encode())
        (d / "cells.csv").write_bytes("sample,current\nS1,5.1 nA\nS1,6.2 nA\n".encode())
        (d / "note.csv").write_bytes("sample,value_V,note\nS1,0.1,측정 이상 12.345 확인\nS2,0.2,ok\n".encode())
        (d / "ids.csv").write_bytes("sample_no,run_id,voltage_V\n1,3,0.1\n2,4,0.2\n".encode())
        (d / "thou.csv").write_bytes('a,b\n"1,234",1\n'.encode())
        t = tables.read_table(d / "semi.csv")                       # B1 소수점 쉼표
        self.assertTrue(t["decimal_comma"])
        self.assertEqual([tables.as_number(r[2], t["decimal_comma"]) for r in t["rows"]], [1.2e-9, 2.4e-9])
        self.assertIsNone(tables.as_number("1,234"))                  # 천 단위는 추측하지 않음
        self.assertEqual(headers.describe_file(d / "cells.csv")["unit_cell_columns"], ["current"])   # B2
        self.assertNotIn("5.1 nA", json.dumps(headers.describe_file(d / "cells.csv"), ensure_ascii=False))
        note = headers.describe_file(d / "note.csv")
        self.assertEqual(note["labels"]["note"], ["ok"])
        self.assertEqual(note["withheld"], 1)
        self.assertIsNone(unit_in_header("sample_no"))               # B3
        self.assertIsNone(unit_in_header("run_id"))
        self.assertEqual(unit_in_header("time_s"), "s")
        r = datacheck.check([("ids.csv", d / "ids.csv"), ("cells.csv", d / "cells.csv")], [], [], None)
        kinds = {(e["column"], e["kind"]) for e in r["e01"]}
        self.assertIn(("sample_no", "단위 없음"), kinds)
        self.assertIn(("current", "셀 안에 단위"), kinds)
        self.assertEqual(parse_unit("무차원")[0], "dimensionless")   # B12
        pages = ["10 nA 10 fA 0.10 % + 50 pA 10.5 nA", "range ±2 V"]  # B4 부호
        self.assertFalse(verify({"page": 1, "quote": pages[0], "min": -10.5, "max": 10.5}, pages, ("min", "max"))["verified"])
        self.assertTrue(verify({"page": 2, "quote": pages[1], "min": -2, "max": 2}, pages, ("min", "max"))["verified"])

    def test_review_run_lifecycle_guards(self):
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        from measuretrace.extract.run import extract_view
        from measuretrace.ingest.run import ingest_view, list_runs
        from measuretrace.recompute import run as rc_run
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR), \
                mock.patch.object(rc_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._extracted(DEMO / "annealing_demo", "life")
            with self.assertRaises(ValueError):                       # B10 봉인: 업로드·재수집 거부
                workspace.save_upload(rid, "data", "x.csv", __import__("io").BytesIO(b"a"), 1)
            with self.assertRaises(ValueError):
                ingest_run.run_ingest(rid, "life")
            self.assertEqual(ingest_view(rid)["run_id"], rid)        # B6 이어서 보기
            self.assertEqual(extract_view(rid)["counts"]["equations"], 8)
            self.assertIn(rid, [r["run_id"] for r in list_runs()])
            v = confirm.start(rid)
            with self.assertRaises(ValueError):                       # B11 확인 중 수동 재추출 거부
                extract_run.run_extract(rid, llm.LLM(client=FakeClient(), model="fake"))
            ans = {i["id"]: {"choice": "proceed" if "proceed" in i["inputs"] else "approve"}
                   for i in v["items"] if i["required"]}
            confirm.submit(rid, "tester", ans)
            (workspace.OUTPUTS_DIR / "life" / rid / "extract" / "headers.json").write_text("{}", encoding="utf-8")
            log = rc_run.run_recompute(rid)                           # B11 확정 뒤 추출 결과가 바뀌면 계산 안 함
            self.assertEqual(log["status"], "blocked")
            self.assertIn("EXTRACT", log["reason"])

    def test_review_code_rules_block_approval(self):
        import fake_llm
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        bad = "import sys\ndef compute(files):\n    return {'results': []}\n"
        orig = fake_llm.answer

        def answer(schema):
            if "explanation" in schema.get("required", []):
                return {"code": bad, "explanation": "규칙 위반 시험"}
            return orig(schema)
        shutil.rmtree(llm.CACHE_DIR, ignore_errors=True)   # 앞 시험의 캐시(정상 코드)를 쓰지 않게
        with mock.patch.object(fake_llm, "answer", answer), \
                mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._extracted(DEMO / "annealing_demo", "rules")
            self.assertTrue(extract_run.extract_view(rid)["plan"]["code_static_check"])   # B7 2-1c 에서 미리 검사
            v = confirm.start(rid)
            code = next(i for i in v["items"] if i["id"] == "3-1:code")
            self.assertTrue(code["proposal"]["static_problems"])
            with self.assertRaises(ValueError):                       # 규칙 위반 코드는 승인 불가
                confirm.submit(rid, "tester", {"3-1:code": {"choice": "approve"}})
        shutil.rmtree(llm.CACHE_DIR, ignore_errors=True)   # 규칙 위반 코드가 뒤 시험의 캐시로 남지 않게

    def test_review_missing_code_blocks_completion(self):
        """B13: 코드 초안이 없으면 3 CONFIRM 이 '완료'되지 않는다."""
        import fake_llm
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        orig = fake_llm.answer

        def answer(schema):
            if "explanation" in schema.get("required", []):
                raise RuntimeError("코드 초안 실패 시험")
            return orig(schema)
        shutil.rmtree(llm.CACHE_DIR, ignore_errors=True)
        with mock.patch.object(fake_llm, "answer", answer), \
                mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            rid = self._extracted(DEMO / "annealing_demo", "nocode")
            v = confirm.start(rid)
            code = next(i for i in v["items"] if i["id"] == "3-1:code")
            self.assertEqual(code["inputs"], ["reject"])
            ans = {i["id"]: {"choice": "proceed" if "proceed" in i["inputs"] else "approve"}
                   for i in v["items"] if i["required"] and "approve" in i["inputs"] or "proceed" in i["inputs"]}
            v = confirm.submit(rid, "tester", ans)
            self.assertEqual(v["status"], "open")
            self.assertGreaterEqual(v["counts"]["required_open"], 1)
        shutil.rmtree(llm.CACHE_DIR, ignore_errors=True)

    def test_review_server_rejects_foreign_requests(self):
        import http.client
        import threading
        from http.server import ThreadingHTTPServer
        sys.path.insert(0, str(ROOT / "web"))
        import server as web
        srv = ThreadingHTTPServer(("127.0.0.1", 0), web.Handler)
        port = srv.server_address[1]
        web.Handler.port = port
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            def req(method, path, headers):
                c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
                c.request(method, path, body=b"{}" if method != "GET" else None, headers=headers)
                return c.getresponse().status
            host = {"Host": f"127.0.0.1:{port}"}
            self.assertEqual(req("GET", "/api/status", {"Host": f"evil.example:{port}"}), 403)          # DNS 리바인딩
            self.assertEqual(req("POST", "/api/runs", {**host, "Content-Type": "text/plain"}), 403)      # 헤더 없는 쓰기
            self.assertEqual(req("POST", "/api/runs", {**host, "X-MeasureTrace": "1",
                                                       "Origin": "https://evil.example"}), 403)          # 다른 출처
            self.assertEqual(req("OPTIONS", "/api/runs", host), 403)
            self.assertEqual(req("POST", "/api/runs", {**host, "X-MeasureTrace": "1",
                                                       "Origin": f"http://127.0.0.1:{port}"}), 200)       # 화면에서 온 요청
            self.assertEqual(req("GET", "/", host), 200)
        finally:
            srv.shutdown()

    def test_rerun_with_everything_carried_over_finalizes(self):
        """같은 입력 재실행 — 필수 항목을 모두 이어받으면 바로 확정 (빈 제출이 거절돼 끝낼 수 없던 문제)."""
        from measuretrace import confirm
        from measuretrace.confirm import run as confirm_run
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR):
            self._confirmed(DEMO / "annealing_demo", "carry")
            rid2 = self._extracted(DEMO / "annealing_demo", "carry")
            v = confirm.start(rid2)
            self.assertEqual(v["status"], "complete", v.get("messages"))
            self.assertTrue(any("이어받아 바로 확정" in m for m in v["messages"]))
            self.assertTrue((workspace.OUTPUTS_DIR / "carry" / rid2 / "confirm" / "confirmed.json").exists())

    def test_llm_unavailable_keeps_python_steps(self):
        r = self.ingest(DEMO / "annealing_demo", "t2")
        ex = extract_run.run_extract(r["run_id"], llm.LLM(client=None, model="none", offline=True))
        self.assertEqual(ex["steps"]["2-1b"]["status"], "ok")
        self.assertEqual(ex["steps"]["2-3"]["status"], "ok")
        self.assertEqual(ex["steps"]["2-1c"]["status"], "error")


if __name__ == "__main__":
    unittest.main()
