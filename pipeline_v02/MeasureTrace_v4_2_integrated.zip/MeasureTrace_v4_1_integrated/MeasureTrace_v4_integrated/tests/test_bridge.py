"""앞단(1~4) → 뒷단(5 VALIDATE · 6 AUDIT) 연결 시험 — 가짜 LLM(토큰 0), 임시 작업 폴더.

  python -m unittest tests.test_bridge
"""
from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from statistics import mean
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests"), str(ROOT / "tests" / "backend")]

from case_builder import FakeClient as BackendFake  # noqa: E402 — 뒷단 시험의 5-1·6-1 가짜 클라이언트
from fake_llm import FakeClient  # noqa: E402
from measuretrace import bridge, confirm, ledger, llm  # noqa: E402
from measuretrace.backend.contract import Confirmed  # noqa: E402
from measuretrace.confirm import run as confirm_run  # noqa: E402
from measuretrace.extract import run as extract_run  # noqa: E402
from measuretrace.ingest import run as ingest_run, workspace  # noqa: E402
from measuretrace.recompute import run as rc_run  # noqa: E402

DEMO = ROOT / "tests" / "demo" / "annealing_demo"


def claim(value_text: str, output_id: str, source: str) -> dict:
    item = {k: "" for k in ("value_text", "unit", "output_id", "lhs_output", "rhs_output", "degree_word", "test_id",
                            "test_name", "df_text", "n_text", "p_text", "n_group")}
    item.update(claim_type="numeric", source_text=source, value_text=value_text, unit="A", statistic="mean",
                output_id=output_id, relation=None, significant=None, p_comparator=None, n_scope=None)
    return {"category": "numeric", "citation_refs": [], "literature_values": [], "claims": [item]}


class BridgeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not DEMO.exists():
            import make_demo  # noqa: F401
        cls.tmp = Path(tempfile.mkdtemp())
        ws = cls.tmp / "workspace"
        cls.patches = [mock.patch.object(workspace, "INPUTS_DIR", ws / "inputs"),
                       mock.patch.object(workspace, "OUTPUTS_DIR", ws / "outputs"),
                       mock.patch.object(extract_run, "OUTPUTS_DIR", ws / "outputs"),
                       mock.patch.object(confirm_run, "OUTPUTS_DIR", ws / "outputs"),
                       mock.patch.object(rc_run, "OUTPUTS_DIR", ws / "outputs"),
                       mock.patch.object(bridge, "OUTPUTS_DIR", ws / "outputs"),
                       mock.patch.object(ledger, "LEDGER_PATH", ws / "outputs" / "lineage.jsonl"),
                       mock.patch.object(llm, "CACHE_DIR", ws / "llm_cache"),
                       mock.patch.object(llm, "AUDIT_LOG", ws / "outputs" / "llm_audit.jsonl")]
        for p in cls.patches:
            p.start()
        # 연구 자료는 데모 그대로, 보고서는 수치 주장 두 문장짜리 글 파일 (하나는 맞고 하나는 틀림)
        by = {}
        for f in sorted((DEMO / "data" / "raw").rglob("*.csv")):
            with f.open(newline="", encoding="utf-8-sig") as fh:
                for row in csv.DictReader(fh):
                    by.setdefault(row["condition"], []).append(float(row["current_A"]))
        cls.good = f"{mean(by['annealed']):.3g}"
        cls.bad = f"{mean(by['control']) * 1.5:.3g}"
        cls.sentences = {"good": f"어닐링 시료의 평균 전류는 {cls.good} A 였다.",
                         "bad": f"대조 시료의 평균 전류는 {cls.bad} A 였다."}
        cls.src = cls.tmp / "case"
        shutil.copytree(DEMO / "data", cls.src / "data")
        (cls.src / "report").mkdir()
        (cls.src / "report" / "report.txt").write_text(
            "결과\n\n" + cls.sentences["good"] + "\n\n" + cls.sentences["bad"] + "\n", encoding="utf-8")

    @classmethod
    def tearDownClass(cls):
        for p in cls.patches:
            p.stop()
        for f in cls.tmp.rglob("*"):
            if f.is_file():
                f.chmod(0o666)
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def _recomputed(self, project: str) -> str:
        rid = workspace.new_run()
        for zone in ("data", "report"):
            for p in sorted((self.src / zone).rglob("*")):
                if p.is_file():
                    with p.open("rb") as f:
                        workspace.save_upload(rid, zone, p.relative_to(self.src / zone).as_posix(), f, p.stat().st_size)
        ingest_run.run_ingest(rid, project)
        extract_run.run_extract(rid, llm.LLM(client=FakeClient(), model="fake"))
        v = confirm.start(rid)
        if v["status"] == "open":   # 같은 프로젝트 재실행은 이전 답을 모두 이어받아 바로 확정될 수 있음
            confirm.submit(rid, "tester", {i["id"]: {"choice": "proceed" if "proceed" in i["inputs"] else "approve"}
                                           for i in v["items"] if i["required"] and i["status"] == "pending"})
        self.assertEqual(rc_run.run_recompute(rid)["status"], "ok")
        return rid

    def _fake(self) -> BackendFake:
        return BackendFake({self.sentences["good"][:12]: claim(self.good, "I", self.sentences["good"]),
                            self.sentences["bad"][:12]: claim(self.bad, "I_2", self.sentences["bad"])})

    def test_preview_builds_valid_contract(self):
        rid = self._recomputed("p")
        v = bridge.preview(rid)
        self.assertEqual(v["problems"], [])
        self.assertEqual(v["data_count"], 20)
        self.assertEqual([o["id"] for o in v["outputs"]], ["I", "I_2"])
        self.assertTrue(all(o["kind"] == "value" and o["unit"] == "A" and o["terms"] == ["전류"] for o in v["outputs"]))
        self.assertEqual(v["reports"], ["report.txt"])
        self.assertEqual(v["tests"][0]["name"], "student_t")
        self.assertEqual(bridge.preview(rid)["bundle_sha256"], v["bundle_sha256"])   # 같은 입력 → 같은 묶음
        self.assertNotIn(self.good, json.dumps(bridge.build(rid)["confirmed"].to_dict(), ensure_ascii=False))   # 값은 인계에 없음

    def test_run_backend_end_to_end(self):
        rid = self._recomputed("e")
        v = bridge.preview(rid)
        with self.assertRaises(ValueError):
            bridge.run(rid, "", v["bundle_sha256"], client=self._fake(), model="fake")          # 승인자 없음
        with self.assertRaises(ValueError):
            bridge.run(rid, "검토자", "0" * 64, client=self._fake(), model="fake")              # 본 적 없는 묶음
        fake = self._fake()
        out = bridge.run(rid, "검토자", v["bundle_sha256"], client=fake, model="fake")
        r = out["result"]
        self.assertEqual(r["recompute"]["status"], "ok")
        # 계산은 4단계에서 한 번 — 5·6 은 같은 뒷단 실행의 계산 로그에 항목을 결합했을 뿐(재실행 없음)
        self.assertEqual(out["execution"]["executions"], 1)
        step4 = json.loads((workspace.OUTPUTS_DIR / "e" / rid / "recompute" / "backend_run.json").read_text(encoding="utf-8"))
        self.assertEqual(out["backend_run_id"], step4["backend_run_id"])
        run_dir = bridge.OUTPUTS_DIR / "_backend" / "e" / "runs" / out["backend_run_id"]
        bound = json.loads((run_dir / "calc_log.json").read_text(encoding="utf-8"))
        discovered = json.loads((run_dir / "calc_log_discover.json").read_text(encoding="utf-8"))
        self.assertEqual(bound["mode"], "bound-after-discover")
        self.assertEqual(bound["finished_at"], discovered["finished_at"])          # 계산 시각은 4단계 그대로
        front = {x["id"]: x["value"] for x in json.loads(
            (workspace.OUTPUTS_DIR / "e" / rid / "recompute" / "calc_log.json").read_text(encoding="utf-8"))["results"]}
        self.assertEqual({k: v["value"] for k, v in r["recompute"]["outputs"].items()}, {k: front[k] for k in ("I", "I_2")})
        verdicts = {c["output_id"]: (c["verdict"], [k["code"] for k in c["codes"]]) for c in r["claims"]}
        self.assertEqual(verdicts["I"], ("Supported", []))
        self.assertEqual(verdicts["I_2"][0], "Unsupported")
        self.assertIn("E05", verdicts["I_2"][1])
        self.assertTrue(r["blind"]["blind_ok"])
        # 봉인된 인계 파일 — 승인자·승인 지문, 코드 해시, 승인 본문 해시
        c = Confirmed.load(ROOT / out["handoff"] if not Path(out["handoff"]).is_absolute() else out["handoff"])
        self.assertEqual(c.code.approved_by, "검토자")
        self.assertEqual(c.approval_problems(), [])
        self.assertEqual(c.code.params["front_code_sha256"],
                         json.loads((workspace.OUTPUTS_DIR / "e" / rid / "confirm" / "confirmed.json")
                                    .read_text(encoding="utf-8"))["code"]["sha256"])
        # R2: 5-1 요청의 재계산 항목 목록에 재계산값이 없다
        catalog = fake.calls[0]["messages"][0]["content"].split("[보고서 문장]")[0]
        self.assertNotIn(self.good, catalog)
        # 저장된 결과 · 장부 · 실행 목록
        self.assertEqual(bridge.get(rid)["backend_run_id"], out["backend_run_id"])
        self.assertIsNotNone(ledger.find(rid, "5·6 VALIDATE·AUDIT"))
        self.assertEqual(next(x for x in ingest_run.list_runs() if x["run_id"] == rid)["audit"], "S1·U1")
        # 같은 실행을 다시 감사하면 4단계를 새로 실행(새 뒷단 실행 id), 6-2 가 이전 실행과 비교
        again = bridge.run(rid, "검토자", v["bundle_sha256"], client=self._fake(), model="fake")
        self.assertNotEqual(again["backend_run_id"], out["backend_run_id"])
        self.assertTrue(again["execution"]["reaudit_new_step4"])
        self.assertEqual(again["result"]["rerun"]["data"]["previous_run"], out["backend_run_id"])
        self.assertEqual(again["result"]["rerun"]["data"]["changes"], [])

    def test_changed_raw_is_refused(self):
        import os
        import stat
        rid = self._recomputed("c")
        f = workspace.run_dir(rid) / "data" / "raw" / "annealed" / "S01.csv"
        os.chmod(f, stat.S_IWRITE | stat.S_IREAD)
        f.write_text(f.read_text() + "S01,annealed,P1,0.6,1e-9\n")
        with self.assertRaises(ValueError):
            bridge.preview(rid)

    # ---- 리뷰 피드백 (2026-09-30) ----
    def test_no_approved_code_reaches_5_6_with_all_e06(self):
        """3-1 코드 미승인 → 4단계는 계산 없이 막힌 채 기록 → 인계 가능 → 5·6 에서 수치 주장 전부 E06(미확정)."""
        rid = self._recomputed("nc")
        conf = workspace.OUTPUTS_DIR / "nc" / rid / "confirm" / "confirmed.json"
        d = json.loads(conf.read_text(encoding="utf-8"))
        d["code"] = None                                  # 3-1 에서 코드를 승인하지 않은 경우와 같은 확정 기록
        conf.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
        rc = rc_run.run_recompute(rid)
        self.assertEqual(rc["status"], "blocked")
        self.assertIn("E06(미확정)", rc["reason"])
        v = bridge.preview(rid)
        self.assertEqual(v["problems"], [])
        self.assertEqual(v["approval_problems_before_seal"], [])
        self.assertTrue(v["no_code"])
        self.assertEqual(v["outputs"], [])
        self.assertTrue(any(p["target"] == "code" for p in v["pending"]))
        out = bridge.run(rid, "검토자", v["bundle_sha256"], client=self._fake(), model="fake")
        r = out["result"]
        self.assertEqual(out["execution"]["executions"], 0)
        self.assertIsNone(out["code_path"])
        self.assertTrue(r["blind"]["blind_ok"])
        self.assertEqual(r["recompute"]["status"], "blocked")
        self.assertEqual(len(r["claims"]), 2)
        for c in r["claims"]:
            self.assertEqual(c["verdict"], "Unsupported")
            self.assertEqual([(k["code"], k["reason_type"]) for k in c["codes"]], [("E06", "미확정")])

    def test_report_changed_after_ingest_is_refused_before_opening(self):
        import os
        import stat
        rid = self._recomputed("rc")
        v = bridge.preview(rid)
        f = workspace.run_dir(rid) / "report" / "report.txt"
        os.chmod(f, stat.S_IWRITE | stat.S_IREAD)
        f.write_text(f.read_text(encoding="utf-8") + "\n추가 문장 99.9 A.\n", encoding="utf-8")
        with self.assertRaises(ValueError) as e:
            bridge.run(rid, "검토자", v["bundle_sha256"], client=self._fake(), model="fake")
        self.assertIn("1 INGEST 이후 바뀜", str(e.exception))
        s4 = json.loads((workspace.OUTPUTS_DIR / "rc" / rid / "recompute" / "backend_run.json").read_text(encoding="utf-8"))
        run_dir = bridge.OUTPUTS_DIR / "_backend" / "rc" / "runs" / s4["backend_run_id"]
        self.assertFalse((run_dir / "blind_log.json").exists())      # 열람 기록을 남기기 전에 멈춤

    def test_corrupt_previous_calc_log_is_skipped_with_reason(self):
        rid1 = self._recomputed("h")
        hist = workspace.OUTPUTS_DIR / "h" / rid1 / "recompute" / "history"
        (hist / "calc_log_00000000-broken.json").write_text("{ 깨진 json", encoding="utf-8")
        (hist / "calc_log_00000001-shape.json").write_text(json.dumps({"status": "ok"}), encoding="utf-8")
        rid2 = self._recomputed("h")                       # 과거 기록이 깨져도 새 4단계는 성공
        log = json.loads((workspace.OUTPUTS_DIR / "h" / rid2 / "recompute" / "calc_log.json").read_text(encoding="utf-8"))
        self.assertEqual(log["e07"]["compared_with"], rid1)
        self.assertEqual({Path(x["file"]).name for x in log["e07"]["excluded"]},
                         {"calc_log_00000000-broken.json", "calc_log_00000001-shape.json"})
        self.assertTrue(all(x["reason"] for x in log["e07"]["excluded"]))

    def test_e03_condition_label_maps_to_design_group(self):
        """2-4 누락의 조건이 설계 이름과 다른 표기('어닐링 (A)')여도 그 집단의 항목에 E03 의존이 걸린다."""
        conds = [{"name": "annealed", "label": "어닐링 (A)", "samples": ["S01", "S07"]},
                 {"name": "control", "label": "대조 (C)", "samples": ["S11"]}]
        by_label = {"condition": "어닐링 (A)", "sample": "S07"}
        by_sample = {"condition": "A 조건", "sample": "s07"}          # 라벨도 이름도 아님 → 시료로 찾음
        unknown = {"condition": "제3 조건", "sample": "S99"}           # 못 찾음 → 모든 항목에 건다
        for m in (by_label, by_sample):
            self.assertEqual(bridge.missing_group(m, conds), "annealed")
            self.assertTrue(bridge.missing_applies(m, ["annealed"], conds))              # G_A_bar 등
            self.assertTrue(bridge.missing_applies(m, ["annealed", "control"], conds))   # t·p·df
            self.assertFalse(bridge.missing_applies(m, ["control"], conds))              # G_C_bar 등
            self.assertTrue(bridge.missing_applies(m, [], conds))                        # 집단 없는 항목
        self.assertIsNone(bridge.missing_group(unknown, conds))
        self.assertTrue(bridge.missing_applies(unknown, ["control"], conds))

    def test_needs_recompute_first(self):
        rid = workspace.new_run()
        for p in sorted((self.src / "data").rglob("*")):
            if p.is_file():
                with p.open("rb") as f:
                    workspace.save_upload(rid, "data", p.relative_to(self.src / "data").as_posix(), f, p.stat().st_size)
        ingest_run.run_ingest(rid, "n")
        with self.assertRaises(ValueError):
            bridge.preview(rid)


if __name__ == "__main__":
    unittest.main()
