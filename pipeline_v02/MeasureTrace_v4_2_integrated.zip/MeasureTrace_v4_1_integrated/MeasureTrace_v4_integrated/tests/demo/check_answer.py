"""도구 정확도 ① 확인 — 4-2 계산 로그의 결과를 데모 정답과 비교한다 (v4 §6: 상대 오차 ≤ 1e-6, 반올림 전).

  python tests/demo/check_answer.py <calc_log.json> [<정답.json>]

결과 항목은 식 번호(eq_id)와 조건으로 정답에 대응시킨다: EQ04 평균 · EQ05 표준편차 · EQ07 t · EQ08 증가율,
이름에 '자유도'·'p' 가 있으면 자유도·p값. 전도도 단위는 nS 로 환산해 비교한다. 대응되지 않은 결과는 '비교 안 함'으로 보여 준다.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from measuretrace.extract.units import parse_unit  # noqa: E402

TOL = 1e-6
COND = {"a": "annealed", "annealed": "annealed", "어닐링": "annealed", "c": "control", "control": "control", "대조": "control"}


def _cond(c) -> str | None:
    if c is None:
        return None
    s = str(c).strip().lower()
    return COND.get(s) or next((v for k, v in COND.items() if len(k) > 1 and k in s), None)


def expected(r: dict, key: dict):
    eq, name, cond = r.get("eq_id") or "", str(r.get("name") or ""), _cond(r.get("condition"))
    if ("시료 수" in name or str(r.get("symbol", "")).startswith("n_")) and cond:
        return key["conditions"][cond]["n"], "n"
    if "자유도" in name or "degrees" in name.lower():
        return key["t_test"]["df"], "df"
    if name.strip().lower() in ("p", "p값", "p-value") or "p값" in name or "p-value" in name.lower() or "유의확률" in name:
        return key["t_test"]["p_two_sided"], "p"
    if eq == "EQ04" and cond:
        return key["conditions"][cond]["mean_nS"], "nS"
    if eq == "EQ05" and cond:
        return key["conditions"][cond]["sd_nS"], "nS"
    if eq == "EQ07" and "t" in name.lower():
        return key["t_test"]["t"], "t"
    if eq == "EQ08":
        return key["increase_percent"], "%"
    return None, None


def check(log: dict, key: dict) -> dict:
    rows = []
    for r in log.get("results", []):
        exp, kind = expected(r, key)
        value = r["value"]
        if kind == "nS":
            unit = parse_unit(r.get("unit") or "")
            if unit and unit[0] == "conductance":
                value = value * unit[1] / 1e-9
        if exp is None:
            rows.append({**r, "expected": None, "verdict": "비교 안 함"})
            continue
        rel = abs(value - exp) / abs(exp) if exp else abs(value)
        rows.append({**r, "value_compared": value, "expected": exp, "rel_error": rel, "verdict": "통과" if rel <= TOL else "불일치"})
    compared = [x for x in rows if x["expected"] is not None]
    return {"tolerance": TOL, "compared": len(compared), "passed": sum(x["verdict"] == "통과" for x in compared),
            "rows": rows}


def main() -> int:
    log = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    key_path = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("annealing_demo_answer_key.json")
    out = check(log, json.loads(key_path.read_text(encoding="utf-8")))
    for x in out["rows"]:
        e = "" if x["expected"] is None else f"정답 {x['expected']:.10g} · 상대 오차 {x['rel_error']:.2e}"
        print(f"[{x['verdict']}] {x.get('name')} ({x.get('condition')}, {x.get('eq_id')}) = {x['value']:.10g} {x.get('unit')}  {e}")
    print(f"\n비교 {out['compared']}개 중 통과 {out['passed']}개 (상대 오차 ≤ {TOL})")
    return 0 if out["compared"] and out["passed"] == out["compared"] else 1


if __name__ == "__main__":
    sys.exit(main())
