"""리허설 — 데모 자료로 1 INGEST → 2 EXTRACT → 3 CONFIRM(전부 승인) → 4 RECOMPUTE 를 임시 작업 폴더에서 돌리고
도구 정확도 ①(정답 대비 상대 오차 ≤ 1e-6)을 확인한다.

  python tests/demo/rehearse.py

- LLM 은 실제 캐시(workspace/llm_cache)만 쓴다(오프라인, 토큰 0) — 화면에서 2 EXTRACT 를 한 번 돌려 캐시가 있어야 한다.
- 실제 작업 폴더(workspace/)의 실행·확인 기록·코드 승인 등록부는 건드리지 않는다. 승인자는 '리허설'로 적힌다.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import check_answer  # noqa: E402
import test_pipeline as T  # noqa: E402
from measuretrace import confirm, llm  # noqa: E402
from measuretrace.confirm import run as confirm_run  # noqa: E402
from measuretrace.extract import run as extract_run  # noqa: E402
from measuretrace.ingest import workspace  # noqa: E402
from measuretrace.recompute import run as rc_run  # noqa: E402

REAL_CACHE = HERE.parents[1] / "workspace" / "llm_cache"


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if not REAL_CACHE.exists():
        print("LLM 캐시가 없음 — 화면에서 데모 자료로 2 EXTRACT 를 한 번 실행한 뒤 다시 돌리세요.")
        return 2
    T.PipelineTest.setUpClass()
    try:
        with mock.patch.object(confirm_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR), \
                mock.patch.object(rc_run, "OUTPUTS_DIR", workspace.OUTPUTS_DIR), \
                mock.patch.object(llm, "CACHE_DIR", REAL_CACHE):
            t = T.PipelineTest("test_llm_unavailable_keeps_python_steps")
            r = t.ingest(T.DEMO / "annealing_demo", "rehearsal")
            ex = extract_run.run_extract(r["run_id"], llm.LLM(client=None, offline=True))
            print("2 EXTRACT", {k: v["status"] for k, v in ex["steps"].items()}, f"캐시 {ex['llm']['cache_hits']}")
            v = confirm.start(r["run_id"])
            ans = {i["id"]: {"choice": "proceed" if "proceed" in i["inputs"] else "approve"}
                   for i in v["items"] if i["required"] and i["status"] == "pending"}
            v = confirm.submit(r["run_id"], "리허설", ans)
            print("3 CONFIRM", v["status"], "코드", (v["confirmed"]["code"] or {}).get("sha256", "")[:12])
            log = rc_run.run_recompute(r["run_id"])
            print("4 RECOMPUTE", log["status"], log.get("reason") or "", f"· 격리 실행 {log.get('sandbox', {}).get('seconds')}초")
            key = json.loads((HERE / "annealing_demo_answer_key.json").read_text(encoding="utf-8"))
            res = check_answer.check(log, key)
            for x in res["rows"]:
                e = "" if x["expected"] is None else f"정답 {x['expected']:.10g} · 상대 오차 {x['rel_error']:.1e}"
                print(f"  [{x['verdict']}] {x.get('name')} ({x.get('condition')}) = {x['value']:.10g} {x.get('unit')}  {e}")
            print(f"도구 정확도 ①: {res['passed']}/{res['compared']} 통과 (상대 오차 ≤ {res['tolerance']})")
            return 0 if res["compared"] and res["passed"] == res["compared"] else 1
    finally:
        T.PipelineTest.tearDownClass()


if __name__ == "__main__":
    sys.exit(main())
