"""데모 연구 자료 한 벌 만들기 — 어닐링(열처리)에 따른 박막 전도도 변화 (가상 연구, 생성형 AI 로 작성).

  python tests/demo/make_demo.py            # tests/demo/ 아래에 만든다

만드는 것
  annealing_demo/data/      연구 자료 칸에 끌어다 놓을 폴더
      research_plan.docx        연구 계획서 — Word 수식(OMML) 8개, 설계·가공 방법·검정 방법
      instrument_spec.pdf       장비 사양서 (가상 장비 MT-SMU 2400, 2쪽)
      raw/annealed/S01~S10.csv  RAW — 시료마다 위치 7개 × 전압 11점 = 77행
      raw/control/S11~S20.csv
      processed/summary_by_sample.csv   가공 데이터 (사용 안 함 — 분류 시험용)
      figures/fig1_conductance.png      그림 (사용 안 함)
      analysis/fit_iv.R                 스크립트 (실행 안 함)
      notes.txt                         메모 (미분류)
  annealing_demo/report/final_report_draft.docx   최종 보고서 초안 — 보고서 칸에 따로
  annealing_demo_rerun/     재실행 시험용: S07 에서 3행 삭제(E07 예시), S12 는 BOM·CRLF 로만 다시 저장(형식만 변경)
  annealing_demo_answer_key.json   정답 — 계획서 식으로 RAW 에서 계산한 값 (업로드하지 않음)

오류는 넣지 않았다(깨끗한 자료). 벤치마크 오류 주입은 규칙을 쓰지 않은 팀원이 한다(v4 §8-4).
"""
from __future__ import annotations

import json
import random
import shutil
import struct
import zlib
from pathlib import Path

import numpy as np
from docx import Document
from docx.oxml import parse_xml
from docx.shared import Pt
from scipy import stats

HERE = Path(__file__).resolve().parent
SEED = 20260929
VOLTAGES = [round(-0.5 + 0.1 * k, 1) for k in range(11)]
POSITIONS = [f"P{j}" for j in range(1, 8)]
CONDITIONS = {"annealed": [f"S{i:02d}" for i in range(1, 11)], "control": [f"S{i:02d}" for i in range(11, 21)]}
TRUE_G_NS = {"annealed": 12.0, "control": 10.0}
AI_NOTE = "※ 이 문서는 MeasureTrace 시험용 가상 자료이며 생성형 AI(Claude)로 작성함."

# ── Word 수식(OMML) 조각 ────────────────────────────────────────────────
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def r(text: str) -> str:
    return f'<m:r><m:t xml:space="preserve">{text}</m:t></m:r>'


def frac(num: str, den: str) -> str:
    return f"<m:f><m:fPr><m:ctrlPr/></m:fPr><m:num>{num}</m:num><m:den>{den}</m:den></m:f>"


def sub(base: str, s: str) -> str:
    return f"<m:sSub><m:sSubPr><m:ctrlPr/></m:sSubPr><m:e>{base}</m:e><m:sub>{s}</m:sub></m:sSub>"


def sup(base: str, s: str) -> str:
    return f"<m:sSup><m:sSupPr><m:ctrlPr/></m:sSupPr><m:e>{base}</m:e><m:sup>{s}</m:sup></m:sSup>"


def subsup(base: str, s: str, p: str) -> str:
    return f"<m:sSubSup><m:sSubSupPr><m:ctrlPr/></m:sSubSupPr><m:e>{base}</m:e><m:sub>{s}</m:sub><m:sup>{p}</m:sup></m:sSubSup>"


def bar(e: str) -> str:
    return f'<m:bar><m:barPr><m:pos m:val="top"/><m:ctrlPr/></m:barPr><m:e>{e}</m:e></m:bar>'


def nsum(lo: str, hi: str, e: str) -> str:
    return (f'<m:nary><m:naryPr><m:chr m:val="∑"/><m:limLoc m:val="undOvr"/><m:ctrlPr/></m:naryPr>'
            f"<m:sub>{lo}</m:sub><m:sup>{hi}</m:sup><m:e>{e}</m:e></m:nary>")


def sqrt(e: str) -> str:
    return f'<m:rad><m:radPr><m:degHide m:val="1"/><m:ctrlPr/></m:radPr><m:deg/><m:e>{e}</m:e></m:rad>'


def paren(e: str) -> str:
    return f"<m:d><m:dPr><m:ctrlPr/></m:dPr><m:e>{e}</m:e></m:d>"


def equations() -> list[tuple[str, str]]:
    """(앞 문장, OMML 본문) — 계획서 5장의 식 1~8."""
    Vk, Vbar = sub(r("V"), r("k")), bar(r("V"))
    Iijk, Iij_bar = sub(r("I"), r("ijk")), bar(sub(r("I"), r("ij")))
    Gi, GA, GC = sub(r("G"), r("i")), bar(sub(r("G"), r("A"))), bar(sub(r("G"), r("C")))
    return [
        ("식 1. 위치별 전도도는 I–V 측정점(전압 11점)에 최소제곱 직선을 맞춘 기울기로 구한다.",
         r("") + sub(r("G"), r("ij")) + r("=") + frac(
             nsum(r("k=1"), r("11"), paren(Vk + r("−") + Vbar) + paren(Iijk + r("−") + Iij_bar)),
             nsum(r("k=1"), r("11"), sup(paren(Vk + r("−") + Vbar), r("2"))))),
        ("식 2. 저항은 전도도의 역수이다(보고에는 쓰지 않고 참고로만 둔다).",
         sub(r("R"), r("ij")) + r("=") + frac(r("1"), sub(r("G"), r("ij")))),
        ("식 3. [가공 방법] 시료 전도도는 그 시료의 위치 7개 전도도의 평균이다. 위치는 기술적 반복이므로 이 평균을 독립 단위의 값으로 쓴다.",
         Gi + r("=") + frac(r("1"), r("7")) + nsum(r("j=1"), r("7"), sub(r("G"), r("ij")))),
        ("식 4. 조건 c의 평균 전도도는 그 조건 시료 n개(n = 10)의 평균이다.",
         bar(sub(r("G"), r("c"))) + r("=") + frac(r("1"), r("n")) + nsum(r("i=1"), r("n"), Gi)),
        ("식 5. 조건 c의 표준편차(표본 표준편차, n − 1).",
         sub(r("s"), r("c")) + r("=") + sqrt(frac(r("1"), r("n−1")) + nsum(
             r("i=1"), r("n"), sup(paren(Gi + r("−") + bar(sub(r("G"), r("c")))), r("2"))))),
        ("식 6. 합동 표준편차.",
         sub(r("s"), r("p")) + r("=") + sqrt(frac(
             paren(sub(r("n"), r("A")) + r("−1")) + subsup(r("s"), r("A"), r("2")) + r("+")
             + paren(sub(r("n"), r("C")) + r("−1")) + subsup(r("s"), r("C"), r("2")),
             sub(r("n"), r("A")) + r("+") + sub(r("n"), r("C")) + r("−2")))),
        ("식 7. 두 조건 비교는 독립 2표본 t 검정(등분산 가정)으로 하며, 자유도는 nA + nC − 2 = 18 이다.",
         r("t=") + frac(GA + r("−") + GC,
                        sub(r("s"), r("p")) + sqrt(frac(r("1"), sub(r("n"), r("A"))) + r("+") + frac(r("1"), sub(r("n"), r("C")))))),
        ("식 8. 어닐링에 따른 전도도 증가율(%).",
         r("ΔG=") + frac(GA + r("−") + GC, GC) + r("×100")),
    ]


def add_equation(doc: Document, omml: str) -> None:
    p = doc.add_paragraph()
    p._p.append(parse_xml(f'<m:oMath xmlns:m="{M_NS}" xmlns:w="{W_NS}">{omml}</m:oMath>'))


# ── RAW 데이터 ─────────────────────────────────────────────────────────
def make_raw(data: Path) -> None:
    rng = random.Random(SEED)
    for cond, samples in CONDITIONS.items():
        folder = data / "raw" / cond
        folder.mkdir(parents=True, exist_ok=True)
        for s in samples:
            g_sample = rng.gauss(TRUE_G_NS[cond], 0.8)
            lines = ["sample_id,condition,position,voltage_V,current_A"]
            for pos in POSITIONS:
                g_pos = g_sample + rng.gauss(0, 0.3)
                offset = rng.gauss(0, 0.02e-9)
                for v in VOLTAGES:
                    i = g_pos * 1e-9 * v + offset + rng.gauss(0, 0.01e-9)
                    lines.append(f"{s},{cond},{pos},{v:.1f},{i:.6e}")
            (folder / f"{s}.csv").write_bytes(("\n".join(lines) + "\n").encode("utf-8"))


def answer_key(data: Path) -> dict:
    """계획서 식 1·3~8 을 RAW 파일에서 그대로 계산 (파일에 적힌 글자를 다시 읽어서)."""
    per_sample: dict[str, dict] = {}
    for cond, samples in CONDITIONS.items():
        for s in samples:
            rows = [l.split(",") for l in (data / "raw" / cond / f"{s}.csv").read_text(encoding="utf-8").splitlines()[1:]]
            g_pos = {}
            for pos in POSITIONS:
                v = np.array([float(x[3]) for x in rows if x[2] == pos])
                i = np.array([float(x[4]) for x in rows if x[2] == pos])
                g_pos[pos] = float(np.sum((v - v.mean()) * (i - i.mean())) / np.sum((v - v.mean()) ** 2)) * 1e9  # nS
            per_sample[s] = {"condition": cond, "G_positions_nS": g_pos, "G_sample_nS": float(np.mean(list(g_pos.values())))}
    out = {"unit": "nS", "per_sample": per_sample, "conditions": {}}
    groups = {}
    for cond in CONDITIONS:
        g = np.array([v["G_sample_nS"] for v in per_sample.values() if v["condition"] == cond])
        groups[cond] = g
        out["conditions"][cond] = {"n": int(len(g)), "mean_nS": float(g.mean()), "sd_nS": float(g.std(ddof=1))}
    t, p = stats.ttest_ind(groups["annealed"], groups["control"], equal_var=True)
    ga, gc = out["conditions"]["annealed"]["mean_nS"], out["conditions"]["control"]["mean_nS"]
    out["t_test"] = {"t": float(t), "df": 18, "p_two_sided": float(p)}
    out["increase_percent"] = (ga - gc) / gc * 100
    return out


# ── 연구 계획서 (docx) ─────────────────────────────────────────────────
def make_plan(path: Path) -> None:
    doc = Document()
    doc.styles["Normal"].font.size = Pt(10.5)
    doc.add_heading("연구 계획서 — 어닐링에 따른 박막 전도도 변화", level=1)
    doc.add_heading("1. 연구 목적", level=2)
    doc.add_paragraph("열처리(어닐링)가 박막의 전기 전도도를 높이는지 확인한다. 어닐링한 시료와 하지 않은 대조 시료의 전도도를 비교한다.")
    doc.add_heading("2. 실험 설계", level=2)
    doc.add_paragraph("조건은 2개(어닐링 A, 대조 C)이며 조건마다 독립 시료 10개를 만든다(A: S01–S10, C: S11–S20). "
                      "시료마다 정해진 위치 7개(P1–P7)에서 전류–전압(I–V)을 측정한다. 위치마다 전압을 −0.5 V부터 0.5 V까지 "
                      "0.1 V 간격(11점)으로 인가하고 전류를 읽는다.")
    doc.add_paragraph("독립 단위는 시료이다. 한 시료 안의 위치 7개는 기술적 반복이므로 통계 검정에서 독립 표본으로 세지 않는다.")
    table = doc.add_table(rows=1, cols=4)
    table.style = "Table Grid"
    for cell, text in zip(table.rows[0].cells, ("조건", "시료", "시료당 위치", "위치당 측정점")):
        cell.text = text
    for cond, label, rng_ in (("annealed", "어닐링 (A)", "S01–S10"), ("control", "대조 (C)", "S11–S20")):
        row = table.add_row().cells
        row[0].text, row[1].text, row[2].text, row[3].text = label, f"{rng_} (10개)", "7 (P1–P7)", "11 (−0.5 ~ 0.5 V)"
    doc.add_heading("3. 측정 장비", level=2)
    doc.add_paragraph("소스 측정 장치 MT-SMU 2400 (가상 장비)의 10 nA 전류 범위를 사용한다. 측정 범위와 정확도는 장비 사양서"
                      "(instrument_spec.pdf)를 따른다.")
    doc.add_heading("4. 데이터 파일", level=2)
    doc.add_paragraph("시료마다 CSV 파일 1개: raw/<조건>/<시료>.csv. 열은 sample_id, condition, position, voltage_V(단위 V), "
                      "current_A(단위 A)이다. 파일 하나에 위치 7개 × 11점 = 77행이 있다.")
    doc.add_heading("5. 계산 방법", level=2)
    doc.add_paragraph("아래 식의 첨자: i = 시료, j = 위치, k = 전압 측정점, c = 조건(A 또는 C).")
    for text, omml in equations():
        doc.add_paragraph(text)
        add_equation(doc, omml)
    doc.add_heading("6. 검정 방법", level=2)
    doc.add_paragraph("어닐링 조건과 대조 조건의 시료 전도도(식 3)를 양측 독립 2표본 t 검정(등분산 가정, 식 6·7)으로 비교한다. "
                      "유의수준은 0.05이다.")
    doc.add_heading("7. 단위와 보고", level=2)
    doc.add_paragraph("전류는 A, 전압은 V로 기록한다. 전도도는 nS(10⁻⁹ S)로 보고하며 평균 ± 표준편차(n = 10)로 적는다.")
    doc.add_heading("8. 이상치 처리", level=2)
    doc.add_paragraph("이상치를 자동으로 제외하지 않는다. 장비 측정 범위를 벗어난 값이 있으면 재측정 여부를 연구자가 결정하고 기록한다.")
    doc.add_paragraph(AI_NOTE)
    doc.save(path)


# ── 장비 사양서 (PDF, 영문 — 기본 글꼴만 사용) ─────────────────────────────
def make_pdf(path: Path, pages: list[list[str]]) -> None:
    objs: list[str] = ["<< /Type /Catalog /Pages 2 0 R >>", ""]
    kids = []
    font_id = 3
    objs.append("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    for lines in pages:
        esc = [l.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") for l in lines]
        text = "BT /F1 11 Tf 60 750 Td 15 TL " + " ".join(f"({l}) '" for l in esc) + " ET"
        objs.append(f"<< /Length {len(text)} >>\nstream\n{text}\nendstream")
        content_id = len(objs)
        objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents {content_id} 0 R "
                    f"/Resources << /Font << /F1 {font_id} 0 R >> >> >>")
        kids.append(f"{len(objs)} 0 R")
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>"
    out, offsets = b"%PDF-1.4\n", []
    for n, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{n} 0 obj\n{o}\nendobj\n".encode("latin-1")
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    out += "".join(f"{o:010d} 00000 n \n" for o in offsets).encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    path.write_bytes(out)


SPEC_PAGES = [
    ["MT-SMU 2400 Source Measure Unit - Specification",
     "(Fictional instrument. Test material for MeasureTrace, written with generative AI.)",
     "",
     "1. Current measurement accuracy (1 year, 23 C +/- 5 C)",
     "Range      Resolution   Accuracy +/-(% of reading + offset)   Max reading",
     "10 nA      10 fA        0.10 % + 50 pA                        10.5 nA",
     "100 nA     100 fA       0.06 % + 100 pA                       105 nA",
     "1 uA       1 pA         0.03 % + 300 pA                       1.05 uA",
     "10 uA      10 pA        0.03 % + 700 pA                       10.5 uA",
     "",
     "2. Voltage source accuracy",
     "Range      Resolution   Accuracy +/-(% of setting + offset)",
     "2 V        50 uV        0.02 % + 600 uV",
     "20 V       500 uV       0.02 % + 2.4 mV"],
    ["3. Measurement range limits",
     "Readings above 105 % of the selected range are out of range.",
     "Out-of-range readings are reported as the overflow value 9.9E37.",
     "Valid current readings on the 10 nA range: -10.5 nA to +10.5 nA.",
     "",
     "4. Operating conditions",
     "Warm-up: 1 hour to rated accuracy.",
     "Temperature: 18 C to 28 C, humidity below 70 % RH.",
     "Integration time: 1 PLC (power line cycle) or longer for rated accuracy."],
]


# ── 최종 보고서 초안 (docx) ─────────────────────────────────────────────
def make_report(path: Path, key: dict) -> None:
    a, c = key["conditions"]["annealed"], key["conditions"]["control"]
    t, p = key["t_test"]["t"], key["t_test"]["p_two_sided"]
    p_text = "p < 0.001" if p < 0.001 else f"p = {p:.3f}"
    doc = Document()
    doc.styles["Normal"].font.size = Pt(10.5)
    doc.add_heading("어닐링 처리에 따른 박막 전도도 향상 — 최종 보고서 (초안)", level=1)
    doc.add_heading("1. 서론", level=2)
    doc.add_paragraph("선행 연구에서 어닐링은 결정립을 키워 박막의 전도도를 높인다고 보고되었다 [1].")
    doc.add_heading("2. 방법", level=2)
    doc.add_paragraph("조건별로 독립 시료 10개를 만들고, 시료마다 위치 7개에서 −0.5 V부터 0.5 V까지 I–V를 측정했다. "
                      "위치별 전도도는 I–V 직선의 기울기로 구하고, 시료 전도도는 위치 7개의 평균으로 했다.")
    doc.add_heading("3. 결과", level=2)
    doc.add_paragraph(f"어닐링 시료의 평균 전도도는 {a['mean_nS']:.1f} ± {a['sd_nS']:.1f} nS, 대조 시료는 "
                      f"{c['mean_nS']:.1f} ± {c['sd_nS']:.1f} nS였다(각 n = 10).")
    doc.add_paragraph(f"어닐링 후 전도도는 대조 시료보다 {key['increase_percent']:.0f} % 높았다.")
    doc.add_paragraph(f"이 차이는 통계적으로 유의했다(t(18) = {t:.2f}, {p_text}).")
    doc.add_paragraph("어닐링한 막의 표면은 육안으로 균일하게 형성되었다.")
    doc.add_paragraph(f"우리 어닐링 시료의 값 {a['mean_nS']:.1f} nS는 문헌값 11.5 nS [1]와 비슷하다.")
    doc.add_heading("4. 결론", level=2)
    doc.add_paragraph("어닐링은 박막의 전도도를 크게 증가시켰다.")
    doc.add_heading("참고문헌", level=2)
    doc.add_paragraph("[1] H. Kim et al., Journal of Thin Film Tests 12, 34 (2024). (가상 문헌)")
    doc.add_paragraph(AI_NOTE)
    doc.save(path)


# ── 분류 시험용 부속 파일 ──────────────────────────────────────────────
def tiny_png(path: Path) -> None:
    """8×8 회색 PNG (유효한 이미지 파일)."""
    raw = b"".join(b"\x00" + b"\x80" * 8 for _ in range(8))
    chunk = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d))
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 8, 8, 8, 0, 0, 0, 0))
                     + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def make_extras(data: Path, key: dict) -> None:
    (data / "processed").mkdir(parents=True, exist_ok=True)
    rows = ["sample_id,condition,G_mean_nS"] + [f"{s},{v['condition']},{v['G_sample_nS']:.3f}" for s, v in key["per_sample"].items()]
    (data / "processed" / "summary_by_sample.csv").write_bytes(("\n".join(rows) + "\n").encode("utf-8"))
    (data / "figures").mkdir(exist_ok=True)
    tiny_png(data / "figures" / "fig1_conductance.png")
    (data / "analysis").mkdir(exist_ok=True)
    (data / "analysis" / "fit_iv.R").write_bytes(b"# lab script - MeasureTrace must never run this\nd <- read.csv('raw/annealed/S01.csv')\n")
    (data / "notes.txt").write_bytes("측정 메모: 9/15 오전 S01–S10, 오후 S11–S20 측정. 장비 예열 1시간.\n".encode("utf-8"))


def make_rerun(src: Path, dst: Path) -> None:
    """재실행 시험용 사본 — S07 은 3행 삭제(내용 변경), S12 는 BOM·CRLF 로만 다시 저장(형식만 변경)."""
    shutil.copytree(src, dst)
    s07 = dst / "data" / "raw" / "annealed" / "S07.csv"
    lines = s07.read_text(encoding="utf-8").splitlines()
    del lines[30:33]   # P3 위치의 앞 3점
    s07.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))
    s12 = dst / "data" / "raw" / "control" / "S12.csv"
    s12.write_bytes(b"\xef\xbb\xbf" + s12.read_bytes().replace(b"\n", b"\r\n"))


def main() -> None:
    root, rerun = HERE / "annealing_demo", HERE / "annealing_demo_rerun"
    for d in (root, rerun):
        if d.exists():
            shutil.rmtree(d)
    data, report = root / "data", root / "report"
    data.mkdir(parents=True)
    report.mkdir(parents=True)
    make_raw(data)
    key = answer_key(data)
    make_plan(data / "research_plan.docx")
    make_pdf(data / "instrument_spec.pdf", SPEC_PAGES)
    make_extras(data, key)
    make_report(report / "final_report_draft.docx", key)
    make_rerun(root, rerun)
    key["_note"] = ("정답 — 계획서 식 1·3~8 로 RAW 에서 계산한 값(반올림 전). 업로드하지 말 것. "
                    "재실행본(annealing_demo_rerun)은 S07 이 3행 적으므로 이 정답과 다르다.")
    (HERE / "annealing_demo_answer_key.json").write_text(json.dumps(key, ensure_ascii=False, indent=2), encoding="utf-8")
    a, c = key["conditions"]["annealed"], key["conditions"]["control"]
    print(f"만듦: {root}")
    print(f"  어닐링 {a['mean_nS']:.3f} ± {a['sd_nS']:.3f} nS · 대조 {c['mean_nS']:.3f} ± {c['sd_nS']:.3f} nS · "
          f"증가 {key['increase_percent']:.2f} % · t(18) = {key['t_test']['t']:.3f}, p = {key['t_test']['p_two_sided']:.2e}")
    print(f"재실행본: {rerun}")


if __name__ == "__main__":
    main()
