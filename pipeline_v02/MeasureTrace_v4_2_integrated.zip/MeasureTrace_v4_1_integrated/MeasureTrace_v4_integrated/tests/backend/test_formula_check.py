"""LLM 생성 수식 코드 검증(measuretrace.formula) — 데모 계획서 수식(EQ01·05·06·07·08)으로 맞는 구현·틀린 구현을 가른다."""
import json

import pytest

from measuretrace.formula import ApprovalStore, NotApproved, Reference, check_function, verify_or_reuse

POOLED = Reference("EQ06", "sqrt(((n_A-1)*s_A^2 + (n_C-1)*s_C^2)/(n_A+n_C-2))",
                   {"n_A": "조건 A 시료 수", "n_C": "조건 C 시료 수", "s_A": "조건 A 표준편차", "s_C": "조건 C 표준편차"},
                   source="계획서 식 6", assume="positive")   # 개수·표준편차 — 양수임을 연구자가 확인
POOLED_BIND = {"nA": "n_A", "nC": "n_C", "sA": "s_A", "sC": "s_C"}

SLOPE = Reference("EQ01", "Sum((V[k]-Sum(V[j],(j,1,n))/n)*(I[k]-Sum(I[j],(j,1,n))/n),(k,1,n))"
                          " / Sum((V[k]-Sum(V[j],(j,1,n))/n)^2,(k,1,n))",
                  {"V": "전압", "I": "전류", "n": "측정점 수"}, vectors={"V": "n", "I": "n"}, source="계획서 식 1")

SD = Reference("EQ05", "sqrt(Sum((G[i]-Sum(G[j],(j,1,n))/n)^2,(i,1,n))/(n-1))",
               {"G": "시료 전도도", "n": "시료 수"}, vectors={"G": "n"}, source="계획서 식 5")


def test_pooled_sd_correct_passes():
    code = """import math
def pooled(nA, nC, sA, sC):
    return math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / (nA + nC - 2))
"""
    r = check_function(code, "pooled", POOLED, POOLED_BIND)
    assert r.status == "proven" and r.ok


def test_pooled_sd_wrong_denominator_is_caught_with_counterexample():
    code = """import math
def pooled(nA, nC, sA, sC):
    return math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / (nA + nC))
"""
    r = check_function(code, "pooled", POOLED, POOLED_BIND)
    assert r.status == "mismatch" and not r.ok
    assert r.details[0]["counterexample"]["at"]


def test_swapped_arguments_are_caught():
    code = """from math import sqrt as root
def pooled(nA, nC, sA, sC):
    return root(((nA - 1) * sC ** 2 + (nC - 1) * sA ** 2) / (nA + nC - 2))
"""
    assert check_function(code, "pooled", POOLED, POOLED_BIND).status == "mismatch"


def test_equivalent_rewrite_with_helper_and_guard_passes():
    code = '''
def _sq(x):
    return x * x

def pooled(nA, nC, sA, sC):
    """다른 모양이지만 같은 식."""
    df = nA + nC - 2
    if df <= 0:
        return float("nan")
    total = 0.0
    total += (nA - 1) * _sq(sA)
    total += (nC - 1) * _sq(sC)
    return (total / df) ** 0.5
'''
    r = check_function(code, "pooled", POOLED, POOLED_BIND)
    assert r.status == "proven", r.reasons
    assert any("보호 분기" in n for n in r.notes)


def test_slope_loop_implementation_passes_and_intercept_variant_fails():
    good = """
def slope(vs, is_):
    n = len(vs)
    vbar = sum(vs) / n
    ibar = sum(is_) / n
    num = 0.0
    den = 0.0
    for v, i in zip(vs, is_):
        num += (v - vbar) * (i - ibar)
        den += (v - vbar) ** 2
    if den == 0.0:
        return float("nan")
    return num / den
"""
    bind = {"vs": "V", "is_": "I"}
    r = check_function(good, "slope", SLOPE, bind)
    assert r.status == "proven", r.reasons
    assert [d["size"] for d in r.details] == [{"n": 2}, {"n": 3}, {"n": 5}]
    through_origin = """
def slope(vs, is_):
    return sum(v * i for v, i in zip(vs, is_)) / sum(v * v for v in vs)
"""
    assert check_function(through_origin, "slope", SLOPE, bind).status == "mismatch"


def test_sample_vs_population_sd():
    bind = {"g": "G"}
    ok = "import statistics\ndef sd(g):\n    return statistics.stdev(g)\n"
    pop = "import numpy as np\ndef sd(g):\n    return np.std(g)\n"
    ddof1 = "import numpy as np\ndef sd(g):\n    return np.std(g, ddof=1)\n"
    assert check_function(ok, "sd", SD, bind).ok
    assert check_function(ddof1, "sd", SD, bind).ok
    assert check_function(pop, "sd", SD, bind).status == "mismatch"


def test_rate_and_t_statistic():
    rate = Reference("EQ08", "(Ga - Gc)/Gc * 100", {"Ga": "A 평균", "Gc": "C 평균"}, assume="real")
    code = "def rate(a, c):\n    return 100 * (a / c - 1)\n"
    assert check_function(code, "rate", rate, {"a": "Ga", "c": "Gc"}).ok
    t = Reference("EQ07", "(Ga - Gc)/(sp*sqrt(1/nA + 1/nC))",
                  {"Ga": "A 평균", "Gc": "C 평균", "sp": "합동 표준편차", "nA": "A 수", "nC": "C 수"}, assume="real")
    code_t = """import math
def t_stat(ma, mc, s, na, nc):
    return {"t": (ma - mc) / (s * math.sqrt(1.0 / na + 1.0 / nc)), "df": na + nc - 2}
"""
    b = {"ma": "Ga", "mc": "Gc", "s": "sp", "na": "nA", "nc": "nC"}
    assert check_function(code_t, "t_stat", t, b, output="t").ok


def test_hardcoded_constant_instead_of_variable_is_mismatch():
    ref = Reference("EQ03", "Sum(G[j],(j,1,n))/n", {"G": "위치별 전도도", "n": "위치 수"}, vectors={"G": "n"})
    code = "def mean7(g):\n    return sum(g) / 7\n"
    assert check_function(code, "mean7", ref, {"g": "G"}).status == "mismatch"


def test_unsupported_code_is_not_guessed():
    code = """import os
def f(nA, nC, sA, sC):
    os.system("echo hi")
    return 0
"""
    r = check_function(code, "f", POOLED, POOLED_BIND)
    assert r.status == "unsupported" and not r.ok
    code2 = "def f(nA, nC, sA, sC):\n    while True:\n        pass\n"
    assert check_function(code2, "f", POOLED, POOLED_BIND).status == "unsupported"


def test_reference_text_cannot_run_code():
    evil = Reference("EQX", "sqrt('__import__(\"os\").getcwd()')", {"x": "x"})
    r = check_function("def f(x):\n    return x\n", "f", evil, {"x": "x"})
    assert r.status == "invalid_reference"
    attr = Reference("EQX", "x.__class__", {"x": "x"})
    assert check_function("def f(x):\n    return x\n", "f", attr, {"x": "x"}).status == "invalid_reference"


def test_reference_symbols_must_have_meaning():
    ref = Reference("EQX", "a * b", {"a": "뜻"})
    assert check_function("def f(a):\n    return a\n", "f", ref, {"a": "a"}).status == "invalid_reference"


def test_store_approves_only_passing_code_and_reuses(tmp_path):
    store = ApprovalStore(tmp_path / "approvals.jsonl")
    good = "import math\ndef pooled(nA, nC, sA, sC):\n    return math.sqrt(((nA-1)*sA**2+(nC-1)*sC**2)/(nA+nC-2))\n"
    bad = "import math\ndef pooled(nA, nC, sA, sC):\n    return math.sqrt((sA**2+sC**2)/2)\n"
    cond = {"plan_sha256": "abc", "unit": "nS"}
    calls = []

    def gen_bad():
        calls.append("bad")
        return bad, "pooled"

    out = verify_or_reuse(POOLED, POOLED_BIND, cond, gen_bad, store)
    assert not out["approved"] and not (tmp_path / "approvals.jsonl").exists()
    with pytest.raises(NotApproved):
        store.approve(check_function(bad, "pooled", POOLED, POOLED_BIND), bad, POOLED, POOLED_BIND, cond)

    def gen_good():
        calls.append("good")
        return good, "pooled"

    first = verify_or_reuse(POOLED, POOLED_BIND, cond, gen_good, store)
    assert first["approved"] and not first["reused"]
    again = verify_or_reuse(POOLED, POOLED_BIND, cond, gen_good, store)
    assert again["reused"] and again["code"] == good and calls == ["bad", "good"]   # 두 번째는 생성하지 않음

    # 적용 조건이 다르면 재사용하지 않는다
    other = verify_or_reuse(POOLED, POOLED_BIND, {**cond, "plan_sha256": "def"}, gen_good, store)
    assert not other["reused"] and calls[-1] == "good" and len(calls) == 3
    # 기준 수식이 공백만 다르면 같은 키 (정규화)
    spaced = Reference(**{**POOLED.to_dict(), "expr": POOLED.expr.replace(" ", "")})
    assert store.lookup(spaced, POOLED_BIND, cond) is not None


def test_store_refuses_tampered_record(tmp_path):
    store = ApprovalStore(tmp_path / "approvals.jsonl")
    good = "import math\ndef pooled(nA, nC, sA, sC):\n    return math.sqrt(((nA-1)*sA**2+(nC-1)*sC**2)/(nA+nC-2))\n"
    verify_or_reuse(POOLED, POOLED_BIND, {}, lambda: (good, "pooled"), store)
    rec = json.loads(store.path.read_text(encoding="utf-8"))
    rec["code"] = rec["code"].replace("-2", "")
    store.path.write_text(json.dumps(rec, ensure_ascii=False) + "\n", encoding="utf-8")
    assert store.lookup(POOLED, POOLED_BIND, {}) is None


def test_undecidable_non_guard_branch_is_unsupported_not_silently_skipped():
    # 값에 따라 다른 식을 쓰는 분기는 어느 갈래도 추측하지 않는다(판정 불가 → else 로 새지 않음)
    code = """import math
def pooled(nA, nC, sA, sC):
    if sA > sC:
        return sA
    return math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / (nA + nC - 2))
"""
    r = check_function(code, "pooled", POOLED, POOLED_BIND)
    assert r.status == "unsupported" and "판정할 수 없는 분기" in r.reasons[0]


def test_guard_that_fires_on_valid_inputs_is_not_proven():
    # 정의역 절반에서 nan 을 내는 '가짜 보호 분기' — 건너뛰고 proven 을 주면 안 된다
    code = """import math
def pooled(nA, nC, sA, sC):
    if sA > sC:
        return float("nan")
    return math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / (nA + nC - 2))
"""
    r = check_function(code, "pooled", POOLED, POOLED_BIND)
    assert r.status == "inconclusive" and not r.ok
    ifexp = "def rate(a, c):\n    return (a - c) / c * 100 if a > c else float('nan')\n"
    rate = Reference("EQ08", "(Ga - Gc)/Gc * 100", {"Ga": "A 평균", "Gc": "C 평균"})
    assert check_function(ifexp, "rate", rate, {"a": "Ga", "c": "Gc"}).status == "inconclusive"


def test_default_real_assumption_catches_dropped_abs():
    ref = Reference("EQX", "Abs(V)", {"V": "전압"})
    assert check_function("def f(v):\n    return v\n", "f", ref, {"v": "V"}).status == "mismatch"


def test_small_scale_constants_are_compared_relatively():
    ref = Reference("EQX", "V*1e-12", {"V": "v"})
    assert check_function("def f(v):\n    return v*2e-12\n", "f", ref, {"v": "V"}).status == "mismatch"
    assert check_function("NS = 1e-12\ndef f(v):\n    return v*NS\n", "f", ref, {"v": "V"}).ok   # 최상위 상수


def test_append_loop_and_or_default():
    ref = Reference("E", "Sum(X[i]^2,(i,1,n))", {"X": "x", "n": "n"}, vectors={"X": "n"})
    code = "def f(xs):\n    out = []\n    for x in xs:\n        out.append(x*x)\n    return sum(out)\n"
    assert check_function(code, "f", ref, {"xs": "X"}).ok
    # 파이썬의 or 는 피연산자 값을 돌려준다 — 2 or 1 은 2, 0 or 3 은 3
    ref2 = Reference("E", "2*V", {"V": "v"})
    assert check_function("def f(v):\n    k = 2 or 1\n    return k*v\n", "f", ref2, {"v": "V"}).ok
    assert check_function("def f(v):\n    k = 0 or 3\n    return k*v\n", "f", ref2, {"v": "V"}).status == "mismatch"


def test_huge_exponents_do_not_hang():
    ref = Reference("E", "V", {"V": "v"})
    assert check_function("def f(v):\n    return v*2**(10**9)\n", "f", ref, {"v": "V"}).status == "unsupported"
    assert check_function("def f(v):\n    return v\n", "f", Reference("E", "V*9**9**9", {"V": "v"}),
                          {"v": "V"}).status == "invalid_reference"


def test_approve_rejects_mismatched_reference_and_unsafe_module_code(tmp_path):
    store = ApprovalStore(tmp_path / "a.jsonl")
    good = "import math\ndef pooled(nA, nC, sA, sC):\n    return math.sqrt(((nA-1)*sA**2+(nC-1)*sC**2)/(nA+nC-2))\n"
    r = check_function(good, "pooled", POOLED, POOLED_BIND)
    other = Reference("EQ99", "s_A", dict(POOLED.variables))
    with pytest.raises(NotApproved):
        store.approve(r, good, other, POOLED_BIND, {})                 # 다른 기준 수식 이름으로 승인 금지
    with pytest.raises(NotApproved):
        store.approve(r, good, POOLED, POOLED_BIND, {}, output="t")     # 검사하지 않은 output
    evil = "import subprocess\nsubprocess.run('x')\n" + good
    r2 = check_function(evil, "pooled", POOLED, POOLED_BIND)
    assert r2.ok                                                          # 수식은 맞지만
    with pytest.raises(NotApproved):
        store.approve(r2, evil, POOLED, POOLED_BIND, {})                # 정적 점검에서 막힌다
    out = verify_or_reuse(Reference("E", "x+", {"x": "x"}), {}, {}, lambda: pytest.fail("생성하면 안 됨"), store)
    assert not out["approved"] and out["error"]
