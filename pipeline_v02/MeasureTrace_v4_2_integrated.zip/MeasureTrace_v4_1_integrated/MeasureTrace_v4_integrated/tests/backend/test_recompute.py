"""4-1 수치 재계산 · 4-2 계산 로그."""
import json

import pytest
from case_builder import build_case, write_csv

from measuretrace.backend.contract import Confirmed
from measuretrace.backend.recompute import CodeHashMismatch, DataChangedError, RecomputeError, run_recompute
from measuretrace.backend.validate.rounding import tool_accuracy_ok


def test_matches_benchmark_within_1e6(tmp_path):
    case = build_case(tmp_path)
    log = run_recompute(Confirmed.load(case["confirmed"]), case["out"], "r1")
    assert log["status"] == "ok"
    for k, v in case["bench"].items():
        assert tool_accuracy_ok(log["outputs"][k]["value"], v), k


def test_deterministic_and_logged(tmp_path):
    case = build_case(tmp_path)
    c = Confirmed.load(case["confirmed"])
    a, b = run_recompute(c, case["out"], "r1"), run_recompute(c, case["out"], "r2")
    assert a["results_sha256"] == b["results_sha256"]
    for key in ("code", "data", "outputs", "steps", "started_at", "finished_at"):
        assert a[key]
    d = a["data"][0]
    assert d["sha256"] and d["content_hash"] and d["rows"] == 31
    assert (case["out"] / "runs" / "r1" / "data_rows.json").exists()
    assert (case["out"] / "approved_code" / f"{a['code']['sha256']}.py").exists()
    ledger = (case["out"] / "lineage.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(ledger) == 2 and json.loads(ledger[0])["step"] == "4-1"


def test_refuses_modified_code(tmp_path):
    case = build_case(tmp_path)
    code = case["confirmed"].parent / "approved_code.py"
    code.write_text(code.read_text(encoding="utf-8") + "\n# 승인 후 수정\n", encoding="utf-8")
    with pytest.raises(CodeHashMismatch):
        run_recompute(Confirmed.load(case["confirmed"]), case["out"], "r1")


def test_refuses_changed_data(tmp_path):
    case = build_case(tmp_path)
    write_csv(case["input"] / "raw" / "conductance.csv", drop_rows=3)
    with pytest.raises(DataChangedError):
        run_recompute(Confirmed.load(case["confirmed"]), case["out"], "r1")


def test_output_inside_input_rejected(tmp_path):
    case = build_case(tmp_path)
    with pytest.raises(RecomputeError):
        run_recompute(Confirmed.load(case["confirmed"]), case["input"] / "out", "r1")


def test_code_failure_is_logged_not_raised(tmp_path):
    case = build_case(tmp_path)
    code = case["confirmed"].parent / "approved_code.py"
    code.write_text("def compute(data, params):\n    raise ValueError('boom')\n", encoding="utf-8")
    c = Confirmed.load(case["confirmed"])
    from measuretrace.backend.common.hashing import sha256_file
    c.code.sha256 = sha256_file(code)
    log = run_recompute(c, case["out"], "r1")
    assert log["status"] == "failed" and "boom" in log["error"]
    assert all(o["status"] == "failed" for o in log["outputs"].values())


def test_sandbox_has_no_api_key(tmp_path, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-should-not-leak")
    case = build_case(tmp_path)
    code = case["confirmed"].parent / "approved_code.py"
    code.write_text("import os\ndef compute(data, params):\n"
                    "    return {'outputs': {'n_annealed': float('ANTHROPIC_API_KEY' in os.environ)}}\n",
                    encoding="utf-8")
    c = Confirmed.load(case["confirmed"])
    from measuretrace.backend.common.hashing import sha256_file
    c.code.sha256 = sha256_file(code)
    log = run_recompute(c, case["out"], "r1")
    assert log["outputs"]["n_annealed"]["value"] == 0.0
    assert log["status"] == "partial"      # 나머지 승인 항목은 코드가 내지 않음
