"""허용오차 ②(유효 자릿수 반올림)와 단위 환산."""
import pytest

from measuretrace.backend.common.units import UnitError, convert
from measuretrace.backend.validate.rounding import (fmt, matches, parse_reported, power_of_ten_factor, round_like,
                                            tool_accuracy_ok)


@pytest.mark.parametrize("text, x, ok", [
    ("7.6", 7.62, True),          # 파이프라인 문서 예: 7.6 nS vs 7.62
    ("7.6", 7.94, False),         # 오류코드 E05 예: 7.94 → 7.9 ≠ 7.6
    ("7.60", 7.62, False),        # 소수 둘째 자리까지 보고했으면 7.62 ≠ 7.60
    ("7.65", 7.65, True),
    ("7.7", 7.65, True),          # 사사오입
    ("1200", 1234, True),         # 끝의 0 은 유효숫자 아님 → 100 단위
    ("1230", 1234, True),
    ("3.2e-5", 3.24e-5, True),
    ("3.2×10⁻⁵", 3.26e-5, False),
    ("-0.8", -0.84, True),
    ("1,234", 1234.4, True),
    ("0.0", 0.04, True),
])
def test_significant_digit_rounding(text, x, ok):
    assert matches(x, parse_reported(text))[0] is ok


def test_round_display():
    assert fmt(round_like(7.6249, parse_reported("7.62"))) == "7.62"


def test_tool_accuracy():
    assert tool_accuracy_ok(1.0000005, 1.0)
    assert not tool_accuracy_ok(1.00001, 1.0)
    assert tool_accuracy_ok(0.0, 0.0) and not tool_accuracy_ok(1e-12, 0.0)


def test_unit_conversion_and_aliases():
    assert convert(3.2e-9, "S", "nS") == pytest.approx(3.2)
    assert convert(1.0, "kohm/sq", "Ω/□") == pytest.approx(1000.0)
    assert convert(0.12, None, "%") == pytest.approx(12.0)
    with pytest.raises(UnitError):
        convert(1.0, "S", "m")


def test_power_of_ten_detection():
    # 보고 "3.2 mS", 재계산 3.2 S 를 mS 로 환산하면 3200 → 10^-3 배
    assert power_of_ten_factor(3200.0, parse_reported("3.2")) == -3
    assert power_of_ten_factor(3.3, parse_reported("3.2")) is None
