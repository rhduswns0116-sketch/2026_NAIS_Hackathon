"""RC-01~06 회귀: 합성 RAW만 사용하고 실행 여부·승인/로그 일관성·원본 보존을 확인한다."""
import json
import os
import subprocess
from pathlib import Path

import pytest
from case_builder import FakeClient, build_case

from measuretrace.backend.common.hashing import canonical_json, sha256_file, sha256_text
from measuretrace.backend.contract import ApprovedCode, Column, Confirmed, DataFile, Equation, Flag, Output, Pending
from measuretrace.backend.pipeline import run_backend
from measuretrace.backend.recompute import RecomputeError, run_recompute
from measuretrace.backend.recompute import engine


NORMAL_CODE = """from math import sqrt as square_root
def compute(data, params):
    return {'outputs': {'mean': float(data['raw']['x'].mean()) * params['factor']['value']},
            'steps': [{'name': 'sqrt', 'value': square_root(9)}]}
"""


def make_case(tmp_path, code=NORMAL_CODE):
    raw_dir, front = tmp_path / "input", tmp_path / "front"
    raw_dir.mkdir()
    front.mkdir()
    raw = raw_dir / "values.csv"
    raw.write_text("x,unused\n2,1\n4,1\n", encoding="utf-8")
    approved = front / "approved.py"
    approved.write_text(code, encoding="utf-8")
    c = Confirmed("guard-test", str(raw_dir),
                  [DataFile("raw", "values.csv", sha256_file(raw),
                            columns={"x": Column("값", "1"), "unused": Column("사용하지 않는 열", "1")})],
                  ApprovedCode("approved.py", sha256_file(approved), params={"factor": {"value": 1}}),
                  [Output("mean", "평균", "value", equations=["EQ1"], depends_on=["raw#x"])],
                  equations=[Equation("EQ1", "mean(x)")], base_dir=str(front))
    c.seal_approval("researcher")
    return c, tmp_path / "out"


@pytest.mark.parametrize("kind", ["equation", "output", "column", "file", "item", "unit", "flag_unit", "flag_anomaly"])
def test_unconfirmed_dependency_never_starts_compute(tmp_path, monkeypatch, kind):
    c, out = make_case(tmp_path)
    if kind == "unit":
        c.data[0].columns["x"].unit_status = "unresolved"
    elif kind.startswith("flag_"):
        c.flags = [Flag("E01" if kind == "flag_unit" else "E02", "raw#x", "승인 대기", "unresolved")]
    else:
        target = {"equation": "eq:EQ1", "output": "mean", "column": "raw#x", "file": "raw",
                  "item": "item:sample_B"}[kind]
        if kind == "item":
            c.outputs[0].depends_on.append(target)
        c.pending = [Pending(target, "확인 대기")]
    c.seal_approval("researcher")

    def forbidden(*args, **kwargs):
        pytest.fail("미확정 의존 코드가 실행됨")

    monkeypatch.setattr(engine, "_run_sandboxed", forbidden)
    log = run_recompute(c, out, "blocked")
    assert log["status"] == "blocked" and log["runner"]["executed"] is False
    assert log["execution_gate"]["blocked_dependencies"]
    assert all(o["status"] == "blocked" and o["value"] is None for o in log["outputs"].values())
    assert not (out / "approved_code").exists()


def test_unused_pending_unit_and_proceed_flag_do_not_block(tmp_path):
    c, out = make_case(tmp_path)
    c.data[0].columns["unused"].unit_status = "unresolved"
    c.pending = [Pending("eq:UNUSED", "이번 계산과 무관")]
    c.flags = [Flag("E02", "raw#x", "그대로 진행 승인", "proceed")]
    c.seal_approval("researcher")
    log = run_recompute(c, out, "confirmed")
    assert log["status"] == "ok" and log["outputs"]["mean"]["value"] == 3
    assert not log["execution_gate"]["blocked_dependencies"]


def test_original_contract_changes_do_not_change_running_calculation(tmp_path, monkeypatch):
    c, out = make_case(tmp_path)
    expected_sha = sha256_text(canonical_json(c.to_dict()))
    approved_hash = c.code.approval_hash
    real_fixed = engine._fixed_code

    def change_original_after_approval(execution, root):
        c.code.params["factor"]["value"] = 10
        c.outputs[0].unit = "mS"
        c.data[0].read["skiprows"] = 1
        return real_fixed(execution, root)

    monkeypatch.setattr(engine, "_fixed_code", change_original_after_approval)
    log = run_recompute(c, out, "frozen")
    assert log["status"] == "ok" and log["outputs"]["mean"]["value"] == 3
    assert log["params"] == {"factor": {"value": 1}}
    assert log["confirmed_sha256"] == expected_sha and log["code"]["approval_hash"] == approved_hash
    assert log["outputs"]["mean"]["unit"] is None
    saved = json.loads((out / "runs/frozen/confirmed_snapshot.json").read_text(encoding="utf-8"))
    assert sha256_text(canonical_json(saved)) == expected_sha
    ledger = json.loads((out / "lineage.jsonl").read_text(encoding="utf-8"))
    assert ledger["params"] == log["params"]


def test_backend_uses_same_snapshot_for_all_stages(tmp_path, monkeypatch):
    case = build_case(tmp_path)
    c = Confirmed.load(case["confirmed"])
    c.seal_approval("researcher")
    real_recompute = __import__("measuretrace.backend.pipeline", fromlist=["run_recompute"]).run_recompute

    def mutate_original(execution, *args, **kwargs):
        c.design.groups["annealed"] = 99
        c.code.params["unapproved"] = True
        return real_recompute(execution, *args, **kwargs)

    monkeypatch.setattr("measuretrace.backend.pipeline.run_recompute", mutate_original)
    result = run_backend(c, case["report"], case["out"], FakeClient(case["labels"]), "fake", "backend-frozen")
    assert result["blind"]["blind_ok"] and result["recompute"]["status"] == "ok"
    snapshot = json.loads((case["out"] / "runs/backend-frozen/confirmed_snapshot.json").read_text(encoding="utf-8"))
    assert snapshot["design"]["groups"]["annealed"] == 5
    assert "unapproved" not in snapshot["code"]["params"]


def directory_link(path, target):
    if os.name == "nt":
        command = "New-Item -ItemType Junction -Path '" + str(path).replace("'", "''") + "' -Target '" \
                  + str(target).replace("'", "''") + "' | Out-Null"
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
                       check=True, capture_output=True)
    else:
        path.symlink_to(target, target_is_directory=True)


@pytest.mark.parametrize("folder", ["runs", "approved_code"])
def test_output_directory_junction_to_raw_is_rejected_before_raw_write(tmp_path, folder):
    c, out = make_case(tmp_path)
    raw = Path(c.input_root)
    before = {str(p.relative_to(raw)): p.read_bytes() for p in raw.rglob("*") if p.is_file()}
    out.mkdir()
    directory_link(out / folder, raw)
    with pytest.raises(RecomputeError, match="출력 경로"):
        run_recompute(c, out, "linked")
    after = {str(p.relative_to(raw)): p.read_bytes() for p in raw.rglob("*") if p.is_file()}
    assert after == before


def test_output_directory_link_to_other_output_is_also_rejected(tmp_path):
    c, out = make_case(tmp_path)
    out.mkdir()
    other = tmp_path / "other"
    other.mkdir()
    directory_link(out / "runs", other)
    with pytest.raises(RecomputeError, match="출력 경로"):
        run_recompute(c, out, "linked")
    assert not list(other.iterdir())


def test_lineage_hard_link_to_raw_is_rejected_before_write(tmp_path):
    c, out = make_case(tmp_path)
    out.mkdir()
    raw = Path(c.input_root) / "values.csv"
    before = raw.read_bytes()
    os.link(raw, out / "lineage.jsonl")
    with pytest.raises(RecomputeError, match="hard link"):
        run_recompute(c, out, "hard-linked")
    assert raw.read_bytes() == before and not (out / "runs").exists()


@pytest.mark.parametrize("field", ["data", "outputs"])
def test_empty_required_list_rejected_without_execution(tmp_path, monkeypatch, field):
    c, out = make_case(tmp_path)
    setattr(c, field, [])
    if field == "data":
        c.outputs[0].depends_on = []
    c.seal_approval("researcher")
    monkeypatch.setattr(engine, "_run_sandboxed", lambda *args, **kwargs: pytest.fail("빈 계약 실행"))
    with pytest.raises(RecomputeError, match="목록이 비어"):
        run_recompute(c, out, "empty")
    assert not out.exists()


@pytest.mark.parametrize("source", [
    "from builtins import eval as evaluate\nevaluate('2 + 3')",
    "from builtins import exec as execute\nexecute('x = 3')",
    "from builtins import getattr as lookup\nlookup(1, 'real')",
    "from sys import modules as registry\n",
    "import builtins as b\nb.eval('2 + 3')",
    "from builtins import *\n",
])
def test_forbidden_import_aliases_cannot_execute(tmp_path, source):
    c, out = make_case(tmp_path, source + "\ndef compute(data, params):\n    return {'outputs': {'mean': 5}}\n")
    log = run_recompute(c, out, "forbidden")
    assert log["status"] == "failed" and "PermissionError" in log["error"]
    assert log["outputs"]["mean"]["value"] is None


def test_job_params_tampering_is_detected_by_runner(tmp_path, monkeypatch):
    c, out = make_case(tmp_path)
    real_process = engine.subprocess.run

    def change_job_before_process(command, *args, **kwargs):
        job_path = Path(command[-2])
        job = json.loads(job_path.read_text(encoding="utf-8"))
        job["params"]["factor"]["value"] = 10
        job_path.write_text(json.dumps(job), encoding="utf-8")
        return real_process(command, *args, **kwargs)

    monkeypatch.setattr(engine.subprocess, "run", change_job_before_process)
    log = run_recompute(c, out, "job-tampered")
    assert log["status"] == "failed" and log["outputs"]["mean"]["value"] is None
    assert "해시" in log["error"] or "hash" in log["error"]
    assert log["params"]["factor"]["value"] == 1
