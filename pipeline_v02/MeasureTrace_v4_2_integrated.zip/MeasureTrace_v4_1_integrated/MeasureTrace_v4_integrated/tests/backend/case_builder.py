"""테스트·데모용 합성 케이스 — 어닐링 전후 박막 전도도.

설계: 시료 10개(어닐링 전 5, 후 5) × 위치 3개(기술적 반복). 독립 단위 = 시료.
계획서 식: G = 1/R, 시료별 평균 → 집단 평균, 2표본 t 검정(등분산) → 자유도 8.
보고서에는 일부러 오류를 넣는다: E05(수치·t 값), E04(t(28) — 위치 30개를 독립으로 셈), E06(계획서에 없는 면저항),
E01(nS 를 mS 로 잘못 씀), 그리고 문헌 인용·정성 문장·정도 표현.
정답(benchmark)은 승인 코드와 별개로 표준 라이브러리만으로 계산한다 (도구 정확도 ① 확인용).
"""
from __future__ import annotations

import json
import math
import re
import statistics
from pathlib import Path
from types import SimpleNamespace

from measuretrace.backend.common.hashing import sha256_file
from measuretrace.backend.contract import (ApprovedCode, Column, Confirmed, DataFile, Design, Equation, Flag, Output,
                                   Test)

R_BASE = {"as_deposited": [1.30e8, 1.32e8, 1.28e8, 1.31e8, 1.29e8],
          "annealed": [1.05e8, 1.07e8, 1.04e8, 1.06e8, 1.03e8]}
OFFSETS = [-0.01e8, 0.0, 0.012e8]

APPROVED_CODE = '''"""승인된 계산 코드 (LLM 초안 → 3-1 승인). 계획서 식 EQ01~EQ03."""
from scipy import stats


def compute(data, params):
    df = data["raw"].copy()
    df["G_S"] = 1.0 / df["resistance_ohm"]                         # EQ01 G = 1/R
    per_sample = df.groupby(["condition", "sample_id"])["G_S"].mean()  # 기술적 반복 → 시료 평균
    an = per_sample.loc["annealed"].to_numpy()
    ad = per_sample.loc["as_deposited"].to_numpy()
    g_an, g_ad = float(an.mean()), float(ad.mean())                 # EQ02 집단 평균
    t, p = stats.ttest_ind(an, ad, equal_var=True)                  # EQ03 2표본 t
    return {
        "outputs": {
            "G_mean_annealed": g_an,
            "G_mean_as_deposited": g_ad,
            "G_diff": g_an - g_ad,
            "G_pct_change": (g_an - g_ad) / g_ad * 100.0,
            "t_stat": float(t),
            "p_value": float(p),
            "df": len(an) + len(ad) - 2,
            "n_annealed": len(an),
            "n_as_deposited": len(ad),
        },
        "steps": [
            {"name": "행 수", "value": len(df)},
            {"name": "시료 수 (어닐링 후)", "value": len(an)},
            {"name": "시료 수 (어닐링 전)", "value": len(ad)},
        ],
    }
'''


def write_csv(path: Path, drop_rows: int = 0) -> None:
    rows = ["sample_id,condition,position,resistance_ohm"]
    for cond, bases in R_BASE.items():
        prefix = "AN" if cond == "annealed" else "AD"
        for i, base in enumerate(bases, start=1):
            for j, off in enumerate(OFFSETS, start=1):
                rows.append(f"{prefix}{i:02d},{cond},{j},{base + off:.0f}")
    if drop_rows:
        rows = rows[:-drop_rows]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(("\n".join(rows) + "\n").encode("utf-8"))   # OS 와 상관없이 LF


def benchmark(csv_path: Path) -> dict:
    """표준 라이브러리로 독립 계산한 정답 (반올림 전)."""
    per = {}
    for line in csv_path.read_text(encoding="utf-8").splitlines()[1:]:
        sid, cond, _, r = line.split(",")
        per.setdefault(cond, {}).setdefault(sid, []).append(1.0 / float(r))
    means = {c: [statistics.fmean(v) for v in d.values()] for c, d in per.items()}
    an, ad = means["annealed"], means["as_deposited"]
    n1, n2 = len(an), len(ad)
    sp2 = ((n1 - 1) * statistics.variance(an) + (n2 - 1) * statistics.variance(ad)) / (n1 + n2 - 2)
    t = (statistics.fmean(an) - statistics.fmean(ad)) / math.sqrt(sp2 * (1 / n1 + 1 / n2))
    return {"G_mean_annealed": statistics.fmean(an), "G_mean_as_deposited": statistics.fmean(ad),
            "G_diff": statistics.fmean(an) - statistics.fmean(ad), "t_stat": t, "df": n1 + n2 - 2}


def make_confirmed(root: Path, input_dir: Path, csv_rel: str, flags: list[Flag] | None = None,
                   pending=None, tests: list[Test] | None = None) -> Path:
    front = root / "front_out"
    front.mkdir(parents=True, exist_ok=True)
    code_path = front / "approved_code.py"
    if not code_path.exists():
        code_path.write_text(APPROVED_CODE, encoding="utf-8")
    raw_deps = ["raw#resistance_ohm", "raw#sample_id", "raw#condition"]
    g_terms = ["전도도", "conductance"]
    value_outputs = [
        Output("G_mean_annealed", "어닐링 후 시료의 평균 전도도", "value", "S", ["EQ01", "EQ02"], raw_deps, ["annealed"],
               g_terms),
        Output("G_mean_as_deposited", "어닐링 전(증착 직후) 시료의 평균 전도도", "value", "S", ["EQ01", "EQ02"], raw_deps,
               ["as_deposited"], g_terms),
        Output("G_diff", "어닐링 후 − 전 평균 전도도 차이", "difference", "S", ["EQ01", "EQ02"], raw_deps,
               ["annealed", "as_deposited"], g_terms),
        Output("G_pct_change", "어닐링 전 대비 후 평균 전도도 변화율", "percent_change", "percent", ["EQ01", "EQ02"],
               raw_deps, ["annealed", "as_deposited"], g_terms),
        Output("t_stat", "어닐링 전후 전도도 2표본 t 통계량", "test_statistic", None, ["EQ03"], raw_deps),
        Output("p_value", "어닐링 전후 전도도 2표본 t 검정 p 값", "p_value", None, ["EQ03"], raw_deps),
        Output("df", "어닐링 전후 2표본 t 검정 자유도", "df", None, ["EQ03"], raw_deps),
        Output("n_annealed", "어닐링 후 시료 수", "n", None, [], ["raw#sample_id"], ["annealed"]),
        Output("n_as_deposited", "어닐링 전 시료 수", "n", None, [], ["raw#sample_id"], ["as_deposited"]),
    ]
    confirmed = Confirmed(
        project_id="demo-anneal-conductance",
        input_root=str(input_dir),
        data=[DataFile("raw", csv_rel, sha256_file(input_dir / csv_rel), None, {},
                       {"sample_id": Column("시료 번호"), "condition": Column("열처리 조건"),
                        "position": Column("측정 위치 (기술적 반복)"),
                        "resistance_ohm": Column("I–V 기울기로 구한 저항", "ohm")})],
        code=ApprovedCode("approved_code.py", sha256_file(code_path), params={}, llm_drafted=True,
                          approved_by="researcher", approved_at="2026-09-29T10:00:00+09:00"),
        outputs=value_outputs,
        equations=[Equation("EQ01", r"G=\frac{1}{R}", "식 1. 위치별 전도도는 저항의 역수로 구한다."),
                   Equation("EQ02", r"\overline{G}=\frac{1}{n}\sum_{i=1}^{n}G_{i}", "식 2. 시료 평균의 집단 평균."),
                   Equation("EQ03", r"t=\frac{\overline{G}_{A}-\overline{G}_{B}}{s_p\sqrt{1/n_A+1/n_B}}",
                            "식 3. 등분산 2표본 t 검정.")],
        design=Design("시료", {"annealed": 5, "as_deposited": 5}, 3,
                      tests if tests is not None else
                      [Test("T1", "student_t", ["annealed", "as_deposited"], 0.05, "p_value", "t_stat", "df",
                            "시료 평균으로 어닐링 전후 비교")]),
        flags=flags or [],
        pending=pending or [],
        confirm_rounds=2,
    )
    path = front / "confirmed.json"
    confirmed.save(path)
    return path


def report_sentences(bench: dict) -> tuple[list[str], list[str]]:
    ad = f"{bench['G_mean_as_deposited'] * 1e9:.2f}"
    an_wrong = f"{bench['G_mean_annealed'] * 1e9 + 0.5:.2f}"
    diff_ms = f"{bench['G_diff'] * 1e9:.2f}"
    page1 = [
        "결과",
        f"어닐링 전 시료의 평균 전도도는 {ad} nS였다.",
        f"어닐링 후 시료의 평균 전도도는 {an_wrong} nS로 어닐링 전보다 높았다.",
        "어닐링 후 전도도는 유의하게 증가하였다 (t(28) = 6.10, p < 0.001).",
    ]
    page2 = [
        "선행 연구에서는 유사한 박막의 전도도가 5 nS로 보고되었다 [3].",
        "박막 표면은 균일하게 형성되었다.",
        "어닐링 후 면저항은 12 % 감소하였다.",
        f"어닐링에 따른 전도도 증가량은 {diff_ms} mS였다.",
        "측정은 시료 10개에 대해 수행하였다 (n = 10).",
        "어닐링 후 전도도가 크게 증가하였다.",
        "참고문헌",
        "[3] Kim, J. et al. Annealing of oxide thin films. Thin Solid Films 2020, 712, 138.",
    ]
    return page1, page2


def write_report(path: Path, bench: dict) -> None:
    import docx
    from docx.enum.text import WD_BREAK
    page1, page2 = report_sentences(bench)
    d = docx.Document()
    for s in page1:
        d.add_paragraph(s)
    d.paragraphs[-1].add_run().add_break(WD_BREAK.PAGE)
    for s in page2:
        d.add_paragraph(s)
    path.parent.mkdir(parents=True, exist_ok=True)
    d.save(str(path))


# ---------------------------------------------------------------------------
# 가짜 LLM — 실제 API 대신 정해진 답을 돌려준다 (토큰 0)
# ---------------------------------------------------------------------------
def item(**kw) -> dict:
    base = {k: None for k in ("value_text", "unit", "statistic", "output_id", "relation", "lhs_output", "rhs_output",
                              "degree_word", "significant", "test_id", "test_name", "df_text", "n_text", "p_text",
                              "p_comparator")}
    return {**base, **kw}


def canned_labels(bench: dict) -> dict[str, dict]:
    """문장 일부 → LLM 이 돌려줄 분류."""
    p1, p2 = report_sentences(bench)
    ad = p1[1].split("는 ")[1].split(" nS")[0]
    an_wrong = p1[2].split("는 ")[1].split(" nS")[0]
    diff_ms = p2[3].split("증가량은 ")[1].split(" mS")[0]

    def row(cat, claims=(), refs=(), lit=()):
        return {"category": cat, "citation_refs": list(refs), "literature_values": list(lit), "claims": list(claims)}
    return {
        "어닐링 전 시료의 평균": row("numeric", [item(claim_type="numeric", source_text=f"평균 전도도는 {ad} nS",
                                                 value_text=ad, unit="nS", statistic="mean",
                                                 output_id="G_mean_as_deposited")]),
        "어닐링 후 시료의 평균": row("numeric", [
            item(claim_type="numeric", source_text=f"평균 전도도는 {an_wrong} nS", value_text=an_wrong, unit="nS",
                 statistic="mean", output_id="G_mean_annealed"),
            item(claim_type="direction", source_text="어닐링 전보다 높았다", relation="greater",
                 lhs_output="G_mean_annealed", rhs_output="G_mean_as_deposited")]),
        "유의하게 증가": row("significance", [
            item(claim_type="significance", source_text="유의하게 증가하였다 (t(28) = 6.10, p < 0.001)",
                 significant=True, test_id="T1", test_name="t-test", df_text="28",
                 p_text="< 0.001", p_comparator=None),     # 실제 LLM 이 낸 모양 그대로 (부등호가 숫자 칸에)
            item(claim_type="numeric", source_text="t(28) = 6.10", value_text="6.10", statistic="t",
                 output_id="t_stat")]),
        "선행 연구": row("citation", refs=["[3]"], lit=["5 nS"]),
        "균일하게": row("qualitative"),
        "면저항": row("numeric", [item(claim_type="numeric", source_text="면저항은 12 % 감소", value_text="12", unit="%",
                                   statistic="percent_change")]),
        "증가량은": row("numeric", [item(claim_type="numeric", source_text=f"증가량은 {diff_ms} mS",
                                      value_text=diff_ms, unit="mS", statistic="difference", output_id="G_diff")]),
        "시료 10개": row("numeric", [item(claim_type="numeric", source_text="n = 10", value_text="10", statistic="n")]),
        "크게 증가": row("degree", [item(claim_type="direction", source_text="크게 증가하였다", relation="greater",
                                     lhs_output="G_mean_annealed", rhs_output="G_mean_as_deposited",
                                     degree_word="크게")]),
    }


class FakeClient:
    """messages.create 만 흉내 낸다. 시스템 프롬프트로 5-1 / 6-1 호출을 구분."""
    is_fake = True

    def __init__(self, labels: dict[str, dict], bad_explanation_for: set[str] | None = None):
        self.labels = labels
        self.bad = bad_explanation_for or set()
        self.calls: list[dict] = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kw):
        self.calls.append(kw)
        system, user = kw["system"], kw["messages"][0]["content"]
        if "문장을 분류" in system:
            data = {"sentences": []}
            for sid, text in re.findall(r"^\[(S\d+)\] (.*)$", user, re.M):
                label = next((v for k, v in self.labels.items() if k in text),
                             {"category": "none", "citation_refs": [], "literature_values": [], "claims": []})
                data["sentences"].append({"sid": sid, **json.loads(json.dumps(label))})
        else:
            data = {"explanations": []}
            for cid, block in re.findall(r"^\[(S\d+-\d+)\](.*?)(?=^\[S|\Z)", user, re.M | re.S):
                if cid in self.bad:
                    text = "재계산값이 3배 차이납니다."          # 숫자 → 거절돼야 함
                else:
                    from measuretrace.backend.audit.explain import ADVICE
                    text = ADVICE[0]
                data["explanations"].append({"claim_id": cid, "text": text})
        return SimpleNamespace(content=[SimpleNamespace(type="text", text=json.dumps(data, ensure_ascii=False))],
                               stop_reason="end_turn", model="fake", id=f"fake-{len(self.calls)}")


def build_case(root: Path, flags: list[Flag] | None = None) -> dict:
    input_dir, report = root / "input", root / "report_inbox" / "final_report.docx"
    write_csv(input_dir / "raw" / "conductance.csv")
    bench = benchmark(input_dir / "raw" / "conductance.csv")
    confirmed = make_confirmed(root, input_dir, "raw/conductance.csv", flags=flags)
    write_report(report, bench)
    return {"root": root, "input": input_dir, "report": report, "confirmed": confirmed, "out": root / "out",
            "bench": bench, "labels": canned_labels(bench)}
