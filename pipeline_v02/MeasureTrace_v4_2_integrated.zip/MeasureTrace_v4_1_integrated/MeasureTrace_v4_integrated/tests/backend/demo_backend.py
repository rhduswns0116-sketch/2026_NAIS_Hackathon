"""데모 — 합성 케이스로 뒷단 전체를 돌리고 리포트를 만든다.

  python scripts/demo.py            가짜 LLM (토큰 0)
  python scripts/demo.py --real     실제 Claude API 호출 (토큰 사용! .env 의 LLM_API_KEY 필요)
  python scripts/demo.py --rerun    데이터를 고쳐 한 번 더 — 6-2 재평가(E07·판정 변화)까지
결과: demo_run/out/runs/<실행>/audit_report.md
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]   # practice_v4
sys.path[:0] = [str(ROOT), str(ROOT / "tests" / "backend")]

from case_builder import FakeClient, build_case, make_confirmed, write_csv  # noqa: E402

from measuretrace.backend.common.llm import make_client  # noqa: E402
from measuretrace.backend.pipeline import run_backend  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", action="store_true", help="실제 Claude API 사용 (토큰 사용)")
    ap.add_argument("--dir", default=str(ROOT / "workspace" / "backend_demo"))
    ap.add_argument("--rerun", action="store_true", help="데이터를 고쳐 한 번 더 실행 (6-2 재평가)")
    args = ap.parse_args()
    root = Path(args.dir)
    shutil.rmtree(root, ignore_errors=True)
    case = build_case(root)
    if args.real:
        client, model = make_client(ROOT / ".env")
        if client is None:
            print("LLM_API_KEY(또는 ANTHROPIC_API_KEY)가 없음 — .env 를 확인", file=sys.stderr)
            return 1
    else:
        client, model = FakeClient(case["labels"]), "fake"
    runs = [run_backend(case["confirmed"], case["report"], case["out"], client=client, model=model)]
    if args.rerun:
        # 6-2 시연: 연구자가 마지막 시료(3행)를 지운 파일로 다시 올림 → 앞단이 새 해시로 confirmed.json 을 다시 씀
        write_csv(case["input"] / "raw" / "conductance.csv", drop_rows=3)
        make_confirmed(root, case["input"], "raw/conductance.csv")
        runs.append(run_backend(case["confirmed"], case["report"], case["out"], client=client, model=model))
    for result in runs:
        s = result["summary"]
        print(f"[{result['run_id']}] Supported {s['Supported']} · Unsupported {s['Unsupported']} · "
              f"검사 대상 아님 {s['검사 대상 아님']} · 구조화 실패 {s['구조화 실패']} · 코드 {s['codes']}")
        print("  ", case["out"] / "runs" / result["run_id"] / "audit_report.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
