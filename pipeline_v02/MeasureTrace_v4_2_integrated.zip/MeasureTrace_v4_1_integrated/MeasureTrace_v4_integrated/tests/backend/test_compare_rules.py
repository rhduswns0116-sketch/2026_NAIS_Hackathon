﻿"""5-2 규칙 단위 테스트 — 파이프라인 없이 비교 함수만."""
from case_builder import build_case, item

from measuretrace.backend.contract import Confirmed
from measuretrace.backend.contract import Test as TestSpec
from measuretrace.backend.validate.compare import compare_claim, expected_df
from measuretrace.backend.validate.report_reader import read_report, reference_text


def _setup(tmp_path):
    case = build_case(tmp_path)
    c = Confirmed.load(case["confirmed"])
    calc = {"outputs": {o.id: {"status": "ok", "value": v, "unit": c.output(o.id).unit}
                        for o, v in zip(c.outputs, [9.5e-9, 7.7e-9, 1.8e-9, 23.4, 23.9, 1e-8, 8, 5, 5])}}
    return c, calc


def _claim(sentence="어닐링 후 전도도 측정 결과", **kw):
    return {"claim_id": "S001-1", "source_text": "x", "sentence": sentence, **item(**kw)}


def test_missing_report_unit_is_e01(tmp_path):
    c, calc = _setup(tmp_path)
    out = compare_claim(_claim(claim_type="numeric", value_text="9.5", unit=None, output_id="G_mean_annealed"),
                        c, calc)
    assert [k["code"] for k in out["codes"]] == ["E01"]


def test_dimension_mismatch_is_e01(tmp_path):
    c, calc = _setup(tmp_path)
    out = compare_claim(_claim(claim_type="numeric", value_text="9.5", unit="nm", output_id="G_mean_annealed"),
                        c, calc)
    assert [k["code"] for k in out["codes"]] == ["E01"] and "차원" in out["codes"][0]["reason"]


def test_percent_and_dimensionless(tmp_path):
    c, calc = _setup(tmp_path)
    ok = compare_claim(_claim(claim_type="numeric", value_text="23", unit="%", output_id="G_pct_change"), c, calc)
    assert ok["codes"] == []
    t = compare_claim(_claim(claim_type="numeric", value_text="23.9", statistic="t", output_id="t_stat"), c, calc)
    assert t["codes"] == []                       # 무차원 통계량은 단위 없이 비교


def test_failed_output_is_e06_data_missing(tmp_path):
    c, calc = _setup(tmp_path)
    calc["outputs"]["G_mean_annealed"] = {"status": "failed", "value": None, "error": "boom"}
    out = compare_claim(_claim(claim_type="numeric", value_text="9.5", unit="nS", output_id="G_mean_annealed"),
                        c, calc)
    assert out["codes"][0]["code"] == "E06" and out["codes"][0]["reason_type"] == "데이터 없음"


def test_direction_reversed_is_e05(tmp_path):
    c, calc = _setup(tmp_path)
    out = compare_claim(_claim(claim_type="direction", relation="less", lhs_output="G_mean_annealed",
                               rhs_output="G_mean_as_deposited"), c, calc)
    assert [k["code"] for k in out["codes"]] == ["E05"]


def test_nonsignificant_claim_when_significant_is_e05(tmp_path):
    c, calc = _setup(tmp_path)
    out = compare_claim(_claim(claim_type="significance", significant=False, test_id="T1"), c, calc)
    assert [k["code"] for k in out["codes"]] == ["E05"]


def test_expected_df_rules(tmp_path):
    c, calc = _setup(tmp_path)
    assert expected_df(TestSpec("a", "student_t", ["annealed", "as_deposited"]), c, calc)[0] == [8]
    assert expected_df(TestSpec("b", "paired_t", ["annealed"]), c, calc)[0] == [4]
    assert expected_df(TestSpec("c", "one_way_anova", ["annealed", "as_deposited"]), c, calc)[0] == [1, 8]
    calc["outputs"]["df"]["value"] = 7.83
    assert expected_df(TestSpec("d", "welch_t", ["annealed", "as_deposited"], df_output="df"), c, calc)[0] == [7.83]
    assert expected_df(TestSpec("e", "other", ["annealed"]), c, calc)[0] is None


def test_welch_df_compared_by_rounding(tmp_path):
    c, calc = _setup(tmp_path)
    calc["outputs"]["df"]["value"] = 7.83
    c.design.tests = [TestSpec("W", "welch_t", ["annealed", "as_deposited"], 0.05, "p_value", "t_stat", "df")]
    ok = compare_claim(_claim(claim_type="significance", significant=True, test_id="W", df_text="7.8"), c, calc)
    bad = compare_claim(_claim(claim_type="significance", significant=True, test_id="W", df_text="28"), c, calc)
    assert ok["codes"] == [] and [k["code"] for k in bad["codes"]] == ["E04"]


def test_text_report_pages_and_references(tmp_path):
    p = tmp_path / "report.txt"
    p.write_text("첫 쪽 문장이다. 값은 7.6 nS였다.\f둘째 쪽이다 [2].\n\nReferences\n\n[2] Lee et al. 2019.\n",
                 encoding="utf-8")
    r = read_report(p)
    assert [(s["page"], s["no_in_page"]) for s in r["sentences"]] == [(1, 1), (1, 2), (2, 1)]
    assert reference_text("[2]", r["references"]) == "[2] Lee et al. 2019."
    assert reference_text("[9]", r["references"]) is None


# ---- LLM 짝 후보 검증 (잘못된 Supported 방지) ----
def _e06_no_match(out):
    return [k["code"] for k in out["codes"]] == ["E06"] and out["codes"][0]["reason_type"] == "식 없음" \
        and not out["outputs_used"]


def test_other_metric_with_same_unit_rejected(tmp_path):
    """면저항 12 % 를 전도도 변화율과 짝지어도 — 단위·종류가 같아도 — 거절 (값이 우연히 맞는 경우 대비)."""
    c, calc = _setup(tmp_path)
    calc["outputs"]["G_pct_change"]["value"] = 12.0          # 값이 우연히 같아도
    out = compare_claim(_claim(sentence="어닐링 후 면저항은 12 % 감소하였다.", claim_type="numeric", value_text="12",
                               unit="%", statistic="percent_change", output_id="G_pct_change"), c, calc)
    assert _e06_no_match(out) and "승인 용어" in out["codes"][0]["reason"]


def test_statistic_kind_mismatch_rejected(tmp_path):
    c, calc = _setup(tmp_path)
    p_to_mean = compare_claim(_claim(claim_type="numeric", value_text="0.05", statistic="p",
                                     output_id="G_mean_annealed"), c, calc)
    t_to_p = compare_claim(_claim(claim_type="numeric", value_text="23.9", statistic="t", output_id="p_value"), c, calc)
    null_to_df = compare_claim(_claim(claim_type="numeric", value_text="8", statistic=None, output_id="df"), c, calc)
    assert _e06_no_match(p_to_mean) and _e06_no_match(t_to_p) and _e06_no_match(null_to_df)


def test_direction_needs_value_outputs_with_terms(tmp_path):
    c, calc = _setup(tmp_path)
    wrong_kind = compare_claim(_claim(claim_type="direction", relation="greater", lhs_output="t_stat",
                                      rhs_output="G_mean_as_deposited"), c, calc)
    wrong_metric = compare_claim(_claim(sentence="어닐링 후 면저항이 높았다.", claim_type="direction", relation="greater",
                                        lhs_output="G_mean_annealed", rhs_output="G_mean_as_deposited"), c, calc)
    assert _e06_no_match(wrong_kind) and _e06_no_match(wrong_metric)


def test_empty_terms_skip_with_note(tmp_path):
    c, calc = _setup(tmp_path)
    c.output("G_mean_annealed").terms = []
    out = compare_claim(_claim(sentence="평균은 9.5 nS", claim_type="numeric", value_text="9.5", unit="nS",
                               statistic="mean", output_id="G_mean_annealed"), c, calc)
    assert out["codes"] == [] and any("용어 대조 생략" in n for n in out["notes"])


# ---- 리뷰(2026-09-29) — 변화량 방향어·절 단위 용어·p 표기 ----
def _pct(c, calc, sentence, source, value_text, recomputed):
    calc["outputs"]["G_pct_change"]["value"] = recomputed
    it = {"claim_id": "S001-1", "sentence": sentence,
          **item(claim_type="numeric", source_text=source, value_text=value_text, unit="%",
                 statistic="percent_change", output_id="G_pct_change")}
    return compare_claim(it, c, calc)


def _codes(out):
    return [k["code"] for k in out["codes"]]


def test_decrease_word_sets_sign(tmp_path):
    """'12 % 감소' 는 −12. 맞는 주장이 E05 가 되거나, 틀린 주장이 Supported 가 되면 안 된다."""
    c, calc = _setup(tmp_path)
    s = "어닐링 후 전도도는 12 % 감소하였다."
    assert _codes(_pct(c, calc, s, "전도도는 12 % 감소", "12", -12.0)) == []          # 실제 감소 → 일치
    wrong = _pct(c, calc, s, "전도도는 12 % 감소", "12", 12.0)                        # 실제 증가 → 불일치
    assert _codes(wrong) == ["E05"] and "감소(= -12)" in wrong["codes"][0]["reason"]


def test_increase_word_and_english(tmp_path):
    c, calc = _setup(tmp_path)
    assert _codes(_pct(c, calc, "어닐링 후 전도도는 12 % 증가하였다.", "12 % 증가", "12", 12.0)) == []
    assert _codes(_pct(c, calc, "어닐링 후 전도도는 12 % 증가하였다.", "12 % 증가", "12", -12.0)) == ["E05"]
    assert _codes(_pct(c, calc, "The conductance decreased by 12 %.", "conductance decreased by 12 %", "12",
                       -12.0)) == []


def test_no_direction_word_compares_magnitude_only(tmp_path):
    c, calc = _setup(tmp_path)
    out = _pct(c, calc, "어닐링 전후 전도도 변화율은 12 %였다.", "전도도 변화율은 12 %", "12", -12.0)
    assert _codes(out) == [] and any("크기만" in n for n in out["notes"])


def test_both_direction_words_is_e06(tmp_path):
    c, calc = _setup(tmp_path)
    out = _pct(c, calc, "전도도 감소폭이 12 % 증가하였다.", "전도도 감소폭이 12 % 증가", "12", -12.0)
    assert _codes(out) == ["E06"]


def test_explicit_sign_used_as_is(tmp_path):
    c, calc = _setup(tmp_path)
    assert _codes(_pct(c, calc, "전도도 변화율은 -12 %였다.", "전도도 변화율은 -12 %", "-12", -12.0)) == []
    assert _codes(_pct(c, calc, "전도도 변화율은 -12 %였다.", "전도도 변화율은 -12 %", "-12", 12.0)) == ["E05"]


def test_term_must_be_in_claim_clause(tmp_path):
    """한 문장에 지표가 둘이면 다른 절의 용어를 빌려 짝지을 수 없다."""
    c, calc = _setup(tmp_path)
    other_metric = _pct(c, calc, "면저항은 12 % 감소하였고 전도도는 증가하였다.", "면저항은 12 % 감소", "12", -12.0)
    assert _codes(other_metric) == ["E06"] and other_metric["codes"][0]["reason_type"] == "식 없음"
    own_clause = _pct(c, calc, "어닐링 후 전도도는 12 % 감소하였고 면저항은 증가하였다.", "전도도는 12 % 감소", "12",
                      -12.0)
    assert _codes(own_clause) == []
    noun_go = _pct(c, calc, "전도도는 최고 12 % 감소하였다.", "최고 12 % 감소", "12", -12.0)   # '최고' 는 절 경계 아님
    assert _codes(noun_go) == []


def test_korean_and_english_p_notation_accepted(tmp_path):
    from measuretrace.backend.validate.claims import verify_item
    c, calc = _setup(tmp_path)
    for sentence, source, p, op in [
        ("전도도는 유의하게 증가하였다 (p값 < 0.05).", "유의하게 증가하였다 (p값 < 0.05)", "0.05", "<"),
        ("전도도는 유의하게 증가하였다 (p 값 < 0.05).", "유의하게 증가하였다 (p 값 < 0.05)", "0.05", "<"),
        ("전도도는 유의하게 증가하였다 (P-value = 0.003).", "유의하게 증가하였다 (P-value = 0.003)", "0.003", "="),
    ]:
        it = item(claim_type="significance", source_text=source, significant=True, test_id="T1", p_text=p,
                  p_comparator=op)
        problem, _ = verify_item(it, sentence, c)
        assert problem is None, (sentence, problem)
        assert it["p_comparator"] == op


def test_n_claim_wrong_output_falls_back_to_design(tmp_path):
    c, calc = _setup(tmp_path)
    out = compare_claim(_claim(claim_type="numeric", value_text="10", statistic="n", output_id="G_mean_annealed"),
                        c, calc)
    assert out["codes"] == [] and any("거절" in n for n in out["notes"]) and any("n 일치" in n for n in out["notes"])


# ---- 실제 API 확인(2026-09-30)에서 깨끗한 데모 보고서를 잘못 걸러낸 두 표기 ----
def test_value_word_without_metric_term_uses_unit_dimension(tmp_path):
    """'우리 시료의 값 12.1 nS' — 지표 용어는 없지만 nS 가 전도도 단위라 짝 인정. % 는 여전히 용어 필요."""
    c, calc = _setup(tmp_path)
    calc["outputs"]["G_mean_annealed"]["value"] = 12.1e-9
    it = {"claim_id": "S001-1", "sentence": "우리 어닐링 시료의 값 12.1 nS는 문헌값 11.5 nS [1]와 비슷하다.",
          **item(claim_type="numeric", source_text="우리 어닐링 시료의 값 12.1 nS", value_text="12.1", unit="nS",
                 statistic="mean", output_id="G_mean_annealed")}
    out = compare_claim(it, c, calc)
    assert out["codes"] == [] and any("단위로 지표 확인" in n for n in out["notes"])
    wrong_dim = compare_claim({**it, "unit": "nm", "source_text": "우리 어닐링 시료의 값 12.1 nm",
                               "sentence": "우리 어닐링 시료의 값 12.1 nm였다."}, c, calc)
    assert [k["code"] for k in wrong_dim["codes"]] == ["E06"]      # 차원이 다르면 단위로 지표를 가릴 수 없음


def test_mean_pm_sd_unit_is_accepted_but_borrowing_is_not(tmp_path):
    from measuretrace.backend.validate.claims import verify_item
    c, _ = _setup(tmp_path)
    s = "어닐링 시료의 평균 전도도는 12.1 ± 0.7 nS, 대조 시료는 9.9 ± 1.0 nS였다(각 n = 10)."
    it = item(claim_type="numeric", source_text="어닐링 시료의 평균 전도도는 12.1", value_text="12.1", unit="nS",
              statistic="mean", output_id="G_mean_annealed")
    problem, notes = verify_item(it, s, c)
    assert problem is None and any("±" in n for n in notes)
    borrowed = item(claim_type="numeric", source_text="시료 수는 10", value_text="10", unit="nS", statistic="n")
    problem, _ = verify_item(borrowed, "시료 수는 10, 평균은 12.1 nS였다.", c)
    assert problem and "단위" in problem


def test_table_cells_are_separate_numbers_and_plus_sign_is_unsigned():
    # PDF 표가 한 줄로 풀리면 "37 2.176" 처럼 이웃 칸이 공백으로만 갈린다 — 공백을 지우고 찾으면 372.176 이 됨
    from measuretrace.backend.validate.claims import _number_in, _numbers_in
    assert _number_in("2.176", "Effective diversity 37 2.176 1.139 3.221")
    assert not _number_in("372.176", "Effective diversity 37 2.176")
    assert _number_in("0.1391", "D = -0.000868(NEP)² + 0.1391(NEP)")          # 식의 '+' 는 부호가 아님
    assert _number_in("-3.287", "0.1391(NEP) - 3.287") and not _number_in("3.287", "0.1391(NEP) -3.287")
    assert _number_in("1.2×10^-3", "값 1.2 × 10^-3 mS") and _numbers_in("1, 35", "F(1, 35) = 4.2")

# ---- 다른 언어 보고서(ex2: 한국어 계획서 용어 ↔ 영어 보고서) — 용어 대신 값 유일성으로 짝 확인 ----
def _en(c, calc, sentence, value_text, **kw):
    it = {"claim_id": "S001-1", "sentence": sentence,
          **item(claim_type="numeric", source_text=sentence, value_text=value_text, **kw)}
    return compare_claim(it, c, calc)


def test_cross_language_pair_confirmed_by_unique_value(tmp_path):
    c, calc = _setup(tmp_path)
    c.output("G_pct_change").terms = ["전도도"]
    ok = _en(c, calc, "The value rose by 23.4 %.", "23.4", unit="%", statistic="percent_change",
             output_id="G_pct_change")
    assert ok["codes"] == [] and any("값으로 짝 확인" in n for n in ok["notes"]) and ok["outputs_used"] == ["G_pct_change"]
    wrong = _en(c, calc, "The value rose by 30.0 %.", "30.0", unit="%", statistic="percent_change",
                output_id="G_pct_change")
    assert _e06_no_match(wrong) and "가릴 수 없음" in wrong["codes"][0]["reason"]    # E05 가 아니라 짝 확인 불가
    coarse = _en(c, calc, "The value rose by 20 %.", "20", unit="%", statistic="percent_change",
                 output_id="G_pct_change")
    assert _e06_no_match(coarse) and "유효 자릿수" in coarse["codes"][0]["reason"]


def test_cross_language_value_matching_two_items_is_ambiguous(tmp_path):
    c, calc = _setup(tmp_path)
    for oid in ("G_mean_annealed", "G_mean_as_deposited"):
        c.output(oid).terms, c.output(oid).unit = ["전도도"], None
        calc["outputs"][oid]["value"] = 9.5
    out = _en(c, calc, "The mean was 9.5.", "9.5", statistic="mean", output_id="G_mean_annealed")
    assert _e06_no_match(out) and "G_mean_as_deposited" in out["codes"][0]["reason"]


def test_same_language_keeps_strict_terms_with_bilingual_terms(tmp_path):
    # 용어가 [전도도, conductance] 이면 한국어 문장에도 비교할 낱말이 있다 — 면저항 문장은 값이 맞아도 거절
    c, calc = _setup(tmp_path)
    calc["outputs"]["G_pct_change"]["value"] = -12.0
    out = _en(c, calc, "어닐링 후 면저항은 12 % 감소하였다.", "12", unit="%", statistic="percent_change",
              output_id="G_pct_change")
    assert _e06_no_match(out) and "승인 용어" in out["codes"][0]["reason"]


def test_cross_language_direction_needs_single_metric(tmp_path):
    c, calc = _setup(tmp_path)
    for oid in ("G_mean_annealed", "G_mean_as_deposited"):
        c.output(oid).terms = ["전도도"]
    claim = {"claim_id": "S001-1", "sentence": "Annealed samples were higher than as-deposited ones.",
             **item(claim_type="direction", source_text="Annealed samples were higher", relation="greater",
                    lhs_output="G_mean_annealed", rhs_output="G_mean_as_deposited")}
    ok = compare_claim(claim, c, calc)
    assert ok["codes"] == [] and any("지표 하나뿐" in n for n in ok["notes"])
    from measuretrace.backend.contract import Output
    c.outputs.append(Output("T_mean_annealed", "어닐링 후 평균 두께", "value", "m", [], ["raw#condition"], ["annealed"], ["두께"]))
    c.outputs.append(Output("T_mean_as_deposited", "어닐링 전 평균 두께", "value", "m", [], ["raw#condition"],
                            ["as_deposited"], ["두께"]))
    amb = compare_claim(claim, c, calc)
    assert _e06_no_match(amb) and "다른 지표" in amb["codes"][0]["reason"]