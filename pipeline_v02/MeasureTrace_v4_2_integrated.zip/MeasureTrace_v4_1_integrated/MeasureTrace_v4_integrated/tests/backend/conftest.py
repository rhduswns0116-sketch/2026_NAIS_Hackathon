import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent          # practice_v4/tests/backend
sys.path[:0] = [str(HERE.parents[1]), str(HERE)]   # practice_v4 (measuretrace 패키지) · 동료 시험 도우미(case_builder)
