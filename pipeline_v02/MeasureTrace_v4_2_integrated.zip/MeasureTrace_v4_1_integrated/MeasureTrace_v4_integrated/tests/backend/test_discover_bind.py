"""통합(2026-09-30) — 4단계 탐색 실행(discover) 한 번 + 5·6 항목 결합(bind) 시험. 가짜 LLM, 토큰 0."""
import json

import pytest
from case_builder import FakeClient, build_case

from measuretrace.backend.contract import Confirmed, Pending
from measuretrace.backend.pipeline import run_backend, run_discovery, run_validate_audit
from measuretrace.backend.recompute import RecomputeError, bind_outputs, engine
from measuretrace.backend.validate import BlindnessError


def _bundles(case):
    """(실행 묶음 — 항목 목록 없음, 전체 묶음 — 항목 목록 포함·봉인)."""
    full = Confirmed.load(case["confirmed"])
    exec_ = Confirmed.from_dict(full.to_dict(), base_dir=full.base_dir)
    exec_.outputs, exec_.design.tests = [], []
    exec_.seal_approval("researcher", "2026-09-29T10:00:00+09:00")
    full.seal_approval("reviewer")
    return exec_, full


def test_discover_records_all_values_without_output_list(tmp_path):
    case = build_case(tmp_path)
    exec_, full = _bundles(case)
    calc = run_discovery(exec_, case["out"], "d1")
    assert calc["mode"] == "discover" and calc["status"] == "ok" and calc["outputs"] == {}
    assert set(calc["produced"]) == {o.id for o in full.outputs}
    assert calc["execution_sha256"] == full.execution_sha256()      # 항목 목록은 실행 지문에 들어가지 않음


def test_bind_uses_same_execution_and_preserves_evidence(tmp_path, monkeypatch):
    case = build_case(tmp_path)
    exec_, full = _bundles(case)
    calc = run_discovery(exec_, case["out"], "d1")
    monkeypatch.setattr(engine, "_run_sandboxed", lambda *a, **k: pytest.fail("결합에서 다시 실행함"))
    bound = bind_outputs(full, case["out"], "d1")
    assert bound["mode"] == "bound-after-discover" and bound["binding"]["executions"] == 1
    assert {k: v["value"] for k, v in bound["outputs"].items()} == calc["produced"]
    assert bound["finished_at"] == calc["finished_at"]               # 블라인드 기준인 계산 시각은 그대로
    run_dir = case["out"] / "runs" / "d1"
    assert json.loads((run_dir / "calc_log_discover.json").read_text(encoding="utf-8"))["mode"] == "discover"
    assert (run_dir / "confirmed_snapshot_discover.json").exists()
    assert json.loads((run_dir / "confirmed_snapshot.json").read_text(encoding="utf-8"))["outputs"]
    with pytest.raises(RecomputeError, match="이미"):
        bind_outputs(full, case["out"], "d1")


def test_bind_refuses_changed_execution_or_unsealed_bundle(tmp_path):
    case = build_case(tmp_path)
    exec_, full = _bundles(case)
    run_discovery(exec_, case["out"], "d1")
    changed = Confirmed.from_dict(full.to_dict(), base_dir=full.base_dir)
    changed.code.params = {"factor": 2}
    changed.seal_approval("reviewer")
    with pytest.raises(RecomputeError, match="RAW·코드·파라미터"):
        bind_outputs(changed, case["out"], "d1")
    unsealed = Confirmed.load(case["confirmed"])
    unsealed.code.approval_hash = ""
    with pytest.raises(RecomputeError, match="approval_hash"):
        bind_outputs(unsealed, case["out"], "d1")


def test_discover_blocks_everything_when_anything_is_unresolved(tmp_path, monkeypatch):
    case = build_case(tmp_path)
    exec_, _ = _bundles(case)
    exec_.pending = [Pending("eq:EQ01", "식 1 미확정")]
    exec_.seal_approval("researcher", "2026-09-29T10:00:00+09:00")
    monkeypatch.setattr(engine, "_run_sandboxed", lambda *a, **k: pytest.fail("미확정인데 실행함"))
    calc = run_discovery(exec_, case["out"], "d1")
    assert calc["status"] == "blocked" and calc["runner"]["executed"] is False and calc["produced"] == {}


def test_pending_added_at_bind_withholds_that_value(tmp_path):
    case = build_case(tmp_path)
    exec_, full = _bundles(case)
    run_discovery(exec_, case["out"], "d1")
    full.pending = [Pending("t_stat", "검정 통계량 정의 미확정")]
    full.seal_approval("reviewer")
    bound = bind_outputs(full, case["out"], "d1")
    assert bound["outputs"]["t_stat"]["status"] == "blocked" and bound["outputs"]["t_stat"]["value"] is None
    assert bound["outputs"]["G_mean_annealed"]["status"] == "ok"


def test_validate_audit_matches_single_shot_backend_with_one_execution(tmp_path, monkeypatch):
    case = build_case(tmp_path / "one")
    single = run_backend(case["confirmed"], case["report"], case["out"], client=FakeClient(case["labels"]),
                         model="fake", previous_run=None)
    case2 = build_case(tmp_path / "two")
    exec_, full = _bundles(case2)
    calls = []
    real = engine._run_sandboxed
    monkeypatch.setattr(engine, "_run_sandboxed", lambda *a, **k: calls.append(1) or real(*a, **k))
    run_discovery(exec_, case2["out"], "d1")
    merged = run_validate_audit(full, case2["report"], case2["out"], "d1", client=FakeClient(case2["labels"]),
                                model="fake", previous_run=None)
    assert calls == [1]                                               # 4~6 전체에서 승인 코드 실행 한 번
    assert merged["summary"] == single["summary"]
    assert [(c["claim_id"], c["verdict"], [k["code"] for k in c["codes"]]) for c in merged["claims"]] == \
        [(c["claim_id"], c["verdict"], [k["code"] for k in c["codes"]]) for c in single["claims"]]
    assert merged["blind"]["blind_ok"]
    with pytest.raises(BlindnessError):                               # 한 실행은 한 번만 감사
        run_validate_audit(full, case2["report"], case2["out"], "d1", client=FakeClient(case2["labels"]), model="fake")
