"""뒷단 전체 (4 → 5 → 6) — 가짜 LLM 클라이언트, 토큰 0."""
import json

import pytest
from case_builder import FakeClient, build_case, make_confirmed, write_csv

from measuretrace.backend.contract import Confirmed, Flag, Pending
from measuretrace.backend.pipeline import run_backend
from measuretrace.backend.validate import BlindnessError, extract_claims


def _run(case, client=None, **kw):
    client = client or FakeClient(case["labels"])
    return run_backend(case["confirmed"], case["report"], case["out"], client=client, model="fake", **kw), client


def _by_source(result):
    return {c["source_text"]: c for c in result["claims"]}


def _codes(claim):
    return sorted({k["code"] for k in claim["codes"]})


def test_verdicts_and_codes(tmp_path):
    case = build_case(tmp_path)
    result, _ = _run(case)
    claims = result["claims"]
    by_id = {c["claim_id"]: c for c in claims}

    # 어닐링 전 평균 — 반올림 일치
    ad = next(c for c in claims if c["outputs_used"] == ["G_mean_as_deposited"])
    assert ad["verdict"] == "Supported" and ad["page"] == 1
    # 어닐링 후 평균 +0.5 nS — E05, 같은 문장의 방향은 Supported
    an = next(c for c in claims if c["outputs_used"] == ["G_mean_annealed"])
    assert an["verdict"] == "Unsupported" and _codes(an) == ["E05"]
    direction = [c for c in claims if c["claim_type"] == "direction"]
    assert all(c["verdict"] == "Supported" for c in direction)
    assert any(c["degree_excluded"] == "크게" for c in direction)
    # 유의성 — p 는 맞지만 t(28): 위치 30개를 독립으로 셈 → E04
    sig = next(c for c in claims if c["claim_type"] == "significance")
    assert sig["verdict"] == "Unsupported" and _codes(sig) == ["E04"]
    assert "p 값 (p < 0.001)" in sig["checks"]          # 부등호가 숫자 칸에 와도 p 대조를 한다
    assert "pseudoreplication" in next(k["reason"] for k in sig["codes"] if k["code"] == "E04")
    # t 값 6.10 — E05
    t = next(c for c in claims if c["outputs_used"] == ["t_stat"])
    assert _codes(t) == ["E05"]
    # 계획서에 없는 면저항 — E06 식 없음
    rs = next(c for c in claims if "면저항" in c["source_text"])
    assert _codes(rs) == ["E06"] and rs["codes"][0]["reason_type"] == "식 없음"
    # nS 를 mS 로 — E01 (10^6 배)
    diff = next(c for c in claims if c["outputs_used"] == ["G_diff"])
    assert _codes(diff) == ["E01"]
    # n = 10 — 설계 합과 일치
    n = next(c for c in claims if c["reported"] == "10")
    assert n["verdict"] == "Supported"

    assert result["summary"]["Supported"] + result["summary"]["Unsupported"] == len(claims)
    cats = {x["category"] for x in result["non_target"]}
    assert {"citation", "qualitative", "none"} <= cats
    cite = next(x for x in result["non_target"] if x["category"] == "citation")
    assert cite["citation_refs"] == ["[3]"] and cite["page"] == 2
    assert cite["reference_texts"][0]["text"].startswith("[3] Kim, J. et al.")   # 참고문헌 원문 기록
    assert not any("Thin Solid Films" in c["sentence"] for c in claims)          # 참고문헌은 주장 아님
    assert len(result["references"]) == 1
    assert by_id  # 모든 주장에 근거
    for c in claims:
        assert c["codes"] or c["checks"], c["claim_id"]
        assert c["code_sha256"]
        for k in c["codes"]:
            assert k["reason"]


def test_every_supported_claim_actually_compared(tmp_path):
    result, _ = _run(build_case(tmp_path))
    for c in result["claims"]:
        if c["verdict"] == "Supported":
            assert c["checks"], c["claim_id"]


def test_blind_order_recorded(tmp_path):
    case = build_case(tmp_path)
    result, _ = _run(case)
    b = result["blind"]
    assert b["blind_ok"] and b["calc_finished_at"] < b["report_opened_at"]


def test_report_cannot_open_before_recompute(tmp_path):
    case = build_case(tmp_path)
    run_dir = case["out"] / "runs" / "x"
    run_dir.mkdir(parents=True)
    with pytest.raises(BlindnessError):
        extract_claims(Confirmed.load(case["confirmed"]), case["report"], run_dir, case["out"],
                       FakeClient(case["labels"]), "fake")


def test_llm_never_sees_measured_values(tmp_path):
    case = build_case(tmp_path)
    result, client = _run(case)
    raw = (case["input"] / "raw" / "conductance.csv").read_text(encoding="utf-8").splitlines()[1]
    resistance = raw.split(",")[-1]
    recomputed = [f"{v['value']:.6g}" for v in result["recompute"]["outputs"].values() if v["value"] is not None]
    for call in client.calls:
        sent = call["system"] + call["messages"][0]["content"]
        assert resistance not in sent
        for r in recomputed:
            if len(r) > 3:   # 짧은 정수(5, 8, 10)는 보고서 문장에도 있어 제외
                assert r not in sent, r


def test_explanations_numbers_filled_by_python(tmp_path):
    case = build_case(tmp_path)
    first = None
    result, _ = _run(case)
    first = result["claims"][0]["claim_id"]
    case2 = build_case(tmp_path / "b")
    result2, _ = _run(case2, client=FakeClient(case2["labels"], bad_explanation_for={first}))
    bad = next(c for c in result2["claims"] if c["claim_id"] == first)
    assert bad["explanation_source"] == "template"     # 숫자를 쓴 LLM 문장은 거절
    others = [c for c in result2["claims"] if c["claim_id"] != first]
    assert all(c["explanation_source"] == "llm" for c in others)
    assert all("{" not in c["explanation"] for c in result2["claims"])


def test_explanation_template_without_llm(tmp_path):
    case = build_case(tmp_path)
    result, _ = _run(case, explain_with_llm=False)
    assert all(c["explanation_source"] == "template" and c["explanation"] for c in result["claims"])


def test_flags_e02_record_and_e03_unsupported(tmp_path):
    flags = [Flag("E02", "raw#resistance_ohm", "AD03 위치 3 값이 사양 범위 상한 근접", "proceed",
                  {"file": "raw/conductance.csv", "row": 9, "column": "resistance_ohm"}, "researcher", "2026-09-29")]
    case = build_case(tmp_path, flags=flags)
    result, _ = _run(case)
    ad = next(c for c in result["claims"] if c["outputs_used"] == ["G_mean_as_deposited"])
    assert ad["verdict"] == "Supported"
    assert any(k["code"] == "E02" and k["effect"] == "record" for k in ad["codes"])
    assert result["records"]

    make_confirmed(tmp_path, case["input"], "raw/conductance.csv",
                   flags=[Flag("E03", "raw#resistance_ohm", "계획서 시료 12개 중 10개만 있음", "missing")],
                   pending=[Pending("G_mean_as_deposited", "어닐링 전 기준 시료 정의")])
    result, _ = _run(case)
    ad = next(c for c in result["claims"] if c["outputs_used"] == ["G_mean_as_deposited"])
    assert ad["verdict"] == "Unsupported" and {"E03", "E06"} <= set(_codes(ad))
    assert any(k.get("reason_type") == "미확정" for k in ad["codes"])


def test_no_test_in_plan_gives_e06_but_direction_still_checked(tmp_path):
    case = build_case(tmp_path)
    make_confirmed(tmp_path, case["input"], "raw/conductance.csv", tests=[])
    result, _ = _run(case)
    sig = next(c for c in result["claims"] if c["claim_type"] == "significance")
    assert _codes(sig) == ["E06"] and sig["codes"][0]["reason_type"] == "검정 방법 없음"
    assert all(c["verdict"] == "Supported" for c in result["claims"] if c["claim_type"] == "direction")


def test_rerun_e07_and_verdict_diff(tmp_path):
    case = build_case(tmp_path)
    first, _ = _run(case, run_id="20260929T100000-a")
    # 연구자가 데이터를 고쳐 다시 올림 → 앞단이 새 해시로 confirmed.json 을 다시 씀
    write_csv(case["input"] / "raw" / "conductance.csv", drop_rows=3)
    make_confirmed(tmp_path, case["input"], "raw/conductance.csv")
    second, _ = _run(case, run_id="20260929T110000-b")
    rr = second["rerun"]
    assert rr["data"]["previous_run"] == "20260929T100000-a"
    ch = rr["data"]["changes"][0]
    assert ch["change"] == "내용 변경" and ch["rows_removed"] == 3 and "3행 감소" in ch["summary"]
    assert any(k["code"] == "E07" and k["effect"] == "record" for c in second["claims"] for k in c["codes"])
    assert any(v["change"] != "변화 없음" for v in rr["verdicts"])
    # 리뷰(2026-09-29): E07 기록만 붙은 주장은 '기록 변화' 로 따로 — 진짜 변화(E01 → E05)가 묻히지 않게
    changes = {v["source_text"]: v["change"] for v in rr["verdicts"]}
    assert changes[next(s for s in changes if "mS" in s)] == "코드 변화"
    assert list(changes.values()).count("기록 변화") >= 5
    md = (case["out"] / "runs" / "20260929T110000-b" / "audit_report.md").read_text(encoding="utf-8")
    assert "E07" in md and "3행 감소" in md


def test_format_only_change_is_not_e07(tmp_path):
    case = build_case(tmp_path)
    _run(case, run_id="20260929T100000-a")
    p = case["input"] / "raw" / "conductance.csv"
    p.write_bytes(p.read_bytes().replace(b"\n", b"\r\n"))    # 개행만 CRLF 로
    make_confirmed(tmp_path, case["input"], "raw/conductance.csv")
    second, _ = _run(case, run_id="20260929T110000-b")
    assert second["rerun"]["data"]["changes"][0]["change"] == "형식만 변경"
    assert not any(k["code"] == "E07" for c in second["claims"] for k in c["codes"])


def test_outputs_written_outside_input(tmp_path):
    case = build_case(tmp_path)
    result, _ = _run(case)
    run_dir = case["out"] / "runs" / result["run_id"]
    for name in ("calc_log.json", "blind_log.json", "claims.json", "audit_result.json", "audit_report.md"):
        assert (run_dir / name).exists(), name
    assert sorted(p.name for p in case["input"].rglob("*")) == ["conductance.csv", "raw"]
    audit_log = (case["out"] / "llm_audit_log.jsonl").read_text(encoding="utf-8").splitlines()
    assert {json.loads(x)["kind"] for x in audit_log} == {"report_claims", "explanations"}


def test_llm_cache_reused(tmp_path):
    case = build_case(tmp_path)
    _, c1 = _run(case, run_id="20260929T100000-a")
    _, c2 = _run(case, run_id="20260929T110000-b")
    assert c1.calls and not c2.calls      # 같은 입력이면 캐시에서
