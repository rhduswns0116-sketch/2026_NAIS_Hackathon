"""2026-09-29 v4 리뷰 회귀 검증. 합성 RAW와 가짜 LLM만 사용한다."""
import copy
import json
from pathlib import Path

import pytest
from case_builder import FakeClient, build_case, item

from measuretrace.backend.audit.rerun import find_previous_run, verdict_changes
from measuretrace.backend.common.hashing import sha256_file
from measuretrace.backend.contract import Confirmed, Pending
from measuretrace.backend.pipeline import run_backend
from measuretrace.backend.recompute import RecomputeError, run_recompute
from measuretrace.backend.recompute import engine
from measuretrace.backend.validate import BlindnessError, classify, extract_claims
from measuretrace.backend.validate.claims import verify_item
from measuretrace.backend.validate.compare import compare_claim


def setup_case(tmp_path):
    case = build_case(tmp_path)
    c = Confirmed.load(case["confirmed"])
    values = [9.5e-9, 7.7e-9, 1.8e-9, 23.4, 23.9, 1e-8, 8, 5, 5]
    calc = {"outputs": {o.id: {"status": "ok", "value": v, "unit": o.unit}
                        for o, v in zip(c.outputs, values)}}
    return case, c, calc


def claim(**kw):
    return item(claim_id="S001-1", source_text="전도도 측정 결과", sentence="전도도 측정 결과", **kw)


@pytest.mark.parametrize("source,value,valid", [
    ("평균 13.20 nS", "3.20", False), ("평균 -3.20 nS", "3.20", False),
    ("평균 3.20e-5 S", "3.20", False), ("평균 3.20×10⁻⁵ S", "3.20", False),
    ("평균 -3.20 nS", "-3.20", True), ("평균 3.20e-5 S", "3.20e-5", True),
    ("평균 3.20×10⁻⁵ S", "3.20×10⁻⁵", True),
])
def test_number_token_keeps_sign_exponent_and_digits(tmp_path, source, value, valid):
    _, c, _ = setup_case(tmp_path)
    row = item(claim_type="numeric", source_text=source, value_text=value)
    problem, _ = verify_item(row, source, c)
    assert (problem is None) == valid


def test_p_and_df_bound_to_original_statistical_notation(tmp_path):
    _, c, _ = setup_case(tmp_path)
    source = "유의하였다 (t(28) = 6.10, p > 0.05)"
    row = item(claim_type="significance", source_text=source, significant=True,
               p_text="0.05", p_comparator="<")
    assert verify_item(row, source, c)[0] is not None
    row = item(claim_type="significance", source_text=source, significant=True, df_text="8")
    assert verify_item(row, source, c)[0] is not None
    row = item(claim_type="significance", source_text=source, significant=True)
    assert verify_item(row, source, c)[0] is None
    assert (row["df_text"], row["p_text"], row["p_comparator"]) == ("28", "0.05", ">")


def test_unit_cannot_be_borrowed_from_other_claim(tmp_path):
    _, c, _ = setup_case(tmp_path)
    row = item(claim_type="numeric", source_text="평균은 3.20", value_text="3.20", unit="nS")
    assert verify_item(row, "평균은 3.20, 차이는 2 nS", c)[0] is not None


@pytest.mark.parametrize("problem", ["missing_design", "missing_welch_df", "failed_n"])
def test_unavailable_n_df_comparison_cannot_support(tmp_path, problem):
    _, c, calc = setup_case(tmp_path)
    if problem == "missing_design":
        c.design.groups = {}
        row = claim(claim_type="numeric", statistic="n", value_text="10")
    elif problem == "missing_welch_df":
        c.design.tests[0].name = "welch_t"
        calc["outputs"].pop("df")
        row = claim(claim_type="numeric", statistic="df", value_text="8", test_id="T1")
    else:
        calc["outputs"]["n_annealed"] = {"status": "failed", "value": None}
        row = claim(claim_type="numeric", statistic="n", value_text="5", output_id="n_annealed")
    cmp = compare_claim(row, c, calc)
    result = classify([row], [cmp], c)[0]
    assert result["verdict"] == "Unsupported"
    assert any(k["code"] == "E06" for k in result["codes"])


def test_welch_df_propagates_pending_dependency(tmp_path):
    _, c, calc = setup_case(tmp_path)
    c.design.tests[0].name = "welch_t"
    c.pending = [Pending("df", "Welch 자유도 확정")]
    row = claim(claim_type="numeric", statistic="df", value_text="8", test_id="T1")
    cmp = compare_claim(row, c, calc)
    assert "df" in cmp["outputs_used"]
    result = classify([row], [cmp], c)[0]
    assert result["verdict"] == "Unsupported"
    assert any(k.get("reason_type") == "미확정" for k in result["codes"])


def test_paired_n_counts_pairs_and_unscoped_two_group_n_is_ambiguous(tmp_path):
    _, c, calc = setup_case(tmp_path)
    row = claim(claim_type="significance", significant=True, test_id="T1", n_text="10")
    assert any(k["code"] == "E06" for k in compare_claim(row, c, calc)["codes"])
    c.design.tests[0].name = "paired_t"
    assert any(k["code"] == "E04" for k in compare_claim(row, c, calc)["codes"])
    row["n_text"], row["n_scope"] = "5", "pairs"
    assert compare_claim(row, c, calc)["codes"] == []


def test_checks_label_alone_does_not_support_and_zip_cannot_drop_claim(tmp_path):
    _, c, _ = setup_case(tmp_path)
    row = claim(claim_type="numeric", value_text="10", statistic="n")
    cmp = {"claim_id": row["claim_id"], "outputs_used": [], "codes": [], "checks": ["검사 예정"]}
    assert classify([row], [cmp], c)[0]["verdict"] == "Unsupported"
    with pytest.raises(ValueError):
        classify([row], [], c)


@pytest.mark.parametrize("reason", ["blank_approval", "pending_code", "changed_bundle"])
def test_unapproved_code_never_executes(tmp_path, reason):
    case, c, _ = setup_case(tmp_path)
    if reason == "blank_approval":
        c.code.approved_by = c.code.approved_at = ""
    elif reason == "pending_code":
        c.pending = [Pending("code", "승인 대기")]
    else:
        c.seal_approval("researcher")
        c.code.params["new_method"] = True
    log = run_recompute(c, case["out"], "blocked")
    assert log["status"] == "blocked" and log["runner"]["executed"] is False
    assert all(o["status"] == "blocked" for o in log["outputs"].values())


def test_raw_change_after_hash_check_uses_verified_snapshot(tmp_path, monkeypatch):
    case, c, _ = setup_case(tmp_path)
    raw_path = case["input"] / "raw" / "conductance.csv"
    original = raw_path.read_bytes()
    real_run = engine._run_sandboxed

    def change_original_then_run(*args, **kw):
        raw_path.write_bytes(original.replace(b"130000000", b"990000000"))
        return real_run(*args, **kw)

    monkeypatch.setattr(engine, "_run_sandboxed", change_original_then_run)
    log = run_recompute(c, case["out"], "snapshot")
    assert log["status"] == "ok"
    assert log["outputs"]["G_mean_as_deposited"]["value"] == pytest.approx(case["bench"]["G_mean_as_deposited"])
    record = log["data"][0]
    saved = case["out"] / "runs" / "snapshot" / record["snapshot_path"]
    assert sha256_file(saved) == record["sha256"] == c.data[0].sha256
    assert sha256_file(raw_path) != record["sha256"]


@pytest.mark.parametrize("target", ["data", "code"])
def test_snapshot_tampering_before_runner_is_rejected(tmp_path, monkeypatch, target):
    case, c, _ = setup_case(tmp_path)
    real_run = engine._run_sandboxed

    def tamper_then_run(code, entrypoint, params, jobs, sandbox, timeout, code_sha):
        path = Path(jobs[0]["path"]) if target == "data" else code
        path.write_text("def compute(data, params):\n    return {'outputs': {'n_annealed': 99}}\n",
                        encoding="utf-8")
        return real_run(code, entrypoint, params, jobs, sandbox, timeout, code_sha)

    monkeypatch.setattr(engine, "_run_sandboxed", tamper_then_run)
    log = run_recompute(c, case["out"], "tampered")
    assert log["status"] == "failed"
    assert "해시" in log["error"] or "사본이 바뀜" in log["error"]
    assert all(o["value"] is None for o in log["outputs"].values())


@pytest.mark.parametrize("action", ["read_report", "write_raw", "network", "subprocess", "exit"])
def test_approved_python_cannot_access_report_or_mutate_raw(tmp_path, action):
    case, c, _ = setup_case(tmp_path)
    raw = case["input"] / "raw" / "conductance.csv"
    before = raw.read_bytes()
    bodies = {
        "read_report": f"from pathlib import Path\nPath({str(case['report'])!r}).read_bytes()",
        "write_raw": f"from pathlib import Path\nPath({str(raw)!r}).write_text('changed')",
        "network": "import socket\nsocket.socket()",
        "subprocess": "import subprocess\nsubprocess.run(['whoami'])",
        "exit": "raise SystemExit(7)",
    }
    c.code_path().write_text(bodies[action] + "\ndef compute(data, params):\n    return {'outputs': {}}\n",
                             encoding="utf-8")
    c.code.sha256 = sha256_file(c.code_path())
    log = run_recompute(c, case["out"], action)
    assert log["status"] == "failed"
    assert ("PermissionError" if action != "exit" else "SystemExit") in log["error"]
    assert raw.read_bytes() == before


def test_reused_run_id_rejected_before_stale_result_can_be_used(tmp_path):
    case, c, _ = setup_case(tmp_path)
    run_recompute(c, case["out"], "once")
    with pytest.raises(RecomputeError, match="이미 존재"):
        run_recompute(c, case["out"], "once")
    with pytest.raises(RecomputeError, match="run_id"):
        run_recompute(c, case["out"], "../escaped")


@pytest.mark.parametrize("value", [True, "5", float("nan"), float("inf"), -1, 5.5])
def test_invalid_numeric_outputs_are_not_used(tmp_path, value):
    _, c, _ = setup_case(tmp_path)
    outputs, _ = engine._check_outputs(c, {"outputs": {"n_annealed": value}})
    assert outputs["n_annealed"]["status"] == "invalid"
    assert outputs["n_annealed"]["value"] is None


def test_numeric_string_not_coerced_to_calculated_number(tmp_path):
    case, c, _ = setup_case(tmp_path)
    c.code_path().write_text("def compute(data, params):\n    return {'outputs': {'n_annealed': '5'}}\n",
                             encoding="utf-8")
    c.code.sha256 = sha256_file(c.code_path())
    log = run_recompute(c, case["out"], "string")
    assert log["outputs"]["n_annealed"]["status"] == "invalid"


def test_report_same_as_raw_and_changed_contract_break_blindness(tmp_path):
    case, c, _ = setup_case(tmp_path)
    with pytest.raises(BlindnessError):
        run_backend(c, case["input"] / c.data[0].path, case["out"])
    run_recompute(c, case["out"], "calculated")
    c.code.params["changed_after_compute"] = True
    with pytest.raises(BlindnessError):
        extract_claims(c, case["report"], case["out"] / "runs" / "calculated", case["out"], None, "fake")


def test_partial_rejection_visible_in_summary_and_markdown(tmp_path):
    case, c, _ = setup_case(tmp_path)
    labels = copy.deepcopy(case["labels"])
    label = labels["어닐링 후 시료의 평균"]
    label["claims"][0]["value_text"] = "999999"
    result = run_backend(c, case["report"], case["out"], FakeClient(labels), "fake", "partial")
    assert result["summary"]["구조화 실패"] == 1
    assert result["rejected_extractions"]
    assert any(c["claim_type"] == "direction" and "어닐링 전보다" in c["source_text"] for c in result["claims"])
    md = (case["out"] / "runs" / "partial" / "audit_report.md").read_text(encoding="utf-8")
    assert "999999" in md and "구조화 실패" in md


def test_corrected_claim_and_duplicates_stay_linked():
    before = {"claim_type": "numeric", "output_id": "mean", "source_text": "평균 13.20 S",
              "verdict": "Unsupported", "codes": [{"code": "E05"}]}
    after = {**before, "source_text": "평균 3.20 S", "verdict": "Supported", "codes": []}
    changes = verdict_changes({"claims": [before, before]}, [after, after])
    assert len(changes) == 2
    assert all(x["change"] == "판정 변화" for x in changes)
    assert len({x["key"] for x in changes}) == 2
    assert all(x["source_text_before"] == before["source_text"] for x in changes)


def test_previous_run_uses_project_and_time_not_run_id_sort(tmp_path):
    runs = tmp_path / "runs"
    for name, project, time in [("zzz-old", "a", "2026-09-29T10:00:00Z"),
                                ("aaa-new", "a", "2026-09-29T11:00:00Z"),
                                ("foreign", "b", "2026-09-29T11:30:00Z")]:
        folder = runs / name
        folder.mkdir(parents=True)
        (folder / "audit_result.json").write_text(json.dumps({"project_id": project, "run_id": name,
                                                             "generated_at": time, "claims": []}),
                                                 encoding="utf-8")
        (folder / "calc_log.json").write_text(json.dumps({"project_id": project, "run_id": name,
                                                         "data": [], "code": {"sha256": "test"}}), encoding="utf-8")
        (folder / "data_rows.json").write_text("{}", encoding="utf-8")
        (folder / "audit_report.md").write_text("# Legacy complete", encoding="utf-8")
    current = runs / "current"
    current.mkdir()
    (current / "calc_log.json").write_text(json.dumps({"started_at": "2026-09-29T12:00:00Z"}), encoding="utf-8")
    assert find_previous_run(tmp_path, "current", "a") == runs / "aaa-new"


def test_foreign_project_rejected_before_compute_and_llm(tmp_path):
    case, c, _ = setup_case(tmp_path)
    previous = tmp_path / "foreign"
    previous.mkdir()
    (previous / "audit_result.json").write_text(json.dumps({"project_id": "other"}), encoding="utf-8")
    client = FakeClient(case["labels"])
    with pytest.raises(ValueError, match="다른 프로젝트"):
        run_backend(c, case["report"], case["out"], client, "fake", previous_run=previous)
    assert not client.calls and not case["out"].exists()


def test_duplicate_ids_and_invalid_design_rejected(tmp_path):
    _, c, _ = setup_case(tmp_path)
    c.data.append(copy.deepcopy(c.data[0]))
    c.design.tests[0].alpha = True
    c.design.replicates_per_unit = 0
    assert {"데이터 id 중복", "검정 T1: alpha는 0과 1 사이여야 함", "기술적 반복 수는 양의 정수여야 함"} <= set(c.problems())
