"""LLM 호출 공통 (common/llm.py) — 실제 API 없이 SDK 응답 모양만 흉내 낸다."""
import json
from types import SimpleNamespace

import pytest

from measuretrace.backend.common import llm

SCHEMA = {"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"],
          "additionalProperties": False}


class BadRequestError(Exception):
    """anthropic.BadRequestError 와 이름이 같은 가짜 (이름으로 판별하므로)."""


class RealLikeClient:
    """is_fake 가 없어 실제 클라이언트처럼 fallback 인자를 받는다."""

    def __init__(self, reject_fallback=False, stop_reason="end_turn", text='{"x": 1}'):
        self.reject_fallback, self.stop_reason, self.text = reject_fallback, stop_reason, text
        self.calls = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kw):
        self.calls.append(kw)
        if self.reject_fallback and "extra_body" in kw:
            raise BadRequestError("fallbacks: unsupported")
        return SimpleNamespace(content=[SimpleNamespace(type="text", text=self.text)], stop_reason=self.stop_reason,
                               model=kw["model"], id="msg_1")


def test_request_shape_and_cache(tmp_path):
    log = llm.LLMLog(tmp_path)
    c = RealLikeClient()
    assert llm.call_json("k", "sys", SCHEMA, "hello", c, "claude-opus-5-5", log) == {"x": 1}
    kw = c.calls[0]
    assert kw["output_config"] == {"format": {"type": "json_schema", "schema": SCHEMA}}
    assert kw["system"] == "sys" and kw["messages"] == [{"role": "user", "content": "hello"}]
    assert kw["extra_body"] == {"fallbacks": "default"} and "anthropic-beta" in kw["extra_headers"]
    assert llm.call_json("k", "sys", SCHEMA, "hello", c, "claude-opus-5-5", log) == {"x": 1}
    assert len(c.calls) == 1   # 두 번째는 캐시
    events = [json.loads(x)["event"] for x in log.audit_path.read_text(encoding="utf-8").splitlines()]
    assert events == ["call", "cache_hit"]


def test_prompt_change_invalidates_cache(tmp_path):
    log, c = llm.LLMLog(tmp_path), RealLikeClient()
    llm.call_json("k", "sys", SCHEMA, "hello", c, "m", log)
    llm.call_json("k", "sys v2", SCHEMA, "hello", c, "m", log)
    assert len(c.calls) == 2


def test_fallback_rejected_retries_without(tmp_path):
    log, c = llm.LLMLog(tmp_path), RealLikeClient(reject_fallback=True)
    assert llm.call_json("k", "sys", SCHEMA, "hi", c, "m", log) == {"x": 1}
    assert len(c.calls) == 2 and "extra_body" not in c.calls[1]
    assert "fallback_rejected" in log.audit_path.read_text(encoding="utf-8")


def test_other_bad_request_not_retried(tmp_path):
    class SchemaRejectClient(RealLikeClient):
        def _create(self, **kw):
            self.calls.append(kw)
            raise BadRequestError("output_config.format.schema: Invalid schema")
    c = SchemaRejectClient()
    with pytest.raises(BadRequestError):
        llm.call_json("k", "sys", SCHEMA, "hi", c, "m", llm.LLMLog(tmp_path))
    assert len(c.calls) == 1


def test_claims_schema_has_no_enum_with_type_list():
    """API 제약: type 이 목록인 곳에 enum 을 같이 쓰면 400 (실제 호출에서 확인)."""
    from measuretrace.backend.audit.explain import SCHEMA as EXPLAIN
    from measuretrace.backend.validate.claims import SCHEMA as CLAIMS

    def walk(node):
        if isinstance(node, dict):
            assert not (isinstance(node.get("type"), list) and "enum" in node), node
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)
    walk(CLAIMS)
    walk(EXPLAIN)


def test_schemas_within_union_field_limit():
    """API 제약: null 허용(type 목록·anyOf) 필드는 스키마 전체 16개까지 — 넘으면 400 (실제 호출에서 확인)."""
    from measuretrace.backend.audit.explain import SCHEMA as EXPLAIN
    from measuretrace.backend.validate.claims import MAX_UNION_FIELDS, SCHEMA as CLAIMS

    def unions(node) -> int:
        if isinstance(node, dict):
            own = int(isinstance(node.get("type"), list) or "anyOf" in node)
            return own + sum(unions(v) for v in node.values())
        if isinstance(node, list):
            return sum(unions(v) for v in node)
        return 0
    assert unions(CLAIMS) <= MAX_UNION_FIELDS
    assert unions(EXPLAIN) <= MAX_UNION_FIELDS


def test_blank_text_fields_become_none(tmp_path):
    """"" 로 받은 '없음'은 None 으로 — 빈 단위가 '단위 있음'으로 읽히면 안 된다."""
    from case_builder import build_case, item
    from measuretrace.backend.contract import Confirmed
    from measuretrace.backend.validate.claims import verify_item
    c = Confirmed.load(build_case(tmp_path)["confirmed"])
    it = item(claim_type="numeric", source_text="평균 전도도는 7.69 nS", value_text="7.69", unit="nS",
              statistic="mean", output_id="G_mean_as_deposited")
    it.update(degree_word="", test_id="", n_group=" ", df_text="")
    problem, _ = verify_item(it, "어닐링 전 시료의 평균 전도도는 7.69 nS였다.", c)
    assert problem is None and it["degree_word"] is None and it["n_group"] is None and it["test_id"] is None
    blank_unit = item(claim_type="numeric", source_text="평균 전도도는 7.69", value_text="7.69", unit="",
                      statistic="mean", output_id="G_mean_as_deposited")
    verify_item(blank_unit, "평균 전도도는 7.69", c)
    assert blank_unit["unit"] is None


def test_explanation_rejects_number_words_and_wrong_direction():
    """리뷰(2026-09-29): 말로 쓴 배수, 판정과 반대인 설명은 LLM 문장을 버리고 템플릿으로."""
    from measuretrace.backend.audit.explain import check
    ph = {"보고값": ("12 %", ""), "재계산값": ("-12 %", "")}
    assert check("재계산값 {재계산값} 은 보고값 {보고값} 의 두 배입니다.", ph, "Unsupported")
    assert check("The recomputed value is twice the reported {보고값}.", ph, "Unsupported")
    assert check("보고값 {보고값} 이 재계산값 {재계산값} 과 일치합니다.", ph, "Unsupported")   # 판정과 반대
    assert check("보고값 {보고값} 이 재계산값 {재계산값} 과 달라 지지되지 않습니다.", ph, "Supported")
    assert check("보고값 {보고값} 이 재계산값 {재계산값} 과 달라 지지되지 않습니다.", ph, "Unsupported") is None
    assert check("보고값 {보고값} 이 재계산값 {재계산값} 과 일치해 지지됩니다. 고칠 부분은 없습니다.", ph, "Supported") is None
    assert check("배경 설명이 필요합니다. 지지되지 않습니다.", ph, "Unsupported") is None   # '배경'의 배는 수량 아님


def test_explanations_batched(tmp_path):
    """주장이 많아도 한 번에 보내지 않는다 — 응답이 잘리면 전부 템플릿이 되므로."""
    from measuretrace.backend.audit import explain
    calls = []

    class Client:
        is_fake = True

        def __init__(self):
            self.messages = SimpleNamespace(create=self.create)

        def create(self, **kw):
            import re
            ids = re.findall(r"^\[(S\d+-\d+)\]", kw["messages"][0]["content"], re.M)
            calls.append(len(ids))
            body = {"explanations": [{"claim_id": i, "text": explain.ADVICE[0]} for i in ids]}
            return SimpleNamespace(content=[SimpleNamespace(type="text", text=json.dumps(body, ensure_ascii=False))],
                                   stop_reason="end_turn", model="m", id="x")
    items = [{"claim": {"claim_id": f"S{i:03d}-1", "source_text": "x"}, "verdict": "Unsupported",
              "comparison": {"reported": None, "recomputed": None},
              "codes": [{"code": "E06", "name": "재계산 대응 없음", "effect": "unsupported", "reason_type": "식 없음",
                         "reason": "없음"}]} for i in range(95)]
    explain.explain_all(items, Client(), "m", llm.LLMLog(tmp_path))
    assert calls == [40, 40, 15] and all(it["explanation_source"] == "llm" for it in items)


def test_fallback_can_be_disabled(tmp_path, monkeypatch):
    monkeypatch.setenv("MT_LLM_FALLBACK", "0")
    c = RealLikeClient()
    llm.call_json("k", "sys", SCHEMA, "hi", c, "m", llm.LLMLog(tmp_path))
    assert "extra_body" not in c.calls[0]


@pytest.mark.parametrize("stop", ["refusal", "max_tokens"])
def test_refusal_and_truncation_fail(tmp_path, stop):
    log = llm.LLMLog(tmp_path)
    with pytest.raises(llm.LLMError):
        llm.call_json("k", "sys", SCHEMA, "hi", RealLikeClient(stop_reason=stop), "m", log)
    assert not list(log.cache_dir.glob("*.json"))     # 실패는 캐시에 남기지 않음


def test_offline_and_missing_client(tmp_path):
    log = llm.LLMLog(tmp_path)
    with pytest.raises(llm.LLMError):
        llm.call_json("k", "sys", SCHEMA, "hi", None, "m", log)
    with pytest.raises(llm.LLMError):
        llm.call_json("k", "sys", SCHEMA, "hi", llm.OfflineClient(), "m", log)


def test_make_client_reads_env(tmp_path, monkeypatch):
    for k in ("LLM_API_KEY", "ANTHROPIC_API_KEY", "LLM_MODEL_STRONG", "MEASURETRACE_OFFLINE"):
        monkeypatch.delenv(k, raising=False)
    env = tmp_path / ".env"
    env.write_text("LLM_MODEL_STRONG=claude-opus-5\n", encoding="utf-8")
    client, model = llm.make_client(env)
    assert client is None and model == "claude-opus-5"
    monkeypatch.setenv("MEASURETRACE_OFFLINE", "1")
    client, _ = llm.make_client(env)
    assert isinstance(client, llm.OfflineClient)
    monkeypatch.delenv("MEASURETRACE_OFFLINE")
    monkeypatch.setenv("LLM_API_KEY", "sk-test")
    client, _ = llm.make_client(env)
    import anthropic
    assert isinstance(client, anthropic.Anthropic)     # 객체만 만들고 호출은 안 함
