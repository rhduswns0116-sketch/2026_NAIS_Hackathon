"""AD-01~07: RAW 보존·설명 일치·응답 대체·완료 근거·시각대 회귀."""
import json
import os
import re
import subprocess
from pathlib import Path

import pytest
from case_builder import FakeClient, build_case
from measuretrace.backend import pipeline
from measuretrace.backend.audit import explain, report, rerun
from measuretrace.backend.audit.storage import AuditError, COMPLETE_FILE, load_completed_run
from measuretrace.backend.common.hashing import file_fingerprint
from measuretrace.backend.common.llm import LLMLog


def item(cid="c1", verdict="Unsupported"):
    return {"claim": {"claim_id": cid, "source_text": "평균 7.6 S"}, "verdict": verdict,
            "comparison": {"reported": "7.6 S", "recomputed": {"raw": 7.94, "unit": "S", "rounded": "7.9"}},
            "codes": [] if verdict == "Supported" else [{"code": "E05", "name": "주장 수치 불일치",
                     "effect": "unsupported", "reason": "보고값과 재계산값이 다름"}]}


@pytest.mark.parametrize("text,verdict", [
    ("고칠 부분은 없습니다. 제출된 자료가 이 주장을 지지합니다.", "Unsupported"),
    ("제출된 자료는 주장을 지지하지 못합니다.", "Supported"),
    ("E07 데이터 버전 변경 때문에 지지되지 않습니다.", "Unsupported"),
    ("보고값은 재계산값의 ٢배여서 지지되지 않습니다.", "Unsupported"),
    ("보고값은 재계산값의 ²배여서 지지되지 않습니다.", "Unsupported"),
    ("보고값은 재계산값의 two times라 지지되지 않습니다.", "Unsupported"),
    ("보고값은 재계산값의 사 배입니다.", "Unsupported"),
])
def test_unsafe_explanation_cannot_replace_python_core(tmp_path, monkeypatch, text, verdict):
    current = item(verdict=verdict)
    monkeypatch.setattr(explain, "call_json", lambda *a, **k: {"explanations": [{"claim_id": "c1", "text": text}]})
    explain.explain_all([current], object(), "fake", LLMLog(tmp_path))
    assert current["explanation_source"] == "template"
    assert current["explanation"] == current["explanation_core"]
    assert current["explanation"].startswith(verdict + ":")
    assert current["explanation_llm_rejected"]
    assert text not in current["explanation"]


@pytest.mark.parametrize("verdict", ["Supported", "Unsupported"])
def test_valid_advice_preserves_core_and_values(tmp_path, monkeypatch, verdict):
    current = item(verdict=verdict)
    monkeypatch.setattr(explain, "call_json", lambda *a, **k: {"explanations": [{"claim_id": "c1", "text": explain.ADVICE[0]}]})
    explain.explain_all([current], object(), "fake", LLMLog(tmp_path))
    assert current["explanation_source"] == "llm" and current["explanation_llm_rejected"] is None
    assert current["explanation"] == current["explanation_core"] + " " + explain.ADVICE[0]
    assert current["explanation_policy"] == explain.EXPLANATION_POLICY
    if verdict == "Supported":
        assert "7.6 S" in current["explanation_core"] and "7.9" in current["explanation_core"]
    else:
        assert "E05" in current["explanation_core"] and "지지되지 않습니다" in current["explanation_core"]


@pytest.mark.parametrize("bad", [123, None, [], {}])
def test_bad_text_only_falls_back_for_affected_claim(tmp_path, monkeypatch, bad):
    items = [item("bad"), item("good")]
    monkeypatch.setattr(explain, "call_json", lambda *a, **k: {"explanations": [
        {"claim_id": "bad", "text": bad}, {"claim_id": "good", "text": explain.ADVICE[0]}]})
    explain.explain_all(items, object(), "fake", LLMLog(tmp_path))
    assert items[0]["explanation_source"] == "template" and items[0]["explanation_status"] == "invalid_response"
    assert items[1]["explanation_source"] == "llm"


def test_duplicate_and_unknown_ids_are_recorded_without_crash(tmp_path, monkeypatch):
    items = [item("duplicate"), item("missing"), item("good")]
    monkeypatch.setattr(explain, "call_json", lambda *a, **k: {"explanations": [
        {"claim_id": "duplicate", "text": explain.ADVICE[0]},
        {"claim_id": "duplicate", "text": explain.ADVICE[1]}, {"claim_id": [], "text": "bad"},
        {"claim_id": "unknown", "text": explain.ADVICE[0]}, {"claim_id": "good", "text": explain.ADVICE[0]}]})
    explain.explain_all(items, object(), "fake", LLMLog(tmp_path))
    assert "중복" in items[0]["explanation_llm_rejected"]
    assert items[1]["explanation_status"] == "missing_response"
    assert items[2]["explanation_source"] == "llm"
    events = [json.loads(line) for line in (tmp_path / "llm_audit_log.jsonl").read_text(encoding="utf-8").splitlines()]
    assert sum(event["event"] == "item_rejected" for event in events) == 2


@pytest.mark.parametrize("body", [[], {}, {"explanations": None}])
def test_invalid_response_container_uses_template(tmp_path, monkeypatch, body):
    current = item()
    monkeypatch.setattr(explain, "call_json", lambda *a, **k: body)
    explain.explain_all([current], object(), "fake", LLMLog(tmp_path))
    assert current["explanation_source"] == "template" and current["explanation_llm_rejected"]


def test_call_failure_and_not_requested_are_distinct(tmp_path, monkeypatch):
    def failed(*args, **kwargs):
        raise RuntimeError("offline")

    monkeypatch.setattr(explain, "call_json", failed)
    failed_item, unused_item = item(), item()
    explain.explain_all([failed_item], object(), "fake", LLMLog(tmp_path))
    explain.explain_all([unused_item], None, "fake", LLMLog(tmp_path), use_llm=False)
    assert failed_item["explanation_status"] == "call_failed"
    assert "offline" in failed_item["explanation_llm_rejected"]
    assert unused_item["explanation_status"] == "not_requested"


def test_invalid_cached_text_is_revalidated(tmp_path):
    from types import SimpleNamespace

    def create(**kwargs):
        body = {"explanations": [{"claim_id": "c1", "text": explain.ADVICE[0]}]}
        return SimpleNamespace(content=[SimpleNamespace(type="text", text=json.dumps(body))], stop_reason="end_turn")

    client = SimpleNamespace(is_fake=True, messages=SimpleNamespace(create=create))
    log = LLMLog(tmp_path)
    explain.explain_all([item()], client, "fake", log)
    path = next((tmp_path / "llm_cache").glob("*.json"))
    cache = json.loads(path.read_text(encoding="utf-8"))
    cache["response"]["explanations"][0]["text"] = 123
    save_json(path, cache)
    current = item()
    explain.explain_all([current], object(), "fake", log)
    assert current["explanation_status"] == "invalid_response" and "문자열" in current["explanation_llm_rejected"]


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def prepared_run(root, name="current", generated="2026-09-29T10:00:00+00:00", legacy=False):
    raw_root = root / "input"
    raw_root.mkdir(exist_ok=True)
    raw = raw_root / "raw.csv"
    if not raw.exists():
        raw.write_text("x\n2\n4\n", encoding="utf-8")
    out = root / "out"
    folder = out / "runs" / name
    folder.mkdir(parents=True)
    fp = file_fingerprint(raw)
    calc = {"run_id": name, "project_id": "p", "started_at": "2026-09-29T09:00:00+00:00",
            "data": [{"id": "raw", "path": "raw.csv", **{k: v for k, v in fp.items() if k != "row_hashes"}}],
            "code": {"sha256": "code"}, "results_sha256": "results"}
    save_json(folder / "calc_log.json", calc)
    save_json(folder / "data_rows.json", {"raw": fp["row_hashes"]})
    save_json(folder / "confirmed_snapshot.json", {"input_root": str(raw_root)})
    result = {"project_id": "p", "run_id": name, "generated_at": generated, "scope_note": "scope",
              "summary": {"Supported": 0, "Unsupported": 0, "검사 대상 아님": 0, "구조화 실패": 0, "codes": {}},
              "blind": {"calc_finished_at": "before", "report_opened_at": "after", "blind_ok": True,
                        "report_sha256": "report"},
              "recompute": {"code_sha256": "code", "results_sha256": "results"},
              "claims": [], "records": [], "non_target": [], "unstructured": [],
              "llm_failures": [], "rejected_extractions": [], "rerun": None}
    if legacy:
        save_json(folder / "audit_result.json", result)
        (folder / "audit_report.md").write_text("# Legacy complete", encoding="utf-8")
    return result, folder, raw, out


@pytest.mark.parametrize("name", ["audit_result.json", "audit_report.md", COMPLETE_FILE])
def test_audit_output_hardlinks_never_change_raw(tmp_path, name):
    result, folder, raw, out = prepared_run(tmp_path)
    before = raw.read_bytes()
    os.link(raw, folder / name)
    with pytest.raises(AuditError, match="hard link"):
        report.write_outputs(result, folder, raw.parent, out)
    assert raw.read_bytes() == before


@pytest.mark.parametrize("name", ["audit_result.json", "audit_report.md"])
def test_backend_audit_hardlink_is_rejected(tmp_path, monkeypatch, name):
    case = build_case(tmp_path)
    raw = case["input"] / "raw" / "conductance.csv"
    before = raw.read_bytes()
    original = pipeline.explain_all

    def linked(*args, **kwargs):
        os.link(raw, case["out"] / "runs" / "linked" / name)
        original(*args, **kwargs)

    monkeypatch.setattr(pipeline, "explain_all", linked)
    with pytest.raises(AuditError, match="hard link"):
        pipeline.run_backend(case["confirmed"], case["report"], case["out"], FakeClient(case["labels"]),
                             "fake", "linked", previous_run=None)
    assert raw.read_bytes() == before
    assert not (case["out"] / "runs" / "linked" / COMPLETE_FILE).exists()


def test_audit_publish_is_complete_and_hash_bound(tmp_path):
    result, folder, raw, out = prepared_run(tmp_path)
    report.write_outputs(result, folder, raw.parent, out)
    loaded = load_completed_run(folder, "p")
    assert loaded["result"]["run_id"] == "current"
    marker = json.loads((folder / COMPLETE_FILE).read_text(encoding="utf-8"))
    assert set(marker["files"]) == {"audit_result.json", "audit_report.md", "calc_log.json",
                                    "data_rows.json", "confirmed_snapshot.json"}


@pytest.mark.parametrize("name", ["audit_result.json", "audit_report.md", "calc_log.json", "data_rows.json"])
def test_completed_evidence_tampering_is_rejected(tmp_path, name):
    result, folder, raw, out = prepared_run(tmp_path)
    report.write_outputs(result, folder, raw.parent, out)
    target = folder / name
    if name.endswith(".json"):
        value = json.loads(target.read_text(encoding="utf-8"))
        value["tampered"] = True
        save_json(target, value)
    else:
        target.write_text("changed", encoding="utf-8")
    with pytest.raises(AuditError, match="변경"):
        load_completed_run(folder, "p")


def test_failed_publish_is_not_a_previous_run(tmp_path, monkeypatch):
    result, folder, raw, out = prepared_run(tmp_path, "failed")
    original = report.os.replace

    def fail_marker(source, target):
        if Path(target).name == COMPLETE_FILE:
            raise OSError("simulated publish failure")
        original(source, target)

    monkeypatch.setattr(report.os, "replace", fail_marker)
    with pytest.raises(OSError, match="publish failure"):
        report.write_outputs(result, folder, raw.parent, out)
    assert (folder / "audit_result.json").exists() and not (folder / COMPLETE_FILE).exists()
    _, current, _, _ = prepared_run(tmp_path, "current")
    calc = json.loads((current / "calc_log.json").read_text(encoding="utf-8"))
    calc["started_at"] = "2026-09-29T12:00:00+00:00"
    save_json(current / "calc_log.json", calc)
    excluded = []
    assert rerun.find_previous_run(out, "current", "p", excluded) is None
    assert excluded and "완료 표식" in excluded[0]["reason"]
    assert not list(folder.glob(".audit-*.tmp"))


def test_output_directory_rejected_before_partial_json(tmp_path):
    result, folder, raw, out = prepared_run(tmp_path)
    (folder / "audit_report.md").mkdir()
    with pytest.raises(AuditError, match="일반 파일"):
        report.write_outputs(result, folder, raw.parent, out)
    assert not (folder / "audit_result.json").exists()


def directory_link(path, target):
    if os.name == "nt":
        command = "New-Item -ItemType Junction -Path '" + str(path).replace("'", "''") + "' -Target '" \
                  + str(target).replace("'", "''") + "' | Out-Null"
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
                       check=True, capture_output=True)
    else:
        path.symlink_to(target, target_is_directory=True)


@pytest.mark.parametrize("target_kind", ["raw", "outside"])
def test_audit_run_directory_link_rejected(tmp_path, target_kind):
    result, folder, raw, out = prepared_run(tmp_path)
    target = raw.parent if target_kind == "raw" else tmp_path / "outside"
    target.mkdir(exist_ok=True)
    linked = out / "runs" / "linked"
    directory_link(linked, target)
    before = {path.name: path.read_bytes() for path in target.iterdir() if path.is_file()}
    with pytest.raises(AuditError, match="출력 경로"):
        report.write_outputs(result, linked, raw.parent, out)
    assert {path.name: path.read_bytes() for path in target.iterdir() if path.is_file()} == before


def current_at_noon(root):
    _, current, _, out = prepared_run(root, "current")
    calc = json.loads((current / "calc_log.json").read_text(encoding="utf-8"))
    calc["started_at"] = "2026-09-29T12:00:00+00:00"
    save_json(current / "calc_log.json", calc)
    return current, out


def test_corrupt_and_incomplete_history_are_excluded_and_recorded(tmp_path):
    _, valid, _, _ = prepared_run(tmp_path, "valid", legacy=True)
    _, incomplete, _, _ = prepared_run(tmp_path, "incomplete", legacy=True)
    (incomplete / "calc_log.json").unlink()
    broken = valid.parent / "broken"
    broken.mkdir()
    (broken / "audit_result.json").write_text('{"project_id": "foreign",', encoding="utf-8")
    _, out = current_at_noon(tmp_path)
    excluded = []
    assert rerun.find_previous_run(out, "current", "p", excluded) == valid
    assert {entry["run_id"] for entry in excluded} == {"incomplete", "broken"}
    assert all(entry["reason"] for entry in excluded)


def test_missing_previous_calc_is_not_treated_as_empty_data(tmp_path):
    _, previous, _, _ = prepared_run(tmp_path, "previous", legacy=True)
    (previous / "calc_log.json").unlink()
    current, _ = current_at_noon(tmp_path)
    with pytest.raises(AuditError, match="calc_log"):
        rerun.data_changes(previous, current)


def test_timezone_order_selects_actual_latest_past_run(tmp_path):
    prepared_run(tmp_path, "older", "2026-09-29T10:00:00Z", legacy=True)
    _, newer, _, _ = prepared_run(tmp_path, "newer", "2026-09-29T20:00:00+09:00", legacy=True)
    _, out = current_at_noon(tmp_path)
    assert rerun.find_previous_run(out, "current", "p") == newer


def test_completion_time_is_used_instead_of_result_generation(tmp_path):
    result, delayed, raw, out = prepared_run(tmp_path, "delayed")
    report.write_outputs(result, delayed, raw.parent, out)
    marker = json.loads((delayed / COMPLETE_FILE).read_text(encoding="utf-8"))
    marker["completed_at"] = "2026-09-29T14:00:00Z"
    save_json(delayed / COMPLETE_FILE, marker)
    _, older, _, _ = prepared_run(tmp_path, "older", "2026-09-29T11:00:00Z", legacy=True)
    _, out = current_at_noon(tmp_path)
    assert rerun.find_previous_run(out, "current", "p") == older


@pytest.mark.parametrize("time", ["2026-09-29T09:00:00-05:00", "2026-09-29T11:00:00", "invalid"])
def test_future_naive_and_invalid_times_excluded(tmp_path, time):
    prepared_run(tmp_path, "bad-time", time, legacy=True)
    _, out = current_at_noon(tmp_path)
    excluded = []
    assert rerun.find_previous_run(out, "current", "p", excluded) is None
    assert excluded[0]["run_id"] == "bad-time" and excluded[0]["reason"]


def test_explicit_incomplete_run_rejected_before_compute(tmp_path, monkeypatch):
    case = build_case(tmp_path)
    previous = tmp_path / "partial"
    previous.mkdir()
    from measuretrace.backend.contract import Confirmed
    save_json(previous / "audit_result.json", {"project_id": Confirmed.load(case["confirmed"]).project_id,
              "run_id": "partial", "generated_at": "2026-09-29T10:00:00Z", "claims": []})

    def forbidden(*args, **kwargs):
        pytest.fail("이전 실행 근거 검사 전에 계산함")

    monkeypatch.setattr(pipeline, "run_recompute", forbidden)
    client = FakeClient(case["labels"])
    with pytest.raises(AuditError):
        pipeline.run_backend(case["confirmed"], case["report"], case["out"], client, "fake", previous_run=previous)
    assert not client.calls


def test_backend_bad_explanation_publishes_reason_and_valid_completion(tmp_path, monkeypatch):
    case = build_case(tmp_path)
    captured = {}

    def bad_text(*args, **kwargs):
        captured["cid"] = re.search(r"^\[([^\]]+)\]", args[3], re.M).group(1)
        return {"explanations": [{"claim_id": captured["cid"], "text": 123}]}

    monkeypatch.setattr(explain, "call_json", bad_text)
    result = pipeline.run_backend(case["confirmed"], case["report"], case["out"], FakeClient(case["labels"]),
                                  "fake", "bad-text", previous_run=None)
    affected = next(claim for claim in result["claims"] if claim["claim_id"] == captured["cid"])
    assert affected["explanation_source"] == "template"
    assert affected["explanation_status"] == "invalid_response"
    assert "문자열" in affected["explanation_llm_rejected"]
    folder = case["out"] / "runs" / "bad-text"
    saved = load_completed_run(folder)["result"]
    assert saved["claims"][0]["explanation_llm_rejected"] == affected["explanation_llm_rejected"]
    assert "설명 대체 사유" in (folder / "audit_report.md").read_text(encoding="utf-8")
