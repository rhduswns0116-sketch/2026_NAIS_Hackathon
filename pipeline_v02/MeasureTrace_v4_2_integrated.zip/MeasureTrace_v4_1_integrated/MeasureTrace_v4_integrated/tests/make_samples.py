"""시험용 입력 묶음 만들기 — RAW CSV 2개 · 가공 CSV · 연구 계획서(docx, Word 수식) · 장비 사양서(PDF) · 스크립트 · 그림 · 보고서.

  python tests/make_samples.py <폴더>     # <폴더>/data , <폴더>/report 를 만든다 (화면에 그대로 끌어다 놓아 시험)
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

OMML = ('<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">'
        '<m:f><m:fPr><m:ctrlPr/></m:fPr><m:num><m:r><m:t>1</m:t></m:r></m:num>'
        '<m:den><m:r><m:t>R</m:t></m:r></m:den></m:f></m:oMath>')


def make_docx(path: Path, paragraphs: list[str], equations: int = 0) -> None:
    """python-docx 없이 최소 docx — 문단과 Word 수식(m:oMath)."""
    w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = "".join(f'<w:p><w:r><w:t>{p}</w:t></w:r></w:p>' for p in paragraphs)
    body += "".join(f'<w:p><w:r><w:t>식 {i + 1}.</w:t></w:r>{OMML}</w:p>' for i in range(equations))
    doc = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="{w}"><w:body>{body}</w:body></w:document>'
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr("word/document.xml", doc)


def make_pdf(path: Path, lines: list[str]) -> None:
    """글자층이 있는 한 쪽짜리 PDF (Helvetica, ASCII)."""
    text = "BT /F1 12 Tf 72 740 Td 16 TL " + " ".join(f"({l}) '" for l in lines) + " ET"
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
            f"<< /Length {len(text)} >>\nstream\n{text}\nendstream",
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    out, offsets = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n".encode("latin-1")
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    out += "".join(f"{o:010d} 00000 n \n" for o in offsets).encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    path.write_bytes(out)


def main(root: Path) -> None:
    data, report = root / "data", root / "report"
    (data / "raw").mkdir(parents=True, exist_ok=True)
    report.mkdir(parents=True, exist_ok=True)
    for name, base in (("sample_A.csv", 0.0), ("sample_B.csv", 0.3)):
        rows = ["position,voltage_V,current_A"] + [f"{p},{v:.1f},{(v / (10 + p + base)):.6f}" for p in range(1, 8) for v in (0.1, 0.2, 0.3)]
        (data / "raw" / name).write_bytes(("\n".join(rows) + "\n").encode("utf-8"))   # LF 고정 (재실행 시험용)
    (data / "summary_mean.csv").write_bytes(b"sample,mean_G,std_G\nA,0.093,0.004\nB,0.090,0.005\n")
    make_docx(data / "research_plan.docx", ["연구 계획서", "위치별 전도도는 I-V 직선 기울기의 역수로 구한다.", "시료 2개 × 위치 7개"], equations=2)
    make_pdf(data / "instrument_spec.pdf", ["Keithley 2400 SourceMeter - Specification", "Measurement range: 1 uA to 1 A",
                                           "Accuracy: 0.03% + 600 nA"])
    (data / "analysis.py").write_text("print('never run')\n", encoding="utf-8")
    (data / "fig1.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"\0" * 32)
    make_docx(report / "final_report_draft.docx", ["결과", "시료 A 의 평균 전도도는 0.093 S 이다."])
    print(f"만듦: {data} , {report}")


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "samples")
