"use strict";
// MeasureTrace Git_v1 화면 — 서버 API 로 1~6 단계를 실행하고 저장된 결과를 그린다.
const $ = (s) => document.querySelector(s);
const WRITE = { "X-MeasureTrace": "1" };
const STAGES = [["ingest", "1 INGEST"], ["extract", "2 EXTRACT"], ["confirm", "3 CONFIRM"],
                ["recompute", "4 RECOMPUTE"], ["validate", "5 VALIDATE"], ["audit", "6 AUDIT"]];
let current = null;
let active = null;          // 지금 보는 단계 카드 (null 이면 가장 최근 단계)
const picked = { data: [], report: [] };
const CARD_OF = { ingest: "ingest", extract: "extract", confirm: "confirm", recompute: "recompute", validate: "validate", audit: "validate", lineage: "lineage" };

// ── 도구 ──────────────────────────────────────────────────────────────
const esc = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const short = (h, n = 12) => (h ? esc(String(h).slice(0, n)) : "—");
const num = (v) => (typeof v === "number" ? (Math.abs(v) >= 1e-4 && Math.abs(v) < 1e7 || v === 0 ? String(+v.toPrecision(10)) : v.toExponential(6)) : esc(v ?? "—"));
const pill = (t, cls = "") => `<span class="pill ${cls}">${esc(t)}</span>`;
const table = (heads, rows) => `<div class="scroll"><table><thead><tr>${heads.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("") || `<tr><td colspan="${heads.length}" class="muted">없음</td></tr>`}</tbody></table></div>`;
const tr = (cells) => `<tr>${cells.map((c) => `<td>${c}</td>`).join("")}</tr>`;
const checks = (list) => `<ul class="checks">${(list || []).map((c) => `<li class="${c.ok ? "" : "bad"}"><b>${esc(c.check)}</b> <span class="muted">${esc(c.detail || "")}</span></li>`).join("")}</ul>`;
const stat = (v, k, cls = "") => `<div class="stat ${cls}"><div class="v">${esc(v)}</div><div class="k">${esc(k)}</div></div>`;
const json = (o) => `<pre>${esc(JSON.stringify(o, null, 2))}</pre>`;
const tex = (t) => `<div class="eq" data-tex="${esc(t)}">${esc(t)}</div>`;

async function api(method, url, body, raw) {
  const opt = { method, headers: method === "GET" ? {} : { ...WRITE } };
  if (raw !== undefined) opt.body = raw;
  else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; }
  const r = await fetch(url, opt);
  const data = await r.json().catch(() => ({ error: `응답을 읽지 못함 (${r.status})` }));
  if (!r.ok) throw new Error(data.error || `오류 ${r.status}`);
  return data;
}
function busy(on, text) { $("#busy").hidden = !on; if (text) $("#busy-text").textContent = text; }
function banner(html, cls) { $("#banner").innerHTML = html ? `<div class="banner ${cls}">${html}</div>` : ""; }
function remember(rid) { try { localStorage.setItem("mt-run", rid); } catch (e) { /* 저장 안 돼도 됨 */ } }
function recall() { try { return localStorage.getItem("mt-run"); } catch (e) { return null; } }

// ── 실행 목록 · 열기 ──────────────────────────────────────────────────
async function loadRuns(select) {
  const runs = await api("GET", "/api/runs");
  const last = (r) => [...STAGES].reverse().find(([k]) => r.stages[k]);
  $("#runs").innerHTML = `<option value="">— 실행을 고르세요 —</option>` + runs.map((r) => {
    const l = last(r);
    return `<option value="${esc(r.run_id)}">${esc(r.project)} · ${esc(r.run_id)} · ${l ? esc(l[1]) + " " + esc(r.stages[l[0]]) : "입력 중"}${r.summary ? " · " + esc(r.summary) : ""}</option>`;
  }).join("");
  if (select) $("#runs").value = select;
}
async function openRun(rid) {
  if (!rid) { current = null; render(); return; }
  current = await api("GET", `/api/runs/${encodeURIComponent(rid)}`);
  active = null;
  remember(rid);
  $("#runs").value = rid;
  render();
}
async function act(path, body, text) {
  const rid = current.state.run_id;
  busy(true, text);
  try {
    current = await api("POST", `/api/runs/${encodeURIComponent(rid)}/${path}`, body || {});
    active = null;       // 방금 실행한 단계(가장 최근 단계)를 보여 줌
    render();
    window.scrollTo(0, 0);
    await loadRuns(rid);
  } catch (e) { banner(esc(e.message), "bad"); window.scrollTo(0, 0); }
  finally { busy(false); }
}

// ── 그리기 ────────────────────────────────────────────────────────────
function render() {
  const st = current ? current.state.stages : {};
  const shown = current ? [...STAGES].reverse().find(([k]) => st[k]) : null;
  const view = active || (shown ? CARD_OF[shown[0]] : "ingest");
  $("#stepper").innerHTML = STAGES.map(([k, n]) => `<span class="step ${esc((st[k] || {}).status || "")}${CARD_OF[k] === view ? " active" : ""}" data-jump="${k}">${n}</span>`).join("")
    + (current ? `<span class="step${view === "lineage" ? " active" : ""}" data-jump="lineage">장부</span>` : "");
  banner("");
  $("#new-run").open = !current;
  if (!current) { $("#stages").innerHTML = ""; return; }
  const c = current.confirm;
  if (c && c.status === "restart_required")
    banner(`3 CONFIRM 에서 파일을 고쳐 다시 올리기로 했습니다 — ${esc((c.restart_reason || []).join(", "))}. 파일을 고친 뒤 <b>같은 프로젝트 이름</b>으로 새 실행을 만들면 1 INGEST 부터 다시 하며 이전 실행과 비교합니다.`, "warn");
  // 한 번에 한 단계만 그린다 (긴 페이지 대신 위의 단계 버튼으로 오감)
  const renderers = { ingest: renderIngest, extract: renderExtract, confirm: renderConfirm, recompute: renderRecompute,
                      validate: renderValidate, lineage: renderLineage };
  $("#stages").innerHTML = renderers[view]() || `<section class="card"><p class="muted">이 단계는 아직 실행하지 않았습니다.</p></section>`;
  if (window.katex) document.querySelectorAll(".eq[data-tex]").forEach((el) => {
    try { window.katex.render(el.dataset.tex, el, { throwOnError: false, displayMode: true }); } catch (e) { /* 글로 둠 */ }
  });
}

function card(id, numTxt, title, sub, body) {
  return `<section class="card" id="stage-${id}"><h2><span class="num">${numTxt}</span>${esc(title)} <small>${sub || ""}</small></h2>${body}</section>`;
}

function renderIngest() {
  const v = current.ingest, st = current.state;
  if (!v) {
    const ups = current.uploads || [];
    return card("ingest", "1", "INGEST", `프로젝트 ${esc(st.project)} · 실행 ${esc(st.run_id)}`,
      `<p>넣은 파일 ${ups.length}개 — 아직 1 INGEST 를 하지 않았습니다.</p><button class="primary" data-act="ingest">1 INGEST 실행</button>`);
  }
  const cnt = Object.entries(v.counts).map(([k, n]) => pill(`${k} ${n}`)).join(" ");
  const find = (v.findings || []).map((f) => `<li class="bad">${pill(f.level, f.level === "막힘" ? "bad" : "warn")} ${esc(f.text)}</li>`).join("");
  const files = v.files.map((f) => tr([`<span class="mono">${esc(f.zone)}/${esc(f.path)}</span>`, `${esc(f.category_ko)} <span class="muted">${f.confidence}</span><div class="hint">${esc(f.reason)}</div>`,
    `<span class="mono">${short(f.sha256)}</span>`, `<span class="mono">${f.content_hash === f.sha256 ? "= 원본" : short(f.content_hash)}</span> <span class="muted">${esc(f.kind)}</span>`,
    f.measured_at ? `${esc(f.measured_at.first)} ~ ${esc(f.measured_at.last)} <span class="muted">${esc(f.measured_at.status)}</span>` : `<span class="muted">파일 안에 기록 없음</span>`]));
  const ch = v.previous_run
    ? (v.changes.length ? table(["파일", "변경", "내용"], v.changes.map((x) => tr([`<span class="mono">${esc(x.file)}</span>`, pill(x.kind, x.kind === "형식만 변경" ? "" : "warn"),
        esc(x.detail) + (x.table ? `<div class="hint">${x.table.spans.map((s) => esc(s.kind + " " + s.where)).join(" · ")}</div>` : "")])))
      : `<p class="muted">이전 실행 ${esc(v.previous_run)} 과 모든 파일이 같음</p>`)
    : `<p class="muted">첫 실행 — 같은 프로젝트 이름으로 다시 돌리면 해시를 비교해 추가·삭제·형식만 변경·내용 변경(표는 행·열 차이)을 보여 줍니다.</p>`;
  const next = !st.stages.extract && !st.stages.ingest.blocked ? `<div class="row end"><button class="primary" data-act="extract">2 EXTRACT 실행 (LLM)</button></div>` : "";
  return card("ingest", "1", "INGEST", `프로젝트 ${esc(v.project)} · 실행 ${esc(v.run_id)} · 입력 해시 ${short(v.input_hash, 16)}`,
    `<h3><span class="tag">1-1</span>입력 격리·분류</h3>${checks(v.checks)}<div>${cnt}</div>${find ? `<ul class="checks">${find}</ul>` : ""}
     <h3><span class="tag">1-2</span>지문·측정 시각 <small class="muted">정규화 ${esc(v.normalization)}</small></h3>
     ${table(["파일", "분류 (규칙 후보 — 확정은 3 CONFIRM)", "원본 해시", "내용 해시", "측정 시각 (파일 안 기록만)"], files)}
     <h3>이전 실행과 비교</h3>${ch}${next}`);
}

function renderExtract() {
  const e = current.extract;
  if (!e || !e.summary) return "";
  const sm = e.summary, a = e["2-1a"], b = e["2-1b"], c = e["2-1c"], sp = e["2-2"], st = e["2-3"], m = e["2-4"];
  const steps = Object.entries(sm.steps).map(([k, v]) => pill(`${k} ${v.status}${v.round > 1 ? " (" + v.round + "회차)" : ""}`, v.status === "ok" ? "ok" : "bad")).join(" ");
  const errs = Object.entries(sm.errors || {}).map(([k, v]) => `<li class="bad"><b>${esc(k)}</b> ${esc(v)}</li>`).join("");
  let html = `<div>${steps}</div>${errs ? `<ul class="checks">${errs}</ul>` : ""}
    <p class="hint">LLM ${esc(sm.llm.model)} · 호출 ${sm.llm.calls} · 캐시 ${sm.llm.cache_hits} · 토큰 입력 ${sm.llm.input_tokens} / 출력 ${sm.llm.output_tokens} · ${esc(sm.blind)}</p>`;
  if (a) html += `<h3><span class="tag">2-1a</span>데이터 내용 파악 <small>LLM 은 열 이름·문자 값만 봄</small></h3>` + a.groups.map((g) =>
    `<p><b>${esc(g.group_id)}</b> 파일 ${g.files.length}개 · ${g.rows_min}~${g.rows_max}행 — ${esc(g.analysis.summary)}</p>` +
    table(["열", "역할", "물리량", "단위", "의미"], g.analysis.columns.map((x) => tr([`<span class="mono">${esc(x.name)}</span>`, esc(x.role), esc(x.quantity || "—"), `${esc(x.unit || "—")} <span class="muted">${esc(x.unit_source)}</span>`, esc(x.meaning)])))
    + `<details><summary>LLM 에 보낸 글 (측정값 없음)</summary><pre>${esc(a.sent[g.group_id])}</pre></details>`).join("");
  if (b) {
    html += `<h3><span class="tag">2-1b</span>연구 내용 추출</h3><p>${esc(b.purpose)}</p>`;
    html += table(["식", "LaTeX (Word 수식 변환)", "뜻 · 역할", "변수 ← 데이터 열"], b.equations.map((x) => tr([`<b>${esc(x.id)}</b>`, tex(x.latex),
      `${esc(x.meaning)}<div class="hint">${esc(x.role)} · ${esc(x.context)}</div>`, (x.variables || []).map((v) => `${esc(v.symbol)}: ${esc(v.meaning)} ${v.unit ? "[" + esc(v.unit) + "]" : ""}${v.column ? " ← <span class='mono'>" + esc(v.column) + "</span>" : ""}`).join("<br>")])));
    html += `<h3>계산 과정</h3><ol>${b.steps.map((s) => `<li>${esc(s.description)} <span class="muted">(${esc(s.inputs)} → ${esc(s.outputs)} · ${esc((s.equation_ids || []).join(", "))})</span></li>`).join("")}</ol>`;
    const d = b.design || {}, t = b.test || {};
    html += `<h3>설계 · 검정</h3>` + table(["조건", "표기", "시료"], (d.conditions || []).map((x) => tr([`<span class="mono">${esc(x.name)}</span>`, esc(x.label), esc(x.samples.join(", "))])))
      + `<p>독립 단위 ${esc(d.independent_unit)} · 반복 ${esc(d.replicate || "—")} × ${esc(d.replicates_per_unit ?? "—")} · 반복당 ${esc(d.points_per_replicate ?? "—")}점 · 자유도 ${esc(d.degrees_of_freedom ?? "—")}</p>`
      + `<p>검정: ${t.present ? `${esc(t.method)} · ${esc(t.alternative)} · α ${esc(t.alpha)}` : "없음"}</p>`;
    html += `<h3>실험 — 데이터 — 식 — 장비</h3>` + table(["실험", "데이터 열", "식", "장비 · 범위", "결과"], (b.matching || []).map((x) => tr([esc(x.experiment), `<span class="mono">${esc(x.data_columns.join(", "))}</span>`, esc(x.equation_ids.join(", ")), `${esc(x.instrument || "—")} · ${esc(x.instrument_range || "—")}`, esc(x.results)])));
    html += `<h3>보고할 값</h3>` + table(["id", "이름", "단위", "식", "단위(per)", "종류"], (b.outputs || []).map((x) => tr([`<span class="mono">${esc(x.id)}</span>`, esc(x.name), esc(x.unit || "—"), esc(x.equation_id || "—"), esc(x.per), esc(x.kind)])));
  }
  if (c) html += `<h3><span class="tag">2-1c</span>계산 코드 초안 <small>승인 전 · 실행 안 함 · 해시 ${short(c.sha256)}</small></h3>
    ${c.static_problems.length ? `<ul class="checks">${c.static_problems.map((p) => `<li class="bad">${esc(p)}</li>`).join("")}</ul>` : `<p class="hint">격리 실행 규칙 정적 점검 통과</p>`}
    <p>${esc(c.explanation)}</p><details><summary>코드 보기</summary><pre>${esc(c.code)}</pre></details>`;
  if (sp) html += `<h3><span class="tag">2-2</span>측정 조건 (장비 사양) <small>이상치 판단에만 씀 · 확정은 3-2</small></h3>` +
    table(["파일", "물리량 · 범위", "유효 판독값", "정확도 · 분해능", "근거", "원문 확인"], (sp.files || []).flatMap((f) => (f.ranges || []).map((r) => tr([esc(f.file), `${esc(r.quantity)} · ${esc(r.range_name || "")}`,
      `${num(r.min)} ~ ${num(r.max)} ${esc(r.unit)}`, `${esc(r.accuracy || "—")} · ${esc(r.resolution || "—")}`, `${r.page}쪽 “${esc(r.quote)}”`, r.verified ? pill("확인", "ok") : pill(r.problems.join("; "), "bad")]))))
    + (sp.overflow_values && sp.overflow_values.length ? `<p>범위 밖 표시값: ${sp.overflow_values.map(num).join(", ")}</p>` : "");
  if (st) html += `<h3><span class="tag">2-3</span>데이터 구조화 <small>${esc(st.spec_status)} · ${esc(st.note)}</small></h3>` +
    table(["열", "역할", "단위", "상태", "비교할 사양 범위"], st.columns.filter((x) => x.unit_status).map((x) => tr([`<span class="mono">${esc(x.column)}</span>`, esc(x.role), esc(x.unit || "—"),
      pill(x.unit_status, x.unit_status === "ok" ? "ok" : "warn"), x.spec_range ? `${esc(x.spec_range.range_name || x.spec_range.quantity)} (${num(x.spec_range.min)} ~ ${num(x.spec_range.max)} ${esc(x.spec_range.unit)})` : `<span class="muted">${esc(x.spec_note || "—")}</span>`])))
    + `<p><b>단위 누락·모호 / 결측 / 이상치</b></p>` + table(["종류", "파일", "열", "건수", "내용"], st.issues.map((x) => tr([pill(x.kind, "warn"), esc(x.file), esc(x.column), x.count, esc(x.detail)])));
  if (m) html += `<h3><span class="tag">2-4</span>누락 점검 <small>LLM 은 계획서만 읽고, 파이썬이 실제 파일과 대조</small></h3>
    <p>계획서 요구: ${esc((m.required.conditions || []).map((c) => `${c.name} ${c.samples.length}개`).join(" · "))} · 반복 ${esc((m.required.replicates || []).join(", ") || "—")} · 반복당 ${esc(m.required.points_per_replicate ?? "—")}점</p>`
    + table(["종류", "조건", "시료", "내용", "파일"], m.missing.map((x) => tr([pill(x.kind, "bad"), esc(x.condition || "—"), esc(x.sample || "—"), esc(x.detail), esc(x.file || "—")])));
  if (sm.questions && sm.questions.length) html += `<h3>3 CONFIRM 으로 넘길 참고 질문</h3><ul>${sm.questions.map((q) => `<li><span class="muted">[${esc(q.source)}]</span> ${esc(q.text)}</li>`).join("")}</ul>`;
  const stc = current.state.stages;
  if (!stc.confirm) html += `<div class="row end"><button class="${stc.extract.status === "error" ? "primary" : "ghost"}" data-act="extract">2 EXTRACT 다시 실행</button>${stc.extract.status === "error" ? "" : `<button class="primary" data-act="confirm/start">3 CONFIRM 시작</button>`}</div>`;
  return card("extract", "2", "EXTRACT", `최종 보고서 초안을 제외한 모든 입력 · ${sm.round}회차`, html);
}

// ── 3 CONFIRM ─────────────────────────────────────────────────────────
function proposal(it) {
  const p = it.proposal, id = it.id;
  if (id.startsWith("3-1:data:")) return `<p>${esc(p.summary)}</p>` + table(["열", "역할", "단위", "의미"], p.columns.map((x) => tr([`<span class="mono">${esc(x.name)}</span>`, esc(x.role), esc(x.unit || "—"), esc(x.meaning)])));
  if (id.startsWith("3-1:eq:")) return tex(p.latex) + `<p>${esc(p.context)}</p><p><b>${esc(p.meaning)}</b> <span class="muted">${esc(p.role)}</span></p>` +
    ((p.variables || []).length ? table(["변수", "뜻", "단위", "← 데이터 열"], p.variables.map((v) => tr([esc(v.symbol), esc(v.meaning), esc(v.unit || "—"), `<span class="mono">${esc(v.column || "—")}</span>`]))) : "");
  if (id === "3-1:steps") return `<ol>${p.steps.map((s) => `<li>${esc(s.description)} <span class="muted">(${esc(s.inputs)} → ${esc(s.outputs)} · ${esc(s.equation_ids.join(", "))})</span></li>`).join("")}</ol>`;
  if (id === "3-1:design") return table(["조건", "표기", "시료"], (p.design.conditions || []).map((x) => tr([esc(x.name), esc(x.label), esc(x.samples.join(", "))])))
    + `<p>독립 단위 ${esc(p.design.independent_unit)} · 반복 ${esc(p.design.replicate || "—")} × ${esc(p.design.replicates_per_unit ?? "—")} · 자유도 ${esc(p.design.degrees_of_freedom ?? "—")}</p>`
    + `<p>검정: ${p.test.present ? `${esc(p.test.method)} · ${esc(p.test.alternative)} · α ${esc(p.test.alpha)}` : "없음"}</p>`
    + table(["보고값 id", "이름", "단위", "식", "종류"], (p.outputs || []).map((x) => tr([`<span class="mono">${esc(x.id)}</span>`, esc(x.name), esc(x.unit || "—"), esc(x.equation_id || "—"), esc(x.kind)])));
  if (id === "3-1:matching") return table(["실험", "데이터 열", "식", "장비 · 범위", "결과"], p.matching.map((x) => tr([esc(x.experiment), esc(x.data_columns.join(", ")), esc(x.equation_ids.join(", ")), `${esc(x.instrument || "—")} · ${esc(x.instrument_range || "—")}`, esc(x.results)])));
  if (id === "3-1:code") return `${p.static_problems && p.static_problems.length ? `<ul class="checks">${p.static_problems.map((x) => `<li class="bad">${esc(x)}</li>`).join("")}</ul>` : `<p class="hint">격리 실행 규칙 정적 점검 통과 · 코드 해시 ${short(p.sha256)}</p>`}
    <p>${esc(p.explanation)}</p>${(p.assumptions || []).length ? `<p><b>가정</b></p><ul>${p.assumptions.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}<details><summary>코드 보기</summary><pre>${esc(p.code)}</pre></details>`;
  if (id === "3-1:missing") return (p.missing.length ? table(["종류", "조건", "시료", "내용"], p.missing.map((x) => tr([pill(x.kind, "bad"), esc(x.condition || "—"), esc(x.sample || "—"), esc(x.detail)]))) : `<p>누락 없음</p>`)
    + `<p class="hint">계획서 요구: ${esc((p.required.conditions || []).map((c) => `${c.name} ${c.samples.length}개`).join(" · "))} · 반복 ${esc((p.required.replicates || []).join(", "))} · 반복당 ${esc(p.required.points_per_replicate ?? "—")}점</p>`;
  if (it.group === "3-2") return `<p>“${esc(p.quote)}” <span class="muted">(${esc(p.file)} ${esc(p.page ?? "")}쪽)</span> ${p.verified ? pill("원문 확인", "ok") : pill((p.problems || ["원문 확인 안 됨"]).join("; "), "bad")}</p>`;
  if (id === "3-3:definition") return table(["열", "역할", "단위", "상태", "사양 범위"], p.columns.map((x) => tr([`<span class="mono">${esc(x.column)}</span>`, esc(x.role), esc(x.unit || "—"), esc(x.unit_status), x.spec_range ? `${esc(x.spec_range.range_name || "")} ${num(x.spec_range.min)} ~ ${num(x.spec_range.max)} ${esc(x.spec_range.unit)}` : esc(x.spec_note || "—")])));
  if (id.startsWith("3-3:unit:")) return `<p>열 <span class="mono">${esc(p.column)}</span> · 헤더 단위 ${esc(p.header_unit || "없음")} · LLM 제안 ${esc(p.llm_unit || "없음")} (${esc(p.llm_unit_source)})</p>`;
  if (id.startsWith("3-3:data:")) return table(["줄", "값"], (p.rows || []).map((r) => tr([r.line, `<span class="mono">${esc(r.value)}</span>`]))) + (p.count > (p.rows || []).length ? `<p class="hint">외 ${p.count - p.rows.length}개</p>` : "");
  if (id === "3-3:times") return table(["파일", "처음", "마지막", "근거"], p.files.map((f) => tr([esc(f.file), esc(f.first), esc(f.last), esc(f.sources.join(", "))])));
  return "";
}
const STATUS_KO = { pending: ["대기", "warn"], approved: ["승인", "ok"], decided: ["결정", "ok"], rejected: ["수정 요청", "bad"], answered: ["답함", "ok"],
  unresolved: ["미확정", "bad"], reupload: ["재입력", "bad"] };
function renderItem(it, idx, open) {
  const [sk, sc] = STATUS_KO[it.status] || [it.status, ""];
  const ans = it.answer ? `<p class="hint">답: ${esc((it.choices.find((c) => c.value === it.answer.choice) || {}).label || it.answer.choice)}${it.answer.text ? " — " + esc(it.answer.text) : ""} · ${esc(it.answer.respondent)} · ${esc(it.answer.round)}회차${it.carried ? " · 이전 회차 답 이어받음" : ""}</p>` : "";
  const form = open && it.status === "pending" ? `<div class="choices" data-item="${esc(it.id)}">${it.choices.map((c) => `<label><input type="radio" name="c${idx}" value="${esc(c.value)}"> ${esc(c.label)}</label>`).join("")}
      ${it.choices.some((c) => c.needs_text) ? `<textarea placeholder="고칠 내용 · 답 · 단위(기타)를 적어 주세요"></textarea>` : ""}</div>` : "";
  return `<div class="item ${esc(it.status)}"><div class="head"><b>${esc(it.title)}</b> <span>${it.required ? "" : pill("선택")} ${pill(sk, sc)}${it.changed_from ? " " + pill("제안 바뀜", "warn") : ""}</span></div>
    <div class="q">${esc(it.question)}</div>${proposal(it)}${ans}${form}</div>`;
}
function renderConfirm() {
  const c = current.confirm;
  if (!c) return "";
  const open = c.status === "open";
  const groups = [["3-1", "데이터 해석 승인", "아니오 → 고칠 내용으로 2 EXTRACT 2-1(a부터) 다시"], ["3-2", "분석 범위 확정 (장비 사양)", "아니오 → 2-2 다시"],
    ["3-3", "측정 기준 승인", "단위는 제안 중 고르거나 직접 입력 · 결측/이상치가 틀리면 파일을 고쳐 1 INGEST 부터 새 실행"], ["Q", "참고 질문 (선택)", "답하면 해당 추출을 다시 함"]];
  let html = `<div class="stats">${stat(c.round + " / " + c.max_rounds, "피드백 회차")}${stat(c.counts.pending_required, "남은 필수 항목", c.counts.pending_required ? "bad" : "ok")}${stat(c.status, "상태")}</div>`;
  if (c.extract_errors) html += `<div class="banner bad">다시 추출하다 실패: ${esc(JSON.stringify(c.extract_errors))}</div>`;
  let idx = 0;
  for (const [g, name, sub] of groups) {
    const items = c.items.filter((i) => i.group === g);
    if (!items.length) continue;
    const body = items.map((it) => renderItem(it, idx++, open)).join("");
    html += g === "Q"   // 참고 질문은 선택 — 기본으로 접어 둠
      ? `<details><summary><span class="tag">Q</span>${esc(name)} ${items.length}개 — ${esc(sub)}</summary>${body}</details>`
      : `<h3><span class="tag">${g}</span>${esc(name)} <small class="muted">${esc(sub)}</small></h3>` + body;
  }
  if (open) html += `<div class="row end"><button data-act="confirm-fill" class="ghost">남은 필수 항목을 모두 '맞음·그대로 진행'으로 표시</button>
    <input id="respondent" type="text" placeholder="확인한 사람 이름" style="max-width:200px"><button class="primary" data-act="confirm-submit">답 제출</button></div>`;
  if (c.confirmed) {
    const cf = c.confirmed;
    html += `<div class="banner ok">확정 — 기록 해시 ${short(cf.hash, 16)} · 계산 코드 ${cf.code ? short(cf.code.sha256) + " 고정 (승인 " + esc(cf.code.approved_by) + ")" : "없음(미확정)"} · 미확정 ${cf.pending.length} · 누락 기록 ${cf.missing.length} · 이상치 진행 ${cf.data_flags.length}</div>`;
    if (!current.state.stages.recompute) html += `<div class="row end"><button class="primary" data-act="recompute">4 RECOMPUTE 실행</button></div>`;
  }
  return card("confirm", "3", "CONFIRM", "LLM 이 잘 읽었는지 사람이 확인 · 승인값 반영은 파이썬", html);
}

function renderRecompute() {
  const r = current.recompute;
  if (!r) return "";
  const res = (r.results || []).map((x) => tr([`<span class="mono">${esc(x.id)}</span>`, esc(x.name), esc(x.group || x.condition || "—"), `<b class="mono">${num(x.value)}</b>`, esc(x.unit || "—"), esc(x.kind), esc(x.equation_id || "—")]));
  const e7 = r.e07 || {};
  const e7html = e7.compared_with ? `<p>이전 계산 ${esc(e7.compared_with)} 과 비교 (${esc(e7.note)})</p>` + table(["파일", "변경", "내용"], (e7.changes || []).map((x) => tr([esc(x.file), pill(x.kind, "warn"), esc(x.detail)])))
    + ((e7.result_changes || []).length ? table(["결과", "이전", "이번"], e7.result_changes.map((x) => tr([esc(x.id), num(x.before), num(x.after)]))) : "")
    : `<p class="muted">${esc(e7.note || "")}</p>`;
  let html = `<div class="stats">${stat(r.status, "상태", r.status === "ok" ? "ok" : "bad")}${stat((r.results || []).length, "결과")}${stat(r.sandbox ? r.sandbox.seconds + "초" : "—", "격리 실행")}</div>
    ${r.reason ? `<div class="banner bad">${esc(r.reason)}</div>` : ""}
    <h3><span class="tag">4-1</span>실행 전 확인 · 격리 실행</h3>${checks(r.checks)}
    ${r.sandbox ? `<p class="hint">${esc(r.sandbox.isolation)} · 제한 ${r.sandbox.timeout}초 · 막은 동작 ${r.sandbox.blocked.length ? esc(r.sandbox.blocked.join(", ")) : "없음"}</p>` : ""}
    ${r.traceback ? `<details><summary>오류 추적</summary><pre>${esc(r.traceback)}</pre></details>` : ""}
    <h3><span class="tag">4-3</span>계산 로그</h3>
    ${table(["id", "이름", "조건", "값 (반올림 전)", "단위", "종류", "식"], res)}
    <p class="hint">① 사용한 RAW ${r.inputs.length}개 · 입력 해시 ${short(r.input_hash, 16)} ② 계산 과정: 확정 기록 ${short(r.confirmed_hash, 16)} · 코드 ${r.code ? short(r.code.sha256) : "—"} ③ 결과값 ④ 결과 해시 ${short(r.result_hash, 16)} · 환경 ${esc(JSON.stringify(r.env))}</p>
    <details><summary>중간값 (intermediate)</summary>${json(r.intermediate)}</details>
    <details><summary>입력 RAW 해시 목록</summary>${table(["파일", "원본 해시", "내용 해시"], r.inputs.map((x) => tr([esc(x.path), `<span class="mono">${short(x.sha256, 16)}</span>`, `<span class="mono">${short(x.content_hash, 16)}</span>`])))}</details>
    <h3>E07 데이터 버전 변경 (기록)</h3>${e7html}`;
  if (!current.state.stages.validate) html += `<div class="row end"><button class="primary" data-act="validate">5 VALIDATE · 6 AUDIT 실행 (LLM)</button></div>`;
  return card("recompute", "4", "RECOMPUTE", "승인 코드로 RAW 에서 다시 계산 · 보고서는 아직 열지 않음", html);
}

function claimRows(list) {
  return list.map((c) => tr([`p.${c.page} 문장 ${c.no}`, `${esc(c.claim.text)}<div class="hint">${esc(c.category_ko)}</div>`, esc(c.reported ?? "—"),
    `${esc(c.shown ?? "—")}${c.recomputed !== undefined && c.recomputed !== null && typeof c.recomputed === "number" ? `<div class="hint">원값 ${num(c.recomputed)}</div>` : ""}`,
    pill(c.verdict, c.verdict === "Supported" ? "ok" : "bad"),
    c.codes.map((x) => `<div>${pill(x.code, x.effect === "기록" ? "" : "bad")} ${esc(x.detail)}</div>`).join("") || "—"]));
}
function renderValidate() {
  const a = current.audit, v = current.validate;
  if (!v) return "";
  const heads = ["위치", "주장", "보고값", "재계산 (보고 자릿수)", "판정", "오류 코드 · 근거"];
  let html = `<div class="stats">${stat(v.summary.Supported, "Supported", "ok")}${stat(v.summary.Unsupported, "Unsupported", v.summary.Unsupported ? "bad" : "")}${stat(v.summary.not_checked, "검사 대상 아님 (문장)")}</div>
    <p class="hint">블라인드: 계산 완료 ${esc(v.blind.calc_finished_at)} → 보고서 첫 열람 ${esc(v.blind.report_opened_at)} ${v.blind.ok ? pill("확인", "ok") : pill("위반", "bad")} · 보고서 ${esc(v.report)} · LLM ${esc(v.llm.model)} 호출 ${v.llm.calls} 캐시 ${v.llm.cache_hits}</p>`;
  if (a) {
    html += `<p class="hint">${esc(a.disclaimer)}</p>
      <h3><span class="tag">6-1</span>Unsupported</h3>${table(heads, claimRows(a.unsupported))}
      <h3><span class="tag">6-1</span>Supported</h3>${table(heads, claimRows(a.supported))}
      <details><summary>검사 대상 아님 ${a.not_checked.length}문장</summary>${table(["위치", "분류", "문장"], a.not_checked.map((x) => tr([`p.${x.page} 문장 ${x.no}`, esc(x.category_ko), esc(x.text)])))}</details>`;
    const r = a.reevaluation;
    html += `<h3><span class="tag">6-3</span>수정 후 재평가</h3>` + (r.previous_run
      ? `<p>이전 감사 ${esc(r.previous_run)} 과 비교: ${Object.entries(r.counts).map(([k, n]) => pill(`${k} ${n}`, k === "고쳐짐" ? "ok" : k === "나빠짐" ? "bad" : "")).join(" ")}</p>`
        + table(["변화", "주장", "이전", "이번", "이전 코드", "이번 코드"], r.rows.map((x) => tr([pill(x.change, x.change === "고쳐짐" ? "ok" : x.change === "나빠짐" ? "bad" : ""), esc(x.claim), esc(x.before || "—"), esc(x.after || "—"), esc(x.codes_before.join(", ") || "—"), esc(x.codes_after.join(", ") || "—")])))
      : `<p class="muted">${esc(r.note)}</p>`);
    html += `<div class="row end"><a class="btn" href="/api/runs/${encodeURIComponent(a.run_id)}/audit_report.md" download="audit_report_${esc(a.run_id)}.md">감사 리포트(.md) 내려받기</a></div>`;
  }
  return card("validate", "5·6", "VALIDATE · AUDIT", "보고서 주장 ↔ 재계산 비교 · 오류 코드 · 결과 출력", html);
}

function renderLineage() {
  const l = current.lineage || [];
  if (!l.length) return "";
  return card("lineage", "1-3", "파생 이력 장부", "(입력 해시, 코드 버전, 파라미터) → 출력 해시",
    table(["시각", "단계", "입력 해시", "코드 버전", "파라미터", "출력"], l.map((e) => tr([esc(e.at.slice(11, 19)), esc(e.stage), `<span class="mono">${short(e.input_hash)}</span>`, `<span class="mono">${short(e.code_version)}</span>`,
      `<span class="mono">${esc(JSON.stringify(e.params))}</span>`, Object.entries(e.outputs).map(([k, h]) => `<span class="mono">${esc(k)} ${short(h, 10)}</span>`).join("<br>")]))));
}

// ── 이벤트 ────────────────────────────────────────────────────────────
$("#stages").addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-act]");
  if (!b) return;
  const a = b.dataset.act;
  if (a === "ingest") return act("ingest", {}, "1 INGEST — 해시·분류 중…");
  if (a === "extract") return act("extract", {}, "2 EXTRACT — LLM 이 계획서·데이터·사양서를 읽는 중 (수 분 걸릴 수 있음)…");
  if (a === "confirm/start") return act("confirm/start", {}, "3 CONFIRM 준비 중…");
  if (a === "recompute") return act("recompute", {}, "4 RECOMPUTE — 격리 실행 중…");
  if (a === "validate") return act("validate", {}, "5 VALIDATE — 보고서를 처음 열어 주장을 뽑는 중 (LLM)…");
  if (a === "confirm-fill") {
    document.querySelectorAll(".choices").forEach((box) => {
      const it = current.confirm.items.find((i) => i.id === box.dataset.item);
      if (!it || !it.required) return;
      const pref = box.querySelector('input[value="yes"]') || box.querySelector('input[value="proceed"]') || box.querySelector('input[value^="unit:"]');
      if (pref && !box.querySelector("input:checked")) pref.checked = true;
    });
    return;
  }
  if (a === "confirm-submit") {
    const who = ($("#respondent").value || "").trim();
    if (!who) { banner("확인한 사람 이름을 적어 주세요", "bad"); window.scrollTo(0, 0); return; }
    const answers = {};
    document.querySelectorAll(".choices").forEach((box) => {
      const r = box.querySelector("input:checked");
      if (r) answers[box.dataset.item] = { choice: r.value, text: (box.querySelector("textarea") || {}).value || "" };
    });
    if (!Object.keys(answers).length) { banner("고른 답이 없음", "bad"); return; }
    return act("confirm/submit", { respondent: who, answers }, "답 반영 중 — '수정 필요'가 있으면 2 EXTRACT 를 다시 합니다(LLM)…");
  }
});
$("#stepper").addEventListener("click", (ev) => {
  const s = ev.target.closest("[data-jump]");
  if (!s || !current) return;
  active = CARD_OF[s.dataset.jump];
  render();
  const el = document.getElementById(`stage-${active}`);
  if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
});
$("#runs").addEventListener("change", () => openRun($("#runs").value).catch((e) => banner(esc(e.message), "bad")));
$("#refresh").addEventListener("click", () => loadRuns(current && current.state.run_id));

function relPath(f, fromDir) {
  const p = (f.webkitRelativePath || f.name).replace(/\\/g, "/");
  return fromDir && p.includes("/") ? p.split("/").slice(1).join("/") : p;
}
function addPicked(zone, files, fromDir) {
  for (const f of files) {
    const path = relPath(f, fromDir);
    if (!picked[zone].some((x) => x.path === path)) picked[zone].push({ path, file: f });
  }
  showPicked();
}
function showPicked() {
  for (const z of ["data", "report"])
    $(`#${z}-list`).innerHTML = picked[z].map((x) => `<li><span class="mono">${esc(x.path)}</span><span class="muted">${(x.file.size / 1024).toFixed(1)} KB</span></li>`).join("") || `<li class="muted">넣은 파일 없음</li>`;
}
$("#data-dir").addEventListener("change", (e) => addPicked("data", e.target.files, true));
$("#data-files").addEventListener("change", (e) => addPicked("data", e.target.files, false));
$("#report-files").addEventListener("change", (e) => addPicked("report", e.target.files, false));
$("#clear").addEventListener("click", () => { picked.data = []; picked.report = []; showPicked(); });
$("#start").addEventListener("click", async () => {
  const project = ($("#project").value || "").trim();
  if (!project) return banner("프로젝트 이름을 적어 주세요", "bad");
  if (!picked.data.length) return banner("연구 자료를 넣어 주세요", "bad");
  busy(true, "실행을 만드는 중…");
  try {
    const { run_id } = await api("POST", "/api/runs", { project });
    const all = [...picked.data.map((x) => ["data", x]), ...picked.report.map((x) => ["report", x])];
    let i = 0;
    for (const [zone, x] of all) {
      $("#busy-text").textContent = `사본 업로드 ${++i}/${all.length} — ${x.path}`;
      await api("PUT", `/api/runs/${encodeURIComponent(run_id)}/files?zone=${zone}&path=${encodeURIComponent(x.path)}`, undefined, x.file);
    }
    $("#busy-text").textContent = "1 INGEST — 해시·분류 중…";
    current = await api("POST", `/api/runs/${encodeURIComponent(run_id)}/ingest`, {});
    picked.data = []; picked.report = []; showPicked();
    await loadRuns(run_id);
    remember(run_id);
    active = null;
    render();
  } catch (e) { banner(esc(e.message), "bad"); }
  finally { busy(false); }
});

(async function init() {
  showPicked();
  try {
    const s = await api("GET", "/api/status");
    $("#llm").innerHTML = `LLM ${esc(s.llm.model)} · ${s.llm.offline ? "오프라인(캐시만)" : s.llm.has_key ? "API 키 있음" : "API 키 없음 — 캐시만"}`;
  } catch (e) { $("#llm").textContent = "서버 연결 실패"; }
  await loadRuns();
  const last = recall();
  if (last && [...$("#runs").options].some((o) => o.value === last)) openRun(last).catch(() => {});
  else render();
})();
