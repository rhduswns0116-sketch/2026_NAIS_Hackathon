"""MeasureTrace Git_v1 시험 — 가짜 LLM(토큰 0), 임시 작업 폴더.

  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import json
import os
import shutil
import stat
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
TMP = Path(tempfile.mkdtemp(prefix="mt_test_"))
os.environ["MT_WORKSPACE"] = str(TMP / "ws")
os.environ.pop("LLM_API_KEY", None)
os.environ.pop("ANTHROPIC_API_KEY", None)

from fake_llm import FakeClient  # noqa: E402
from mtagent import design, hashing, sandbox, store, units  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import audit, confirm, extract, ingest, recompute, validate  # noqa: E402

SAMPLES = ROOT / "samples"
KEY = json.loads((SAMPLES / "annealing_demo_answer_key.json").read_text(encoding="utf-8"))


def tearDownModule():
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def fake(client=None):
    return LLM(client=client or FakeClient(), model="fake")


def new_run(project: str, folder: Path) -> str:
    rid = store.new_run(project)
    store.add_folder(rid, "data", folder / "data")
    if (folder / "report").exists():
        store.add_folder(rid, "report", folder / "report")
    time.sleep(0.01)
    return rid


def approve_all(rid: str, who="tester"):
    v = confirm.view(rid)
    ans = {}
    for i in v["items"]:
        if i["required"] and i["status"] == "pending":
            vals = [c["value"] for c in i["choices"]]
            ans[i["id"]] = {"choice": next(x for x in ("yes", "proceed") if x in vals) if {"yes", "proceed"} & set(vals)
                            else vals[0]}
    return confirm.submit(rid, who, ans)


def full(rid: str, client=None):
    ingest.run(rid)
    extract.run(rid, fake(client))
    confirm.start(rid)
    approve_all(rid)
    recompute.run(rid)
    validate.run(rid, fake(client))
    return audit.run(rid)


class UnitsHashing(unittest.TestCase):
    def test_units(self):
        self.assertAlmostEqual(units.convert(1.2e-8, "A", "nA"), 12.0)
        self.assertEqual(units.dimension("nS"), "conductance")
        self.assertEqual(units.dimension("μA"), "current")
        self.assertIsNone(units.parse("furlong"))
        self.assertEqual(units.from_header("current_A"), "A")
        self.assertEqual(units.from_header("Current (nA)"), "nA")
        self.assertIsNone(units.from_header("sample_id"))
        with self.assertRaises(ValueError):
            units.convert(1, "A", "V")

    def test_format_only_and_row_diff(self):
        d = TMP / "h"
        d.mkdir(exist_ok=True)
        rows = "a,b\n1,2\n3,4\n5,6\n"
        (d / "x.csv").write_text(rows, encoding="utf-8")
        (d / "y.csv").write_bytes(("﻿" + rows.replace("\n", "  \r\n")).encode("utf-8"))
        (d / "z.csv").write_text("a,b\n1,2\n5,6\n", encoding="utf-8")
        x, y, z = (hashing.fingerprint(d / n) for n in ("x.csv", "y.csv", "z.csv"))
        self.assertNotEqual(x["sha256"], y["sha256"])
        self.assertEqual(x["content_hash"], y["content_hash"])
        ch = hashing.compare_sets({"x": x}, {"x": z})
        self.assertEqual(ch[0]["table"]["removed"], 1)
        self.assertEqual(ch[0]["table"]["spans"], [{"kind": "빠짐", "where": "옛 파일 3줄"}])

    def test_condition_matching(self):
        conds = [{"name": "annealed", "label": "어닐링 (A)", "samples": ["S01", "S02"]},
                 {"name": "control", "label": "대조 (C)", "samples": ["S11"]}]
        self.assertEqual(design.match_condition("어닐링 (A)", conds), "annealed")
        self.assertEqual(design.match_condition("annealed (A)", conds), "annealed")
        self.assertEqual(design.match_condition("A 조건", conds, "s02"), "annealed")
        self.assertIsNone(design.match_condition("제3 조건", conds, "S99"))
        self.assertEqual(design.expand_samples(["S01–S03", "X"]), ["S01", "S02", "S03", "X"])


class Schemas(unittest.TestCase):
    def test_structured_output_limits(self):
        """Claude API 구조화 출력 제약: null 허용(유니언) 항목 16개 이하, null 섞인 enum 금지, 모든 object 에 additionalProperties=false."""
        from mtagent.stages import validate as v

        def walk(x, acc):
            if isinstance(x, dict):
                if isinstance(x.get("type"), list) or "anyOf" in x:
                    acc["unions"] += 1
                if isinstance(x.get("type"), list) and "enum" in x:
                    acc["bad_enum"] += 1
                if x.get("type") == "object" and x.get("additionalProperties") is not False:
                    acc["open_obj"] += 1
                for y in x.values():
                    walk(y, acc)
            elif isinstance(x, list):
                for y in x:
                    walk(y, acc)
            return acc
        for name in ("SCHEMA_A", "SCHEMA_B", "SCHEMA_B2", "SCHEMA_C", "SCHEMA_S", "SCHEMA_M"):
            acc = walk(getattr(extract, name), {"unions": 0, "bad_enum": 0, "open_obj": 0})
            self.assertLessEqual(acc["unions"], 16, name)
            self.assertEqual((acc["bad_enum"], acc["open_obj"]), (0, 0), name)
        acc = walk(v.SCHEMA, {"unions": 0, "bad_enum": 0, "open_obj": 0})
        self.assertLessEqual(acc["unions"], 16)
        self.assertEqual((acc["bad_enum"], acc["open_obj"]), (0, 0))


class Sandbox(unittest.TestCase):
    def test_static_check(self):
        bad = "import os\nimport socket\ndef compute(files):\n    eval('1')\n    open('a', 'w')\n    return {}\n"
        probs = sandbox.static_check(bad)
        self.assertEqual(len(probs), 4, probs)
        self.assertIn("compute(files) 함수가 없음", sandbox.static_check("x = 1\n"))

    def test_runtime_blocks_write_and_foreign_read(self):
        d = TMP / "sb"
        d.mkdir(exist_ok=True)
        target = d / "leak.txt"
        for body, word in ((f"open(r'{target}', 'w').write('x')", "쓰기"), ("import socket", "import")):
            p = d / "code.py"
            p.write_text("def compute(files):\n    " + body + "\n    return {'results': []}\n", encoding="utf-8")
            from mtagent.util import sha_file
            r = sandbox.run(p, sha_file(p), {}, 60)
            self.assertEqual(r["status"], "error")
            self.assertIn(word, r["error"])
        self.assertFalse(target.exists())


class Pipeline(unittest.TestCase):
    def test_demo_end_to_end(self):
        client = FakeClient()
        rid = new_run("demo", SAMPLES / "annealing_demo")
        a = full(rid, client)
        # 4 RECOMPUTE 정답 대비
        res = {r["id"]: r["value"] for r in store.read(rid, "recompute/calc_log.json")["results"]}
        exp = {"G_mean__annealed": KEY["conditions"]["annealed"]["mean_nS"], "G_sd__control": KEY["conditions"]["control"]["sd_nS"],
               "t": KEY["t_test"]["t"], "p": KEY["t_test"]["p_two_sided"], "dG": KEY["increase_percent"], "df": 18}
        for k, v in exp.items():
            self.assertLess(abs(res[k] - v) / abs(v), 1e-9, k)
        # 5·6
        self.assertEqual(a["summary"]["Unsupported"], 0)
        self.assertEqual(a["summary"]["Supported"], 12)
        self.assertTrue(a["blind"]["ok"])
        # 블라인드·값 미전송: 추출 요청에 측정값이 없고, 보고서 문장이 없음 / 5-1 요청에 재계산 값이 없음
        s01 = (SAMPLES / "annealing_demo/data/raw/annealed/S01.csv").read_text(encoding="utf-8").splitlines()[1].split(",")[-1]
        for call in client.calls:
            if call["task"].startswith("2-"):
                self.assertNotIn(s01, call["user"])
                self.assertNotIn("12.1 ± 0.7", call["user"])
        five = next(c for c in client.calls if c["task"] == "5-1")
        catalog = five["user"].split("[보고서 문장]")[0]
        self.assertNotIn("12.1016", catalog)
        self.assertNotIn("6.0494", catalog)
        # 확정 코드는 읽기 전용, 장부에 단계가 모두 있음
        code = store.out_dir(rid) / "confirm" / "approved_code.py"
        self.assertFalse(os.access(code, os.W_OK))
        from mtagent import lineage
        stages = {" ".join(e["stage"].split(" ")[:2]) for e in lineage.entries(rid)}
        for s in ("1 INGEST", "2 EXTRACT", "3 CONFIRM", "4 RECOMPUTE", "5 VALIDATE", "6 AUDIT"):
            self.assertIn(s, stages)
        # 입력 봉인
        with self.assertRaises(ValueError), open(code, "rb") as f:
            store.save_upload(rid, "data", "x.csv", f, 1)

    def test_rerun_detects_changes_and_scopes_e03(self):
        full(new_run("re", SAMPLES / "annealing_demo"))
        rid = new_run("re", SAMPLES / "annealing_demo_rerun")
        a = full(rid)
        ch = {c["file"]: c for c in store.read(rid, "ingest.json")["changes"]}
        self.assertEqual(ch["data/raw/annealed/S07.csv"]["table"]["spans"], [{"kind": "빠짐", "where": "옛 파일 31–33줄"}])
        self.assertEqual(ch["data/raw/control/S12.csv"]["kind"], "형식만 변경")
        miss = store.read(rid, "extract/missing.json")["missing"]
        self.assertEqual([m["detail"] for m in miss], ["S07 position=P3: 8/11점"])
        by = {}
        for c in store.read(rid, "validate.json")["claims"]:
            by.setdefault(c["claim"].get("output_id") or c["claim"].get("lhs"), []).append(c)
        # 누락은 어닐링 집단과 두 집단을 함께 쓰는 항목에만 — 대조 집단 항목은 Supported
        for oid in ("G_mean__annealed", "G_sd__annealed", "dG", "t", "p"):
            for c in by[oid]:
                self.assertEqual(c["verdict"], "Unsupported", oid)
                self.assertIn("E03", {x["code"] for x in c["codes"]})
        for oid in ("G_mean__control", "G_sd__control", "n__control"):
            for c in by[oid]:
                self.assertEqual(c["verdict"], "Supported", oid)
        self.assertEqual(a["reevaluation"]["counts"], {"나빠짐": 9, "그대로": 3})

    def test_confirm_no_reruns_extract_with_feedback(self):
        client = FakeClient()
        rid = new_run("fb", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client))
        v = confirm.start(rid)
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans["3-1:eq:EQ05"] = {"choice": "no", "text": "표준편차는 n-1 로 나누는 표본 표준편차임"}
        before = len(client.calls)
        v = confirm.submit(rid, "tester", ans, llm=fake(client))
        self.assertEqual(v["round"], 2)
        self.assertEqual(v["status"], "open")
        again = [c for c in client.calls[before:] if c["task"] == "2-1b"]
        self.assertTrue(again and "n-1 로 나누는" in again[0]["user"])
        # 제안이 같은 항목은 이어받고, 다른 항목은 다시 묻지 않음(가짜 LLM 은 같은 답) → 바로 확정 가능
        self.assertTrue(any(i.get("carried") for i in v["items"]))

    def test_max_rounds_leaves_pending_and_e06(self):
        client = FakeClient()
        rid = new_run("mx", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client))
        confirm.start(rid)
        for _ in range(3):
            v = confirm.view(rid)
            ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and i["status"] == "pending"
                   and "yes" in [c["value"] for c in i["choices"]]}
            if "3-1:eq:EQ04" in ans or confirm.view(rid)["round"] == 1:
                ans["3-1:eq:EQ04"] = {"choice": "no", "text": "조건 평균의 뜻이 틀림"}
            v = confirm.submit(rid, "tester", ans, llm=fake(client))
            if v["status"] == "complete":
                break
            # 가짜 LLM 은 같은 답을 주므로 EQ04 는 이전 답(no)이 이어지지 않고 다시 대기 → 다시 no
            for it in v["items"]:
                if it["id"] == "3-1:eq:EQ04":
                    self.assertEqual(it["status"], "pending")
        v = confirm.view(rid)
        self.assertEqual(v["status"], "complete")
        self.assertEqual([p["target"] for p in v["confirmed"]["pending"]], ["eq:EQ04"])
        recompute.run(rid)
        out = validate.run(rid, fake(client))
        g = [c for c in out["claims"] if c["claim"].get("output_id") == "G_mean__annealed"]
        self.assertTrue(g and all("E06" in {x["code"] for x in c["codes"]} for c in g))
        sd = [c for c in out["claims"] if c["claim"].get("output_id") == "G_sd__annealed"]
        self.assertTrue(sd and all(c["verdict"] == "Supported" for c in sd))

    def test_out_of_spec_value_asks_and_reupload_restarts(self):
        src = TMP / "oos"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        f = src / "data/raw/control/S15.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        parts = lines[5].split(",")
        parts[-1] = "5.0e-08"          # 50 nA — 10 nA 범위(±10.5 nA) 밖
        lines[5] = ",".join(parts)
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("oos", src)
        ingest.run(rid)
        extract.run(rid, fake())
        v = confirm.start(rid)
        item = next(i for i in v["items"] if i["id"].startswith("3-3:data:out_of_spec"))
        self.assertEqual(item["proposal"]["rows"], [{"line": 6, "value": "5.0e-08"}])
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans[item["id"]] = {"choice": "reupload"}
        v = confirm.submit(rid, "tester", ans)
        self.assertEqual(v["status"], "restart_required")
        with self.assertRaises(ValueError):
            recompute.run(rid)

    def test_text_value_none_is_not_missing_but_numeric_na_is(self):
        """조건 이름 'none' 은 정상 값, 숫자 열의 'NA' 는 결측."""
        src = TMP / "na"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        for f in (src / "data/raw/control").glob("*.csv"):
            f.write_text(f.read_text(encoding="utf-8").replace(",control,", ",none,"), encoding="utf-8")
        f = src / "data/raw/annealed/S03.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        lines[4] = ",".join(lines[4].split(",")[:-1] + ["NA"])
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("na", src)
        ingest.run(rid)
        extract.run(rid, fake())
        issues = store.read(rid, "extract/structure.json")["issues"]
        self.assertEqual([(i["kind"], i["file"], i["column"], i["rows"]) for i in issues],
                         [("missing_value", "raw/annealed/S03.csv", "current_A", [{"line": 5, "value": "NA"}])])

    def test_report_is_not_opened_before_validate(self):
        rid = new_run("bl", SAMPLES / "annealing_demo")
        out = ingest.run(rid)
        rep = next(x for x in out["files"] if x["zone"] == "report")
        self.assertEqual(rep["kind"], "bytes (열지 않음)")
        with self.assertRaises(ValueError):
            validate.run(rid, fake())


class Server(unittest.TestCase):
    def test_host_origin_and_write_header(self):
        from http.server import ThreadingHTTPServer
        from web import server
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        server.Handler.port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{server.Handler.port}"

        def req(method, path, body=None, headers=None):
            r = urllib.request.Request(base + path, data=json.dumps(body).encode() if body is not None else None,
                                       method=method, headers={"Content-Type": "application/json", **(headers or {})})
            try:
                with urllib.request.urlopen(r, timeout=10) as resp:
                    return resp.status, json.loads(resp.read() or b"null") if "json" in resp.headers.get("Content-Type", "") else None
            except urllib.error.HTTPError as e:
                return e.code, None
        try:
            self.assertEqual(req("GET", "/api/status")[0], 200)
            self.assertEqual(req("POST", "/api/runs", {"project": "s"})[0], 403)
            self.assertEqual(req("POST", "/api/runs", {"project": "s"}, {"X-MeasureTrace": "1", "Origin": "http://evil.example"})[0], 403)
            code, body = req("POST", "/api/runs", {"project": "s"}, {"X-MeasureTrace": "1"})
            self.assertEqual(code, 200)
            self.assertEqual(req("GET", f"/api/runs/{body['run_id']}")[0], 200)
            self.assertEqual(req("PUT", f"/api/runs/{body['run_id']}/files?zone=data&path=../x.csv", {}, {"X-MeasureTrace": "1"})[0], 400)
        finally:
            httpd.shutdown()


if __name__ == "__main__":
    unittest.main()
