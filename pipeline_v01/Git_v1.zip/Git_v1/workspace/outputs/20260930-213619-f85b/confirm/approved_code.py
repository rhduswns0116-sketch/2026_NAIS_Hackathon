# MeasureTrace 2-1c: 어닐링 박막 전도도 재계산 (EQ01~EQ08)
# 계획서 순서: (1) raw CSV 읽기·형식 확인 -> (2) 전류 범위 확인(자동 제외 없음)
# -> (3) 위치별 I-V 최소제곱 기울기 G_ij (EQ01) -> (4) 참고 R_ij (EQ02)
# -> (5) 시료 전도도 G_i = 위치 7개 평균 (EQ03) -> (6) 조건별 평균·표본 SD (EQ04, EQ05)
# -> (7) 합동 SD·등분산 t 검정 (EQ06, EQ07) -> (8) 증가율 (EQ08) -> (9) nS 변환 보고
import csv
import math
import re
from collections import defaultdict

import numpy as np
from scipy import stats

DESIGN = {
    'annealed': ['S01', 'S02', 'S03', 'S04', 'S05', 'S06', 'S07', 'S08', 'S09', 'S10'],
    'control': ['S11', 'S12', 'S13', 'S14', 'S15', 'S16', 'S17', 'S18', 'S19', 'S20'],
}
CONDITION_ORDER = ['annealed', 'control']
SAMPLE_TO_CONDITION = {s: c for c in CONDITION_ORDER for s in DESIGN[c]}
EXPECTED_POSITIONS = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7']
EXPECTED_VOLTAGE_STEPS = list(range(-5, 6))  # 전압 = 0.1 V x step (-0.5 ~ 0.5 V, 11점)
# ASSUMPTION: 전압이 0.1 V 격자 위에 있는지 판정할 때 허용오차 1e-6 (step 단위)를 쓴다.
VOLTAGE_GRID_TOL = 1e-6
EXPECTED_ROWS_PER_FILE = 77
REQUIRED_COLUMNS = ['sample_id', 'condition', 'position', 'voltage_V', 'current_A']
S_TO_NS = 1e9
ALPHA = 0.05
# ASSUMPTION: instrument_spec.pdf 가 입력에 없어 10 nA 범위의 실제 측정 한계를 알 수 없다.
# 명목 풀스케일 10 nA(1e-8 A)를 넘는 |I| 를 '연구자 확인 필요'로 표시만 하고, 계산에서 제외하지 않는다.
NOMINAL_RANGE_A = 10e-9
PATH_RE = re.compile(r'^raw/([^/]+)/([^/]+)[.]csv$')
POS_RE = re.compile(r'^P([0-9]+)$')


def _parse_float(text):
    if text is None:
        return None, '값 없음'
    s = text.strip()
    if s == '':
        return None, '빈 값'
    try:
        v = float(s)
    except ValueError:
        return None, '숫자로 변환 불가: ' + repr(s)
    if not math.isfinite(v):
        return None, '유한하지 않은 값: ' + repr(s)
    return v, None


def _num(x):
    if x is None:
        return None
    x = float(x)
    return x if math.isfinite(x) else None


def _ns(x):
    return None if x is None else x * S_TO_NS


def _pos_key(p):
    m = POS_RE.match(p)
    return (0, int(m.group(1)), p) if m else (1, 0, p)


def _ls_slope(vs, cs):
    # EQ01: G = sum((V-Vbar)(I-Ibar)) / sum((V-Vbar)^2)
    v = np.asarray(vs, dtype=float)
    c = np.asarray(cs, dtype=float)
    if v.size < 2:
        return None
    dv = v - v.mean()
    sxx = float(np.sum(dv * dv))
    if sxx == 0.0:
        return None
    return float(np.sum(dv * (c - c.mean())) / sxx)


def compute(files: dict) -> dict:
    skipped = []
    warnings = []
    file_checks = {}
    iv = defaultdict(list)            # (sample_id, position) -> [(V, I, file, line)]
    cond_values = defaultdict(set)    # sample_id -> condition 열 값들
    sample_files = defaultdict(set)   # sample_id -> 파일들
    over_range = []
    max_abs_current = {}

    # ---- 단계 1·2: 읽기, 형식 확인, 전류 범위 표시 ----
    for rel in sorted(files):
        m = PATH_RE.match(rel)
        folder_cond = m.group(1) if m else None
        file_sample = m.group(2) if m else None
        chk = {'folder_condition': folder_cond, 'file_sample': file_sample,
               'data_rows': 0, 'parsed_rows': 0, 'sample_ids': set(),
               'condition_values': set(), 'problems': []}
        file_checks[rel] = chk
        if m is None:
            chk['problems'].append('경로가 raw/<조건>/<시료>.csv 형식이 아님')
        elif folder_cond not in DESIGN:
            chk['problems'].append('폴더 이름이 설계 조건(annealed/control)이 아님: ' + folder_cond)
        with open(files[rel], 'r', encoding='utf-8-sig', newline='') as fh:
            reader = csv.reader(fh, delimiter=',')
            header = next(reader, None)
            idx = None
            if header is None:
                chk['problems'].append('빈 파일(헤더 없음)')
                skipped.append({'file': rel, 'line': 1, 'reason': '빈 파일(헤더 없음)'})
            else:
                header = [h.strip() for h in header]
                missing = [c for c in REQUIRED_COLUMNS if c not in header]
                if missing:
                    msg = '필수 열 없음: ' + ', '.join(missing) + ' - 파일 전체를 계산에 쓰지 못함'
                    chk['problems'].append(msg)
                    skipped.append({'file': rel, 'line': 1, 'reason': msg})
                else:
                    idx = {c: header.index(c) for c in REQUIRED_COLUMNS}
            if idx is not None:
                need = max(idx.values()) + 1
                for rec in reader:
                    line = reader.line_num
                    if not rec or all(x.strip() == '' for x in rec):
                        skipped.append({'file': rel, 'line': line, 'reason': '빈 줄'})
                        continue
                    chk['data_rows'] += 1
                    if len(rec) < need:
                        skipped.append({'file': rel, 'line': line, 'reason': '열 개수 부족(%d개)' % len(rec)})
                        continue
                    sid = rec[idx['sample_id']].strip()
                    cond = rec[idx['condition']].strip()
                    pos = rec[idx['position']].strip()
                    v, err_v = _parse_float(rec[idx['voltage_V']])
                    cur, err_i = _parse_float(rec[idx['current_A']])
                    reasons = []
                    if sid == '':
                        reasons.append('sample_id 빈 값')
                    if pos == '':
                        reasons.append('position 빈 값')
                    if err_v:
                        reasons.append('voltage_V ' + err_v)
                    if err_i:
                        reasons.append('current_A ' + err_i)
                    if reasons:
                        skipped.append({'file': rel, 'line': line, 'reason': '; '.join(reasons)})
                        continue
                    chk['parsed_rows'] += 1
                    chk['sample_ids'].add(sid)
                    chk['condition_values'].add(cond)
                    cond_values[sid].add(cond)
                    sample_files[sid].add(rel)
                    iv[(sid, pos)].append((v, cur, rel, line))
                    a = abs(cur)
                    if a > max_abs_current.get(sid, -1.0):
                        max_abs_current[sid] = a
                    if a > NOMINAL_RANGE_A:
                        over_range.append({'file': rel, 'line': line, 'sample_id': sid,
                                           'position': pos, 'voltage_V': v, 'current_A': cur})
        if chk['data_rows'] != EXPECTED_ROWS_PER_FILE:
            chk['problems'].append('데이터 행 수 %d (기대 %d)' % (chk['data_rows'], EXPECTED_ROWS_PER_FILE))
        if file_sample is not None and chk['sample_ids'] != {file_sample}:
            chk['problems'].append('sample_id 열 값 %s 이(가) 파일 이름 %s 와 다름' % (sorted(chk['sample_ids']), file_sample))
        if folder_cond is not None and chk['condition_values'] != {folder_cond}:
            chk['problems'].append('condition 열 값 %s 이(가) 폴더 이름 %s 와 다름' % (sorted(chk['condition_values']), folder_cond))
        if file_sample is not None and folder_cond in DESIGN and SAMPLE_TO_CONDITION.get(file_sample) != folder_cond:
            chk['problems'].append('시료 %s 은(는) 계획서상 %s 조건 시료 목록에 없음' % (file_sample, folder_cond))
        for pr in chk['problems']:
            warnings.append(rel + ': ' + pr)
        chk['sample_ids'] = sorted(chk['sample_ids'])
        chk['condition_values'] = sorted(chk['condition_values'])

    # ---- 조건 배정: 계획서(design) 시료 목록 기준 ----
    sample_condition = {}
    for sid in sorted(sample_files):
        seen = sorted(cond_values[sid])
        design_c = SAMPLE_TO_CONDITION.get(sid)
        if design_c is not None:
            sample_condition[sid] = design_c
            if seen != [design_c]:
                warnings.append('시료 %s: 데이터 condition 값 %s 이(가) 계획서 배정 %s 와 다름(계획서 배정 사용)' % (sid, seen, design_c))
        elif len(seen) == 1 and seen[0] in DESIGN:
            # ASSUMPTION: 계획서 목록에 없는 시료는 데이터의 condition 값으로 배정하고 경고를 남긴다.
            sample_condition[sid] = seen[0]
            warnings.append('시료 %s: 계획서 시료 목록에 없음 - 데이터 condition 값 %s 으로 배정' % (sid, seen[0]))
        else:
            sample_condition[sid] = None
            warnings.append('시료 %s: 조건을 정할 수 없어 조건별 통계에서 빠짐' % sid)
        if len(sample_files[sid]) > 1:
            warnings.append('시료 %s: 여러 파일에 나타남 %s' % (sid, sorted(sample_files[sid])))
    for c in CONDITION_ORDER:
        for s in DESIGN[c]:
            if s not in sample_files:
                warnings.append('계획서 시료 %s(%s)의 사용 가능한 데이터가 없음' % (s, c))

    # ---- 단계 3·4: 위치별 전도도 G_ij (EQ01), 참고 저항 R_ij (EQ02) ----
    G_ij = defaultdict(dict)
    R_ij = defaultdict(dict)
    fit_detail = defaultdict(dict)
    for key in sorted(iv, key=lambda k: (k[0], _pos_key(k[1]))):
        sid, pos = key
        pts = iv[key]
        vs = [p[0] for p in pts]
        cs = [p[1] for p in pts]
        steps = [int(round(v * 10.0)) for v in vs]
        off_grid = [v for v in vs if abs(v * 10.0 - round(v * 10.0)) > VOLTAGE_GRID_TOL]
        step_set = set(steps)
        missing_v = [round(s * 0.1, 1) for s in EXPECTED_VOLTAGE_STEPS if s not in step_set]
        extra_v = [round(s * 0.1, 1) for s in sorted(step_set) if s not in EXPECTED_VOLTAGE_STEPS]
        dup_v = sorted({round(s * 0.1, 1) for s in steps if steps.count(s) > 1})
        problems = []
        if len(pts) != len(EXPECTED_VOLTAGE_STEPS):
            # ASSUMPTION: 11점이 아니어도 남은 점(서로 다른 전압 2점 이상)으로 기울기를 계산하고 경고한다.
            problems.append('I-V 점 수 %d (기대 11)' % len(pts))
        if missing_v:
            problems.append('빠진 전압점 %s V' % missing_v)
        if extra_v:
            problems.append('범위 밖 전압점 %s V' % extra_v)
        if dup_v:
            problems.append('중복 전압점 %s V' % dup_v)
        if off_grid:
            problems.append('0.1 V 격자 밖 전압값 %s' % off_grid)
        slope = _ls_slope(vs, cs)
        if slope is None:
            problems.append('기울기 계산 불가(서로 다른 전압 2점 미만)')
        G_ij[sid][pos] = slope
        R_ij[sid][pos] = (1.0 / slope) if (slope is not None and slope != 0.0) else None
        fit_detail[sid][pos] = {'n_points': len(pts),
                                'source': [[p[2], p[3]] for p in pts],
                                'missing_voltages_V': missing_v,
                                'extra_voltages_V': extra_v,
                                'duplicate_voltages_V': dup_v,
                                'problems': problems}
        for pr in problems:
            warnings.append('%s %s: %s' % (sid, pos, pr))

    # ---- 단계 5: 시료 전도도 G_i (EQ03) ----
    G_i = {}
    for sid in sorted(G_ij):
        pos_list = sorted(G_ij[sid], key=_pos_key)
        if pos_list != EXPECTED_POSITIONS:
            warnings.append('시료 %s: 위치 목록 %s 이(가) P1-P7 과 다름' % (sid, pos_list))
        vals = [G_ij[sid][p] for p in pos_list if G_ij[sid][p] is not None]
        if len(vals) != len(EXPECTED_POSITIONS):
            # ASSUMPTION: 위치가 7개가 아니면 계산 가능한 위치만 평균하고 경고한다.
            warnings.append('시료 %s: 평균에 쓴 위치 수 %d (기대 7)' % (sid, len(vals)))
        G_i[sid] = (math.fsum(vals) / len(vals)) if vals else None

    # ---- 단계 6: 조건별 평균 (EQ04), 표본 표준편차 (EQ05) ----
    cond_stats = {}
    cond_vals = {}
    for c in CONDITION_ORDER:
        samples = sorted(s for s, cc in sample_condition.items() if cc == c and G_i.get(s) is not None)
        vals = [G_i[s] for s in samples]
        n = len(vals)
        mean = (math.fsum(vals) / n) if n else None
        sd = math.sqrt(math.fsum((x - mean) ** 2 for x in vals) / (n - 1)) if n >= 2 else None
        if n != len(DESIGN[c]):
            warnings.append('조건 %s: 시료 수 %d (계획서 %d)' % (c, n, len(DESIGN[c])))
        cond_vals[c] = vals
        cond_stats[c] = {'samples': samples, 'n': n, 'mean_S': mean, 'sd_S': sd,
                         'mean_nS': _ns(mean), 'sd_nS': _ns(sd)}

    # ---- 단계 7: 합동 SD (EQ06), t (EQ07), 양측 p ----
    A = cond_stats['annealed']
    C = cond_stats['control']
    nA, nC = A['n'], C['n']
    df = (nA + nC - 2) if (nA + nC - 2) > 0 else None
    pooled = None
    diff = None
    t_val = None
    p_val = None
    pct = None
    if A['sd_S'] is not None and C['sd_S'] is not None and df is not None:
        pooled = math.sqrt(((nA - 1) * A['sd_S'] ** 2 + (nC - 1) * C['sd_S'] ** 2) / df)
    if A['mean_S'] is not None and C['mean_S'] is not None:
        diff = A['mean_S'] - C['mean_S']  # 부호: A - C
    if pooled is not None and pooled > 0.0 and diff is not None:
        t_val = diff / (pooled * math.sqrt(1.0 / nA + 1.0 / nC))
        p_val = float(2.0 * stats.t.sf(abs(t_val), df))  # 양측
    # ---- 단계 8: 증가율 (EQ08) ----
    if diff is not None and C['mean_S'] not in (None, 0.0):
        pct = diff / C['mean_S'] * 100.0

    scipy_check = None
    if nA >= 2 and nC >= 2:
        st, pv = stats.ttest_ind(cond_vals['annealed'], cond_vals['control'], equal_var=True)
        scipy_check = {'t': _num(st), 'p_two_sided': _num(pv)}

    # ---- 단계 9: 결과 (전도도는 nS) ----
    def _r(id_, name, value, unit, condition, kind, eq):
        return {'id': id_, 'name': name, 'value': _num(value), 'unit': unit,
                'condition': condition, 'kind': kind, 'equation_id': eq}

    results = []
    for c in CONDITION_ORDER:
        results.append(_r('mean_G__' + c, '조건별 평균 전도도', cond_stats[c]['mean_nS'], 'nS', c, 'value', 'EQ04'))
    for c in CONDITION_ORDER:
        results.append(_r('sd_G__' + c, '조건별 전도도 표본 표준편차', cond_stats[c]['sd_nS'], 'nS', c, 'value', 'EQ05'))
    for c in CONDITION_ORDER:
        results.append(_r('n__' + c, '조건별 시료 수', float(cond_stats[c]['n']), None, c, 'n', None))
    results.append(_r('pooled_sd', '합동 표준편차', _ns(pooled), 'nS', None, 'other', 'EQ06'))
    results.append(_r('mean_diff', '평균 전도도 차이 (A − C)', _ns(diff), 'nS', None, 'difference', None))
    results.append(_r('t_stat', 't 통계량', t_val, None, None, 'test_statistic', 'EQ07'))
    results.append(_r('df', '자유도', None if df is None else float(df), None, None, 'df', 'EQ07'))
    results.append(_r('p_value', '양측 p값', p_val, None, None, 'p_value', None))
    results.append(_r('percent_increase', '어닐링에 따른 전도도 증가율', pct, '%', None, 'percent_change', 'EQ08'))

    intermediate = {
        'skipped_rows': skipped,
        'warnings': warnings,
        'file_checks': file_checks,
        'sample_condition': sample_condition,
        'G_ij_S': {s: dict(d) for s, d in G_ij.items()},
        'R_ij_ohm_reference_only': {s: dict(d) for s, d in R_ij.items()},
        'position_fit_detail': {s: dict(d) for s, d in fit_detail.items()},
        'G_i_S': G_i,
        'G_i_nS': {s: _ns(g) for s, g in G_i.items()},
        'condition_stats': cond_stats,
        'comparison': {'pooled_sd_S': pooled, 'mean_diff_S': diff, 't': t_val, 'df': df,
                       'p_two_sided': p_val, 'alpha': ALPHA,
                       'significant_at_alpha': (p_val < ALPHA) if p_val is not None else None,
                       'percent_increase': pct, 'scipy_ttest_ind_crosscheck': scipy_check},
        'current_range_check': {
            'note': 'instrument_spec.pdf 미제공 - 실제 한계 미확인. 명목 10 nA 초과값을 표시만 하며 제외하지 않음. 재측정 여부는 연구자 결정.',
            'nominal_limit_A': NOMINAL_RANGE_A,
            'n_over_nominal': len(over_range),
            'over_nominal_rows': over_range,
            'max_abs_current_A_by_sample': max_abs_current},
    }
    return {'results': results, 'intermediate': intermediate}
