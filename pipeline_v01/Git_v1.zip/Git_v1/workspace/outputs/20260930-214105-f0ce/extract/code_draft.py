# MeasureTrace 과업 2-1c: 계획서대로 raw I-V 데이터에서 보고값을 다시 계산한다.
# 연구자가 3 CONFIRM 에서 승인한 뒤 격리 환경에서 실행한다.
import csv
import math
import statistics
from scipy import stats

N_POS_EXPECTED = 7
N_PTS_EXPECTED = 11
ROWS_EXPECTED = N_POS_EXPECTED * N_PTS_EXPECTED  # 77
EXPECTED_V = [round(-0.5 + 0.1 * k, 6) for k in range(N_PTS_EXPECTED)]
# ASSUMPTION: MT-SMU 2400 의 '10 nA 범위'를 |I| <= 1e-8 A 로 해석한다. 사양서(instrument_spec.pdf)는 RAW 가 아니라 열 수 없다.
# 범위를 넘는 값은 표시만 하고 계산에서 빼지 않는다(계획서 단계 2: 자동 제외 금지).
RANGE_LIMIT_A = 1e-8
TO_NS = 1e9
ALPHA = 0.05
COND_ORDER = ['annealed', 'control']
DESIGN = {
    'annealed': ['S%02d' % k for k in range(1, 11)],
    'control': ['S%02d' % k for k in range(11, 21)],
}
REQUIRED_COLS = ['sample_id', 'condition', 'position', 'voltage_V', 'current_A']


def _to_float(text):
    if text is None:
        return None, '값 없음(열 누락)'
    s = str(text).strip()
    if s == '':
        return None, '빈 값'
    try:
        x = float(s)
    except ValueError:
        return None, '숫자로 변환 불가: %r' % s
    if not math.isfinite(x):
        return None, '유한하지 않은 값: %r' % s
    return x, None


def _ls_slope(vs, cs):
    # EQ01: G_ij = sum((V_k - Vbar)(I_ijk - Ibar_ij)) / sum((V_k - Vbar)^2)
    n = len(vs)
    vbar = math.fsum(vs) / n
    ibar = math.fsum(cs) / n
    sxy = math.fsum((v - vbar) * (c - ibar) for v, c in zip(vs, cs))
    sxx = math.fsum((v - vbar) ** 2 for v in vs)
    if sxx == 0:
        return None
    return sxy / sxx


def _finite(x):
    return x is not None and isinstance(x, float) and math.isfinite(x)


def compute(files: dict) -> dict:
    skipped = []
    issues = []
    range_flags = []
    file_rows = {}
    points = {}
    sample_conds = {}
    sample_files = {}

    # 단계 1: CSV 읽기와 형식 확인
    for rel in sorted(files):
        path = files[rel]
        parts = rel.split('/')
        folder_cond = parts[-2] if len(parts) >= 2 else None
        file_sid = parts[-1].rsplit('.', 1)[0]
        with open(path, 'r', encoding='utf-8-sig', newline='') as fh:
            reader = csv.DictReader(fh, delimiter=',')
            header = [h.strip() if h else h for h in (reader.fieldnames or [])]
            reader.fieldnames = header
            missing = [c for c in REQUIRED_COLS if c not in header]
            if missing:
                skipped.append({'file': rel, 'line': 1, 'reason': '필수 열 없음: ' + ', '.join(missing) + ' (파일 전체 미사용)'})
                file_rows[rel] = None
                continue
            n_rows = 0
            for row in reader:
                line = reader.line_num
                n_rows += 1
                sid = (row.get('sample_id') or '').strip()
                cond = (row.get('condition') or '').strip()
                pos = (row.get('position') or '').strip()
                if not sid or not cond or not pos:
                    skipped.append({'file': rel, 'line': line, 'reason': 'sample_id/condition/position 중 빈 값'})
                    continue
                v, err = _to_float(row.get('voltage_V'))
                if err:
                    skipped.append({'file': rel, 'line': line, 'reason': 'voltage_V ' + err})
                    continue
                c, err = _to_float(row.get('current_A'))
                if err:
                    skipped.append({'file': rel, 'line': line, 'reason': 'current_A ' + err})
                    continue
                if sid != file_sid:
                    issues.append({'file': rel, 'line': line, 'issue': 'sample_id(%s)가 파일명(%s)과 다름' % (sid, file_sid)})
                if folder_cond is not None and cond != folder_cond:
                    issues.append({'file': rel, 'line': line, 'issue': 'condition(%s)이 폴더명(%s)과 다름' % (cond, folder_cond)})
                # 단계 2: 장비 범위 점검(표시만, 제외하지 않음)
                if abs(c) > RANGE_LIMIT_A:
                    range_flags.append({'file': rel, 'line': line, 'sample_id': sid, 'position': pos,
                                        'voltage_V': v, 'current_A': c})
                points.setdefault((sid, pos), []).append({'v': v, 'i': c, 'file': rel, 'line': line})
                sample_conds.setdefault(sid, set()).add(cond)
                sample_files.setdefault(sid, set()).add(rel)
            file_rows[rel] = n_rows
            if n_rows != ROWS_EXPECTED:
                issues.append({'file': rel, 'line': None,
                               'issue': '데이터 행 수 %d (계획서 기대값 %d)' % (n_rows, ROWS_EXPECTED)})

    # 단계 3·4: 위치별 전도도(EQ01)와 참고용 저항(EQ02)
    pos_results = {}
    for key in sorted(points):
        sid, pos = key
        pts = points[key]
        vs = [p['v'] for p in pts]
        cs = [p['i'] for p in pts]
        vr = [round(v, 6) for v in vs]
        missing_v = [ev for ev in EXPECTED_V if ev not in vr]
        extra_v = sorted(set(x for x in vr if x not in EXPECTED_V))
        dup_v = sorted(set(x for x in vr if vr.count(x) > 1))
        # ASSUMPTION: 전압점이 11개보다 적으면 남은 점으로 EQ01 기울기를 구한다(평균도 남은 점 기준). 해당 위치는 기록한다.
        # ASSUMPTION: 중복 전압점은 버리지 않고 모두 적합에 넣고 기록한다.
        g = _ls_slope(vs, cs) if len(set(vr)) >= 2 else None
        r = (1.0 / g) if (g is not None and g != 0) else None
        if missing_v or extra_v or dup_v or len(pts) != N_PTS_EXPECTED:
            issues.append({'file': ';'.join(sorted(set(p['file'] for p in pts))), 'line': None,
                           'issue': '%s %s: 점 %d개, 빠진 전압 %s, 계획 외 전압 %s, 중복 전압 %s' % (
                               sid, pos, len(pts), missing_v, extra_v, dup_v)})
        if g is None:
            issues.append({'file': ';'.join(sorted(set(p['file'] for p in pts))), 'line': None,
                           'issue': '%s %s: 서로 다른 전압이 2개 미만이라 기울기 계산 불가(G_ij 없음)' % (sid, pos)})
        pos_results.setdefault(sid, {})[pos] = {
            'n_points': len(pts),
            'voltages_V': vs,
            'currents_A': cs,
            'missing_voltages_V': missing_v,
            'unexpected_voltages_V': extra_v,
            'duplicate_voltages_V': dup_v,
            'G_S': g,
            'G_nS': (g * TO_NS) if g is not None else None,
            'R_ohm_reference_only': r,
        }

    # 단계 5: 시료 전도도(EQ03) - 위치 평균
    sample_G = {}
    for sid in sorted(pos_results):
        recs = pos_results[sid]
        gs = [recs[p]['G_S'] for p in sorted(recs) if recs[p]['G_S'] is not None]
        if len(recs) != N_POS_EXPECTED or len(gs) != N_POS_EXPECTED:
            # ASSUMPTION: 위치가 7개가 아니면 사용 가능한 위치로 평균하고 기록한다.
            issues.append({'file': ';'.join(sorted(sample_files.get(sid, []))), 'line': None,
                           'issue': '%s: 위치 %d개, 기울기 있는 위치 %d개 (계획서 7개)' % (sid, len(recs), len(gs))})
        if not gs:
            sample_G[sid] = None
            issues.append({'file': ';'.join(sorted(sample_files.get(sid, []))), 'line': None,
                           'issue': '%s: 시료 전도도 계산 불가 - 검정에서 빠짐' % sid})
            continue
        sample_G[sid] = math.fsum(gs) / len(gs)

    # 조건 배정: condition 열 기준, 설계 목록과 대조
    cond_samples = {c: [] for c in COND_ORDER}
    sample_assign = {}
    for sid in sorted(sample_G):
        conds = sample_conds.get(sid, set())
        design_c = None
        for c in COND_ORDER:
            if sid in DESIGN[c]:
                design_c = c
        if len(conds) == 1:
            c = next(iter(conds))
        else:
            # ASSUMPTION: 한 시료에 condition 값이 여러 개면 계획서 설계 목록을 따른다.
            issues.append({'file': ';'.join(sorted(sample_files.get(sid, []))), 'line': None,
                           'issue': '%s: condition 값이 여러 개 %s - 설계 목록(%s) 사용' % (sid, sorted(conds), design_c)})
            c = design_c
        if design_c is not None and c != design_c:
            issues.append({'file': ';'.join(sorted(sample_files.get(sid, []))), 'line': None,
                           'issue': '%s: condition 열(%s)이 계획서 설계(%s)와 다름 - condition 열 사용' % (sid, c, design_c)})
        if design_c is None:
            issues.append({'file': ';'.join(sorted(sample_files.get(sid, []))), 'line': None,
                           'issue': '%s: 계획서 설계 목록에 없는 시료' % sid})
        sample_assign[sid] = c
        if c not in cond_samples:
            issues.append({'file': ';'.join(sorted(sample_files.get(sid, []))), 'line': None,
                           'issue': '%s: 알 수 없는 조건 %r - 검정에서 빠짐' % (sid, c)})
            continue
        if sample_G[sid] is None:
            continue
        cond_samples[c].append(sid)
    for c in COND_ORDER:
        for sid in DESIGN[c]:
            if sid not in sample_G:
                issues.append({'file': None, 'line': None, 'issue': '계획서 시료 %s(%s)의 데이터가 없음' % (sid, c)})

    # 단계 6: 조건별 평균(EQ04)과 표본 표준편차(EQ05)
    vals = {c: [sample_G[s] for s in cond_samples[c]] for c in COND_ORDER}
    n = {c: len(vals[c]) for c in COND_ORDER}
    mean = {c: (math.fsum(vals[c]) / n[c]) if n[c] > 0 else float('nan') for c in COND_ORDER}
    sd = {c: statistics.stdev(vals[c]) if n[c] >= 2 else float('nan') for c in COND_ORDER}

    # 단계 7: 합동 표준편차(EQ06), t 통계량(EQ07), 양측 p값
    nA, nC = n['annealed'], n['control']
    mA, mC = mean['annealed'], mean['control']
    sA, sC = sd['annealed'], sd['control']
    df = nA + nC - 2
    if nA >= 2 and nC >= 2:
        sp = math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / df)
    else:
        sp = float('nan')
    diff = mA - mC
    if nA > 0 and nC > 0 and math.isfinite(sp) and sp > 0:
        t = diff / (sp * math.sqrt(1.0 / nA + 1.0 / nC))
    else:
        t = float('nan')
    if math.isfinite(t) and df > 0:
        p = float(2.0 * stats.t.sf(abs(t), df))
    else:
        p = float('nan')

    # 단계 8: 증가율(EQ08)
    pct = (diff / mC * 100.0) if (math.isfinite(mC) and mC != 0) else float('nan')

    # 교차 확인: scipy 등분산 t 검정
    crosscheck = None
    if nA >= 2 and nC >= 2:
        res = stats.ttest_ind(vals['annealed'], vals['control'], equal_var=True)
        crosscheck = {'t': float(res.statistic), 'p_two_sided': float(res.pvalue)}

    # 단계 9: 보고 단위 nS
    results = []
    for c in COND_ORDER:
        results.append({'id': 'mean_G__' + c, 'name': '조건별 평균 전도도', 'value': float(mean[c] * TO_NS),
                        'unit': 'nS', 'condition': c, 'kind': 'value', 'equation_id': 'EQ04'})
    for c in COND_ORDER:
        results.append({'id': 'sd_G__' + c, 'name': '조건별 전도도 표본 표준편차', 'value': float(sd[c] * TO_NS),
                        'unit': 'nS', 'condition': c, 'kind': 'value', 'equation_id': 'EQ05'})
    for c in COND_ORDER:
        results.append({'id': 'n_samples__' + c, 'name': '조건별 표본 수(시료 수)', 'value': float(n[c]),
                        'unit': None, 'condition': c, 'kind': 'n', 'equation_id': None})
    results.append({'id': 'pooled_sd', 'name': '합동 표준편차', 'value': float(sp * TO_NS),
                    'unit': 'nS', 'condition': None, 'kind': 'value', 'equation_id': 'EQ06'})
    results.append({'id': 'mean_diff', 'name': '평균 전도도 차이(A − C)', 'value': float(diff * TO_NS),
                    'unit': 'nS', 'condition': None, 'kind': 'difference', 'equation_id': None})
    results.append({'id': 't_stat', 'name': 't 통계량', 'value': float(t),
                    'unit': None, 'condition': None, 'kind': 'test_statistic', 'equation_id': 'EQ07'})
    results.append({'id': 'df', 'name': '자유도', 'value': float(df),
                    'unit': None, 'condition': None, 'kind': 'df', 'equation_id': 'EQ07'})
    results.append({'id': 'p_value', 'name': '양측 p값', 'value': float(p),
                    'unit': None, 'condition': None, 'kind': 'p_value', 'equation_id': None})
    results.append({'id': 'pct_increase', 'name': '어닐링에 따른 전도도 증가율', 'value': float(pct),
                    'unit': '%', 'condition': None, 'kind': 'percent_change', 'equation_id': 'EQ08'})

    intermediate = {
        'skipped_rows': skipped,
        'validation_issues': issues,
        'range_flags_over_10nA': range_flags,
        'range_limit_A': RANGE_LIMIT_A,
        'rows_per_file': file_rows,
        'position_conductance': pos_results,
        'sample_conductance_S': sample_G,
        'sample_conductance_nS': {s: (g * TO_NS if g is not None else None) for s, g in sample_G.items()},
        'sample_condition': sample_assign,
        'samples_used_per_condition': cond_samples,
        'condition_mean_S': mean,
        'condition_sd_S': sd,
        'pooled_sd_S': sp,
        'mean_diff_S': diff,
        'expected_df_plan': 18,
        'alpha': ALPHA,
        'significant_at_alpha': (p < ALPHA) if math.isfinite(p) else None,
        'scipy_ttest_ind_crosscheck': crosscheck,
    }
    return {'results': results, 'intermediate': intermediate}
