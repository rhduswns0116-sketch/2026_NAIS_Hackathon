import csv
import math
import statistics
from scipy import stats

# 계획서(design / test / outputs)에서 가져온 상수
REQUIRED_COLUMNS = ['sample', 'group', 'trial', 'time_s']
CONDITIONS = [
    ('catalyst', ['K1', 'K2', 'K3', 'K4']),
    ('none', ['N1', 'N2', 'N3', 'N4']),
]
EXPECTED_TRIALS = [1, 2, 3]
PLANNED_DF = 6
ALPHA = 0.05
TREAT = 'catalyst'
CONTROL = 'none'


def _parse_float(raw):
    if raw is None:
        return None, '값 없음(열 누락)'
    txt = str(raw).strip()
    if txt == '':
        return None, '빈 값'
    try:
        v = float(txt)
    except ValueError:
        return None, '숫자로 변환 불가: ' + repr(raw)
    if not math.isfinite(v):
        return None, '유한하지 않은 값: ' + repr(raw)
    return v, None


def _parse_trial(raw):
    v, err = _parse_float(raw)
    if err is not None:
        return None, err
    if v != int(v):
        return None, '정수가 아닌 trial: ' + repr(raw)
    return int(v), None


def _nan():
    return float('nan')


def _r1(x):
    if x is None or not math.isfinite(x):
        return None
    return round(x, 1)


def compute(files: dict) -> dict:
    skipped = []
    warnings = []
    cond_names = [c for c, _ in CONDITIONS]
    sample_to_cond = {}
    design_order = []
    for c, ss in CONDITIONS:
        for s in ss:
            sample_to_cond[s] = c
            design_order.append(s)

    # ---------- 1단계: 파일 읽기 · 형식 확인 ----------
    table = []
    file_checks = {}
    for rel in sorted(files):
        path = files[rel]
        base = rel.split('/')[-1]
        stem = base[:-4] if base.lower().endswith('.csv') else base
        check = {'header': None, 'missing_columns': [], 'n_data_rows': 0,
                 'n_valid_rows': 0, 'trials': [], 'ok': True}
        file_checks[rel] = check
        with open(path, 'r', encoding='utf-8-sig', newline='') as fh:
            reader = csv.DictReader(fh, delimiter=',')
            header = [(h or '').strip() for h in (reader.fieldnames or [])]
            reader.fieldnames = header
            check['header'] = header
            missing = [c for c in REQUIRED_COLUMNS if c not in header]
            check['missing_columns'] = missing
            if missing:
                check['ok'] = False
                skipped.append({'file': rel, 'line': 1,
                                'reason': '필수 열 없음: ' + ', '.join(missing) + ' — 파일 전체를 계산에 쓰지 못함'})
                continue
            for row in reader:
                line = reader.line_num
                extra = row.get(None)
                vals = [row.get(c) for c in header]
                if all(v is None or str(v).strip() == '' for v in vals) and not extra:
                    skipped.append({'file': rel, 'line': line, 'reason': '빈 행'})
                    continue
                check['n_data_rows'] += 1
                if extra:
                    warnings.append(f'{rel}:{line} 헤더보다 필드가 많음(추가 필드 {extra!r}) — 추가 필드는 무시')
                sample = (row.get('sample') or '').strip()
                group_raw = (row.get('group') or '').strip()
                if sample == '':
                    skipped.append({'file': rel, 'line': line, 'reason': 'sample 값 없음'})
                    continue
                if sample != stem:
                    # ASSUMPTION: 파일명과 sample 열이 다르면 sample 열을 기준으로 한다.
                    warnings.append(f'{rel}:{line} sample 값 {sample!r} 이 파일명 {stem!r} 과 다름 — sample 열 기준 사용')
                design_cond = sample_to_cond.get(sample)
                if group_raw in cond_names:
                    cond = group_raw
                    if design_cond is not None and design_cond != cond:
                        warnings.append(f'{rel}:{line} group={group_raw!r} 이 설계상 {sample} 의 조건 {design_cond!r} 과 다름 — group 열 기준 사용')
                elif design_cond is not None:
                    # ASSUMPTION: group 값이 조건 name(catalyst/none)과 다르면 설계의 시료 목록으로 조건을 정한다.
                    cond = design_cond
                    warnings.append(f'{rel}:{line} group={group_raw!r} 이 조건 name 과 일치하지 않음 — 설계 시료 목록으로 {design_cond!r} 배정')
                else:
                    skipped.append({'file': rel, 'line': line,
                                    'reason': f'조건을 정할 수 없음 (group={group_raw!r}, sample={sample!r})'})
                    continue
                trial, terr = _parse_trial(row.get('trial'))
                if terr is not None:
                    warnings.append(f'{rel}:{line} trial {terr} — time_s 는 계산에 사용')
                check['trials'].append(trial)
                time_v, err = _parse_float(row.get('time_s'))
                if err is not None:
                    skipped.append({'file': rel, 'line': line, 'reason': 'time_s ' + err})
                    continue
                check['n_valid_rows'] += 1
                table.append({'file': rel, 'line': line, 'sample': sample,
                              'condition': cond, 'group_raw': group_raw,
                              'trial': trial, 'time_s': time_v})
        if check['n_data_rows'] != len(EXPECTED_TRIALS):
            check['ok'] = False
            warnings.append(f'{rel}: 데이터 행 {check["n_data_rows"]}개 (계획: {len(EXPECTED_TRIALS)}행)')
        got_trials = sorted(t for t in check['trials'] if t is not None)
        if got_trials != EXPECTED_TRIALS:
            check['ok'] = False
            warnings.append(f'{rel}: trial 값 {got_trials} (계획: {EXPECTED_TRIALS})')

    # ---------- 2단계: 시료 값 (기술적 반복 평균) ----------
    by_key = {}
    for r in table:
        key = (r['condition'], r['sample'])
        d = by_key.setdefault(key, {'condition': r['condition'], 'sample': r['sample'],
                                    'times': [], 'trials': [], 'files': []})
        d['times'].append(r['time_s'])
        d['trials'].append(r['trial'])
        if r['file'] not in d['files']:
            d['files'].append(r['file'])
    seen_cond = {}
    for (c, s) in by_key:
        seen_cond.setdefault(s, []).append(c)
    for s, cs in seen_cond.items():
        if len(cs) > 1:
            warnings.append(f'시료 {s} 가 여러 조건 {cs} 에 나타남 — 조건별로 따로 집계')
    for s in design_order:
        if s not in seen_cond:
            warnings.append(f'설계 시료 {s} 의 유효 데이터가 없음')

    def _order(key):
        c, s = key
        idx = design_order.index(s) if s in design_order else len(design_order)
        return (cond_names.index(c), idx, s)

    sample_values = {c: [] for c in cond_names}
    sample_table = []
    for key in sorted(by_key, key=_order):
        d = by_key[key]
        n_rep = len(d['times'])
        m = statistics.fmean(d['times'])
        if n_rep != len(EXPECTED_TRIALS):
            # ASSUMPTION: 반복 수가 3이 아니면(숫자 변환 불가 행 등) 남은 유효 반복의 평균을 시료 값으로 쓴다.
            warnings.append(f'시료 {d["sample"]}: 유효 반복 {n_rep}개로 평균 (계획: {len(EXPECTED_TRIALS)}개)')
        sample_values[d['condition']].append(m)
        sample_table.append({'sample': d['sample'], 'condition': d['condition'],
                             'trials': d['trials'], 'times_s': d['times'],
                             'n_replicates': n_rep, 'sample_mean_s': m,
                             'files': d['files']})

    # ---------- 3단계: 조건 요약 ----------
    summary = {}
    for c in cond_names:
        vals = sample_values[c]
        n = len(vals)
        mean = statistics.fmean(vals) if n >= 1 else _nan()
        sd = statistics.stdev(vals) if n >= 2 else _nan()
        if n < 2:
            warnings.append(f'조건 {c}: 시료 수 {n} — 표준편차 계산 불가')
        if n != 4:
            warnings.append(f'조건 {c}: 시료 수 {n} (계획: 4)')
        summary[c] = {'n': n, 'mean_s': mean, 'sd_s': sd,
                      'var_s2': (sd * sd) if math.isfinite(sd) else _nan()}

    # ---------- 4단계: 독립 2표본 t 검정 (등분산, 양측) ----------
    # ASSUMPTION: t 의 부호는 (none − catalyst) 순서로 정의한다. mean_diff 와 같은 방향이며 양수면 촉매 쪽 반응 시간이 짧다.
    n1 = summary[CONTROL]['n']
    n2 = summary[TREAT]['n']
    df = n1 + n2 - 2
    t_stat = _nan()
    p_value = _nan()
    pooled_var = _nan()
    se = _nan()
    if n1 >= 2 and n2 >= 2:
        s1 = summary[CONTROL]['sd_s']
        s2 = summary[TREAT]['sd_s']
        pooled_var = ((n1 - 1) * s1 * s1 + (n2 - 1) * s2 * s2) / df
        se = math.sqrt(pooled_var * (1.0 / n1 + 1.0 / n2))
        diff = summary[CONTROL]['mean_s'] - summary[TREAT]['mean_s']
        if se > 0:
            t_stat = diff / se
            p_value = float(2.0 * stats.t.sf(abs(t_stat), df))
        else:
            warnings.append('합동 표준오차가 0 — t 통계량 계산 불가')
    else:
        warnings.append('조건별 시료가 2개 미만 — t 검정 불가')
    if df != PLANNED_DF:
        warnings.append(f'자유도 {df} 가 계획값 {PLANNED_DF} 과 다름')
    scipy_check = None
    if n1 >= 2 and n2 >= 2:
        res = stats.ttest_ind(sample_values[CONTROL], sample_values[TREAT], equal_var=True)
        scipy_check = {'statistic': float(res.statistic), 'pvalue': float(res.pvalue)}
    # ASSUMPTION: 유의 판정은 p < α (등호 처리는 계획서에 없음).
    significant = (p_value < ALPHA) if math.isfinite(p_value) else None

    # ---------- 5단계: 감소율 · 평균 차이 ----------
    m_ctrl = summary[CONTROL]['mean_s']
    m_trt = summary[TREAT]['mean_s']
    mean_diff = m_ctrl - m_trt
    if math.isfinite(m_ctrl) and m_ctrl != 0:
        reduction_pct = (m_ctrl - m_trt) / m_ctrl * 100.0
    else:
        reduction_pct = _nan()
        warnings.append('대조 평균이 0 이거나 없음 — 감소율 계산 불가')

    # ---------- results ----------
    results = []
    for c in cond_names:
        results.append({'id': 'mean_time__' + c, 'name': '조건 평균 반응 시간', 'value': float(summary[c]['mean_s']),
                        'unit': 's', 'condition': c, 'kind': 'value', 'equation_id': None})
        results.append({'id': 'sd_time__' + c, 'name': '조건 표준편차(표본 표준편차, n − 1)', 'value': float(summary[c]['sd_s']),
                        'unit': 's', 'condition': c, 'kind': 'value', 'equation_id': None})
        results.append({'id': 'n_samples__' + c, 'name': '조건별 시료 수', 'value': float(summary[c]['n']),
                        'unit': None, 'condition': c, 'kind': 'n', 'equation_id': None})
    results.append({'id': 't_stat', 'name': '독립 2표본 t 검정 통계량', 'value': float(t_stat),
                    'unit': None, 'condition': None, 'kind': 'test_statistic', 'equation_id': None})
    results.append({'id': 'df', 'name': '자유도', 'value': float(df),
                    'unit': None, 'condition': None, 'kind': 'df', 'equation_id': None})
    results.append({'id': 'p_value', 'name': '양측 p값', 'value': float(p_value),
                    'unit': None, 'condition': None, 'kind': 'p_value', 'equation_id': None})
    results.append({'id': 'reduction_pct', 'name': '감소율 (대조 평균 − 촉매 평균) / 대조 평균 × 100', 'value': float(reduction_pct),
                    'unit': '%', 'condition': None, 'kind': 'percent_change', 'equation_id': None})
    results.append({'id': 'mean_diff', 'name': '평균 차이 (대조 평균 − 촉매 평균)', 'value': float(mean_diff),
                    'unit': 's', 'condition': None, 'kind': 'difference', 'equation_id': None})

    # ---------- 6단계: 보고용 반올림 (intermediate 에만) ----------
    reporting_rounded = {
        c: {'mean_s': _r1(summary[c]['mean_s']), 'sd_s': _r1(summary[c]['sd_s']), 'n': summary[c]['n']}
        for c in cond_names
    }
    reporting_rounded['mean_diff_s'] = _r1(mean_diff)

    intermediate = {
        'file_checks': file_checks,
        'rows': table,
        'n_valid_rows': len(table),
        'sample_values': sample_table,
        'condition_sample_values_s': sample_values,
        'condition_summary': summary,
        't_test': {
            'method': '독립 2표본 t 검정(등분산 가정, 양측)',
            'order': CONTROL + ' − ' + TREAT,
            'n_control': n1, 'n_treat': n2, 'df': df, 'planned_df': PLANNED_DF,
            'pooled_variance_s2': pooled_var, 'standard_error_s': se,
            't': t_stat, 'p_two_sided': p_value, 'alpha': ALPHA,
            'significant_p_lt_alpha': significant,
            'scipy_ttest_ind_check': scipy_check,
        },
        'reporting_rounded_1dp': reporting_rounded,
        'warnings': warnings,
        'skipped_rows': skipped,
    }
    return {'results': results, 'intermediate': intermediate}
