# lab script - MeasureTrace must never run this
d <- read.csv('raw/annealed/S01.csv')
