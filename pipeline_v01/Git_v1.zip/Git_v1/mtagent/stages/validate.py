"""5 VALIDATE — 최종 보고서 초안의 주장을 4 RECOMPUTE 결과와 비교하고 오류 코드를 붙인다.

블라인드: 보고서는 4 RECOMPUTE 계산이 끝난 뒤 여기서 처음 연다(열람 시각 기록, 1 INGEST 해시 대조).
5-1 주장 추출 [LLM]   문장마다 몇 쪽 몇 번째 문장인지 번호를 붙여 보내고(능력 저하 줄이기), 분류와 검사할 주장을 받는다.
                     재계산 항목 목록은 이름·단위·조건만 보낸다 — 재계산 값은 보내지 않음(LLM 이 값에 끌려가지 않게).
5-2 비교 [PY]        보고 자릿수로 반올림해 비교 · 단위 환산 · 방향 · 유의성(α) · 표본 수·자유도.
5-3 오류 코드 [PY]   비교 결과 + 앞 단계 기록(미확정·누락·사양 밖 값·데이터 변경)을 주장이 쓰는 항목 기준으로 붙인다.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from mtagent import codes, design, lineage, readers, store, units
from mtagent.codes import code
from mtagent.llm import LLM, arr, boolean, num, obj, s
from mtagent.util import is_finite_number, now, sha_file, write_json

CATEGORIES = ["numeric", "direction", "significance", "degree", "mixed", "qualitative", "citation", "none"]
CATEGORY_KO = {"numeric": "자기 데이터 수치", "direction": "방향", "significance": "유의성", "degree": "정도 표현",
               "mixed": "혼합(자기 값 + 문헌값)", "qualitative": "정성 서술", "citation": "문헌 인용", "none": "주장 아님"}
SCHEMA = obj({"sentences": arr(obj({
    "sid": s(), "category": s(enum=CATEGORIES),
    "claims": arr(obj({
        "type": s(enum=["value", "n", "direction", "significance"]),
        "text": s("문장 안의 해당 부분을 글자 그대로"),
        "value": num("적힌 수치 그대로"), "unit": s("적힌 단위 그대로, 없으면 null", nullable=True),
        "output_id": s("재계산 항목 id, 목록에 없으면 null", nullable=True),
        "lhs": s(nullable=True), "rhs": s(nullable=True), "relation": s(nullable=True, enum=["greater", "less", "equal"]),
        "p_value": num(), "p_comparator": s(nullable=True, enum=["<", "<=", "=", ">", ">="]),
        "significant": boolean(nullable=True), "df": num(), "literature": boolean()}))}))})
SYSTEM = """너는 연구 재현성 감사 도구 MeasureTrace 의 주장 추출 담당이다. 한국어로 답한다.
과업 5-1 주장 추출: 최종 보고서 초안의 문장(쪽·문장 번호가 붙은 목록)마다 분류하고, 재계산 결과와 대조할 수 있는 주장을 뽑는다.
계산하거나 맞는지 판단하지 않는다 — 대조는 파이썬이 한다.
- category: numeric(자기 데이터 수치) · direction(크다/작다/증가) · significance(유의성·검정) · degree(정도 표현: 크게, 약간)
  · mixed(자기 값과 문헌값이 섞임) · qualitative(수치 없는 서술) · citation(문헌 인용) · none(제목·설명 등)
- claims — 문장마다 0개 이상:
  value: 보고한 수치 하나마다(평균, 표준편차 ±, 통계량, 증가율 등). value 는 적힌 그대로, unit 은 적힌 그대로, output_id 는 재계산 항목 목록에서 고른다.
  n: 표본 수. "각 n = 10" 처럼 여러 조건에 걸리면 조건마다 하나씩.
  direction: lhs·rhs 에 비교하는 두 재계산 항목 id, relation 은 lhs 가 rhs 보다 greater/less/equal.
  significance: output_id 는 p값 항목, p_value·p_comparator 는 적힌 그대로(p < 0.001 → 0.001, "<"), significant 는 유의하다고 주장하면 true,
                자유도가 적혀 있으면 df. 검정 통계량 값(t = 6.05 등)은 따로 value 주장으로.
- 문헌값(인용한 남의 값)은 literature=true 로 표시하고 output_id 는 null. 자기 값과 섞인 문장은 자기 값만 literature=false.
- 재계산 항목 목록에 맞는 항목이 없으면 output_id 는 null 로 둔다(지어내지 않는다). 해당 없는 필드는 null."""


def split_sentences(par: str) -> list[str]:
    parts = re.split(r"(?<=[.!?。])(?<!\d\.)\s+(?=\S)", par.strip())
    return [p.strip() for p in parts if p.strip()]


def _decimals(claim_text: str, value: float) -> int:
    for tok in re.findall(r"\d+(?:\.\d+)?", claim_text or ""):
        if abs(float(tok) - abs(value)) <= 1e-12 * max(1, abs(value)):
            return len(tok.split(".")[1]) if "." in tok else 0
    t = repr(float(value))
    return 0 if t.endswith(".0") else len(t.split(".")[1]) if "." in t and "e" not in t else 3


def _catalog(results: list[dict], conds: list[dict]) -> list[dict]:
    label = {c["name"]: c.get("label") or c["name"] for c in conds}
    return [{"id": r["id"], "name": r.get("name"), "unit": r.get("unit"), "kind": r.get("kind"),
             "condition": label.get(r.get("group"), r.get("condition"))} for r in results]


def _compare(cl: dict, outs: dict[str, dict], conf: dict) -> tuple[dict, list[dict]]:
    """→ (비교 기록, 오류 코드). 비교 기록: {outputs_used, reported, recomputed, shown, compared, note}."""
    t = cl["type"]
    rec = {"outputs_used": [], "reported": None, "recomputed": None, "shown": None, "compared": False, "note": ""}
    found = []
    if t in ("value", "n"):
        o = outs.get(cl.get("output_id") or "")
        if t == "n" and o is None:
            sizes = {len(c.get("samples") or []) for c in (conf.get("design") or {}).get("conditions", [])}
            if len(sizes) == 1 and is_finite_number(cl.get("value")):
                n = sizes.pop()
                rec.update(reported=cl["value"], recomputed=n, shown=str(n), compared=True, note="설계의 조건별 시료 수와 비교")
                if int(cl["value"]) != n:
                    found.append(code("E04", f"보고 n={cl['value']:g} · 설계 n={n}"))
                return rec, found
        if o is None:
            return rec, [code("E06", f"'{cl.get('text')}' 에 해당하는 재계산 항목 없음 (output_id={cl.get('output_id')})")]
        rec["outputs_used"] = [o["id"]]
        if not is_finite_number(cl.get("value")):
            return rec, [code("E06", "보고한 수치를 읽지 못함")]
        val, rv = float(cl["value"]), float(o["value"])
        if t == "n" or o.get("kind") in ("n", "df"):
            rec.update(reported=val, recomputed=rv, shown=f"{rv:g}", compared=True)
            if round(val) != round(rv):
                found.append(code("E04", f"보고 {val:g} · 재계산 {rv:g}"))
            return rec, found
        uo, uc = o.get("unit"), cl.get("unit")
        do, dc = units.dimension(uo), units.dimension(uc)
        if uo and do not in (None, "none") and not uc:
            found.append(code("E01", f"단위 누락 — 재계산 단위는 {uo}"))
            conv = rv
        elif uc and dc is None:
            return rec, [code("E01", f"보고 단위 '{uc}' 를 해석할 수 없음")]
        elif uc and do not in (None,) and dc != do and not (dc == "none" and do == "none"):
            return rec, [code("E01", f"단위 불일치 — 보고 {uc}({dc}) · 재계산 {uo}({do})")]
        else:
            conv = units.convert(rv, uo, uc) if uc and uo and do == dc else rv
        d = _decimals(cl.get("text") or "", val)
        shown = f"{conv:.{d}f}"
        rec.update(reported=f"{val:.{d}f}" + (f" {uc}" if uc else ""), recomputed=rv, shown=shown + (f" {uc}" if uc else ""), compared=True,
                   note=f"보고 자릿수({d})로 비교" + (f" · {uo}→{uc} 환산" if uc and uo and uc != uo else ""))
        if abs(conv - val) > 0.5 * 10 ** (-d) * (1 + 1e-9) + 1e-12:
            found.append(code("E05", f"보고 {val:g} · 재계산 {shown} (원값 {rv:.6g})"))
        return rec, found
    if t == "direction":
        a, b = outs.get(cl.get("lhs") or ""), outs.get(cl.get("rhs") or "")
        if not a or not b or not cl.get("relation"):
            return rec, [code("E06", "방향 주장의 비교 항목을 찾지 못함")]
        rec["outputs_used"] = [a["id"], b["id"]]
        diff = a["value"] - b["value"]
        ok = {"greater": diff > 0, "less": diff < 0, "equal": abs(diff) <= 1e-9 * max(abs(a["value"]), 1)}[cl["relation"]]
        rec.update(reported=f"{a['id']} {'>' if cl['relation'] == 'greater' else '<' if cl['relation'] == 'less' else '='} {b['id']}",
                   recomputed=diff, shown=f"차이 {diff:.6g}", compared=True)
        if not ok:
            found.append(code("E05", f"방향 불일치 — 재계산 차이 {diff:.6g}"))
        return rec, found
    if t == "significance":
        p = outs.get(cl.get("output_id") or "") or next((o for o in outs.values() if o.get("kind") == "p_value"), None)
        if p is None:
            return rec, [code("E06", "p값 재계산 항목 없음")]
        alpha = ((conf.get("test") or {}).get("alpha")) or 0.05
        pv = float(p["value"])
        rec.update(outputs_used=[p["id"]], reported=" ".join(str(x) for x in (cl.get("p_comparator"), cl.get("p_value")) if x is not None)
                   or ("유의" if cl.get("significant") else "유의하지 않음"), recomputed=pv,
                   shown=f"p = {pv:.3g} (α={alpha})", compared=True)
        if cl.get("significant") is not None and bool(cl["significant"]) != (pv < alpha):
            found.append(code("E05", f"유의성 불일치 — 재계산 p = {pv:.3g}, α = {alpha}"))
        if is_finite_number(cl.get("p_value")) and cl.get("p_comparator"):
            x = float(cl["p_value"])
            op = cl["p_comparator"]
            ok = {"<": pv < x, "<=": pv <= x, ">": pv > x, ">=": pv >= x,
                  "=": abs(pv - x) <= 0.5 * 10 ** (-_decimals(cl.get("text") or "", x))}[op]
            if not ok:
                found.append(code("E05", f"p 표현 불일치 — 보고 p {op} {x:g} · 재계산 p = {pv:.3g}"))
        if is_finite_number(cl.get("df")):
            dfo = next((o for o in outs.values() if o.get("kind") == "df"), None)
            if dfo:
                rec["outputs_used"].append(dfo["id"])
                if round(float(cl["df"])) != round(dfo["value"]):
                    found.append(code("E04", f"자유도 불일치 — 보고 {cl['df']:g} · 재계산 {dfo['value']:g}"))
        return rec, found
    return rec, [code("E06", f"알 수 없는 주장 종류 {t}")]


def _dependency_codes(used: list[str], outs: dict[str, dict], conf: dict, calc: dict) -> list[dict]:
    """주장이 쓰는 재계산 항목에 걸린 앞 단계 기록."""
    found = []
    conds = (conf.get("design") or {}).get("conditions") or []
    used_o = [outs[u] for u in used if u in outs]
    groups = {o.get("group") for o in used_o}

    def touches(group):       # 이 집단의 데이터를 쓰는가 — 집단 없는 항목(합동·비교)은 모든 집단을 쓴다
        return group is None or None in groups or group in groups

    for p in conf.get("pending", []):
        tg = p.get("target") or "*"
        if tg in ("*", "code") or tg.startswith("unit:") or tg.startswith("data:") or \
                (tg.startswith("eq:") and any(o.get("equation_id") == tg[3:] for o in used_o)):
            found.append(code("E06", f"CONFIRM 뒤에도 미확정: {p['title']}", [p["item"]]))
    for m in conf.get("missing", []):
        if m.get("kind") == "필요 문서 없음":
            continue
        g = design.match_condition(m.get("condition"), conds, m.get("sample"))
        if touches(g):
            found.append(code("E03", f"{m['kind']}: {m['detail']}", [m.get("file") or ""]))
    for f in conf.get("data_flags", []):
        g = design.match_condition(None, conds, Path(f["file"]).stem)
        if touches(g):
            found.append(code("E02", f"{f['file']} {f['column']}: {f['detail']} — 연구자가 값이 맞다고 확인", [f["file"]]))
    for ch in (calc.get("e07") or {}).get("changes") or []:
        if ch["kind"] == "형식만 변경":
            continue
        g = design.match_condition(None, conds, Path(ch["file"]).stem)
        if touches(g):
            found.append(code("E07", f"{ch['file']}: {ch['kind']} — {ch['detail']}", [calc["e07"]["compared_with"]]))
    return found


def run(rid: str, llm: LLM | None = None, report: str | None = None) -> dict:
    store.require(rid, "recompute", ok=("done", "blocked", "error"))
    calc = store.read(rid, "recompute/calc_log.json")
    conf = store.read(rid, "confirm/confirmed.json")
    ing = store.read(rid, "ingest.json")
    reports = [x for x in ing["files"] if x["zone"] == "report" and x["category"] == "report"]
    if not reports:
        raise ValueError("최종 보고서 초안이 없음 — 1 INGEST 의 '최종 보고서 초안' 칸에 넣은 실행이어야 함")
    rep = next((x for x in reports if x["path"] == report), None) if report else reports[0]
    if rep is None:
        raise ValueError(f"보고서 {report!r} 는 이 실행의 보고서가 아님")
    path = store.in_dir(rid) / "report" / rep["path"]
    if sha_file(path) != rep["sha256"]:
        raise ValueError("보고서가 1 INGEST 이후 바뀜 — 새 실행")
    opened = now()
    blind = {"calc_finished_at": calc.get("finished_at"), "report_opened_at": opened,
             "ok": bool(calc.get("finished_at")) and calc["finished_at"] < opened, "report": rep["path"], "sha256": rep["sha256"]}
    llm = llm or LLM()
    sentences = []
    for pi, paras in enumerate(readers.document_pages(path), 1):
        no = 0
        for par in paras:
            for sent in split_sentences(par):
                no += 1
                sentences.append({"sid": f"S{len(sentences) + 1:03d}", "page": pi, "no": no, "text": sent})
    results = calc.get("results") or []
    outs = {r["id"]: r for r in results}
    conds = (conf.get("design") or {}).get("conditions") or []
    catalog = _catalog(results, conds)
    user =("[재계산 항목 목록 — 값은 보내지 않음]\n" + json.dumps(catalog, ensure_ascii=False, indent=1)
            + "\n\n[설계]\n" + json.dumps({"conditions": [{k: c.get(k) for k in ("name", "label")} for c in conds],
                                           "test": conf.get("test")}, ensure_ascii=False)
            + "\n\n[보고서 문장]\n" + json.dumps([{k: x[k] for k in ("sid", "page", "no", "text")} for x in sentences],
                                                ensure_ascii=False, indent=1) + "\n[끝]")
    got = llm.json("5-1", SYSTEM, user, SCHEMA, effort="high")
    by_sid = {x["sid"]: x for x in got.get("sentences", [])}
    claims, non_target = [], []
    blocked = calc.get("status") != "ok"
    for sx in sentences:
        g = by_sid.get(sx["sid"]) or {"category": "none", "claims": []}
        sx["category"] = g["category"]
        own = [c for c in g.get("claims", []) if not c.get("literature")]
        if not own:
            non_target.append({**sx, "category_ko": CATEGORY_KO.get(g["category"], g["category"]),
                               "literature_only": any(c.get("literature") for c in g.get("claims", []))})
            continue
        for k, cl in enumerate(own, 1):
            if blocked:
                rec, found = {"outputs_used": [], "compared": False, "note": "4 RECOMPUTE 가 계산하지 않음"}, \
                    [code("E06", f"재계산이 {calc.get('status')} — {calc.get('reason')}")]
            else:
                rec, found = _compare(cl, outs, conf)
                found += _dependency_codes(rec["outputs_used"], outs, conf, calc)
            verdict = "Unsupported" if any(c["effect"] == "Unsupported" for c in found) or not rec.get("compared") else "Supported"
            rec["groups"] = sorted({str(outs[u].get("group")) for u in rec.get("outputs_used", []) if u in outs})
            claims.append({"cid": f"{sx['sid']}-{k}", **{f: sx[f] for f in ("sid", "page", "no")}, "sentence": sx["text"],
                           "category": g["category"], "category_ko": CATEGORY_KO.get(g["category"], g["category"]),
                           "claim": cl, **rec, "codes": found, "verdict": verdict,
                           "note": rec.get("note", "") + (" · 정도 표현은 판단하지 않고 방향만 확인" if g["category"] == "degree" else "")})
    counts: dict[str, int] = {}
    for c in claims:
        for k in {x["code"] for x in c["codes"]}:
            counts[k] = counts.get(k, 0) + 1
    summary = {"Supported": sum(c["verdict"] == "Supported" for c in claims),
               "Unsupported": sum(c["verdict"] == "Unsupported" for c in claims),
               "not_checked": len(non_target), "codes": counts}
    out = {"stage": "5 VALIDATE", "run_id": rid, "at": now(), "blind": blind, "report": rep["path"],
           "sentences": sentences, "claims": claims, "non_target": non_target, "summary": summary,
           "llm": {**llm.status(), **llm.stats}, "sent": user}
    p = write_json(store.out_dir(rid) / "validate.json", out)
    lineage.record("5 VALIDATE", rid, calc.get("result_hash") or calc.get("input_hash"), lineage.code_version(sys.modules[__name__], codes),
                   {"report": rep["path"], "report_sha256": rep["sha256"][:16], "model": llm.model}, [p])
    store.mark(rid, "validate", "done", **{k: summary[k] for k in ("Supported", "Unsupported")})
    return out
