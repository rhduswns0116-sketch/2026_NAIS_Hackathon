"""4 RECOMPUTE — 확정된 식·가공 순서(3 CONFIRM)를 구현한 승인 코드로 RAW 에서 다시 계산하고 계산 로그를 남긴다.

4-1 수치 재계산  실행 전 확인: 승인 코드 해시 = 확정 해시 · 추출 결과가 확정 때와 같음 · RAW 사본 해시 = 1 INGEST 해시 · 정적 점검.
                 하나라도 어긋나면 실행하지 않고 이유를 남긴다. 실행은 격리 프로세스에서 한 번(입력은 RAW 만, 보고서 미개봉).
4-3 계산 커밋    계산 로그: ① 사용한 RAW 해시 ② 계산 과정(확정 단계·코드 해시·중간값) ③ 결과값(반올림 전) ④ 결과 해시.
                 같은 프로젝트의 이전 계산과 RAW 해시를 비교해 데이터 변경(E07)을 기록 — 판정은 바꾸지 않음.
(그래프 재생성은 하지 않음 — 파이프라인 v4 에서 제외)
"""
from __future__ import annotations

import sys
from importlib import metadata

from mtagent import config, design, hashing, lineage, sandbox, store
from mtagent.util import canonical, now, sha_file, sha_text, write_json


def _versions() -> dict:
    out = {"python": sys.version.split()[0]}
    for pkg in ("numpy", "scipy", "pandas"):
        try:
            out[pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            out[pkg] = None
    return out


def run(rid: str) -> dict:
    store.require(rid, "confirm")
    conf = store.read(rid, "confirm/confirmed.json")
    ing = store.read(rid, "ingest.json")
    raw = [x for x in ing["files"] if x["zone"] == "data" and x["category"] == "raw"]
    base = store.in_dir(rid) / "data"
    started = now()
    inputs = [{"path": x["path"], "sha256": x["sha256"], "content_hash": x["content_hash"]} for x in raw]
    input_hash = sha_text(canonical([(x["path"], x["sha256"]) for x in inputs]))
    log = {"stage": "4 RECOMPUTE", "run_id": rid, "project": conf["project"], "started_at": started,
           "inputs": inputs, "input_hash": input_hash, "confirmed_hash": conf["hash"],
           "steps": conf.get("steps"), "equations": [e["id"] for e in conf.get("equations", [])],
           "code": conf.get("code"), "env": _versions(), "results": [], "intermediate": {}, "checks": []}
    checks = log["checks"]

    def check(name, ok, detail=""):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        return ok

    ok = check("계산 코드 승인", conf.get("code"), "3-1 에서 승인한 코드" if conf.get("code") else
               "승인된 코드 없음(미확정) — 계산하지 않고 막힌 채 기록, 5단계에서 수치 주장은 E06")
    code_path = store.out_dir(rid) / "confirm" / "approved_code.py"
    if ok:
        ok = check("승인 코드 해시", code_path.exists() and sha_file(code_path) == conf["code"]["sha256"],
                   f"확정 해시 {conf['code']['sha256'][:12]}")
    if ok:
        now_hash = (store.read(rid, "extract/summary.json") or {}).get("hash")
        ok = check("추출 결과가 확정 때와 같음", now_hash == conf.get("extract_hash"), f"{(now_hash or '')[:12]}")
    if ok:
        bad = [x["path"] for x in raw if sha_file(base / x["path"]) != x["sha256"]]
        ok = check("RAW 사본이 1 INGEST 해시와 같음", not bad, ", ".join(bad[:5]) or f"{len(raw)}개 같음")
    if ok:
        code = code_path.read_text(encoding="utf-8")
        problems = sandbox.static_check(code)
        ok = check("정적 점검", not problems, "; ".join(problems[:5]) or "금지 항목 없음")
    if not ok:
        log.update(status="blocked", reason=next(c for c in checks if not c["ok"])["check"] + " 실패")
    else:
        files = {x["path"]: str((base / x["path"]).resolve()) for x in raw}
        res = sandbox.run(code_path, conf["code"]["sha256"], files, config.SANDBOX_TIMEOUT)
        log["sandbox"] = {"seconds": res.get("seconds"), "blocked": res.get("blocked", []), "stdout": res.get("stdout", ""),
                          "timeout": config.SANDBOX_TIMEOUT,
                          "isolation": "별도 프로세스(python -I -B) + 감사 훅 · 최소 환경 변수 · 빈 임시 폴더 — 컨테이너·VM 아님"}
        check("격리 실행", res.get("status") == "ok", res.get("error") or "완료")
        if res.get("status") == "ok":
            conds = (conf.get("design") or {}).get("conditions") or []
            for r in res["results"]:
                r["group"] = design.match_condition(r.get("condition"), conds) if r.get("condition") else None
            log.update(status="ok", results=res["results"], intermediate=res.get("intermediate") or {},
                       result_hash=sandbox.result_hash(res["results"]))
        else:
            log.update(status="error", reason=res.get("error"), traceback=res.get("traceback"))
    log["finished_at"] = now()
    log["e07"] = _e07(rid, ing, log)
    rdir = store.out_dir(rid) / "recompute"
    path = write_json(rdir / "calc_log.json", log)
    write_json(rdir / "history" / f"calc_{log['finished_at'][:19].replace(':', '').replace('-', '')}.json", log)
    lineage.record("4 RECOMPUTE", rid, input_hash, sha_text((conf.get("code") or {}).get("sha256", "") + conf["hash"]),
                   {"confirmed": conf["hash"][:16], "status": log["status"]}, [path])
    store.mark(rid, "recompute", "done" if log["status"] == "ok" else log["status"])
    return log


def _e07(rid: str, ing: dict, log: dict) -> dict:
    prev = store.previous_run(rid, "recompute")
    if not prev:
        return {"compared_with": None, "note": "같은 프로젝트의 이전 계산 없음"}
    old_ing = store.read(prev, "ingest.json") or {}
    old = {x["path"]: x for x in old_ing.get("files", []) if x["zone"] == "data" and x["category"] == "raw"}
    new = {x["path"]: x for x in ing["files"] if x["zone"] == "data" and x["category"] == "raw"}
    changes = hashing.compare_sets(old, new)
    old_log = store.read(prev, "recompute/calc_log.json") or {}
    ov = {r["id"]: r["value"] for r in old_log.get("results") or []}
    value_changes = [{"id": r["id"], "before": ov[r["id"]], "after": r["value"]}
                     for r in log.get("results") or [] if r["id"] in ov and ov[r["id"]] != r["value"]]
    return {"compared_with": prev, "changes": changes, "result_changes": value_changes,
            "note": "기록만 — 판정은 바꾸지 않음"}
