"""오류 코드 — 5 VALIDATE 가 주장마다 붙이고 6 AUDIT 가 보여 준다.

Unsupported 로 만드는 코드와 기록만 하는 코드(판정은 바꾸지 않음)를 나눈다.
"""
from __future__ import annotations

NAMES = {
    "E01": "단위 불일치 (누락 포함)",
    "E02": "측정값 이상 — 장비 사양 범위 밖 값을 그대로 진행",
    "E03": "필요 데이터 누락",
    "E04": "표본 수·자유도 불일치",
    "E05": "수치·방향·유의성 불일치",
    "E06": "재계산 근거 없음·미확정",
    "E07": "데이터 버전 변경 (이전 실행 대비)",
}
UNSUPPORTED = {"E01", "E03", "E04", "E05", "E06"}
RECORD = {"E02", "E07"}


def code(c: str, detail: str, evidence: list[str] | None = None) -> dict:
    return {"code": c, "name": NAMES[c], "effect": "Unsupported" if c in UNSUPPORTED else "기록",
            "detail": detail, "evidence": evidence or []}
