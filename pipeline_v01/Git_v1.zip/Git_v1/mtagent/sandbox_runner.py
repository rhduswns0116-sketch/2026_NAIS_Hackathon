"""격리 실행기 — 단독 파일(패키지를 import 하지 않음). `python -I -B sandbox_runner.py` 로만 실행.

표준 입력: {"code_path", "code_sha256", "files": {상대 경로: 실제 경로}}
표준 출력: @@MT_RESULT@@{"status", "results", "intermediate", "stdout", "blocked", "error"}
"""
import contextlib
import hashlib
import io
import json
import math
import os
import sys
import traceback

MARK = "@@MT_RESULT@@"
ALLOWED_IMPORTS = {"math", "statistics", "csv", "collections", "itertools", "functools", "re", "json", "decimal",
                   "fractions", "operator", "typing", "dataclasses", "numpy", "scipy", "pandas"}   # sandbox.py 와 같게
FORBIDDEN_MODULES = {"socket", "ssl", "subprocess", "ctypes", "_ctypes", "multiprocessing", "shutil", "urllib",
                     "http", "ftplib", "smtplib", "requests", "winreg", "_winapi", "pickle", "marshal", "webbrowser"}
BLOCK_EVENTS = ("socket.", "subprocess.", "os.system", "os.exec", "os.spawn", "os.posix_spawn", "os.fork",
                "os.kill", "os.remove", "os.unlink", "os.rename", "os.rmdir", "os.mkdir", "os.chmod", "os.truncate",
                "shutil.", "ctypes.", "winreg.", "_winapi.", "webbrowser.", "urllib.", "http.")
WRITE_FLAGS = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_APPEND | os.O_TRUNC


def emit(obj):
    sys.__stdout__.write(MARK + json.dumps(obj, ensure_ascii=False, default=_default) + "\n")
    sys.__stdout__.flush()


def _default(x):
    try:
        import numpy as np
        if isinstance(x, np.generic):
            return x.item()
        if isinstance(x, np.ndarray):
            return x.tolist()
    except Exception:
        pass
    return str(x)


def main():
    # -I 는 PYTHONIOENCODING 을 무시하므로 직접 UTF-8 로 맞춘다 (한글 경로·출력)
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        stream.reconfigure(encoding="utf-8", errors="replace")
    spec = json.loads(sys.stdin.read())
    code_bytes = open(spec["code_path"], "rb").read()
    if hashlib.sha256(code_bytes).hexdigest() != spec["code_sha256"]:
        return emit({"status": "error", "error": "코드 해시가 승인 해시와 다름 — 실행하지 않음"})
    code = code_bytes.decode("utf-8")
    # 무거운 허용 모듈은 감사 훅 전에 미리 불러 둔다
    for mod in ("numpy", "scipy", "scipy.stats", "scipy.optimize", "pandas", "statistics", "csv", "decimal", "fractions"):
        try:
            __import__(mod)
        except ImportError:
            pass
    allowed_files = {os.path.normcase(os.path.abspath(p)) for p in spec["files"].values()}
    allowed_files.add(os.path.normcase(os.path.abspath(__file__)))   # 오류 추적(traceback)이 실행기 소스를 읽음
    roots = {os.path.normcase(os.path.abspath(r)) for r in (sys.prefix, sys.base_prefix, sys.exec_prefix) if r}
    blocked = []

    def hook(event, args):
        if event == "open":
            path, mode, flags = (list(args) + [None, None, None])[:3]
            if isinstance(path, int) or path is None or os.fsdecode(path).startswith("<"):
                return
            writing = (isinstance(mode, str) and any(c in mode for c in "wax+")) or \
                      (isinstance(flags, int) and flags & WRITE_FLAGS)
            p = os.path.normcase(os.path.abspath(os.fsdecode(path)))
            if writing:
                blocked.append(f"파일 쓰기 {p}")
                raise PermissionError("MeasureTrace 격리 실행: 파일 쓰기 금지")
            if p not in allowed_files and not any(p.startswith(r + os.sep) or p == r for r in roots):
                blocked.append(f"허용 밖 읽기 {p}")
                raise PermissionError("MeasureTrace 격리 실행: 허용한 RAW 밖 읽기 금지")
        elif event == "import":
            if str(args[0]).split(".")[0] in FORBIDDEN_MODULES:
                blocked.append(f"금지 모듈 {args[0]}")
                raise ImportError(f"MeasureTrace 격리 실행: 금지 모듈 {args[0]}")
        elif event.startswith(BLOCK_EVENTS):
            blocked.append(event)
            raise PermissionError(f"MeasureTrace 격리 실행: 금지 동작 {event}")

    sys.addaudithook(hook)
    # 승인 코드의 import 는 허용 목록만 (이미 불러온 모듈은 import 감사 이벤트가 나지 않으므로 여기서 막는다)
    import builtins
    real_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if level != 0 or name.split(".")[0] not in ALLOWED_IMPORTS:
            blocked.append(f"금지 import {name}")
            raise ImportError(f"MeasureTrace 격리 실행: 허용하지 않은 import {name}")
        return real_import(name, globals, locals, fromlist, level)

    safe_builtins = dict(vars(builtins))
    safe_builtins["__import__"] = guarded_import
    namespace = {"__name__": "approved_code", "__builtins__": safe_builtins}
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(code, "approved_code.py", "exec"), namespace)
            out = namespace["compute"](dict(spec["files"]))
        if not isinstance(out, dict):
            raise TypeError("compute() 는 dict 를 돌려줘야 함")
        results = out.get("results")
        for r in results or []:
            if isinstance(r, dict) and r.get("value") is not None:
                try:
                    r["value"] = float(r["value"])
                    if not math.isfinite(r["value"]):
                        r["value"] = None
                except (TypeError, ValueError):
                    pass
        emit({"status": "ok", "results": results, "intermediate": out.get("intermediate") or {},
              "stdout": buf.getvalue()[-5000:], "blocked": blocked})
    except BaseException as e:
        emit({"status": "error", "error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()[-3000:],
              "stdout": buf.getvalue()[-5000:], "blocked": blocked})


if __name__ == "__main__":
    main()
