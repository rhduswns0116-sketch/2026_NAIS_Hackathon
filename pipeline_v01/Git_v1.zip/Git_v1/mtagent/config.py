"""설정 — 경로·모델·키는 여기서만 정한다.

  workspace/inputs/<실행>/data/     연구 자료 사본 (읽기 전용으로 잠금)
  workspace/inputs/<실행>/report/   최종 보고서 초안 사본 (5 VALIDATE 전까지 열지 않음)
  workspace/outputs/<실행>/         산출물 (입력 밖)
  workspace/outputs/lineage.jsonl  파생 이력 장부
  workspace/llm_cache/             LLM 응답 캐시 (같은 입력 → 같은 답)

환경 변수(.env 가능): LLM_API_KEY(또는 ANTHROPIC_API_KEY) · LLM_MODEL · MT_OFFLINE=1(캐시만) · MT_WORKSPACE(작업 폴더)
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL = "claude-opus-5-5"
CONFIRM_MAX_ROUNDS = 3          # CONFIRM 피드백 회차 상한 — 넘으면 남은 항목은 미확정(E06)
SANDBOX_TIMEOUT = 300           # 4 RECOMPUTE 격리 실행 제한(초)

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
except ImportError:   # python-dotenv 가 없으면 환경 변수만 쓴다
    pass


def workspace() -> Path:
    return Path(os.environ.get("MT_WORKSPACE") or ROOT / "workspace")


def inputs_dir() -> Path:
    return workspace() / "inputs"


def outputs_dir() -> Path:
    return workspace() / "outputs"


def cache_dir() -> Path:
    return workspace() / "llm_cache"


def model() -> str:
    return os.environ.get("LLM_MODEL") or DEFAULT_MODEL


def api_key() -> str:
    return (os.environ.get("LLM_API_KEY") or os.environ.get("ANTHROPIC_API_KEY") or "").strip()


def offline() -> bool:
    return os.environ.get("MT_OFFLINE") == "1"
