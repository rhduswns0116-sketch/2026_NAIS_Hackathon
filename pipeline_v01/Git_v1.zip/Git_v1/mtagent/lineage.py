"""1-3 파생 이력(lineage) 장부.

파이프라인이 만든 산출물마다 한 줄: (입력 해시, 코드 버전, 파라미터) → 출력 해시.
같은 입력·같은 코드·같은 파라미터면 같은 출력 해시가 나와야 한다 — 다르면 어딘가 바뀐 것이다.
연구자가 가져온 파일은 파이프라인이 만든 것이 아니므로 적지 않는다(입력 해시로만 등장).
"""
from __future__ import annotations

import json
import threading
from pathlib import Path

from mtagent import config
from mtagent.util import canonical, now, sha_file, sha_text

_lock = threading.Lock()


def ledger_path() -> Path:
    return config.outputs_dir() / "lineage.jsonl"


def code_version(*modules) -> str:
    """이 단계를 만든 소스 파일들의 해시 — 코드가 바뀌면 달라진다."""
    parts = []
    for m in modules:
        p = Path(m.__file__)
        parts.append(p.name + ":" + sha_file(p))
    return sha_text("|".join(sorted(parts)))


def record(stage: str, run_id: str, input_hash: str, code_ver: str, params: dict, outputs: list[Path]) -> dict:
    outs = {Path(p).name: sha_file(Path(p)) for p in outputs if Path(p).exists()}
    entry = {"at": now(), "stage": stage, "run_id": run_id, "input_hash": input_hash, "code_version": code_ver,
             "params": params, "outputs": outs, "output_hash": sha_text(canonical(outs))}
    path = ledger_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with _lock, path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
    return entry


def entries(run_id: str | None = None, limit: int = 200) -> list[dict]:
    path = ledger_path()
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if run_id is None or e.get("run_id") == run_id:
            out.append(e)
    return out[-limit:]
