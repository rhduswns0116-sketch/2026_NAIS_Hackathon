"""실행(run) 저장소 — 실행 폴더 · 상태 · 업로드.

한 실행 = 한 벌의 입력. 1 INGEST 를 마치면 입력이 봉인되어 파일을 더할 수 없다(입력이 바뀌면 새 실행).
"""
from __future__ import annotations

import os
import secrets
import shutil
import stat
from datetime import datetime
from pathlib import Path, PurePosixPath

from mtagent import config
from mtagent.util import now, read_json, write_json

ZONES = ("data", "report")
STAGES = ("ingest", "extract", "confirm", "recompute", "validate", "audit")
MAX_UPLOAD = 2 * 1024 ** 3


def new_run(project: str) -> str:
    project = (project or "").strip()
    if not project:
        raise ValueError("프로젝트 이름이 필요함")
    if any(c in project for c in '\\/:*?"<>|') or project.startswith("."):
        raise ValueError("프로젝트 이름에 쓸 수 없는 글자가 있음")
    rid = datetime.now().strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(2)
    for z in ZONES:
        (in_dir(rid) / z).mkdir(parents=True, exist_ok=False)
    out_dir(rid).mkdir(parents=True, exist_ok=False)
    save_state(rid, {"run_id": rid, "project": project, "created_at": now(), "stages": {}})
    return rid


def _check_id(rid: str) -> str:
    if not rid or any(c in rid for c in "\\/.") or len(rid) > 64:
        raise ValueError(f"실행 ID 가 올바르지 않음: {rid!r}")
    return rid


def in_dir(rid: str) -> Path:
    return config.inputs_dir() / _check_id(rid)


def out_dir(rid: str) -> Path:
    return config.outputs_dir() / _check_id(rid)


def state(rid: str) -> dict:
    s = read_json(out_dir(rid) / "state.json")
    if s is None:
        raise ValueError(f"실행 {rid} 가 없음")
    return s


def read(rid: str, name: str, default=None):
    """산출물 읽기 (outputs/<실행>/<name>)."""
    return read_json(out_dir(rid) / name, default)


def save_state(rid: str, s: dict) -> None:
    write_json(out_dir(rid) / "state.json", s)


def mark(rid: str, stage: str, status: str, **extra) -> dict:
    s = state(rid)
    s["stages"][stage] = {"status": status, "at": now(), **extra}
    save_state(rid, s)
    return s


def stage_status(rid: str, stage: str) -> str | None:
    return (state(rid)["stages"].get(stage) or {}).get("status")


def require(rid: str, stage: str, ok=("done",)) -> None:
    st = stage_status(rid, stage)
    if st not in ok:
        raise ValueError(f"{stage} 단계를 먼저 마쳐야 함 (현재: {st or '실행 안 함'})")


def safe_rel(rel: str) -> str:
    """업로드 상대 경로 검사 — 절대 경로·상위 폴더·드라이브 문자 금지."""
    rel = (rel or "").replace("\\", "/").strip("/")
    p = PurePosixPath(rel)
    if not rel or p.is_absolute() or ":" in rel or any(part in ("", ".", "..") for part in p.parts):
        raise ValueError(f"올바르지 않은 파일 경로: {rel!r}")
    return p.as_posix()


def save_upload(rid: str, zone: str, rel: str, stream, length: int) -> dict:
    if zone not in ZONES:
        raise ValueError(f"zone 은 {ZONES} 중 하나")
    if stage_status(rid, "ingest"):
        raise ValueError("이 실행은 1 INGEST 를 시작해 봉인됨 — 입력을 바꾸려면 새 실행")
    if length > MAX_UPLOAD:
        raise ValueError("파일이 너무 큼")
    rel = safe_rel(rel)
    dest = in_dir(rid) / zone / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    left = length
    with open(dest, "wb") as f:
        while left > 0:
            chunk = stream.read(min(left, 1 << 20))
            if not chunk:
                break
            f.write(chunk)
            left -= len(chunk)
    if left:
        dest.unlink(missing_ok=True)
        raise ValueError("업로드가 중간에 끊김")
    return {"zone": zone, "path": rel, "size": length}


def add_folder(rid: str, zone: str, folder: Path) -> int:
    """로컬 폴더를 사본으로 넣기(명령줄·시험용). 원본은 건드리지 않는다."""
    folder = Path(folder)
    n = 0
    for p in sorted(folder.rglob("*")):
        if p.is_file():
            with p.open("rb") as f:
                save_upload(rid, zone, p.relative_to(folder).as_posix(), f, p.stat().st_size)
            n += 1
    return n


def lock_readonly(root: Path) -> int:
    n = 0
    for p in root.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IREAD)
            n += 1
    return n


def input_files(rid: str) -> list[tuple[str, str, Path]]:
    """(zone, 상대 경로, 실제 경로) — 이름순."""
    out = []
    for z in ZONES:
        base = in_dir(rid) / z
        for p in sorted(base.rglob("*")):
            if p.is_file():
                out.append((z, p.relative_to(base).as_posix(), p))
    return out


def list_runs() -> list[dict]:
    root = config.outputs_dir()
    if not root.exists():
        return []
    runs = []
    for d in sorted(root.iterdir(), reverse=True):
        s = read_json(d / "state.json") if d.is_dir() else None
        if s:
            runs.append({"run_id": s["run_id"], "project": s["project"], "created_at": s["created_at"],
                         "stages": {k: v.get("status") for k, v in s["stages"].items()},
                         "summary": s.get("summary")})
    return runs


def previous_run(rid: str, stage: str, status: str = "done") -> str | None:
    """같은 프로젝트의 앞선 실행 중 stage 를 마친 가장 최근 실행."""
    me = state(rid)
    for r in list_runs():
        if r["project"] == me["project"] and r["run_id"] < rid and r["stages"].get(stage) == status:
            return r["run_id"]
    return None


def delete_run(rid: str) -> None:
    for root in (in_dir(rid), out_dir(rid)):
        if root.exists():
            for p in root.rglob("*"):
                if p.is_file():
                    os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
            shutil.rmtree(root)
