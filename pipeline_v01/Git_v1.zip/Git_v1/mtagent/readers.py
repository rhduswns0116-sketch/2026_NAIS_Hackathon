"""파일 읽기 — 표(CSV·TSV·엑셀) · Word(글 + 수식) · PDF · 글 파일.

Word 수식(OMML)은 LaTeX 형태 글로 바꾼다(직접 구현). 파일 수정 시각은 읽지 않는다.
"""
from __future__ import annotations

import csv
import re
import zipfile
from pathlib import Path

from mtagent.util import sha_bytes

TABLE_EXT = {".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xlsm"}
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"


# ── 글자 인코딩 ─────────────────────────────────────────────────────────
def decode(data: bytes) -> tuple[str, str]:
    for enc in ("utf-8-sig", "cp949", "latin-1"):
        try:
            return data.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace"), "utf-8?"


def read_text(path: Path) -> str:
    return decode(Path(path).read_bytes())[0]


# ── 표 ──────────────────────────────────────────────────────────────────
def _sniff_delim(lines: list[str]) -> str | None:
    sample = [ln for ln in lines if ln.strip()][:20]
    if len(sample) < 2:
        return None
    for d in (",", "\t", ";", "|"):
        counts = {ln.count(d) for ln in sample}
        if len(counts) == 1 and next(iter(counts)) >= 1:
            return d
    return None


def read_table(path: Path) -> dict | None:
    """표면 {columns, rows, lines(원본 줄 번호), comments, encoding, delimiter}, 표가 아니면 None."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext in (".xlsx", ".xlsm"):
        return _read_excel(path)
    if ext not in TABLE_EXT:
        return None
    text, enc = decode(path.read_bytes())
    phys = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    comments, body = [], []
    for i, ln in enumerate(phys, 1):
        if not ln.strip():
            continue
        if ln.lstrip().startswith("#") and not body:
            comments.append(ln.strip())
            continue
        body.append((i, ln))
    delim = _sniff_delim([ln for _, ln in body]) if ext != ".tsv" else "\t"
    if not delim or len(body) < 2:
        return None
    parsed = list(csv.reader([ln for _, ln in body], delimiter=delim))
    columns = [c.strip() for c in parsed[0]]
    rows = [[c.strip() for c in r] for r in parsed[1:]]
    return {"columns": columns, "rows": rows, "lines": [i for i, _ in body[1:]], "comments": comments,
            "encoding": enc, "delimiter": delim}


def _read_excel(path: Path) -> dict | None:
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.worksheets[0]
    raw = [["" if v is None else str(v).strip() for v in row] for row in ws.iter_rows(values_only=True)]
    wb.close()
    body = [(i, r) for i, r in enumerate(raw, 1) if any(r)]
    if len(body) < 2:
        return None
    return {"columns": body[0][1], "rows": [r for _, r in body[1:]], "lines": [i for i, _ in body[1:]],
            "comments": [], "encoding": "xlsx", "delimiter": None, "sheet": ws.title}


def to_float(s: str) -> float | None:
    s = (s or "").strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        try:
            return float(s.replace(",", "."))   # 소수점 쉼표
        except ValueError:
            return None


# ── Word 수식(OMML) → LaTeX ────────────────────────────────────────────
_SYM = {"∑": r"\sum", "∏": r"\prod", "∫": r"\int", "−": "-", "×": r"\times", "·": r"\cdot", "±": r"\pm",
        "≤": r"\le", "≥": r"\ge", "≠": r"\ne", "≈": r"\approx", "∞": r"\infty", "Δ": r"\Delta", "∂": r"\partial"}


def _kid(el, name):
    return el.find(M + name)


def _val(el, path_name):
    x = el.find(path_name)
    return x.get(M + "val") if x is not None else None


def omml(el) -> str:
    tag = el.tag.replace(M, "m:").replace(W, "w:")
    kids = list(el)

    def sub(name):
        k = _kid(el, name)
        return omml(k) if k is not None else ""

    if tag == "m:t":
        return "".join((_SYM[ch] + " " if _SYM.get(ch, "").startswith("\\") else _SYM.get(ch, ch))
                       for ch in (el.text or ""))
    if tag == "m:f":
        return r"\frac{%s}{%s}" % (sub("num"), sub("den"))
    if tag == "m:sSub":
        return "{%s}_{%s}" % (sub("e"), sub("sub"))
    if tag == "m:sSup":
        return "{%s}^{%s}" % (sub("e"), sub("sup"))
    if tag == "m:sSubSup":
        return "{%s}_{%s}^{%s}" % (sub("e"), sub("sub"), sub("sup"))
    if tag == "m:rad":
        deg = sub("deg")
        return (r"\sqrt[%s]{%s}" % (deg, sub("e"))) if deg.strip() else r"\sqrt{%s}" % sub("e")
    if tag == "m:nary":
        ch = _val(el, f"{M}naryPr/{M}chr") or "∫"
        op = _SYM.get(ch, ch)
        lo, hi = sub("sub"), sub("sup")
        return op + (f"_{{{lo}}}" if lo else "") + (f"^{{{hi}}}" if hi else "") + "{" + sub("e") + "}"
    if tag == "m:d":
        beg = _val(el, f"{M}dPr/{M}begChr")
        end = _val(el, f"{M}dPr/{M}endChr")
        sep = _val(el, f"{M}dPr/{M}sepChr") or ","
        inner = sep.join(omml(e) for e in el.findall(M + "e"))
        return r"\left%s%s\right%s" % (beg if beg is not None else "(", inner, end if end is not None else ")")
    if tag == "m:bar":
        return r"\overline{%s}" % sub("e")
    if tag == "m:acc":
        ch = _val(el, f"{M}accPr/{M}chr") or "̂"
        cmd = {"̅": r"\overline", "¯": r"\overline", "̂": r"\hat", "̃": r"\tilde", "̇": r"\dot", "→": r"\vec"}.get(ch, r"\hat")
        return cmd + "{" + sub("e") + "}"
    if tag == "m:func":
        return sub("fName") + "{" + sub("e") + "}"
    if tag in ("m:limLow", "m:limUpp"):
        return "{%s}%s{%s}" % (sub("e"), "_" if tag == "m:limLow" else "^", sub("lim"))
    if tag in ("m:eqArr", "m:m"):
        return r" \\ ".join(omml(k) for k in kids if k.tag in (M + "e", M + "mr"))
    if tag.endswith("Pr") or tag in ("w:rPr",):
        return ""
    return "".join(omml(k) for k in kids)


# ── Word 문서 ───────────────────────────────────────────────────────────
def read_docx(path: Path) -> dict:
    """{paragraphs:[{i, page, text}], equations:[{id, latex, paragraph, context, omml_sha256}], text}.

    쪽 번호는 문서 안의 쪽 나눔 표시(수동 쪽 나눔 · 마지막 렌더링 쪽 나눔)로만 센다 — 없으면 모두 1쪽.
    """
    from lxml import etree
    with zipfile.ZipFile(path) as z:
        root = etree.fromstring(z.read("word/document.xml"))
    body = root.find(W + "body")
    paragraphs, equations = [], []
    page = 1

    def para_text(p) -> str:
        nonlocal page
        parts = []
        for node in p.iter():
            if node.tag == W + "br" and node.get(W + "type") == "page" or node.tag == W + "lastRenderedPageBreak":
                page += 1 if parts else 0
            if node.tag in (M + "oMath",) and not _inside(node, M + "oMath"):
                eid = f"EQ{len(equations) + 1:02d}"
                equations.append({"id": eid, "latex": omml(node).strip(), "paragraph": len(paragraphs),
                                  "omml_sha256": sha_bytes(etree.tostring(node))})
                parts.append(f" [{eid}] ")
            elif node.tag == W + "t" and not _inside(node, M + "oMath"):
                parts.append(node.text or "")
            elif node.tag == W + "tab":
                parts.append("\t")
        return re.sub(r"[ \t]+", " ", "".join(parts)).strip()

    for el in body:
        if el.tag == W + "p":
            paragraphs.append({"i": len(paragraphs), "page": page, "text": para_text(el)})
        elif el.tag == W + "tbl":
            for tr in el.iter(W + "tr"):
                cells = [" ".join(t.text or "" for t in tc.iter(W + "t")).strip() for tc in tr.iter(W + "tc")]
                paragraphs.append({"i": len(paragraphs), "page": page, "text": " | ".join(cells), "table": True})
    for e in equations:   # 식 설명 — 식이 든 문단, 비어 있으면 바로 앞의 글 문단
        own = re.sub(r"\[EQ\d+\]", "", paragraphs[e["paragraph"]]["text"]).strip()
        prev = next((paragraphs[j]["text"] for j in range(e["paragraph"] - 1, -1, -1)
                     if re.sub(r"\[EQ\d+\]", "", paragraphs[j]["text"]).strip()), "")
        e["context"] = own or prev
    return {"paragraphs": paragraphs, "equations": equations,
            "text": "\n".join(p["text"] for p in paragraphs if p["text"])}


def _inside(node, tag) -> bool:
    p = node.getparent()
    while p is not None:
        if p.tag == tag:
            return True
        p = p.getparent()
    return False


# ── PDF ─────────────────────────────────────────────────────────────────
def read_pdf_pages(path: Path) -> list[str]:
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        return [(pg.extract_text() or "") for pg in pdf.pages]


# ── 문서 공통 ───────────────────────────────────────────────────────────
def document_pages(path: Path) -> list[list[str]]:
    """문서 → 쪽마다 문단 목록 (보고서 문장 추출용)."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext == ".docx":
        d = read_docx(path)
        pages: dict[int, list[str]] = {}
        for p in d["paragraphs"]:
            if p["text"]:
                pages.setdefault(p["page"], []).append(p["text"])
        return [pages[k] for k in sorted(pages)] or [[]]
    if ext == ".pdf":
        return [[ln for ln in re.split(r"\n\s*\n", t) if ln.strip()] for t in read_pdf_pages(path)]
    text = read_text(path)
    return [[ln.strip() for ln in re.split(r"\n\s*\n|\n", text) if ln.strip()]]


def normalize_space(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()
