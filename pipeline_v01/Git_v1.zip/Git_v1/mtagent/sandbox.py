"""승인된 계산 코드의 정적 점검과 격리 실행.

정적 점검(문법 트리): 허용한 모듈만 import · eval/exec/compile/__import__/getattr 등 금지 · 쓰기 모드 open 금지 · 이중 밑줄 속성 금지.
격리 실행: 별도 프로세스 `python -I -B sandbox_runner.py` — 최소 환경 변수(API 키 없음), 빈 임시 작업 폴더, 시간 제한.
실행기 안에서 감사 훅으로 파일 쓰기 · 허용 밖 읽기 · 네트워크 · 하위 프로세스를 막는다.
운영체제 수준 격리(컨테이너·VM)는 아니다 — 로컬 데모용 방어선.
"""
from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from mtagent.util import is_finite_number, sha_text

ALLOWED_IMPORTS = {"math", "statistics", "csv", "collections", "itertools", "functools", "re", "json", "decimal",
                   "fractions", "operator", "typing", "dataclasses", "numpy", "scipy", "pandas"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "getattr", "setattr", "delattr", "globals", "locals",
                   "vars", "breakpoint", "input", "memoryview", "help", "exit", "quit"}
RESULT_KINDS = {"value", "n", "df", "p_value", "test_statistic", "percent_change", "difference", "ratio", "other"}
RUNNER = Path(__file__).with_name("sandbox_runner.py")
MARK = "@@MT_RESULT@@"


def static_check(code: str) -> list[str]:
    """금지 항목 목록(비어 있으면 통과)."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return [f"문법 오류: {e.msg} ({e.lineno}줄)"]
    problems = []
    has_compute = False
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "compute":
            has_compute = True
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] not in ALLOWED_IMPORTS:
                    problems.append(f"{node.lineno}줄: 허용하지 않은 import {a.name}")
        elif isinstance(node, ast.ImportFrom):
            if node.level or (node.module or "").split(".")[0] not in ALLOWED_IMPORTS:
                problems.append(f"{node.lineno}줄: 허용하지 않은 import {node.module}")
        elif isinstance(node, ast.Call):
            f = node.func
            name = f.id if isinstance(f, ast.Name) else f.attr if isinstance(f, ast.Attribute) else None
            if isinstance(f, ast.Name) and name in FORBIDDEN_CALLS:
                problems.append(f"{node.lineno}줄: 금지 함수 {name}()")
            if name == "open":
                mode = node.args[1] if len(node.args) > 1 else next((k.value for k in node.keywords if k.arg == "mode"), None)
                if mode is not None and not (isinstance(mode, ast.Constant) and isinstance(mode.value, str)
                                             and set(mode.value) <= set("rbt")):
                    problems.append(f"{node.lineno}줄: 읽기 전용이 아닌 open()")
            if name in ("to_csv", "to_excel", "to_json", "to_pickle", "savetxt", "save", "savez", "tofile",
                        "write_text", "write_bytes", "mkdir", "unlink", "remove", "system", "popen"):
                problems.append(f"{node.lineno}줄: 파일·시스템 쓰기 함수 {name}()")
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__") and node.attr != "__name__":
            problems.append(f"{node.lineno}줄: 특수 속성 {node.attr}")
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            problems.append(f"{node.lineno}줄: global/nonlocal 사용")
    if not has_compute:
        problems.append("compute(files) 함수가 없음")
    return problems


def _env() -> dict:
    keep = {k: os.environ[k] for k in ("SYSTEMROOT", "SystemRoot", "WINDIR", "PATH", "TEMP", "TMP") if k in os.environ}
    return {**keep, "PYTHONHASHSEED": "0", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"}


def run(code_path: Path, code_sha256: str, files: dict[str, str], timeout: int) -> dict:
    """격리 실행 → {status, results, intermediate, stdout, blocked, seconds, error}."""
    spec = json.dumps({"code_path": str(code_path), "code_sha256": code_sha256, "files": files})
    t0 = time.time()
    with tempfile.TemporaryDirectory(prefix="mt_sandbox_") as tmp:
        try:
            p = subprocess.run([sys.executable, "-I", "-B", str(RUNNER)], input=spec, capture_output=True,
                               text=True, encoding="utf-8", errors="replace", cwd=tmp, env=_env(), timeout=timeout)
        except subprocess.TimeoutExpired:
            return {"status": "error", "error": f"시간 제한 {timeout}초 초과", "seconds": round(time.time() - t0, 2)}
    seconds = round(time.time() - t0, 2)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith(MARK)), None)
    if line is None:
        return {"status": "error", "error": f"실행기가 결과를 내지 않음 (종료 코드 {p.returncode})",
                "stderr": p.stderr[-3000:], "seconds": seconds}
    out = json.loads(line[len(MARK):])
    out["seconds"] = seconds
    if out.get("status") == "ok":
        problems = validate_results(out.get("results"))
        if problems:
            out.update(status="error", error="결과 형식 문제: " + "; ".join(problems[:10]))
    return out


def validate_results(results) -> list[str]:
    if not isinstance(results, list) or not results:
        return ["results 가 비어 있거나 목록이 아님"]
    problems, seen = [], set()
    for i, r in enumerate(results):
        if not isinstance(r, dict):
            problems.append(f"{i}번 결과가 dict 가 아님")
            continue
        rid = r.get("id")
        if not rid or rid in seen:
            problems.append(f"{i}번 결과 id 가 없거나 겹침: {rid!r}")
        seen.add(rid)
        if not is_finite_number(r.get("value")):
            problems.append(f"{rid}: 값이 유한한 숫자가 아님 ({r.get('value')!r})")
        if r.get("kind") not in RESULT_KINDS:
            problems.append(f"{rid}: kind {r.get('kind')!r} 모름")
    return problems


def result_hash(results: list[dict]) -> str:
    return sha_text(json.dumps([[r["id"], repr(float(r["value"])), r.get("unit")] for r in results], ensure_ascii=False))
