"""실험 설계의 조건(집단) 이름 맞추기.

같은 조건이 단계마다 다르게 적힐 수 있다 — 데이터 값 'annealed', 계획서 표기 '어닐링 (A)', 코드 결과 'annealed (A)'.
모든 단계는 이 함수로 설계의 조건 이름(name)에 맞춘다. 못 맞추면 None (부르는 쪽이 안전한 쪽으로 처리).
"""
from __future__ import annotations

import re


def _norm(x: str) -> str:
    return re.sub(r"\s+", " ", str(x or "")).strip().lower()


def _paren(x: str) -> str | None:
    m = re.search(r"\(\s*([^()]+?)\s*\)\s*$", x or "")
    return _norm(m.group(1)) if m else None


def match_condition(text: str | None, conditions: list[dict], sample: str | None = None) -> str | None:
    """조건 표기(또는 시료) → 설계 조건 name."""
    if conditions and (text or sample):
        t = _norm(text)
        if t:
            for c in conditions:                                   # 이름·표기가 같음
                if t in (_norm(c.get("name")), _norm(c.get("label"))):
                    return c["name"]
            for c in conditions:                                   # 'annealed (A)' ↔ name 'annealed' 또는 label '어닐링 (A)'
                if _norm(c.get("name")) and re.match(re.escape(_norm(c["name"])) + r"\b", t):
                    return c["name"]
            p = _paren(t)
            if p:
                hits = [c["name"] for c in conditions if p in (_paren(c.get("label")), _paren(c.get("name")), _norm(c.get("name")))]
                if len(hits) == 1:
                    return hits[0]
        if sample:
            sm = _norm(sample)
            hits = [c["name"] for c in conditions if sm in {_norm(x) for x in c.get("samples") or []}]
            if len(hits) == 1:
                return hits[0]
    return None


def expand_samples(items: list[str]) -> list[str]:
    """'S01–S10' 같은 범위 표기를 풀어 쓴다 (LLM 이 풀지 않았을 때 대비)."""
    out = []
    for it in items or []:
        m = re.fullmatch(r"\s*([A-Za-z_\-]*?)(\d+)\s*[–\-~]\s*([A-Za-z_\-]*?)(\d+)\s*", str(it))
        if m and (not m.group(3) or m.group(3) == m.group(1)) and int(m.group(4)) >= int(m.group(2)) \
                and int(m.group(4)) - int(m.group(2)) < 10000:
            w = len(m.group(2))
            out += [f"{m.group(1)}{i:0{w}d}" for i in range(int(m.group(2)), int(m.group(4)) + 1)]
        else:
            out.append(str(it).strip())
    return list(dict.fromkeys(out))
