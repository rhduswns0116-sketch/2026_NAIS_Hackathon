# MeasureTrace Git_v3

보고서의 수치 주장이 **제출된 데이터(RAW·PROCESSED)로 지지되는지** 다시 계산해 확인하는 Agent AI.
파이프라인(1 INGEST → 2 EXTRACT → 3 CONFIRM → 4 RECOMPUTE → 5 VALIDATE → 6 AUDIT)은 `docs/PIPELINE_v2.md` 를 따른다.
Git_v1(친구 구현) → GIT_v2(파이프라인 문서 반영) → Git_v3(리뷰·실검증에서 찾은 문제 수정). 바뀐 점은 아래 **v2 → v3**, **v1 → v2** 참고.
LLM 은 **읽기**(데이터 뜻·계획서·사양서·보고서 문장)만 하고, **계산·비교·판정은 파이썬**이 한다. 사람은 3 CONFIRM 에서 LLM 이 잘 읽었는지 확인한다.

## 연구자가 가져올 파일

RAW_DATA · PROCESSED_DATA · 연구 계획서 · 장비 사양 보고서 (연구 자료 폴더) + 최종 보고서 초안 (다른 폴더로 따로).
1 INGEST 가 다섯 가지가 있는지 점검표(`ingest.json` 의 `required`)로 남긴다.

## 실행

```powershell
pip install -r requirements.txt
Copy-Item .env.example .env      # LLM_API_KEY 넣기 (.env 는 커밋 금지 — .gitignore 에 있음)
```

**웹 화면** (Git_v1 과 같음 — 이번 단계에서 검증·수정하지 않음):
`python run.py` → http://127.0.0.1:8765

**명령줄** (v2 추가 — 웹 없이 단계별로):

```powershell
python cli.py new 데모 --data samples\annealing_demo\data --report samples\annealing_demo\report   # 1 INGEST
python cli.py extract <실행 ID>        # 2 EXTRACT            ← LLM 호출 (토큰 사용)
python cli.py confirm <실행 ID>        # 3 CONFIRM 질문 + 관계 도식 + 답 양식(answers_template.json)
python cli.py answer <실행 ID> 답.json --who 홍길동   # '아니오'가 있으면 2 EXTRACT 다시 ← LLM
python cli.py recompute <실행 ID>      # 4 RECOMPUTE (격리 실행, LLM 없음)
python cli.py validate <실행 ID>       # 5 VALIDATE + 6 AUDIT ← LLM 호출 (토큰 사용)
python cli.py freshness <실행 ID> <새 연구 자료 폴더>   # 계산에 쓴 데이터 해시와 대조 — 최신 파일인지
python cli.py status
```

`MT_OFFLINE=1` 이면 LLM 캐시만 쓴다(토큰 0). 시험: `python -m unittest discover -s tests -v` (가짜 LLM, 토큰 0).

샘플: `samples/annealing_demo`(연구 자료 `data/`, 보고서 `report/`) — 정답 `samples/annealing_demo_answer_key.json`(업로드하지 않음).
`samples/annealing_demo_rerun` 은 S07 에서 3행이 빠지고 S12 의 형식만 바뀐 재실행본.

## v2 → v3 (코드 리뷰 · 실제 API 검증에서 찾은 문제)

| 문제 (GIT_v2) | Git_v3 |
|---|---|
| RAW·PROCESSED 에 같은 이름의 값 열이 있고 단위가 누락·모호하면 3-3 단위 질문 id 가 겹쳐 **CONFIRM 이 끝나지 않음** | 단위 질문 id·단위 결정을 **묶음+열**(`3-3:unit:G1:current`, `P1:current`)로 — 따로 묻고 따로 적음 |
| 가공 파일이 RAW 와 한 목록으로 계산 코드에 들어가, 연구자 가공값이 결과로 새어 나올 수 있음(순환 검증) | 계산 코드는 **`compute(raw, processed)`** 로 따로 받음. 4 RECOMPUTE 가 **PROCESSED 를 비우고 한 번 더 실행**해 값이 바뀌거나 사라지는 결과를 `depends_on_processed` 로 표시(`processed_dependency`), 5 VALIDATE 에서 그 결과를 쓰는 주장은 **E06** |
| 실제 실행에서 LLM 이 계산 과정(steps)·실험—데이터—식—장비(matching)를 빈 목록으로 줬는데 그대로 통과 | 2-1b 가 비면 **한 번 다시 물음**(그때만 토큰 추가), 그래도 비면 `empty_after_retry` 에 남기고 3-1 에서 **'수정 필요'만 고를 수 있음** |
| 측정 조건은 인용만 원문 대조 | 값의 숫자가 인용 안에 있는지도 확인 |
| 파일 수정 시각을 첫 장비 기록과만 비교 | **마지막** 장비 기록과 비교(측정 중간에 저장된 파일도 잡음) |
| 계산하지 못한 실행도 `freshness` 가 '최신' | 계산 상태가 ok 가 아니면 비교하지 않고 이유를 알림 |
| processed_check 의 file 이 목록이면 4 RECOMPUTE 가 멈춤 | '대조 못 함'으로 기록하고 계속 |
| 측정 시각 요약이 계획서·그림까지 '없음'으로 셈 | 데이터(RAW·PROCESSED·메모)만 셈 |
| 폴더를 넣을 때 파일마다 upload_meta.json 을 다시 씀 | 폴더 단위로 한 번 씀 (중간에 실패해도 이미 넣은 파일 기록은 남김) |

v3 2차 (v3 코드 리뷰 · 실제 API 실행에서 찾은 문제)

| 문제 | 수정 |
|---|---|
| PROCESSED 없이 다시 돌리다 실패하면 이유와 상관없이 모든 결과가 E06 | **시간 초과**는 '독립성 확인 못 함'(`independent: null`, 판정 안 바꿈), **오류**는 PROCESSED 에 기댄 것으로 봄. 두 번째 실행 기록(`run`: 시간·막은 동작·오류)도 남김 |
| PROCESSED 를 쓰지 않는 코드도 매번 두 번 실행 | 승인 코드가 `processed` 인자를 읽지 않으면(정적 확인) 다시 실행하지 않음 |
| compute 인자 검사가 `(raw, processed, /)`·기본값 인자를 거부, 클래스 메서드 compute 도 검사 | 모듈 최상위 compute 만, 두 인자로 부를 수 있으면 통과 |
| 2-1b 다시 묻기가 실패하면 2 EXTRACT 전체가 실패 | 다시 묻기 실패는 질문으로 남기고 첫 답으로 진행 |
| 다시 묻기로 같은 참고 질문이 두 번 → 같은 id 두 항목 | 질문 중복 제거, 3 CONFIRM 에서도 같은 id 는 한 번만 |
| 측정 조건 숫자 검사가 `1E-3`·`1,000` 을 틀리게 판단 | 지수·천 단위 쉼표 처리 |
| 3-3 측정 정의에서 같은 이름 열의 묶음을 구분 못 함 | `group_id`·`category` 표시 |
| `empty_after_retry` 가 2-1c 지시문에 섞여 들어감 | LLM 에 보내지 않음 (기록용) |
| **실제 실행**: '시료마다 위치 7개' 가 조건별 시료 수(10)와 비교돼 E04 | 재계산 항목이 없는 n 주장은 **계획서의 수(조건별 시료 수·시료당 반복 수·반복당 측정점 수)** 와 비교 |
| **실제 실행**: 인가 전압 '−0.5 V ~ 0.5 V' 같은 실험 설정값이 주장으로 뽑혀 E06 | 5-1 지시문 — 실험 방법·설정값은 주장으로 뽑지 않음 |

GIT_v2 에서 복사해 온 `workspace/` 의 실행은 `compute(files)` 형식 코드라 볼 수는 있지만 Git_v3 에서 4 RECOMPUTE 를 다시 돌리면 정적 점검에서 막힌다(새 실행으로).

## v1 → v2 (파이프라인 문서 반영)

| 단계 | Git_v1 | GIT_v2 |
|---|---|---|
| 1-1 유형 분류 | 가공 데이터는 '사용 안 함' | **PROCESSED 데이터를 입력으로 사용**. 연구자가 가져올 5종 점검표(`required`) |
| 1-2 측정 시각 | 파일 안의 기록만 | **(1) 파일 수정 시각 (2) 장비 기록 시각 둘 다 기록, 장비 기록 우선**. 명령줄로 넣으면 원본 수정 시각을 사본에 옮김(`upload_meta.json`), 웹 업로드는 원본 시각이 없어 '업로드 시각'으로 표시하고 측정 시각으로 쓰지 않음. 파일 수정이 장비 기록보다 이르면 확인 요청 |
| 2-1a 데이터 내용 | RAW 묶음만 | RAW(G1…) + **PROCESSED(P1…) 묶음**, 열 역할에 `derived`(계산된 값) 추가 |
| 2-1c 계산 코드 | RAW 만 입력 | RAW + PROCESSED 입력(원칙은 RAW 에서 계산, RAW 없는 단계만 PROCESSED), **processed_check**(가공값 ↔ RAW 재계산값) 목록 |
| 2-2 측정 조건 | 범위·정확도·범위 밖 표시값 | + 동작 조건 인용도 원문 대조 |
| 2-3 데이터 구조화 | RAW | RAW + PROCESSED 의 단위·결측·숫자 아닌 값 (사양 범위 이상치는 장비가 낸 RAW 측정값에만) |
| 3-1 데이터 해석 승인 | 매칭 표 | + **실험 ↔ 데이터 ↔ 식 ↔ 장비 도식**(Mermaid·글, `confirm/relation_diagram.md`, 항목 proposal 의 `diagram`) |
| 3-2 분석 범위 확정 | 범위·범위 밖 표시값 | + **측정 조건**(동작 온도 등) 항목, 승인분은 `confirmed.json` 의 `spec.conditions` |
| 3-3 측정 시각 | 파일 안 기록 | 장비 기록/파일 수정 시각 중 무엇을 썼는지(`basis`) 함께 확인 |
| 4 계산 로그 | 사용한 RAW 해시 | **`commit` = ① 데이터 해시 2종(파일별 + 묶음 원본·내용 해시, RAW·PROCESSED) ② 계산 과정(확정 식 LaTeX·단계·코드 해시·중간값 해시·환경) ③ 결과값 ④ 결과 해시** |
| 4 최신 여부 | 이전 실행과 E07 | + **`freshness`** — 새 데이터 폴더를 계산에 쓴 해시와 대조. E07 은 PROCESSED 변경도 포함 |
| 4 PROCESSED 대조 | — | 가공 파일 값을 **적힌 자릿수로** RAW 재계산값과 비교, 불일치는 파일·줄·열로 기록(판정은 바꾸지 않음) |
| 6 리포트 | 주장 판정·재평가 | + 재계산 결과 표·데이터/결과 해시·PROCESSED 대조 |

웹 화면(`web/`)은 Git_v1 그대로다. v2 가 더한 값(도식·동작 조건·commit·PROCESSED 대조)은 산출물 JSON·리포트·명령줄에는 나오지만 화면에는 아직 그리지 않는다 — 화면 반영은 다음 단계.

## 단계별 구현

| 단계 | 과업 | 주체 | 구현 |
|---|---|---|---|
| 1 INGEST | 1-1 입력 격리·분류 | PY | 사본을 `workspace/inputs/<실행>/data`·`/report` 에 받고 **읽기 전용**으로 잠금. 산출물은 `workspace/outputs/<실행>/`(입력 밖). 보고서는 따로 받고 5단계 전까지 열지 않음(원본 해시만). 규칙으로 분류: RAW · PROCESSED · 연구 계획서 · 장비 사양서 · 스크립트(실행 안 함) · 그림 · 메모 · 미분류 | `stages/ingest.py` |
| | 1-2 지문·시각 | PY | 해시 2종(원본 바이트 + 내용 정규화: 인코딩·BOM·줄바꿈·공백·구분자 무시). 표는 행별 해시 → 이전 실행과 **바뀜·추가·빠짐과 줄 번호**. 측정 시각 2종(장비 기록 우선) | `hashing.py` |
| | 1-3 파생 이력 | PY | `(입력 해시, 코드 버전, 파라미터) → 출력 해시` 를 `workspace/outputs/lineage.jsonl` 에 단계마다 한 줄. 연구자가 가져온 PROCESSED 는 파이프라인 밖에서 만든 것이라 파생 기록이 없음(입력 해시로만 등장) | `lineage.py` |
| 2 EXTRACT | 2-1a 데이터 내용 파악 | LLM | 같은 열 구성의 RAW·PROCESSED 묶음마다 **열 이름·문자 값만** 보내(숫자 값 없음) 역할·단위·뜻 | `stages/extract.py` |
| | 2-1b 연구 내용 추출 | LLM | Word 수식(OMML)은 **파이썬이 LaTeX 로 변환**(id 고정), LLM 은 식의 뜻·변수↔데이터 열, 계산 과정, 설계·검정, 실험—데이터—식—장비 매칭, 보고할 값 목록 | `readers.py` |
| | 2-1c 계산 코드 | LLM | 계획서대로 계산하는 `compute(raw, processed)` 초안. **실행하지 않음**, 정적 점검만 | |
| | 2-2 측정 조건 | LLM→PY | 장비 사양서의 유효 판독 범위·정확도·범위 밖 표시값·동작 조건. 인용이 원문에 있는지 파이썬이 확인 | |
| | 2-3 데이터 구조화 | PY | 단위 누락·모호, 결측, 숫자 아닌 값, 사양 범위 밖(이상치), 범위 밖 표시값 — 파일·열·**줄 번호·값** | |
| | 2-4 누락 점검 | LLM→PY | LLM 은 계획서만 읽고 필요한 시료·반복·측정점 수를 뽑고, 파이썬이 RAW 와 대조 | |
| 3 CONFIRM | 3-1 데이터 해석 승인 | 사람 | 데이터 내용·식·계산 과정·설계·매칭(도식)·코드·누락. **아니오 + 고칠 내용 → 2-1 을 a 부터 다시** → 제안이 바뀐 항목만 다시 물음 | `stages/confirm.py` |
| | 3-2 분석 범위 확정 | 사람 | 장비 사양(범위·정확도·범위 밖 표시값·측정 조건). **아니오 → 2-2 다시** | |
| | 3-3 측정 기준 승인 | 사람 | 측정 정의(열 역할·단위) 고정. 단위 누락·모호 → 제안 중 고르거나 **기타 직접 입력**. 결측·이상치 → **'아니오 → 파일을 고쳐 1 INGEST 부터 새 실행'** 또는 '값이 맞음(진행, E02 기록)' | |
| | 승인값 반영 | PY | 피드백 최대 3회 — 그 뒤에도 아니오면 미확정(관련 주장 E06). 확정 기록 `confirmed.json`, 승인 코드는 해시 고정·읽기 전용 | |
| 4 RECOMPUTE | 4-1 수치 재계산 | PY | 실행 전 확인(승인 코드 해시 · 추출 결과 불변 · 데이터 해시 · 정적 점검) → **격리 실행**(`python -I -B` 별도 프로세스, 감사 훅으로 쓰기·허용 밖 읽기·네트워크·하위 프로세스 차단, 시간 제한) · PROCESSED 대조 | `stages/recompute.py`, `sandbox.py`, `sandbox_runner.py` |
| | 4-2 계산 로그 | PY | `commit` 4요소(위 표) + 같은 프로젝트의 이전 계산과 비교해 E07 · `freshness()` | |
| 5 VALIDATE | 5-1 주장 추출 | LLM | 보고서를 **이때 처음 열고**(열람 시각 > 계산 완료 시각 확인), 문장마다 **몇 쪽 몇 번째 문장** 번호 | `stages/validate.py` |
| | 5-2 비교 · 5-3 오류 코드 | PY | 보고 자릿수로 반올림 비교 · 단위 환산 · 방향 · 유의성(α) · n·자유도 | `codes.py`, `design.py` |
| 6 AUDIT | 6-1 결과 출력 · 6-2 재평가 | PY | Supported / Unsupported 주장마다 문장·보고값·재계산값·오류 코드·근거. 이전 감사와 주장별 수정 전·후. `audit_report.md` | `stages/audit.py` |

## 오류 코드

| 코드 | 뜻 | 판정 |
|---|---|---|
| E01 | 단위 불일치 (누락 포함) | Unsupported |
| E02 | 측정값 이상 — 장비 사양 범위 밖 값을 연구자가 확인하고 진행 | 기록 |
| E03 | 필요 데이터 누락 (계획서 대비) — 그 집단을 쓰는 주장에만 | Unsupported |
| E04 | 표본 수·자유도 불일치 | Unsupported |
| E05 | 수치·방향·유의성 불일치 | Unsupported |
| E06 | 재계산 근거 없음·미확정 | Unsupported |
| E07 | 데이터 버전 변경 (이전 실행 대비, RAW·PROCESSED) | 기록 |

판정은 과학적 진실이 아니라 '제출된 자료가 이 주장을 지지하는가'에 대한 것이다. 계산식의 과학적 타당성, 그림, 외부 문헌 수치, 데이터 조작 여부는 판정하지 않는다.
파이프라인 문서의 5-3 '오류 코드 분류 — 수정하기' 는 아직 열려 있어 Git_v1 의 E01~E07 을 그대로 쓴다.

## 파일

```
run.py                 웹 화면 실행 (Git_v1 그대로)
cli.py                 명령줄 실행 (v2)
docs/PIPELINE_v2.md    파이프라인 문서 + 단계 ↔ 코드 대응
mtagent/
  config.py            경로·모델·키 (.env)          llm.py       구조화 출력·캐시·호출 기록
  store.py             실행 폴더·상태·업로드(원본 수정 시각)   lineage.py   1-3 파생 이력
  readers.py           표·Word(글+수식→LaTeX)·PDF     hashing.py   해시 2종·행 차이·측정 시각 2종
  units.py             단위 해석·환산                design.py    조건 이름 맞추기
  sandbox.py · sandbox_runner.py  정적 점검·격리 실행    codes.py     오류 코드
  docx_equations.py    Word 수식 → LaTeX (dwml 0.3, 수식마다 실패 격리) — 1 INGEST 에서 equations.json, 2·3 단계가 사용
  stages/ ingest · extract · confirm · recompute · validate · audit
web/                   표준 라이브러리 HTTP 서버 + 화면 (Git_v1 그대로)
tests/                 test_pipeline.py · fake_llm.py (가짜 LLM)
                       test_docx_equations.py · make_eq_docx.py (시험용 수식 docx 생성기)
samples/               시험 자료 (생성형 AI 로 만든 가상 자료)
workspace/             실행하면 생김 — inputs · outputs · llm_cache (.gitignore)
```

### Word 수식 → LaTeX (`mtagent/docx_equations.py`)

`extract(docx 경로, 파일 sha256)` → `{plan_sha256, converter, equations[{id, sentence, omml_sha256, plan_sha256, latex, status, error}], failed, plan_text}`.
LLM 없이 파이썬만 쓴다. 문단 안의 가장 바깥 m:oMath 를 문서 순서대로 EQ01… 로 번호 매겨 dwml `oMath2Latex` 로 바꾸고,
수식마다 예외를 따로 잡아 그 수식만 `failed`(다음 수식은 계속). dwml 이 없으면 모두 `failed`, `converter=null`.

확인한 것 (dwml 0.3)
- 시험 docx 8식 · 샘플 `research_plan.docx` 8식 모두 ok. 샘플은 기존 `readers.py` 변환과 구조가 같다(중괄호 표기만 다름: `{G}_{ij}` ↔ `G_{ij}`).
- 분수 속성 `m:fPr` 가 빠지면 `KeyError: 'fPr'` — 그 수식만 실패.
- 재점검에서 고친 것: **적분**(m:chr 없음 = ∫ 표준 기본값)을 dwml 이 TypeError 로 못 바꾸던 것 → 변환기에 넘기는 사본에만 ∫ 를 채우고
  `filled_defaults` 에 기록(해시는 원본) · Word 호환 감싸개(mc:AlternateContent)의 대체본 때문에 같은 식을 두 번 세던 것 → mc:Fallback 무시 ·
  문단 밖 수식을 빠뜨리던 것 → 한 줄로 처리 · 탭·줄바꿈이 붙어 버리던 것 → 공백.

파이프라인 연결
- **1 INGEST**(1-2-3): Word 계획서마다 `extract(경로, 1 INGEST 가 계산한 sha256)` → `outputs/<실행>/equations.json`, 파생 이력 `1 INGEST 계획서 수식`.
  확인 항목 '계획서 수식 → LaTeX', 변환 실패·수식 없음·Word 가 아닌 계획서는 findings 에 남김.
- **2 EXTRACT**: 식 목록과 계획서 글을 equations.json 에서 — 글 안의 식 자리에 `[EQ01] $ LaTeX $` 가 들어가 LLM 이 식을 함께 본다
  (예전 실행처럼 equations.json 이 없으면 그 자리에서 변환). 변환 실패한 식은 `status=failed` 로 넘기고 뜻을 지어내지 말라고 지시.
- **3 CONFIRM**: 변환 실패한 식은 3-1 에서 '직접 입력 — 원문의 식을 LaTeX 로'만 고를 수 있고, 적은 식이 확정 기록의 `latex`
  (`status=manual`, `latex_source=researcher`)가 된다. 자동 변환한 식은 `latex_source=dwml.omml.oMath2Latex`.
  적은 식은 2-1 피드백에도 남아, 다른 항목 때문에 2 EXTRACT 를 다시 할 때 LLM 에 전달된다(계산 코드는 자동으로 다시 쓰지 않음 — 3-1 코드 항목에서 확인).
- 기존 `readers.py` 의 수식 변환은 파일 지문(내용 해시) 계산에만 남아 있다.
- **유니코드 기호는 그대로 나온다**: 뺄셈 `−`(U+2212) · `×` · `Δ` 가 `-` · `\times` · `\Delta` 로 바뀌지 않는다(`∑`→`\sum` 은 바뀜).
  기존 `readers.py` 는 이 셋을 LaTeX 명령으로 바꾼다. 이 단계에서는 임의로 고치지 않고 기록만 한다.

남은 확인 (사람): 시험 자료는 손으로 만든 XML 이다. 실제 Word 수식 편집기로 입력·저장한 docx 1개로 돌려 보고
속성 요소가 빠진 수식이 있는지 · 변환 결과가 자연스러운지 기록한다.

## 설정

`.env`: `LLM_API_KEY`(또는 `ANTHROPIC_API_KEY`) · `LLM_MODEL`(기본 `claude-opus-5-5`) · `MT_OFFLINE=1`(캐시만, 토큰 0) · `MT_WORKSPACE`(작업 폴더).
LLM 응답은 `workspace/llm_cache/` 에 캐시된다 — 같은 입력이면 토큰 0 으로 같은 답(재현성). 호출 기록은 `workspace/outputs/llm_calls.jsonl`.
