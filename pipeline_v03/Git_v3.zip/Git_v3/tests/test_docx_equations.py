"""docx 수식 → LaTeX (mtagent.docx_equations) 시험 — LLM 없음, dwml 0.3, 시험용 docx 는 make_eq_docx 로 만든다.

  python -m unittest tests.test_docx_equations -v
"""
from __future__ import annotations

import json
import re
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]

import make_eq_docx as mk  # noqa: E402
from mtagent import docx_equations as de  # noqa: E402
from mtagent.util import sha_file  # noqa: E402

TMP = Path(tempfile.mkdtemp(prefix="mt_eq_"))

# 실제 dwml 0.3 출력을 확인한 뒤 고정한 값. 뺄셈 −(U+2212)·×·Δ 는 dwml 이 LaTeX 명령으로 바꾸지 않고 그대로 둔다.
EXPECTED = {
    "EQ02": r"R_{ij}=\frac{1}{G_{ij}}",
    "EQ03": r"G_{i}=\frac{1}{7}\sum_{j=1}^{7}G_{ij}",
    "EQ05": r"s_{c}=\sqrt{\frac{1}{n−1}\sum_{i=1}^{n}\left(G_{i}−\overline{G_{c}}\right)^{2}}",
    "EQ07": r"t=\frac{\overline{G_{A}}−\overline{G_{C}}}{s_{p}\sqrt{\frac{1}{n_{A}}+\frac{1}{n_{C}}}}",
    "EQ08": r"ΔG=\frac{\overline{G_{A}}−\overline{G_{C}}}{\overline{G_{C}}}×100",
}


def tearDownModule():
    shutil.rmtree(TMP, ignore_errors=True)


def norm(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def build(name: str, paragraphs: list[str]) -> tuple[Path, dict]:
    p = mk.write_docx(TMP / name, paragraphs)
    return p, de.extract(p, sha_file(p))


class Normal(unittest.TestCase):
    def test_eight_equations_all_ok(self):
        path, out = build("normal.docx", mk.default_paragraphs())
        eqs = out["equations"]
        self.assertEqual(out["converter"], "dwml.omml.oMath2Latex")
        self.assertEqual(out["plan_sha256"], sha_file(path))
        self.assertEqual([e["id"] for e in eqs], [f"EQ{i:02d}" for i in range(1, 9)])
        self.assertEqual([e["status"] for e in eqs], ["ok"] * 8)
        self.assertEqual(out["failed"], [])
        self.assertTrue(all("error" not in e and e["plan_sha256"] == out["plan_sha256"] for e in eqs))
        # 수식 ↔ 바로 앞 설명 문장
        self.assertEqual([e["sentence"] for e in eqs], [s for s, _ in mk.equations()])
        # 대표 수식 LaTeX (공백 정규화 비교)
        by = {e["id"]: e for e in eqs}
        for k, v in EXPECTED.items():
            self.assertEqual(norm(by[k]["latex"]), norm(v), k)
        self.assertIn(r"\sum_{k=1}^{11}", by["EQ01"]["latex"])
        self.assertIn(r"\overline{V}", by["EQ01"]["latex"])
        self.assertIn(r"s_{A}^{2}", by["EQ06"]["latex"])
        # plan_text: [EQ01]~[EQ08] 이 순서대로, 각 수식 줄 바로 앞 줄이 설명 문장
        lines = out["plan_text"].splitlines()
        pos = [next(i for i, ln in enumerate(lines) if ln.startswith(f"[{e['id']}] $")) for e in eqs]
        self.assertEqual(pos, sorted(pos))
        for e, i in zip(eqs, pos):
            self.assertEqual(lines[i - 1], e["sentence"])
            self.assertEqual(lines[i], f"[{e['id']}] $ {e['latex']} $")
        json.dumps(out, ensure_ascii=False)          # JSON 으로 저장 가능


class Broken(unittest.TestCase):
    def test_missing_fraction_property_fails_only_that_equation(self):
        eqs = mk.equations()[:3]
        eqs[1] = (eqs[1][0], mk.omath(mk.sub(mk.r("R"), mk.r("ij")), mk.r("="),
                                      mk.frac(mk.r("1"), mk.sub(mk.r("G"), mk.r("ij")), pr=False)))   # m:fPr 없음
        _, out = build("broken.docx", mk.default_paragraphs(eqs))
        by = {e["id"]: e for e in out["equations"]}
        self.assertEqual([by[k]["status"] for k in ("EQ01", "EQ02", "EQ03")], ["ok", "failed", "ok"])
        self.assertTrue(by["EQ02"]["error"].startswith("KeyError:"), by["EQ02"]["error"])
        self.assertIsNone(by["EQ02"]["latex"])
        self.assertEqual(out["failed"], ["EQ02"])
        self.assertIn("[EQ02] (변환 실패 — 원문 확인 필요)", out["plan_text"])
        self.assertIn("[EQ03] $ G_{i}=", out["plan_text"])

    def test_dwml_not_installed(self):
        with mock.patch.dict(sys.modules, {"dwml": None, "dwml.omml": None}):
            _, out = build("nodwml.docx", mk.default_paragraphs())
        self.assertIsNone(out["converter"])
        self.assertEqual(out["failed"], [f"EQ{i:02d}" for i in range(1, 9)])
        self.assertTrue(all(e["status"] == "failed" and e["error"] == "dwml 미설치 — pip install dwml" and e["latex"] is None
                            for e in out["equations"]))
        self.assertEqual(out["plan_text"].count("(변환 실패 — 원문 확인 필요)"), 8)


class Hashes(unittest.TestCase):
    def test_same_file_same_hash_and_one_change_one_hash(self):
        path, a = build("h1.docx", mk.default_paragraphs())
        b = de.extract(path, sha_file(path))                               # 같은 파일 두 번
        self.assertEqual([e["omml_sha256"] for e in a["equations"]], [e["omml_sha256"] for e in b["equations"]])
        eqs = mk.equations()
        eqs[2] = (eqs[2][0], mk.omath(mk.sub(mk.r("G"), mk.r("i")), mk.r("="), mk.frac(mk.r("1"), mk.r("8")),
                                      mk.nsum(mk.r("j=1"), mk.r("7"), mk.sub(mk.r("G"), mk.r("ij")))))   # EQ03 만 1/7 → 1/8
        _, c = build("h2.docx", mk.default_paragraphs(eqs))
        diff = [x["id"] for x, y in zip(a["equations"], c["equations"]) if x["omml_sha256"] != y["omml_sha256"]]
        self.assertEqual(diff, ["EQ03"])


class ParagraphText(unittest.TestCase):
    def test_sentence_excludes_math_text_and_math_only_paragraph_takes_previous(self):
        paragraphs = [mk.text_para("앞 문단 설명."),
                      mk.inline_para("기울기는 ", mk.omath(mk.sub(mk.r("G"), mk.r("ij"))), " 로 구한다."),
                      mk.math_para(mk.omath(mk.r("XYZ")))]
        _, out = build("text.docx", paragraphs)
        e1, e2 = out["equations"]
        self.assertEqual(e1["sentence"], "기울기는  로 구한다.")           # 수식 안 글자(G, ij)는 섞이지 않음
        self.assertNotIn("ij", e1["sentence"])
        self.assertEqual(e2["sentence"], e1["sentence"])                    # 수식만 있는 문단 → 앞 문단 문장
        self.assertEqual(out["plan_text"].splitlines()[1], "기울기는  로 구한다. [EQ01] $ G_{ij} $")

    def test_only_outermost_math_is_counted(self):
        nested = "<m:oMath>" + mk.r("a") + mk.omath(mk.r("b")) + "</m:oMath>"
        _, out = build("nested.docx", [mk.text_para("중첩 수식."), mk.math_para(nested)])
        self.assertEqual([e["id"] for e in out["equations"]], ["EQ01"])


class EdgeCases(unittest.TestCase):
    """재점검에서 찾은 경우 — 적분 기본 기호 · 호환 감싸개 중복 · 문단 밖 수식 · 탭."""

    def test_integral_without_chr_uses_standard_default(self):
        integral = ('<m:oMath><m:nary><m:naryPr><m:limLoc m:val="subSup"/>' + mk.CTRL + "</m:naryPr>"
                    "<m:sub>" + mk.r("0") + "</m:sub><m:sup>" + mk.r("T") + "</m:sup><m:e>" + mk.r("f(t)dt") + "</m:e></m:nary></m:oMath>")
        path, out = build("integral.docx", [mk.text_para("적분."), mk.math_para(integral)])
        e = out["equations"][0]
        self.assertEqual((e["status"], e["latex"]), ("ok", r"\int_{0}^{T}f(t)dt"))
        self.assertEqual(e["filled_defaults"], ["m:naryPr/m:chr=∫ (표준 기본값 — 적분)"])
        from lxml import etree
        import zipfile
        root = etree.fromstring(zipfile.ZipFile(path).read("word/document.xml"))
        original = next(root.iter(de.M_OMATH))
        self.assertEqual(e["omml_sha256"], de._omml_sha256(original))          # 해시는 채우기 전 원본
        self.assertNotIn("filled_defaults", build("sum.docx", mk.default_paragraphs())[1]["equations"][0])

    def test_alternate_content_is_not_counted_twice(self):
        mc = "http://schemas.openxmlformats.org/markup-compatibility/2006"
        para = (f'<w:p><w:r><w:t>글상자 안 수식.</w:t></w:r><mc:AlternateContent xmlns:mc="{mc}">'
                f'<mc:Choice Requires="wps">{mk.omath(mk.r("y=2"))}</mc:Choice>'
                f'<mc:Fallback>{mk.omath(mk.r("y=2"))}<w:p><w:r><w:t>대체본 글</w:t></w:r></w:p></mc:Fallback>'
                f"</mc:AlternateContent></w:p>")
        _, out = build("alt.docx", [para])
        self.assertEqual([(e["id"], e["latex"]) for e in out["equations"]], [("EQ01", "y=2")])
        self.assertNotIn("대체본", out["plan_text"])

    def test_math_outside_paragraph_and_tab_spacing(self):
        tab = '<w:p><w:r><w:t>식 1.</w:t></w:r><w:r><w:tab/></w:r><w:r><w:t>설명</w:t></w:r></w:p>'
        _, out = build("body.docx", [tab, "<m:oMathPara>" + mk.omath(mk.r("x=1")) + "</m:oMathPara>", mk.text_para("뒤 문장.")])
        self.assertEqual([(e["id"], e["latex"], e["sentence"]) for e in out["equations"]], [("EQ01", "x=1", "식 1. 설명")])
        self.assertEqual(out["plan_text"].splitlines(), ["식 1. 설명", "[EQ01] $ x=1 $", "뒤 문장."])


if __name__ == "__main__":
    unittest.main()
