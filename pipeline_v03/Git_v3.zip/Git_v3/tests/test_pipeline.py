"""MeasureTrace Git_v3 시험 — 가짜 LLM(토큰 0), 임시 작업 폴더.

  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import json
import os
import shutil
import stat
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
TMP = Path(tempfile.mkdtemp(prefix="mt_test_"))
os.environ["MT_WORKSPACE"] = str(TMP / "ws")
os.environ.pop("LLM_API_KEY", None)
os.environ.pop("ANTHROPIC_API_KEY", None)

from fake_llm import FakeClient  # noqa: E402
from mtagent import design, hashing, sandbox, store, units  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import audit, confirm, extract, ingest, recompute, validate  # noqa: E402

SAMPLES = ROOT / "samples"
KEY = json.loads((SAMPLES / "annealing_demo_answer_key.json").read_text(encoding="utf-8"))


def tearDownModule():
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def fake(client=None):
    return LLM(client=client or FakeClient(), model="fake")


def new_run(project: str, folder: Path) -> str:
    rid = store.new_run(project)
    store.add_folder(rid, "data", folder / "data")
    if (folder / "report").exists():
        store.add_folder(rid, "report", folder / "report")
    time.sleep(0.01)
    return rid


def approve_all(rid: str, who="tester"):
    v = confirm.view(rid)
    ans = {}
    for i in v["items"]:
        if i["required"] and i["status"] == "pending":
            vals = [c["value"] for c in i["choices"]]
            ans[i["id"]] = {"choice": next(x for x in ("yes", "proceed") if x in vals) if {"yes", "proceed"} & set(vals)
                            else vals[0]}
    return confirm.submit(rid, who, ans)


def full(rid: str, client=None):
    ingest.run(rid)
    extract.run(rid, fake(client))
    confirm.start(rid)
    approve_all(rid)
    recompute.run(rid)
    validate.run(rid, fake(client))
    return audit.run(rid)


class UnitsHashing(unittest.TestCase):
    def test_units(self):
        self.assertAlmostEqual(units.convert(1.2e-8, "A", "nA"), 12.0)
        self.assertEqual(units.dimension("nS"), "conductance")
        self.assertEqual(units.dimension("μA"), "current")
        self.assertIsNone(units.parse("furlong"))
        self.assertEqual(units.from_header("current_A"), "A")
        self.assertEqual(units.from_header("Current (nA)"), "nA")
        self.assertIsNone(units.from_header("sample_id"))
        with self.assertRaises(ValueError):
            units.convert(1, "A", "V")

    def test_format_only_and_row_diff(self):
        d = TMP / "h"
        d.mkdir(exist_ok=True)
        rows = "a,b\n1,2\n3,4\n5,6\n"
        (d / "x.csv").write_text(rows, encoding="utf-8")
        (d / "y.csv").write_bytes(("﻿" + rows.replace("\n", "  \r\n")).encode("utf-8"))
        (d / "z.csv").write_text("a,b\n1,2\n5,6\n", encoding="utf-8")
        x, y, z = (hashing.fingerprint(d / n) for n in ("x.csv", "y.csv", "z.csv"))
        self.assertNotEqual(x["sha256"], y["sha256"])
        self.assertEqual(x["content_hash"], y["content_hash"])
        ch = hashing.compare_sets({"x": x}, {"x": z})
        self.assertEqual(ch[0]["table"]["removed"], 1)
        self.assertEqual(ch[0]["table"]["spans"], [{"kind": "빠짐", "where": "옛 파일 3줄"}])

    def test_condition_matching(self):
        conds = [{"name": "annealed", "label": "어닐링 (A)", "samples": ["S01", "S02"]},
                 {"name": "control", "label": "대조 (C)", "samples": ["S11"]}]
        self.assertEqual(design.match_condition("어닐링 (A)", conds), "annealed")
        self.assertEqual(design.match_condition("annealed (A)", conds), "annealed")
        self.assertEqual(design.match_condition("A 조건", conds, "s02"), "annealed")
        self.assertIsNone(design.match_condition("제3 조건", conds, "S99"))
        self.assertEqual(design.expand_samples(["S01–S03", "X"]), ["S01", "S02", "S03", "X"])


class Schemas(unittest.TestCase):
    def test_structured_output_limits(self):
        """Claude API 구조화 출력 제약: null 허용(유니언) 항목 16개 이하, null 섞인 enum 금지, 모든 object 에 additionalProperties=false."""
        from mtagent.stages import validate as v

        def walk(x, acc):
            if isinstance(x, dict):
                if isinstance(x.get("type"), list) or "anyOf" in x:
                    acc["unions"] += 1
                if isinstance(x.get("type"), list) and "enum" in x:
                    acc["bad_enum"] += 1
                if x.get("type") == "object" and x.get("additionalProperties") is not False:
                    acc["open_obj"] += 1
                for y in x.values():
                    walk(y, acc)
            elif isinstance(x, list):
                for y in x:
                    walk(y, acc)
            return acc
        for name in ("SCHEMA_A", "SCHEMA_B", "SCHEMA_B2", "SCHEMA_C", "SCHEMA_S", "SCHEMA_M"):
            acc = walk(getattr(extract, name), {"unions": 0, "bad_enum": 0, "open_obj": 0})
            self.assertLessEqual(acc["unions"], 16, name)
            self.assertEqual((acc["bad_enum"], acc["open_obj"]), (0, 0), name)
        acc = walk(v.SCHEMA, {"unions": 0, "bad_enum": 0, "open_obj": 0})
        self.assertLessEqual(acc["unions"], 16)
        self.assertEqual((acc["bad_enum"], acc["open_obj"]), (0, 0))


class Sandbox(unittest.TestCase):
    def test_static_check(self):
        bad = "import os\nimport socket\ndef compute(raw, processed):\n    eval('1')\n    open('a', 'w')\n    return {}\n"
        probs = sandbox.static_check(bad)
        self.assertEqual(len(probs), 4, probs)
        self.assertIn("compute(raw, processed) 함수가 없음", sandbox.static_check("x = 1\n"))
        self.assertTrue(any("인자 두 개" in p for p in sandbox.static_check("def compute(files):\n    return {}\n")))

    def test_runtime_blocks_write_and_foreign_read(self):
        d = TMP / "sb"
        d.mkdir(exist_ok=True)
        target = d / "leak.txt"
        for body, word in ((f"open(r'{target}', 'w').write('x')", "쓰기"), ("import socket", "import")):
            p = d / "code.py"
            p.write_text("def compute(raw, processed):\n    " + body + "\n    return {'results': []}\n", encoding="utf-8")
            from mtagent.util import sha_file
            r = sandbox.run(p, sha_file(p), {}, 60)
            self.assertEqual(r["status"], "error")
            self.assertIn(word, r["error"])
        self.assertFalse(target.exists())


class Pipeline(unittest.TestCase):
    def test_demo_end_to_end(self):
        client = FakeClient()
        rid = new_run("demo", SAMPLES / "annealing_demo")
        a = full(rid, client)
        # 4 RECOMPUTE 정답 대비
        res = {r["id"]: r["value"] for r in store.read(rid, "recompute/calc_log.json")["results"]}
        exp = {"G_mean__annealed": KEY["conditions"]["annealed"]["mean_nS"], "G_sd__control": KEY["conditions"]["control"]["sd_nS"],
               "t": KEY["t_test"]["t"], "p": KEY["t_test"]["p_two_sided"], "dG": KEY["increase_percent"], "df": 18}
        for k, v in exp.items():
            self.assertLess(abs(res[k] - v) / abs(v), 1e-9, k)
        # 5·6
        self.assertEqual(a["summary"]["Unsupported"], 0)
        self.assertEqual(a["summary"]["Supported"], 12)
        self.assertTrue(a["blind"]["ok"])
        # 블라인드·값 미전송: 추출 요청에 측정값이 없고, 보고서 문장이 없음 / 5-1 요청에 재계산 값이 없음
        s01 = (SAMPLES / "annealing_demo/data/raw/annealed/S01.csv").read_text(encoding="utf-8").splitlines()[1].split(",")[-1]
        for call in client.calls:
            if call["task"].startswith("2-"):
                self.assertNotIn(s01, call["user"])
                self.assertNotIn("12.1 ± 0.7", call["user"])
        five = next(c for c in client.calls if c["task"] == "5-1")
        catalog = five["user"].split("[보고서 문장]")[0]
        self.assertNotIn("12.1016", catalog)
        self.assertNotIn("6.0494", catalog)
        # 확정 코드는 읽기 전용, 장부에 단계가 모두 있음
        code = store.out_dir(rid) / "confirm" / "approved_code.py"
        self.assertFalse(os.access(code, os.W_OK))
        from mtagent import lineage
        stages = {" ".join(e["stage"].split(" ")[:2]) for e in lineage.entries(rid)}
        for s in ("1 INGEST", "2 EXTRACT", "3 CONFIRM", "4 RECOMPUTE", "5 VALIDATE", "6 AUDIT"):
            self.assertIn(s, stages)
        # 입력 봉인
        with self.assertRaises(ValueError), open(code, "rb") as f:
            store.save_upload(rid, "data", "x.csv", f, 1)

    def test_rerun_detects_changes_and_scopes_e03(self):
        full(new_run("re", SAMPLES / "annealing_demo"))
        rid = new_run("re", SAMPLES / "annealing_demo_rerun")
        a = full(rid)
        ch = {c["file"]: c for c in store.read(rid, "ingest.json")["changes"]}
        self.assertEqual(ch["data/raw/annealed/S07.csv"]["table"]["spans"], [{"kind": "빠짐", "where": "옛 파일 31–33줄"}])
        self.assertEqual(ch["data/raw/control/S12.csv"]["kind"], "형식만 변경")
        miss = store.read(rid, "extract/missing.json")["missing"]
        self.assertEqual([m["detail"] for m in miss], ["S07 position=P3: 8/11점"])
        by = {}
        for c in store.read(rid, "validate.json")["claims"]:
            by.setdefault(c["claim"].get("output_id") or c["claim"].get("lhs"), []).append(c)
        # 누락은 어닐링 집단과 두 집단을 함께 쓰는 항목에만 — 대조 집단 항목은 Supported
        for oid in ("G_mean__annealed", "G_sd__annealed", "dG", "t", "p"):
            for c in by[oid]:
                self.assertEqual(c["verdict"], "Unsupported", oid)
                self.assertIn("E03", {x["code"] for x in c["codes"]})
        for oid in ("G_mean__control", "G_sd__control", "n__control"):
            for c in by[oid]:
                self.assertEqual(c["verdict"], "Supported", oid)
        self.assertEqual(a["reevaluation"]["counts"], {"나빠짐": 9, "그대로": 3})

    def test_confirm_no_reruns_extract_with_feedback(self):
        client = FakeClient()
        rid = new_run("fb", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client))
        v = confirm.start(rid)
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans["3-1:eq:EQ05"] = {"choice": "no", "text": "표준편차는 n-1 로 나누는 표본 표준편차임"}
        before = len(client.calls)
        v = confirm.submit(rid, "tester", ans, llm=fake(client))
        self.assertEqual(v["round"], 2)
        self.assertEqual(v["status"], "open")
        again = [c for c in client.calls[before:] if c["task"] == "2-1b"]
        self.assertTrue(again and "n-1 로 나누는" in again[0]["user"])
        # 제안이 같은 항목은 이어받고, 다른 항목은 다시 묻지 않음(가짜 LLM 은 같은 답) → 바로 확정 가능
        self.assertTrue(any(i.get("carried") for i in v["items"]))

    def test_max_rounds_leaves_pending_and_e06(self):
        client = FakeClient()
        rid = new_run("mx", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake(client))
        confirm.start(rid)
        for _ in range(3):
            v = confirm.view(rid)
            ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and i["status"] == "pending"
                   and "yes" in [c["value"] for c in i["choices"]]}
            if "3-1:eq:EQ04" in ans or confirm.view(rid)["round"] == 1:
                ans["3-1:eq:EQ04"] = {"choice": "no", "text": "조건 평균의 뜻이 틀림"}
            v = confirm.submit(rid, "tester", ans, llm=fake(client))
            if v["status"] == "complete":
                break
            # 가짜 LLM 은 같은 답을 주므로 EQ04 는 이전 답(no)이 이어지지 않고 다시 대기 → 다시 no
            for it in v["items"]:
                if it["id"] == "3-1:eq:EQ04":
                    self.assertEqual(it["status"], "pending")
        v = confirm.view(rid)
        self.assertEqual(v["status"], "complete")
        self.assertEqual([p["target"] for p in v["confirmed"]["pending"]], ["eq:EQ04"])
        recompute.run(rid)
        out = validate.run(rid, fake(client))
        g = [c for c in out["claims"] if c["claim"].get("output_id") == "G_mean__annealed"]
        self.assertTrue(g and all("E06" in {x["code"] for x in c["codes"]} for c in g))
        sd = [c for c in out["claims"] if c["claim"].get("output_id") == "G_sd__annealed"]
        self.assertTrue(sd and all(c["verdict"] == "Supported" for c in sd))

    def test_out_of_spec_value_asks_and_reupload_restarts(self):
        src = TMP / "oos"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        f = src / "data/raw/control/S15.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        parts = lines[5].split(",")
        parts[-1] = "5.0e-08"          # 50 nA — 10 nA 범위(±10.5 nA) 밖
        lines[5] = ",".join(parts)
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("oos", src)
        ingest.run(rid)
        extract.run(rid, fake())
        v = confirm.start(rid)
        item = next(i for i in v["items"] if i["id"].startswith("3-3:data:out_of_spec"))
        self.assertEqual(item["proposal"]["rows"], [{"line": 6, "value": "5.0e-08"}])
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans[item["id"]] = {"choice": "reupload"}
        v = confirm.submit(rid, "tester", ans)
        self.assertEqual(v["status"], "restart_required")
        with self.assertRaises(ValueError):
            recompute.run(rid)

    def test_text_value_none_is_not_missing_but_numeric_na_is(self):
        """조건 이름 'none' 은 정상 값, 숫자 열의 'NA' 는 결측."""
        src = TMP / "na"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        for f in (src / "data/raw/control").glob("*.csv"):
            f.write_text(f.read_text(encoding="utf-8").replace(",control,", ",none,"), encoding="utf-8")
        f = src / "data/raw/annealed/S03.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        lines[4] = ",".join(lines[4].split(",")[:-1] + ["NA"])
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("na", src)
        ingest.run(rid)
        extract.run(rid, fake())
        issues = store.read(rid, "extract/structure.json")["issues"]
        self.assertEqual([(i["kind"], i["file"], i["column"], i["rows"]) for i in issues],
                         [("missing_value", "raw/annealed/S03.csv", "current_A", [{"line": 5, "value": "NA"}])])

    def test_report_is_not_opened_before_validate(self):
        rid = new_run("bl", SAMPLES / "annealing_demo")
        out = ingest.run(rid)
        rep = next(x for x in out["files"] if x["zone"] == "report")
        self.assertEqual(rep["kind"], "bytes (열지 않음)")
        with self.assertRaises(ValueError):
            validate.run(rid, fake())


class V2(unittest.TestCase):
    """GIT_v2 에서 바뀐 것 — 측정 시각 2종 · PROCESSED 사용·대조 · 계산 로그 4요소 · 최신 여부 · 관계 도식."""

    def test_measurement_time_prefers_device_then_original_mtime(self):
        src = TMP / "times"
        (src / "raw").mkdir(parents=True, exist_ok=True)
        (src / "raw" / "dev.csv").write_text("# measured: 2026-09-15 09:30\nx,y_A\n1,2\n", encoding="utf-8")
        (src / "raw" / "plain.csv").write_text("x,y_A\n1,2\n", encoding="utf-8")
        stamp = 1757900000          # 2025-09-15 — 원본 수정 시각
        for f in (src / "raw").iterdir():
            os.utime(f, (stamp, stamp))
        rid = store.new_run("times")
        store.add_folder(rid, "data", src)
        with open(src / "raw" / "plain.csv", "rb") as fh:       # 웹 업로드처럼 수정 시각 없이
            store.save_upload(rid, "data", "raw/web.csv", fh, (src / "raw" / "plain.csv").stat().st_size)
        by = {x["path"]: x for x in ingest.run(rid)["files"]}
        dev, plain, web = by["raw/dev.csv"], by["raw/plain.csv"], by["raw/web.csv"]
        self.assertEqual((dev["measured_at"]["basis"], dev["measured_at"]["first"]), ("device", "2026-09-15 09:30"))
        self.assertEqual(dev["times"]["file_mtime"]["origin"], "original")
        self.assertIn("conflict", dev["measured_at"])          # 파일 수정(2025)이 장비 기록(2026)보다 이름 — 확인 필요
        from datetime import datetime
        self.assertEqual(plain["measured_at"]["basis"], "file_mtime")
        self.assertEqual(plain["measured_at"]["first"], datetime.fromtimestamp(stamp).strftime("%Y-%m-%d %H:%M:%S"))
        self.assertEqual(web["times"]["file_mtime"]["origin"], "upload")
        self.assertIsNone(web["measured_at"])                   # 업로드 시각은 측정 시각으로 쓰지 않음

    def test_processed_is_used_logged_and_cross_checked(self):
        src = TMP / "proc"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        f = src / "data/processed/summary_by_sample.csv"
        lines = f.read_text(encoding="utf-8").splitlines()
        lines[3] = lines[3].replace("12.065", "12.965")        # S03 가공값을 틀리게
        f.write_text("\n".join(lines) + "\n", encoding="utf-8")
        rid = new_run("proc", src)
        ing = ingest.run(rid)
        self.assertEqual({r["file"]: r["count"] for r in ing["required"]}["PROCESSED_DATA"], 1)
        extract.run(rid, fake())
        groups = store.read(rid, "extract/data_content.json")["groups"]
        self.assertEqual([(g["group_id"], g["category"]) for g in groups], [("G1", "raw"), ("P1", "processed")])
        v = confirm.start(rid)
        items = {i["id"]: i for i in v["items"]}
        self.assertIn("3-1:data:P1", items)
        self.assertIn("flowchart LR", items["3-1:matching"]["proposal"]["diagram"]["mermaid"])
        self.assertTrue((store.out_dir(rid) / "confirm" / "relation_diagram.md").exists())
        cond = [i for i in v["items"] if i["id"].startswith("3-2:cond")]
        self.assertTrue(cond and cond[0]["proposal"]["verified"])
        approve_all(rid)
        self.assertEqual(len(store.read(rid, "confirm/confirmed.json")["spec"]["conditions"]), 1)
        log = recompute.run(rid)
        self.assertEqual(log["status"], "ok")
        self.assertEqual(sorted({x["category"] for x in log["inputs"]}), ["processed", "raw"])
        self.assertTrue(log["processed_dependency"]["independent"])      # 결과는 모두 RAW 만으로 같은 값
        self.assertFalse(any(r["depends_on_processed"] for r in log["results"]))
        c = log["commit"]
        self.assertEqual(list(c), ["data", "process", "results", "result_hash"])
        self.assertNotEqual(c["data"]["byte_hash"], c["data"]["content_hash"])
        self.assertEqual(c["result_hash"], log["result_hash"])
        pc = log["processed_check"]
        self.assertEqual((pc["checked"], pc["matched"]), (20, 19))
        self.assertEqual([(m["file"], m["line"], m["reported"]) for m in pc["mismatches"]],
                         [("processed/summary_by_sample.csv", 4, "12.965")])
        # 결과(RAW 기준)는 가공값 오류와 무관
        res = {r["id"]: r["value"] for r in log["results"]}
        self.assertLess(abs(res["G_mean__annealed"] - KEY["conditions"]["annealed"]["mean_nS"]), 1e-9)
        # 최신 여부 — 같은 폴더는 최신, 재실행본은 S07 내용 변경
        self.assertTrue(recompute.freshness(rid, src / "data")["fresh"])
        fr = recompute.freshness(rid, SAMPLES / "annealing_demo_rerun" / "data")
        self.assertFalse(fr["fresh"])
        kinds = {c["file"]: c["kind"] for c in fr["changes"]}
        self.assertEqual(kinds["raw/annealed/S07.csv"], "내용 변경")
        self.assertEqual(kinds["processed/summary_by_sample.csv"], "내용 변경")
        validate.run(rid, fake())
        md = audit.markdown(audit.run(rid))
        self.assertIn("불일치: processed/summary_by_sample.csv 4줄", md)

    def test_cli_runs_offline_stages(self):
        import io
        from contextlib import redirect_stdout
        sys.path.insert(0, str(ROOT))
        import cli
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.assertEqual(cli.main(["new", "cli", "--data", str(SAMPLES / "annealing_demo" / "data")]), 0)
            self.assertEqual(cli.main(["status"]), 0)
        self.assertIn("PROCESSED_DATA: 1개", buf.getvalue())
        self.assertIn("최종 보고서 초안: 0개", buf.getvalue())


def fresh_llm(client, tag: str) -> LLM:
    """캐시를 다른 시험과 나누지 않도록 모델 이름을 따로 — 같은 입력에 다른 가짜 답을 줄 때."""
    return LLM(client=client, model=f"fake-{tag}")


class V3(unittest.TestCase):
    """Git_v3 개선 — 단위 질문 id 겹침 · 빈 계산 과정/매칭 · PROCESSED 독립성 · 리뷰의 작은 버그."""

    def test_same_column_name_in_raw_and_processed_gets_separate_unit_questions(self):
        import re
        src = TMP / "dup"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        for f in (src / "data/raw").rglob("*.csv"):
            f.write_text(f.read_text(encoding="utf-8").replace("current_A", "current", 1), encoding="utf-8")
        p = src / "data/processed/summary_by_sample.csv"
        p.write_text(p.read_text(encoding="utf-8").replace("G_mean_nS", "current", 1), encoding="utf-8")
        roles = {"sample_id": ("id", None), "condition": ("condition", None), "position": ("replicate", None),
                 "voltage_V": ("independent", "V")}

        def columns(user):
            head, raw = user.split("[연구 계획서]")[0], user.startswith("[원시")
            cols = []
            for n in re.findall(r'"name": "([^"]+)"', head):
                role, unit = roles.get(n, ("measured" if raw else "derived", None))
                cols.append({"name": n, "role": role, "quantity": None, "unit": unit,
                             "unit_source": "header" if unit else "none", "meaning": n})
            return {"summary": "단위 없는 current 열", "layout": "long", "columns": cols, "questions": []}
        rid = new_run("dup", src)
        ingest.run(rid)
        extract.run(rid, fresh_llm(FakeClient({"2-1a": columns}), "dup"))
        v = confirm.start(rid)
        ids = sorted(i["id"] for i in v["items"] if i["id"].startswith("3-3:unit:"))
        self.assertEqual(ids, ["3-3:unit:G1:current", "3-3:unit:P1:current"])
        definition = next(i for i in v["items"] if i["id"] == "3-3:definition")["proposal"]["columns"]
        self.assertEqual(sorted(c["group_id"] for c in definition if c["column"] == "current"), ["G1", "P1"])
        ans = {i["id"]: {"choice": "yes"} for i in v["items"] if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        ans["3-3:unit:G1:current"] = {"choice": "other", "text": "A"}
        ans["3-3:unit:P1:current"] = {"choice": "other", "text": "nS"}
        v = confirm.submit(rid, "tester", ans)
        self.assertEqual(v["status"], "complete")
        reg = {(c["group_id"], c["column"]): c["unit"] for c in v["confirmed"]["columns"]}
        self.assertEqual((reg[("G1", "current")], reg[("P1", "current")]), ("A", "nS"))

    def test_empty_steps_and_matching_are_asked_again_then_cannot_be_approved(self):
        from fake_llm import answer

        def once_empty(user):
            out = answer("2-1b", user)
            return out if "[다시 요청]" in user else {**out, "steps": [], "matching": []}
        client = FakeClient({"2-1b": once_empty})
        rid = new_run("empty1", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fresh_llm(client, "empty1"))
        b = store.read(rid, "extract/research.json")
        self.assertTrue(b["steps"] and b["matching"])
        self.assertEqual(b["empty_after_retry"], [])
        self.assertEqual(sum(c["task"] == "2-1b" for c in client.calls), 2)      # 비었을 때만 한 번 더

        always = FakeClient({"2-1b": lambda u: {**answer("2-1b", u), "steps": [], "matching": []}})
        rid = new_run("empty2", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fresh_llm(always, "empty2"))
        self.assertEqual(store.read(rid, "extract/research.json")["empty_after_retry"], ["steps", "matching"])
        items = {i["id"]: i for i in confirm.start(rid)["items"]}
        for k in ("3-1:steps", "3-1:matching"):
            self.assertEqual([c["value"] for c in items[k]["choices"]], ["no"], k)

    def test_result_leaning_on_processed_is_flagged_and_e06(self):
        from fake_llm import REFERENCE_CODE
        hook = "    groups = defaultdict(list)\n"
        self.assertEqual(REFERENCE_CODE.count(hook), 1)
        leaky = REFERENCE_CODE.replace(hook, (
            "    for rel in processed:                      # 가공값으로 시료 전도도를 덮어씀 — 순환 검증\n"
            "        with open(processed[rel], newline='', encoding='utf-8-sig') as fh:\n"
            "            for row in csv.DictReader(fh):\n"
            "                g_sample[row['sample_id']] = float(row['G_mean_nS']) / 1e9\n") + hook)
        client = FakeClient({"2-1c": lambda u: {"code": leaky, "explanation": "가공값 사용", "assumptions": []}})
        llm = fresh_llm(client, "leak")
        rid = new_run("leak", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, llm)
        confirm.start(rid)
        approve_all(rid)
        log = recompute.run(rid)
        dep = log["processed_dependency"]
        self.assertFalse(dep["independent"])
        self.assertIn("G_mean__annealed", dep["ids"])
        self.assertNotIn("n__annealed", dep["ids"])
        out = validate.run(rid, llm)
        g = [c for c in out["claims"] if c["claim"].get("output_id") == "G_mean__annealed"]
        self.assertTrue(g)
        for c in g:
            self.assertEqual(c["verdict"], "Unsupported")
            self.assertIn("E06", {x["code"] for x in c["codes"]})
        n = [c for c in out["claims"] if c["claim"].get("output_id") == "n__control"]
        self.assertTrue(n and all(c["verdict"] == "Supported" for c in n))

    def test_small_review_fixes(self):
        # 파일 수정 시각은 마지막 장비 기록과 비교
        d = {"first": "2026-09-15 09:00", "last": "2026-09-15 18:00", "count": 2, "sources": []}
        m = {"value": "2026-09-15 12:00:00", "origin": "original"}
        self.assertIn("conflict", hashing.measured_at(d, m))
        self.assertNotIn("conflict", hashing.measured_at(d, {**m, "value": "2026-09-15 18:05:00"}))
        self.assertNotIn("conflict", hashing.measured_at(d, {**m, "origin": "upload"}))
        # processed_check 의 file 이 목록이어도 멈추지 않음
        pc = recompute.processed_check([{"file": ["processed/a.csv"], "reported": "1.0", "recomputed": 1.0}],
                                       {"processed/a.csv"})
        self.assertEqual((pc["checked"], len(pc["problems"])), (0, 1))
        # 측정 조건 값의 숫자가 인용에 없으면 확인 안 됨
        from fake_llm import answer

        def bad_condition(user):
            out = answer("2-2", user)
            out["conditions"] = [{**out["conditions"][0], "value": "20 ms"}]
            return out
        rid = new_run("cond", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fresh_llm(FakeClient({"2-2": bad_condition}), "cond"))
        cond = store.read(rid, "extract/spec.json")["files"][0]["conditions"][0]
        self.assertFalse(cond["verified"])
        self.assertIn("값의 숫자 20 가 인용 안에 없음", cond["problems"])
        # 계산하지 않은 실행은 최신 여부를 답하지 않음
        from mtagent.util import write_json
        write_json(store.out_dir(rid) / "recompute" / "calc_log.json", {"status": "blocked", "reason": "코드 미승인", "inputs": []})
        with self.assertRaises(ValueError):
            recompute.freshness(rid, SAMPLES / "annealing_demo" / "data")
        # 측정 시각 요약은 데이터만 센다 (샘플의 데이터 22개 — RAW 20 · PROCESSED 1 · 메모 1)
        detail = next(c["detail"] for c in store.read(rid, "ingest.json")["checks"] if c["check"] == "측정 시각 2종")
        self.assertIn("파일 수정 시각 22 · 없음 0", detail)


class V3Review(unittest.TestCase):
    """Git_v3 리뷰·실제 실행에서 나온 문제."""

    def test_compute_signature_rules(self):
        ok = ("def compute(raw, processed):\n    return {}\n", "def compute(raw, processed, /):\n    return {}\n",
              "def compute(raw, processed, opts=None):\n    return {}\n",
              "class H:\n    def compute(self):\n        return 1\n\ndef compute(raw, processed):\n    return {}\n")
        for code in ok:
            self.assertEqual(sandbox.static_check(code), [], code)
        self.assertTrue(sandbox.static_check("def compute(files):\n    return {}\n"))
        self.assertIn("compute(raw, processed) 함수가 없음",
                      sandbox.static_check("class H:\n    def compute(self, a, b):\n        return 1\n"))
        self.assertFalse(sandbox.uses_second_arg("def compute(raw, processed):\n    return {'n': len(raw)}\n"))
        self.assertTrue(sandbox.uses_second_arg("def compute(raw, p):\n    def f():\n        return p\n    return f()\n"))

    def test_independence_timeout_is_unverified_but_error_is_dependent(self):
        from mtagent import config
        from mtagent.util import sha_file
        d = TMP / "indep"
        d.mkdir(exist_ok=True)
        res = [{"id": "a", "value": 1.0}]
        cases = {"loop": ("        while True:\n            pass\n", None),
                 "error": ("        raise KeyError('processed')\n", False)}
        old = config.SANDBOX_TIMEOUT
        config.SANDBOX_TIMEOUT = 5
        try:
            for name, (body, expect) in cases.items():
                code = ("def compute(raw, processed):\n    if not processed:\n" + body +
                        "    return {'results': [{'id': 'a', 'value': 1.0, 'unit': None, 'kind': 'value'}]}\n")
                p = d / f"{name}.py"
                p.write_text(code, encoding="utf-8")
                dep = recompute._independence(p, sha_file(p), {}, {"processed/x.csv": str(p)}, res, code)
                self.assertIs(dep["independent"], expect, name)
                self.assertEqual(dep["ids"], [] if expect is None else ["a"], name)
                self.assertIn("run", dep)
        finally:
            config.SANDBOX_TIMEOUT = old
        code = "def compute(raw, processed):\n    return {'results': []}\n"
        dep = recompute._independence(d / "none.py", "", {}, {"processed/x.csv": "x"}, res, code)
        self.assertEqual((dep["checked"], dep["independent"]), (False, True))     # processed 를 안 읽으면 다시 안 돌림

    def test_count_claims_are_checked_against_plan_counts(self):
        conf = {"design": {"conditions": [{"name": "a", "samples": ["S1", "S2"]}, {"name": "b", "samples": ["S3", "S4"]}],
                           "replicate": "위치", "replicates_per_unit": 7, "points_per_replicate": 11}}
        from mtagent.stages.validate import _compare
        for value, bad in ((7, False), (11, False), (2, False), (8, True)):
            rec, found = _compare({"type": "n", "text": f"{value}개", "value": value, "output_id": None}, {}, conf)
            self.assertEqual(any(c["code"] == "E04" for c in found), bad, value)
            self.assertTrue(rec["compared"])
        self.assertIn("실험 방법·설정값", validate.SYSTEM)

    def test_retry_failure_and_duplicate_questions(self):
        from fake_llm import answer

        def dup(user):      # 첫 답과 다시 묻기 답에 같은 질문
            out = {**answer("2-1b", user), "questions": ["절편을 고정했습니까?"]}
            return out if "[다시 요청]" in user else {**out, "steps": [], "matching": []}
        rid = new_run("dupq", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fresh_llm(FakeClient({"2-1b": dup}), "dupq"))
        self.assertEqual(store.read(rid, "extract/research.json")["questions"], ["절편을 고정했습니까?"])
        items = confirm.start(rid)["items"]
        self.assertEqual(len([i["id"] for i in items]), len({i["id"] for i in items}))

        def fails(user):
            if "[다시 요청]" in user:
                raise RuntimeError("rate limit")
            return {**answer("2-1b", user), "steps": [], "matching": []}
        client = FakeClient({"2-1b": fails})
        rid = new_run("retryfail", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fresh_llm(client, "retryfail"))
        self.assertEqual(store.state(rid)["stages"]["extract"]["status"], "done")     # 다시 묻기 실패로 막히지 않음
        b = store.read(rid, "extract/research.json")
        self.assertTrue(any("다시 묻기 실패" in q for q in b["questions"]))
        self.assertEqual(b["empty_after_retry"], ["steps", "matching"])
        code_call = next(c for c in client.calls if c["task"] == "2-1c")
        self.assertNotIn("empty_after_retry", code_call["user"])                     # 내부 기록은 LLM 에 보내지 않음

    def test_number_matching_and_partial_folder_meta(self):
        self.assertTrue(extract._num_in(1000, "rated for 1,000 h"))
        self.assertTrue(extract._num_in(0.001, "integration time 1E-3 s"))
        import re
        self.assertEqual([float(n) for n in re.findall(extract.NUM, "1E-3 s")], [0.001])
        src = TMP / "meta"
        src.mkdir(exist_ok=True)
        (src / "a.csv").write_text("x\n1\n", encoding="utf-8")
        (src / "b.csv").write_text("x\n" + "1\n" * 200, encoding="utf-8")
        rid = store.new_run("meta")
        old = store.MAX_UPLOAD
        store.MAX_UPLOAD = 50
        try:
            with self.assertRaises(ValueError):
                store.add_folder(rid, "data", src)
        finally:
            store.MAX_UPLOAD = old
        self.assertEqual(store.upload_meta(rid), {"data/a.csv": {"mtime_origin": "original"}})

    def test_claim_comparison_respects_units_and_exact_counts(self):
        from mtagent.stages.validate import _compare

        outs = {"a": {"id": "a", "value": 1000.0, "unit": "mA"},
                "b": {"id": "b", "value": 2.0, "unit": "A"}}
        rec, found = _compare({"type": "direction", "lhs": "a", "rhs": "b", "relation": "greater"}, outs, {})
        self.assertTrue(rec["compared"])
        self.assertEqual(rec["recomputed"], -1000.0)
        self.assertIn("E05", {x["code"] for x in found})
        outs["b"]["unit"] = "V"
        rec, found = _compare({"type": "direction", "lhs": "a", "rhs": "b", "relation": "greater"}, outs, {})
        self.assertFalse(rec["compared"])
        self.assertIn("E01", {x["code"] for x in found})

        rec, found = _compare({"type": "n", "output_id": "n", "value": 2.4},
                              {"n": {"id": "n", "value": 2.0, "kind": "n"}}, {})
        self.assertIn("E04", {x["code"] for x in found})
        self.assertAlmostEqual(units.convert(0, "C", "K"), 273.15)
        self.assertAlmostEqual(units.convert(273.15, "K", "C"), 0)

    def test_significance_requires_a_specific_p_value_and_df(self):
        from mtagent.stages.validate import _compare

        outs = {"p1": {"id": "p1", "value": 0.01, "kind": "p_value"},
                "p2": {"id": "p2", "value": 0.9, "kind": "p_value"}}
        for output_id in (None, "missing"):
            rec, found = _compare({"type": "significance", "output_id": output_id, "significant": True}, outs, {})
            self.assertFalse(rec["compared"])
            self.assertIn("E06", {x["code"] for x in found})
        rec, found = _compare({"type": "significance", "output_id": "p2", "significant": True, "df": 8}, outs, {})
        self.assertEqual(rec["outputs_used"], ["p2"])
        self.assertIn("E05", {x["code"] for x in found})
        self.assertIn("E06", {x["code"] for x in found})

    def test_scientific_notation_uses_reported_precision(self):
        from mtagent.stages.validate import _compare

        outs = {"x": {"id": "x", "value": 0.0014, "unit": "A", "kind": "value"}}
        _, found = _compare({"type": "value", "text": "1.0e-3 A", "value": 0.001, "unit": "A", "output_id": "x"}, outs, {})
        self.assertIn("E05", {x["code"] for x in found})
        _, found = _compare({"type": "value", "text": "1e-3 A", "value": 0.001, "unit": "A", "output_id": "x"}, outs, {})
        self.assertNotIn("E05", {x["code"] for x in found})

    def test_processed_dependency_includes_result_metadata(self):
        code = "def compute(raw, processed):\n    return processed\n"
        alone = {"status": "ok", "results": [{"id": "x", "value": 1.0, "unit": "A", "kind": "value"}]}
        with patch("mtagent.stages.recompute.sandbox.run", return_value=alone):
            dep = recompute._independence(Path("unused"), "", {}, {"p.csv": "unused"},
                                          [{"id": "x", "value": 1.0, "unit": "mA", "kind": "value"}], code)
        self.assertEqual(dep["ids"], ["x"])

    def test_extract_retry_does_not_show_stale_outputs(self):
        rid = new_run("extract-stale", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake())
        exdir = store.out_dir(rid) / "extract"
        self.assertTrue((exdir / "code_draft.py").exists())
        with patch("mtagent.stages.extract._part_b", side_effect=RuntimeError("retry failed")):
            view = extract.run(rid, fake(), parts={"2-1"})
        self.assertIn("2-1b", view["summary"]["errors"])
        self.assertIsNone(view["2-1b"])
        self.assertIsNone(view["2-1c"])
        self.assertIsNone(view["2-3"])
        self.assertEqual(view["summary"]["steps"]["2-1c"]["status"], "skipped")
        self.assertFalse((exdir / "code_draft.py").exists())
        self.assertTrue((exdir / "history" / "round1" / "code.json").exists())

    def test_extract_mixed_numeric_column_does_not_send_values(self):
        tables = {"raw.csv": {"columns": ["current_A", "sample_id"],
                              "rows": [["1.23", "S01"], ["NA", "S02"]], "comments": []}}
        group = extract._groups(tables)[0]
        self.assertEqual(group["profile"][0]["text_values"], ["NA"])
        self.assertEqual(group["profile"][1]["text_values"], ["S01", "S02"])

    def test_confirm_rejects_invalid_answer_shapes(self):
        rid = new_run("confirm-shapes", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake())
        item = next(i for i in confirm.start(rid)["items"] if i["required"])
        for answers in ([], {item["id"]: []}, {item["id"]: {"choice": "no", "text": 1}}):
            with self.assertRaises(ValueError):
                confirm.submit(rid, "tester", answers)
        self.assertEqual(confirm.view(rid)["round"], 1)

    def test_confirm_stays_on_round_when_reextract_fails(self):
        rid = new_run("confirm-retry-error", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, fake())
        view = confirm.start(rid)
        answers = {i["id"]: {"choice": "yes"} for i in view["items"]
                   if i["required"] and "yes" in [c["value"] for c in i["choices"]]}
        answers["3-1:eq:EQ05"] = {"choice": "no", "text": "식 수정"}
        with patch("mtagent.stages.extract._part_b", side_effect=RuntimeError("retry failed")):
            with self.assertRaisesRegex(ValueError, "2 EXTRACT 재실행 실패"):
                confirm.submit(rid, "tester", answers, llm=fake())
        self.assertEqual(confirm.view(rid)["round"], 1)
        self.assertEqual(confirm.view(rid)["status"], "open")
        self.assertIsNone(store.read(rid, "confirm/confirmed.json"))


class Server(unittest.TestCase):
    def test_host_origin_and_write_header(self):
        from http.server import ThreadingHTTPServer
        from web import server
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        server.Handler.port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{server.Handler.port}"

        def req(method, path, body=None, headers=None):
            r = urllib.request.Request(base + path, data=json.dumps(body).encode() if body is not None else None,
                                       method=method, headers={"Content-Type": "application/json", **(headers or {})})
            try:
                with urllib.request.urlopen(r, timeout=10) as resp:
                    return resp.status, json.loads(resp.read() or b"null") if "json" in resp.headers.get("Content-Type", "") else None
            except urllib.error.HTTPError as e:
                return e.code, None
        try:
            self.assertEqual(req("GET", "/api/status")[0], 200)
            self.assertEqual(req("POST", "/api/runs", {"project": "s"})[0], 403)
            self.assertEqual(req("POST", "/api/runs", {"project": "s"}, {"X-MeasureTrace": "1", "Origin": "http://evil.example"})[0], 403)
            code, body = req("POST", "/api/runs", {"project": "s"}, {"X-MeasureTrace": "1"})
            self.assertEqual(code, 200)
            self.assertEqual(req("GET", f"/api/runs/{body['run_id']}")[0], 200)
            self.assertEqual(req("POST", f"/api/runs/{body['run_id']}/confirm/submit", [],
                                 {"X-MeasureTrace": "1"})[0], 400)
            self.assertEqual(req("PUT", f"/api/runs/{body['run_id']}/files?zone=data&path=../x.csv", {}, {"X-MeasureTrace": "1"})[0], 400)
        finally:
            httpd.shutdown()


if __name__ == "__main__":
    unittest.main()
