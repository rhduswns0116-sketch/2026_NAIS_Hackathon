"""계획서 수식(docx_equations) ↔ 파이프라인 연결 시험 — 가짜 LLM(토큰 0).

1 INGEST 가 Word 계획서의 수식을 LaTeX 로 바꿔 equations.json 에 남기고, 2 EXTRACT 가 그것을 쓰며,
변환 실패한 식은 3 CONFIRM 에서 연구자가 직접 적는다.

  python -m unittest tests.test_equations_pipeline -v
"""
from __future__ import annotations

import os
import shutil
import stat
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]

import make_eq_docx as mk  # noqa: E402
from fake_llm import FakeClient  # noqa: E402
from mtagent import lineage, store  # noqa: E402
from mtagent.llm import LLM  # noqa: E402
from mtagent.stages import confirm, extract, ingest  # noqa: E402

SAMPLES = ROOT / "samples"
TMP = Path(tempfile.mkdtemp(prefix="mt_eqpipe_"))
_OLD_WS = None


def setUpModule():            # 이 모듈만 자기 작업 폴더 — 다른 시험 모듈의 설정을 건드리지 않는다
    global _OLD_WS
    _OLD_WS = os.environ.get("MT_WORKSPACE")
    os.environ["MT_WORKSPACE"] = str(TMP / "ws")


def tearDownModule():
    if _OLD_WS is None:
        os.environ.pop("MT_WORKSPACE", None)
    else:
        os.environ["MT_WORKSPACE"] = _OLD_WS
    for p in TMP.rglob("*"):
        if p.is_file():
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
    shutil.rmtree(TMP, ignore_errors=True)


def llm(tag: str, client=None) -> LLM:
    return LLM(client=client or FakeClient(), model=f"fake-eqpipe-{tag}")


def new_run(project: str, folder: Path) -> str:
    rid = store.new_run(project)
    store.add_folder(rid, "data", folder / "data")
    if (folder / "report").exists():
        store.add_folder(rid, "report", folder / "report")
    return rid


class Ingest(unittest.TestCase):
    def test_sample_plan_equations_are_converted_at_ingest(self):
        rid = new_run("eq-ingest", SAMPLES / "annealing_demo")
        out = ingest.run(rid)
        # INGEST 자체는 그대로 — 막힘 없음, 5종 모두, 사본 잠금, 처리 중 입력 불변
        self.assertFalse(store.state(rid)["stages"]["ingest"]["blocked"])
        self.assertTrue(all(r["count"] for r in out["required"]))
        self.assertTrue(all(c["ok"] for c in out["checks"]), [c for c in out["checks"] if not c["ok"]])
        # 계획서 수식
        eq = out["equations"]
        self.assertEqual(eq["converter"], "dwml.omml.oMath2Latex")
        self.assertEqual(eq["files"], [{"file": "research_plan.docx", "equations": 8, "failed": []}])
        doc = store.read(rid, "equations.json")
        plan = next(x for x in out["files"] if x["path"] == "research_plan.docx")
        f = doc["files"][0]
        self.assertEqual(f["plan_sha256"], plan["sha256"])                       # 1 INGEST 가 계산한 파일 해시
        self.assertEqual([e["id"] for e in f["equations"]], [f"EQ{i:02d}" for i in range(1, 9)])
        self.assertTrue(f["equations"][0]["latex"].startswith(r"G_{ij}=\frac{\sum_{k=1}^{11}"))
        self.assertIn("[EQ01] $ G_{ij}=", f["plan_text"])
        stages = [e["stage"] for e in lineage.entries(rid)]
        self.assertIn("1 INGEST 계획서 수식", stages)
        self.assertIn("1 INGEST", stages)
        self.assertFalse(any("수식" in x["text"] for x in out["findings"]))

    def test_non_docx_plan_is_noted(self):
        src = TMP / "txtplan"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        (src / "data/research_plan.docx").unlink()
        (src / "data/research_plan.md").write_text("# 연구 계획\n실험 설계와 계산식\n", encoding="utf-8")
        out = ingest.run(new_run("eq-txt", src))
        self.assertIsNone(out["equations"])
        self.assertTrue(any("research_plan.md" in x["text"] and "수식을 자동으로 읽지 않음" in x["text"]
                            for x in out["findings"]))


class Extract(unittest.TestCase):
    def test_extract_uses_ingest_equations_and_inline_latex(self):
        client = FakeClient()
        rid = new_run("eq-extract", SAMPLES / "annealing_demo")
        ingest.run(rid)
        extract.run(rid, llm("extract", client))
        b = store.read(rid, "extract/research.json")
        doc = store.read(rid, "equations.json")["files"][0]["equations"]
        self.assertEqual([(e["id"], e["latex"], e["status"]) for e in b["equations"]],
                         [(e["id"], e["latex"], e["status"]) for e in doc])
        a = next(c for c in client.calls if c["task"] == "2-1a")
        self.assertIn("[EQ01] $ G_{ij}=", a["user"])                              # 자리 표시만이 아니라 식이 함께
        self.assertNotIn("[EQ01]\n", a["user"])

    def test_old_run_without_equations_json_converts_on_the_fly(self):
        rid = new_run("eq-old", SAMPLES / "annealing_demo")
        ingest.run(rid)
        (store.out_dir(rid) / "equations.json").unlink()
        extract.run(rid, llm("old"))
        self.assertEqual(len(store.read(rid, "extract/research.json")["equations"]), 8)


class FailedEquation(unittest.TestCase):
    def test_failed_equation_is_asked_and_researcher_latex_is_confirmed(self):
        src = TMP / "broken"
        shutil.copytree(SAMPLES / "annealing_demo", src)
        eqs = mk.equations()
        eqs[1] = (eqs[1][0], mk.omath(mk.sub(mk.r("R"), mk.r("ij")), mk.r("="),
                                      mk.frac(mk.r("1"), mk.sub(mk.r("G"), mk.r("ij")), pr=False)))   # m:fPr 없음
        os.chmod(src / "data/research_plan.docx", stat.S_IWRITE | stat.S_IREAD)
        mk.write_docx(src / "data/research_plan.docx", mk.default_paragraphs(eqs))
        rid = new_run("eq-broken", src)
        out = ingest.run(rid)
        self.assertEqual(out["equations"]["files"][0]["failed"], ["EQ02"])
        self.assertTrue(any("EQ02" in x["text"] and "직접 입력" in x["text"] for x in out["findings"]))
        self.assertFalse(next(c for c in out["checks"] if c["check"] == "계획서 수식 → LaTeX")["ok"])

        extract.run(rid, llm("broken"))
        b = {e["id"]: e for e in store.read(rid, "extract/research.json")["equations"]}
        self.assertEqual((b["EQ02"]["status"], b["EQ02"]["latex"]), ("failed", None))
        self.assertTrue(b["EQ02"]["error"].startswith("KeyError"))

        v = confirm.start(rid)
        item = next(i for i in v["items"] if i["id"] == "3-1:eq:EQ02")
        self.assertEqual([c["value"] for c in item["choices"]], ["manual"])
        self.assertEqual(item["proposal"]["latex"], "(변환 실패 — 원문 확인 필요)")
        ans = {i["id"]: {"choice": "yes"} for i in v["items"]
               if i["required"] and i["status"] == "pending" and "yes" in [c["value"] for c in i["choices"]]}
        for i in v["items"]:
            if i["required"] and i["status"] == "pending" and i["id"] not in ans and "proceed" in [c["value"] for c in i["choices"]]:
                ans[i["id"]] = {"choice": "proceed"}
        ans["3-1:eq:EQ02"] = {"choice": "manual", "text": r"R_{ij}=\frac{1}{G_{ij}}"}
        v = confirm.submit(rid, "tester", ans)
        self.assertEqual(v["status"], "complete")
        eq = {e["id"]: e for e in v["confirmed"]["equations"]}
        self.assertEqual((eq["EQ02"]["latex"], eq["EQ02"]["status"], eq["EQ02"]["latex_source"]),
                         (r"R_{ij}=\frac{1}{G_{ij}}", "manual", "researcher"))
        self.assertEqual(eq["EQ01"]["latex_source"], "dwml.omml.oMath2Latex")
        self.assertTrue(any("EQ02" in x for x in confirm.load(rid)["feedback"]["2-1"]))


if __name__ == "__main__":
    unittest.main()
