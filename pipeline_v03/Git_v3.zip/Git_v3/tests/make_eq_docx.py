"""시험용 docx 생성기 — Word 수식(OMML) 조각을 조합해 최소 docx 를 만든다.

  python tests/make_eq_docx.py out.docx        기본 문서(설명 문장 + 수식 8개)를 만든다

조각 함수는 OMML 문자열을 돌려준다. Word 가 저장하듯 속성 요소(m:fPr, m:sSubPr …)와 그 안의 m:ctrlPr 를 모두 넣는다.
pr=False 로 주면 속성 요소를 뺀다(고장 시험용).
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
CTRL = '<m:ctrlPr><w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/><w:i/></w:rPr></m:ctrlPr>'


# ── OMML 조각 ───────────────────────────────────────────────────────────
def r(text: str) -> str:
    """수식 글자 한 덩어리."""
    return f"<m:r><m:t>{escape(text)}</m:t></m:r>"


def _e(x: str) -> str:
    return f"<m:e>{x}</m:e>"


def frac(num: str, den: str, pr: bool = True) -> str:
    return f"<m:f>{'<m:fPr>' + CTRL + '</m:fPr>' if pr else ''}<m:num>{num}</m:num><m:den>{den}</m:den></m:f>"


def sub(base: str, s: str) -> str:
    return f"<m:sSub><m:sSubPr>{CTRL}</m:sSubPr>{_e(base)}<m:sub>{s}</m:sub></m:sSub>"


def sup(base: str, s: str) -> str:
    return f"<m:sSup><m:sSupPr>{CTRL}</m:sSupPr>{_e(base)}<m:sup>{s}</m:sup></m:sSup>"


def subsup(base: str, lo: str, hi: str) -> str:
    return f"<m:sSubSup><m:sSubSupPr>{CTRL}</m:sSubSupPr>{_e(base)}<m:sub>{lo}</m:sub><m:sup>{hi}</m:sup></m:sSubSup>"


def bar(x: str) -> str:
    """윗줄(평균 기호)."""
    return f'<m:bar><m:barPr><m:pos m:val="top"/>{CTRL}</m:barPr>{_e(x)}</m:bar>'


def nsum(lo: str, hi: str, body: str) -> str:
    """합 ∑ (아래·위 한계)."""
    return (f'<m:nary><m:naryPr><m:chr m:val="∑"/><m:limLoc m:val="undOvr"/>{CTRL}</m:naryPr>'
            f"<m:sub>{lo}</m:sub><m:sup>{hi}</m:sup>{_e(body)}</m:nary>")


def sqrt(x: str) -> str:
    """제곱근 (차수 숨김)."""
    return f'<m:rad><m:radPr><m:degHide m:val="1"/>{CTRL}</m:radPr><m:deg/>{_e(x)}</m:rad>'


def paren(x: str) -> str:
    """괄호 ( )."""
    return f"<m:d><m:dPr>{CTRL}</m:dPr>{_e(x)}</m:d>"


def omath(*parts: str) -> str:
    return "<m:oMath>" + "".join(parts) + "</m:oMath>"


# ── 문단 · 문서 ─────────────────────────────────────────────────────────
def text_para(text: str) -> str:
    return f'<w:p><w:r><w:t xml:space="preserve">{escape(text)}</w:t></w:r></w:p>'


def math_para(math: str) -> str:
    """수식만 있는 문단 (Word 의 '표시' 수식 — m:oMathPara 로 감쌈)."""
    return f"<w:p><m:oMathPara>{math}</m:oMathPara></w:p>"


def inline_para(before: str, math: str, after: str) -> str:
    """글 사이에 수식이 끼인 문단."""
    return (f'<w:p><w:r><w:t xml:space="preserve">{escape(before)}</w:t></w:r>{math}'
            f'<w:r><w:t xml:space="preserve">{escape(after)}</w:t></w:r></w:p>')


def document_xml(paragraphs: list[str]) -> str:
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            f'<w:document xmlns:w="{W_NS}" xmlns:m="{M_NS}"><w:body>{"".join(paragraphs)}</w:body></w:document>')


CONTENT_TYPES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                 '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                 '<Default Extension="xml" ContentType="application/xml"/>'
                 '<Override PartName="/word/document.xml" '
                 'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="word/document.xml"/></Relationships>')


def write_docx(path: Path, paragraphs: list[str]) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CONTENT_TYPES)
        z.writestr("_rels/.rels", RELS)
        z.writestr("word/document.xml", document_xml(paragraphs))
    return path


# ── 기본 문서: 설명 문장 + 수식 8개 (연구 계획서 모양) ───────────────────
def equations() -> list[tuple[str, str]]:
    """(설명 문장, 수식) 8개. 뺄셈은 Word 처럼 유니코드 − (U+2212), 곱은 ×, 증가량은 Δ."""
    vbar, gc = bar(r("V")), bar(sub(r("G"), r("c")))
    ga, gcc = bar(sub(r("G"), r("A"))), bar(sub(r("G"), r("C")))
    return [
        ("위치별 전도도는 전압–전류 11점의 최소제곱 기울기이다.",
         omath(sub(r("G"), r("ij")), r("="),
               frac(nsum(r("k=1"), r("11"), paren(sub(r("V"), r("k")) + r("−") + vbar)
                         + paren(sub(r("I"), r("ijk")) + r("−") + bar(sub(r("I"), r("ij"))))),
                    nsum(r("k=1"), r("11"), sup(paren(sub(r("V"), r("k")) + r("−") + vbar), r("2")))))),
        ("저항은 전도도의 역수이다.", omath(sub(r("R"), r("ij")), r("="), frac(r("1"), sub(r("G"), r("ij"))))),
        ("시료 전도도는 위치 7개의 평균이다.",
         omath(sub(r("G"), r("i")), r("="), frac(r("1"), r("7")), nsum(r("j=1"), r("7"), sub(r("G"), r("ij"))))),
        ("조건 평균 전도도는 시료 n개의 평균이다.",
         omath(gc, r("="), frac(r("1"), r("n")), nsum(r("i=1"), r("n"), sub(r("G"), r("i"))))),
        ("조건 표준편차는 표본 표준편차이다.",
         omath(sub(r("s"), r("c")), r("="),
               sqrt(frac(r("1"), r("n−1")) + nsum(r("i=1"), r("n"), sup(paren(sub(r("G"), r("i")) + r("−") + gc), r("2")))))),
        ("합동 표준편차는 두 조건의 분산을 자유도로 가중 평균한다.",
         omath(sub(r("s"), r("p")), r("="),
               sqrt(frac(paren(sub(r("n"), r("A")) + r("−1")) + subsup(r("s"), r("A"), r("2")) + r("+")
                         + paren(sub(r("n"), r("C")) + r("−1")) + subsup(r("s"), r("C"), r("2")),
                         sub(r("n"), r("A")) + r("+") + sub(r("n"), r("C")) + r("−2"))))),
        ("t 통계량은 등분산을 가정한 독립 2표본 검정이다.",
         omath(r("t="), frac(ga + r("−") + gcc,
                             sub(r("s"), r("p")) + sqrt(frac(r("1"), sub(r("n"), r("A"))) + r("+")
                                                        + frac(r("1"), sub(r("n"), r("C"))))))),
        ("증가율은 대조 대비 백분율이다.",
         omath(r("ΔG="), frac(ga + r("−") + gcc, gcc), r("×100"))),
    ]


def default_paragraphs(eqs: list[tuple[str, str]] | None = None) -> list[str]:
    out = [text_para("연구 계획서 — 계산식")]
    for sentence, math in eqs or equations():
        out += [text_para(sentence), math_para(math)]
    return out


if __name__ == "__main__":
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "equations_sample.docx")
    print(write_docx(target, default_paragraphs()))
