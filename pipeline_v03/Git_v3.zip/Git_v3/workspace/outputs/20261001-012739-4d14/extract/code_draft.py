import csv
import math

from scipy import stats

# ---- 계획서(추출 결과)에서 가져온 설정 ----
ID_COL = 'sample_id'
COND_COL = 'condition'
POS_COL = 'position'
V_COL = 'voltage_V'
I_COL = 'current_A'
REQUIRED_COLS = [ID_COL, COND_COL, POS_COL, V_COL, I_COL]
PROC_VALUE_COL = 'G_mean_nS'  # P1 의 시료 전도도(nS), 식 3 결과와 같은 뜻

# 설계 조건(name, 시료 목록). 첫 번째가 A(어닐링), 두 번째가 C(대조).
CONDITIONS = [
    ('annealed', ['S01', 'S02', 'S03', 'S04', 'S05', 'S06', 'S07', 'S08', 'S09', 'S10']),
    ('control', ['S11', 'S12', 'S13', 'S14', 'S15', 'S16', 'S17', 'S18', 'S19', 'S20']),
]
# ASSUMPTION: raw 의 condition 열 값은 조건 name('annealed'/'control') 또는 약칭('A'/'C')이다.
#             어느 쪽도 아니면 validation 에 기록만 하고, 조건 배정은 설계의 시료 목록(파일 이름)을 따른다.
COND_ALIASES = {'annealed': ('annealed', 'A'), 'control': ('control', 'C')}

EXPECTED_ROWS_PER_FILE = 77          # 위치 7 x 전압 11
EXPECTED_POSITIONS = 7
EXPECTED_VOLTAGES = [-0.5 + 0.1 * k for k in range(11)]
# ASSUMPTION: 전압 격자(-0.5~0.5 V, 0.1 V 간격) 확인 허용 오차는 1e-6 V 로 둔다(확인용, 제외에는 쓰지 않음).
VOLT_TOL = 1e-6
# ASSUMPTION: '10 nA 범위'는 |I| <= 10 nA 를 뜻하고 경계값은 범위 안으로 본다. 벗어난 값은 표시만 하고 제외하지 않는다.
CURRENT_LIMIT_A = 10e-9
S_TO_NS = 1e9
ALPHA = 0.05
EXPECTED_DF = 18
NAN = float('nan')


def _to_float(text):
    s = '' if text is None else text.strip()
    if s == '':
        return None, '빈 값'
    try:
        x = float(s)
    except ValueError:
        return None, '숫자로 바꿀 수 없음: ' + repr(s)
    if not math.isfinite(x):
        return None, '유한하지 않은 값: ' + repr(s)
    return x, None


def _mean(xs):
    return math.fsum(xs) / len(xs)


def _sd(xs):
    # EQ05: 표본 표준편차(n - 1)
    m = _mean(xs)
    return math.sqrt(math.fsum((x - m) ** 2 for x in xs) / (len(xs) - 1))


def _ls_slope(vs, cs):
    # EQ01: 최소제곱 직선 기울기 = sum((V-Vbar)(I-Ibar)) / sum((V-Vbar)^2)
    n = len(vs)
    vbar = math.fsum(vs) / n
    ibar = math.fsum(cs) / n
    sxx = math.fsum((v - vbar) ** 2 for v in vs)
    sxy = math.fsum((v - vbar) * (c - ibar) for v, c in zip(vs, cs))
    if sxx == 0.0:
        return None
    return sxy / sxx


def _stem(rel):
    name = rel.split('/')[-1]
    return name.rsplit('.', 1)[0]


def _folder(rel):
    parts = rel.split('/')
    return parts[-2] if len(parts) >= 2 else None


def _read_raw(rel, path, skipped):
    # 반환: (유효 행 목록, 머리글을 뺀 비어 있지 않은 데이터 줄 수)
    rows = []
    n_data_lines = 0
    idx = None
    with open(path, 'r', encoding='utf-8-sig', newline='') as f:
        reader = csv.reader(f, delimiter=',')
        for rec in reader:
            line = reader.line_num
            if idx is None:
                header = [h.strip() for h in rec]
                missing = [c for c in REQUIRED_COLS if c not in header]
                if missing:
                    skipped.append({'file': rel, 'line': line,
                                    'reason': '머리글에 필요한 열 없음: ' + ', '.join(missing) + ' (파일 전체를 쓰지 못함)'})
                    return rows, n_data_lines
                idx = {c: header.index(c) for c in REQUIRED_COLS}
                continue
            if len(rec) == 0 or all(x.strip() == '' for x in rec):
                skipped.append({'file': rel, 'line': line, 'reason': '빈 줄'})
                continue
            n_data_lines += 1
            if len(rec) <= max(idx.values()):
                skipped.append({'file': rel, 'line': line, 'reason': '열 개수 부족: ' + str(len(rec)) + '개'})
                continue
            v, err_v = _to_float(rec[idx[V_COL]])
            c, err_c = _to_float(rec[idx[I_COL]])
            pos = rec[idx[POS_COL]].strip()
            reasons = []
            if err_v:
                reasons.append(V_COL + ': ' + err_v)
            if err_c:
                reasons.append(I_COL + ': ' + err_c)
            if pos == '':
                reasons.append(POS_COL + ': 빈 값')
            if reasons:
                skipped.append({'file': rel, 'line': line, 'reason': '; '.join(reasons)})
                continue
            rows.append({'line': line,
                         'sample_id': rec[idx[ID_COL]].strip(),
                         'condition': rec[idx[COND_COL]].strip(),
                         'position': pos,
                         'V': v,
                         'I': c})
    if idx is None:
        skipped.append({'file': rel, 'line': None, 'reason': '빈 파일(머리글 없음)'})
    return rows, n_data_lines


def compute(raw: dict, processed: dict) -> dict:
    skipped = []
    validation = []
    range_flags = []

    sample_to_cond = {}
    for cname, samples in CONDITIONS:
        for s in samples:
            sample_to_cond[s] = cname

    G_ij = {}       # 시료 -> {위치: G (S)}
    R_ij = {}       # 시료 -> {위치: R (Ω)} 참고용(EQ02), 보고에 쓰지 않음
    n_points = {}   # 시료 -> {위치: 사용한 점 수}
    file_of_sample = {}

    # ---- 단계 1~4: raw 읽기, 확인, 위치별 전도도 ----
    for rel in sorted(raw):
        sample = _stem(rel)
        if sample not in sample_to_cond:
            validation.append({'file': rel, 'issue': '설계 시료 목록에 없는 파일 - 계산에 쓰지 않음'})
            continue
        if sample in file_of_sample:
            validation.append({'file': rel, 'issue': '같은 시료의 파일이 또 있음 - 처음 파일(' + file_of_sample[sample] + ')만 사용'})
            continue
        file_of_sample[sample] = rel
        cond = sample_to_cond[sample]
        folder = _folder(rel)
        if folder != cond:
            validation.append({'file': rel, 'issue': '경로의 조건 폴더(' + str(folder) + ')가 설계 조건(' + cond + ')과 다름'})

        rows, n_lines = _read_raw(rel, raw[rel], skipped)
        if n_lines != EXPECTED_ROWS_PER_FILE:
            validation.append({'file': rel, 'issue': '데이터 줄 수 ' + str(n_lines) + ' (기대 ' + str(EXPECTED_ROWS_PER_FILE) + ')'})
        if len(rows) != n_lines:
            validation.append({'file': rel, 'issue': '유효 행 ' + str(len(rows)) + ' / 데이터 줄 ' + str(n_lines) + ' (skipped_rows 참고)'})

        ids = sorted(set(r['sample_id'] for r in rows))
        if rows and ids != [sample]:
            validation.append({'file': rel, 'issue': 'sample_id 열 값 ' + repr(ids) + ' 이 파일 이름(' + sample + ')과 다름'})
        conds = sorted(set(r['condition'] for r in rows))
        bad_conds = [c for c in conds if c not in COND_ALIASES[cond]]
        if bad_conds:
            validation.append({'file': rel, 'issue': 'condition 열 값 ' + repr(bad_conds) + ' 이 설계 조건(' + cond + ')과 다름'})

        by_pos = {}
        for r in rows:
            by_pos.setdefault(r['position'], []).append(r)
            # 단계 2: 장비 범위 확인 - 표시만, 제외하지 않음
            if abs(r['I']) > CURRENT_LIMIT_A:
                range_flags.append({'file': rel, 'line': r['line'], 'sample': sample,
                                    'position': r['position'], 'voltage_V': r['V'], 'current_A': r['I']})
        if len(by_pos) != EXPECTED_POSITIONS:
            validation.append({'file': rel, 'issue': '위치 수 ' + str(len(by_pos)) + ' (기대 ' + str(EXPECTED_POSITIONS) + '): ' + repr(sorted(by_pos))})

        G_ij[sample] = {}
        R_ij[sample] = {}
        n_points[sample] = {}
        for pos in sorted(by_pos):
            pts = by_pos[pos]
            vs = [p['V'] for p in pts]
            cs = [p['I'] for p in pts]
            n_points[sample][pos] = len(pts)
            vs_sorted = sorted(vs)
            grid_ok = (len(vs_sorted) == len(EXPECTED_VOLTAGES) and
                       all(abs(a - b) <= VOLT_TOL for a, b in zip(vs_sorted, EXPECTED_VOLTAGES)))
            if not grid_ok:
                validation.append({'file': rel, 'issue': '위치 ' + pos + ' 전압점이 -0.5~0.5 V 0.1 V 간격 11점과 다름',
                                   'voltages_V': vs_sorted})
            if len(pts) < 2:
                validation.append({'file': rel, 'issue': '위치 ' + pos + ' 유효 점 ' + str(len(pts)) + '개 - 기울기 계산 불가'})
                continue
            # ASSUMPTION: EQ01 의 V_k 는 파일에 적힌 voltage_V 실측 값을 그대로 쓴다(명목 전압으로 바꾸지 않음).
            g = _ls_slope(vs, cs)
            if g is None:
                validation.append({'file': rel, 'issue': '위치 ' + pos + ' 전압 분산이 0 - 기울기 계산 불가'})
                continue
            G_ij[sample][pos] = g
            R_ij[sample][pos] = (1.0 / g) if g != 0.0 else None

    for s in sorted(sample_to_cond):
        if s not in file_of_sample:
            validation.append({'file': None, 'issue': '설계 시료 ' + s + ' 의 raw 파일이 없음'})

    # ---- 단계 5: 시료 전도도 (EQ03), S -> nS ----
    G_i_nS = {}
    for s in sorted(G_ij):
        vals = [G_ij[s][p] for p in sorted(G_ij[s])]
        if not vals:
            validation.append({'file': file_of_sample.get(s), 'issue': '시료 ' + s + ' 에 계산된 위치 전도도가 없음 - 시료 전도도 계산 불가'})
            continue
        if len(vals) != EXPECTED_POSITIONS:
            # ASSUMPTION: 위치가 7개가 아니면 있는 위치만으로 평균하고 기록한다.
            validation.append({'file': file_of_sample.get(s), 'issue': '시료 ' + s + ' 위치 ' + str(len(vals)) + '개로 평균'})
        G_i_nS[s] = _mean(vals) * S_TO_NS

    # ---- 단계 6: 조건별 평균·표본 표준편차 (EQ04, EQ05) ----
    cond_stats = {}
    for cname, samples in CONDITIONS:
        used = [s for s in samples if s in G_i_nS]
        xs = [G_i_nS[s] for s in used]
        n = len(xs)
        m = _mean(xs) if n >= 1 else NAN
        sd = _sd(xs) if n >= 2 else NAN
        cond_stats[cname] = {'n': n, 'mean_nS': m, 'sd_nS': sd, 'samples_used': used, 'values_nS': xs}

    a_name = CONDITIONS[0][0]
    c_name = CONDITIONS[1][0]
    nA = cond_stats[a_name]['n']
    nC = cond_stats[c_name]['n']
    mA = cond_stats[a_name]['mean_nS']
    mC = cond_stats[c_name]['mean_nS']
    sA = cond_stats[a_name]['sd_nS']
    sC = cond_stats[c_name]['sd_nS']

    # ---- 단계 7: 합동 표준편차 (EQ06) ----
    df = nA + nC - 2
    if df > 0:
        sp = math.sqrt(((nA - 1) * sA ** 2 + (nC - 1) * sC ** 2) / df)
    else:
        sp = NAN

    # ---- 단계 8: t 통계량 (EQ07), 양측 p ----
    if nA > 0 and nC > 0 and sp > 0:
        t_stat = (mA - mC) / (sp * math.sqrt(1.0 / nA + 1.0 / nC))
    else:
        t_stat = NAN
    if df > 0 and math.isfinite(t_stat):
        p_value = float(2.0 * stats.t.sf(abs(t_stat), df))
    else:
        p_value = NAN

    scipy_check = None
    if nA >= 2 and nC >= 2:
        tt = stats.ttest_ind(cond_stats[a_name]['values_nS'], cond_stats[c_name]['values_nS'], equal_var=True)
        scipy_check = {'t': float(tt.statistic), 'p_two_sided': float(tt.pvalue)}

    # ---- 단계 9: 증가율 (EQ08) ----
    if mC != 0.0:
        delta_pct = (mA - mC) / mC * 100.0
    else:
        delta_pct = NAN

    # ---- 결과 ----
    results = []

    def add(oid, name, value, unit, cond, kind, eq):
        results.append({'id': oid if cond is None else oid + '__' + cond,
                        'name': name, 'value': float(value), 'unit': unit,
                        'condition': cond, 'kind': kind, 'equation_id': eq})

    for cname, _s in CONDITIONS:
        add('G_mean', '조건별 평균 전도도', cond_stats[cname]['mean_nS'], 'nS', cname, 'value', 'EQ04')
    for cname, _s in CONDITIONS:
        add('G_sd', '조건별 전도도 표본 표준편차', cond_stats[cname]['sd_nS'], 'nS', cname, 'value', 'EQ05')
    for cname, _s in CONDITIONS:
        add('n', '조건별 시료 수', cond_stats[cname]['n'], None, cname, 'n', None)
    add('s_pooled', '합동 표준편차', sp, 'nS', None, 'other', 'EQ06')
    add('t_stat', '독립 2표본 t 통계량', t_stat, None, None, 'test_statistic', 'EQ07')
    add('df', '자유도', df, None, None, 'df', 'EQ07')
    add('p_value', '양측 p값', p_value, None, None, 'p_value', 'EQ07')
    # ASSUMPTION: 증가율 단위는 outputs 에 적힌 대로 '%' 로 둔다.
    add('delta_G_pct', '어닐링에 따른 전도도 증가율', delta_pct, '%', None, 'percent_change', 'EQ08')

    # ---- processed_check: P1 의 G_mean_nS 와 raw 재계산 G_i (nS) ----
    checks = []
    for rel in sorted(processed):
        with open(processed[rel], 'r', encoding='utf-8-sig', newline='') as f:
            reader = csv.reader(f, delimiter=',')
            i_id = None
            i_g = None
            for rec in reader:
                line = reader.line_num
                if i_id is None:
                    header = [h.strip() for h in rec]
                    if ID_COL not in header or PROC_VALUE_COL not in header:
                        break
                    i_id = header.index(ID_COL)
                    i_g = header.index(PROC_VALUE_COL)
                    continue
                if len(rec) <= max(i_id, i_g):
                    continue
                sid = rec[i_id].strip()
                if sid in G_i_nS:
                    checks.append({'file': rel, 'line': line, 'column': PROC_VALUE_COL,
                                   'reported': rec[i_g], 'recomputed': float(G_i_nS[sid])})

    intermediate = {
        'skipped_rows': skipped,
        'validation': validation,
        'current_range_flags': {
            'limit_A': CURRENT_LIMIT_A,
            'count': len(range_flags),
            'rows': range_flags,
            'note': '범위를 벗어난 값은 제외하지 않았다. 재측정 여부는 연구자가 결정·기록해야 한다(단계 2).'
        },
        'files_used': file_of_sample,
        'position_points_used': n_points,
        'G_ij_S': G_ij,
        'R_ij_ohm_reference_only': R_ij,
        'G_i_nS': G_i_nS,
        'condition_stats': cond_stats,
        'df_expected_in_plan': EXPECTED_DF,
        'df_computed': df,
        'alpha': ALPHA,
        'significant_at_alpha': (bool(p_value < ALPHA) if math.isfinite(p_value) else None),
        'scipy_ttest_ind_crosscheck': scipy_check,
        'processed_check': checks,
    }
    return {'results': results, 'intermediate': intermediate}
