# 실험 ↔ 데이터 ↔ 식 ↔ 장비

3 CONFIRM 3-1 에서 확인할 관계 (2-1b 추출 결과, 확인 전).

```mermaid
flowchart LR
  X1["실험: 위치별 I–V 측정 및 위치별 전도도 산출 (시료 20개 × 위치 7개, 전압 −0.5~0.5 V 11점)"] --> D1["데이터: sample_id, condition, position, voltage_V, current_A"]
  I1["장비: 소스 측정 장치 MT-SMU 2400 (가상 장비) · 10 nA"] -. 측정 .-> D1
  D1 --> E1["식: EQ01, EQ02"]
  E1 --> R1["결과: 위치별 전도도 G_ij (S), 참고용 위치별 저항 R_ij"]
  X2["실험: 시료 전도도 산출 (기술적 반복인 위치 7개 평균)"] --> D2["데이터: sample_id, condition, position, G_mean_nS"]
  I2["장비: —"] -. 측정 .-> D2
  D2 --> E2["식: EQ03"]
  E2 --> R2["결과: 시료 전도도 G_i (nS), 처리 데이터 P1의 G_mean_nS 열"]
  X3["실험: 어닐링(A) vs 대조(C) 전도도 비교 (양측 독립 2표본 t 검정, 등분산, α = 0.05)"] --> D3["데이터: sample_id, condition, G_mean_nS"]
  I3["장비: —"] -. 측정 .-> D3
  D3 --> E3["식: EQ04, EQ05, EQ06, EQ07, EQ08"]
  E3 --> R3["결과: 조건별 평균 ± 표준편차 (nS, n = 10), 합동 표준편차, t 통계량(자유도 18)과 양측 p값, …"]
```

```
[1] 실험 「위치별 I–V 측정 및 위치별 전도도 산출 (시료 20개 × 위치 7개, 전압 −0.5~0.5 V 11점)」
     ├─ 장비  소스 측정 장치 MT-SMU 2400 (가상 장비) · 10 nA
     ├─ 데이터 sample_id, condition, position, voltage_V, current_A
     ├─ 식    EQ01, EQ02
     └─ 결과  위치별 전도도 G_ij (S), 참고용 위치별 저항 R_ij
[2] 실험 「시료 전도도 산출 (기술적 반복인 위치 7개 평균)」
     ├─ 장비  —
     ├─ 데이터 sample_id, condition, position, G_mean_nS
     ├─ 식    EQ03
     └─ 결과  시료 전도도 G_i (nS), 처리 데이터 P1의 G_mean_nS 열
[3] 실험 「어닐링(A) vs 대조(C) 전도도 비교 (양측 독립 2표본 t 검정, 등분산, α = 0.05)」
     ├─ 장비  —
     ├─ 데이터 sample_id, condition, G_mean_nS
     ├─ 식    EQ04, EQ05, EQ06, EQ07, EQ08
     └─ 결과  조건별 평균 ± 표준편차 (nS, n = 10), 합동 표준편차, t 통계량(자유도 18)과 양측 p값, 전도도 증가율 ΔG (%)
```
