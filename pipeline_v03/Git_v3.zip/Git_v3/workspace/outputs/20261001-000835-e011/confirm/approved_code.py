"""MeasureTrace 과업 2-1c: raw I-V 데이터에서 보고값을 다시 계산한다.

계획서 순서
  1단계 raw 검증(77행, 전압 격자, 시료 번호, condition)
  2단계 전류 범위(10 nA) 확인. 표시만 하고 제외하지 않는다.
  3단계 EQ01 위치별 기울기 G_ij (S)
  4단계 EQ02 참고용 R_ij = 1/G_ij (Ohm). 보고에는 쓰지 않는다.
  5단계 EQ03 시료 평균 G_i (S -> nS)
  6단계 EQ04, EQ05 조건별 평균과 표본 표준편차 (nS)
  7단계 EQ06, EQ07 합동 표준편차, t, 자유도, 양측 p
  8단계 EQ08 증가율 (%)
processed 는 processed_check 에만 쓴다.
"""
import csv
import math

from scipy import stats

DESIGN_CONDITIONS = [
    ("annealed", ["S01", "S02", "S03", "S04", "S05", "S06", "S07", "S08", "S09", "S10"]),
    ("control", ["S11", "S12", "S13", "S14", "S15", "S16", "S17", "S18", "S19", "S20"]),
]
# ASSUMPTION: condition 열 값과 폴더 이름은 annealed/A, control/C (대소문자 무시) 중 하나로 본다.
# ASSUMPTION: 조건 배정은 계획서 설계의 시료 목록을 기준으로 하고, condition 열과 폴더가 다르면 기록만 한다.
CONDITION_ALIASES = {"annealed": "annealed", "a": "annealed", "control": "control", "c": "control"}
REQUIRED_COLUMNS = ["sample_id", "condition", "position", "voltage_V", "current_A"]
ROWS_PER_FILE = 77
POSITIONS_PER_SAMPLE = 7
POINTS_PER_POSITION = 11
EXPECTED_VOLTAGES = [-0.5 + 0.1 * k for k in range(11)]
# ASSUMPTION: 전압 격자(-0.5~0.5 V, 0.1 V 간격) 비교 허용 오차는 1e-6 V 로 둔다.
VOLTAGE_TOL_V = 1e-6
# ASSUMPTION: '10 nA 전류 범위'는 |I| <= 10 nA 로 해석하고, 넘는 값은 표시만 한다(제외하지 않음).
CURRENT_RANGE_A = 10e-9
S_TO_NS = 1e9
ALPHA = 0.05
PLANNED_DF = 18


def _to_float(text):
    if text is None:
        return None, "값 없음(열 개수 부족)"
    s = text.strip()
    if s == "":
        return None, "빈 값"
    try:
        x = float(s)
    except ValueError:
        return None, "숫자로 바꿀 수 없음: " + repr(s)
    if not math.isfinite(x):
        return None, "유한한 수가 아님: " + repr(s)
    return x, None


def _slope(points):
    # EQ01: 절편 포함 최소제곱 직선의 기울기
    n = len(points)
    if n < 2:
        return None
    v_bar = math.fsum(v for v, _ in points) / n
    i_bar = math.fsum(i for _, i in points) / n
    sxx = math.fsum((v - v_bar) ** 2 for v, _ in points)
    if sxx == 0.0:
        return None
    sxy = math.fsum((v - v_bar) * (i - i_bar) for v, i in points)
    return sxy / sxx


def _mean(xs):
    # EQ04 (EQ03 도 같은 산술평균)
    if not xs:
        return None
    return math.fsum(xs) / len(xs)


def _sd(xs):
    # EQ05: 표본 표준편차(분모 n - 1)
    n = len(xs)
    if n < 2:
        return None
    m = math.fsum(xs) / n
    return math.sqrt(math.fsum((x - m) ** 2 for x in xs) / (n - 1))


def _alias(value):
    if value is None:
        return None
    return CONDITION_ALIASES.get(value.strip().lower())


def _result(rid, name, value, unit, condition, kind, eq):
    # ASSUMPTION: 계산할 수 없는 값은 value 를 None 으로 두고 intermediate 의 validation_issues 에 이유를 남긴다.
    return {
        "id": rid,
        "name": name,
        "value": None if value is None else float(value),
        "unit": unit,
        "condition": condition,
        "kind": kind,
        "equation_id": eq,
    }


def _read_raw(raw, skipped, issues, out_of_range):
    data = {}
    file_info = {}
    for rel in sorted(raw):
        path = raw[rel]
        parts = rel.split("/")
        fname = parts[-1]
        stem = fname[:-4] if fname.lower().endswith(".csv") else fname
        folder = parts[-2] if len(parts) >= 2 else None
        n_rows = 0
        sids_in_file = set()
        with open(path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh, delimiter=",")
            fields = reader.fieldnames or []
            missing = [c for c in REQUIRED_COLUMNS if c not in fields]
            if missing:
                issues.append({"file": rel, "issue": "필수 열 없음", "detail": missing})
                skipped.append({"file": rel, "line": 1, "reason": "필수 열 없음(" + ", ".join(missing) + ") - 파일 전체를 읽지 못함"})
                file_info[rel] = {"rows": None, "sample_ids": [], "folder": folder}
                continue
            for row in reader:
                line = reader.line_num
                n_rows += 1
                sid = (row.get("sample_id") or "").strip()
                pos = (row.get("position") or "").strip()
                cond = (row.get("condition") or "").strip()
                if sid == "":
                    skipped.append({"file": rel, "line": line, "reason": "sample_id 비어 있음"})
                    continue
                if pos == "":
                    skipped.append({"file": rel, "line": line, "reason": "position 비어 있음"})
                    continue
                v, err = _to_float(row.get("voltage_V"))
                if err is not None:
                    skipped.append({"file": rel, "line": line, "reason": "voltage_V " + err})
                    continue
                cur, err = _to_float(row.get("current_A"))
                if err is not None:
                    skipped.append({"file": rel, "line": line, "reason": "current_A " + err})
                    continue
                # 2단계: 범위 초과 표시만 한다. 제외하지 않는다.
                if abs(cur) > CURRENT_RANGE_A:
                    out_of_range.append({
                        "file": rel,
                        "line": line,
                        "sample_id": sid,
                        "position": pos,
                        "voltage_V": v,
                        "current_A": cur,
                        "note": "10 nA 범위 초과 - 계산에는 포함함. 재측정 여부는 연구자 결정 필요",
                    })
                sids_in_file.add(sid)
                entry = data.setdefault(sid, {"files": [], "folders": [], "condition_values": [], "positions": {}})
                if rel not in entry["files"]:
                    entry["files"].append(rel)
                    entry["folders"].append(folder)
                if cond not in entry["condition_values"]:
                    entry["condition_values"].append(cond)
                entry["positions"].setdefault(pos, []).append((v, cur))
        file_info[rel] = {"rows": n_rows, "sample_ids": sorted(sids_in_file), "folder": folder}
        if n_rows != ROWS_PER_FILE:
            issues.append({"file": rel, "issue": "데이터 행 수가 77이 아님", "detail": n_rows})
        if sorted(sids_in_file) != [stem]:
            issues.append({"file": rel, "issue": "파일 이름과 sample_id 열이 다름", "detail": sorted(sids_in_file)})
    return data, file_info


def _processed_check(processed, g_i_nS):
    out = []
    for rel in sorted(processed):
        path = processed[rel]
        with open(path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh, delimiter=",")
            fields = reader.fieldnames or []
            if "sample_id" not in fields or "G_mean_nS" not in fields:
                continue
            for row in reader:
                line = reader.line_num
                sid = (row.get("sample_id") or "").strip()
                reported = row.get("G_mean_nS")
                if reported is None:
                    continue
                rec = g_i_nS.get(sid)
                if rec is None:
                    continue
                out.append({
                    "file": rel,
                    "line": line,
                    "column": "G_mean_nS",
                    "reported": reported,
                    "recomputed": float(rec),
                })
    return out


def compute(raw: dict, processed: dict) -> dict:
    skipped = []
    issues = []
    out_of_range = []

    sample_to_design = {}
    for cname, samples in DESIGN_CONDITIONS:
        for s in samples:
            sample_to_design[s] = cname

    # 1단계, 2단계
    data, file_info = _read_raw(raw, skipped, issues, out_of_range)

    for s in sample_to_design:
        if s not in data:
            issues.append({"sample_id": s, "issue": "설계에 있는 시료의 raw 데이터가 없음"})

    per_sample = {}
    g_ij = {}
    g_i_S = {}
    g_i_nS = {}
    for sid in sorted(data):
        entry = data[sid]
        design_cond = sample_to_design.get(sid)
        col_conds = sorted(set(str(_alias(c)) for c in entry["condition_values"]))
        folder_conds = sorted(set(str(_alias(f)) for f in entry["folders"]))
        if design_cond is None:
            issues.append({"sample_id": sid, "issue": "설계 시료 목록에 없는 시료 - 조건 통계에 넣지 않음"})
        else:
            if col_conds != [design_cond]:
                issues.append({"sample_id": sid, "issue": "condition 열 값이 설계 조건과 다름", "detail": entry["condition_values"]})
            if folder_conds != [design_cond]:
                issues.append({"sample_id": sid, "issue": "폴더 이름이 설계 조건과 다름", "detail": entry["folders"]})
        if len(entry["files"]) > 1:
            issues.append({"sample_id": sid, "issue": "한 시료가 여러 파일에 나옴", "detail": entry["files"]})

        positions = entry["positions"]
        if len(positions) != POSITIONS_PER_SAMPLE:
            issues.append({"sample_id": sid, "issue": "위치 수가 7이 아님", "detail": sorted(positions)})

        # 3단계 EQ01, 4단계 EQ02
        g_ij[sid] = {}
        for pos in sorted(positions):
            pts = positions[pos]
            volts = sorted(v for v, _ in pts)
            grid_ok = len(volts) == POINTS_PER_POSITION and all(
                abs(a - b) <= VOLTAGE_TOL_V for a, b in zip(volts, EXPECTED_VOLTAGES)
            )
            if not grid_ok:
                issues.append({"sample_id": sid, "position": pos, "issue": "전압 점이 -0.5~0.5 V, 0.1 V 간격 11점과 다름", "detail": volts})
            g = _slope(pts)
            if g is None:
                issues.append({"sample_id": sid, "position": pos, "issue": "기울기 계산 불가(점 부족 또는 전압 분산 0)"})
            r = (1.0 / g) if (g is not None and g != 0.0) else None
            g_ij[sid][pos] = {"G_S": g, "R_ohm_reference_only": r, "n_points": len(pts), "voltage_grid_ok": grid_ok}

        # 5단계 EQ03 (S -> nS)
        vals = [x["G_S"] for x in g_ij[sid].values() if x["G_S"] is not None]
        if len(vals) != POSITIONS_PER_SAMPLE:
            # ASSUMPTION: 기울기를 구한 위치가 7개보다 적으면 있는 위치만 평균하고 기록한다.
            issues.append({"sample_id": sid, "issue": "평균에 쓴 위치 수가 7이 아님", "detail": len(vals)})
        gs = _mean(vals)
        g_i_S[sid] = gs
        g_i_nS[sid] = None if gs is None else gs * S_TO_NS
        per_sample[sid] = {
            "design_condition": design_cond,
            "condition_column_values": entry["condition_values"],
            "files": entry["files"],
            "n_positions_used": len(vals),
            "G_i_S": gs,
            "G_i_nS": g_i_nS[sid],
        }

    # 6단계 EQ04, EQ05
    cond_values = {}
    cond_samples = {}
    for cname, samples in DESIGN_CONDITIONS:
        xs = []
        used = {}
        for s in samples:
            val = g_i_nS.get(s)
            if val is None:
                issues.append({"sample_id": s, "condition": cname, "issue": "시료 전도도 없음 - 조건 통계에서 빠짐"})
                continue
            xs.append(val)
            used[s] = val
        cond_values[cname] = xs
        cond_samples[cname] = used

    stats_by_cond = {}
    for cname, _ in DESIGN_CONDITIONS:
        xs = cond_values[cname]
        stats_by_cond[cname] = {"n": len(xs), "mean_nS": _mean(xs), "sd_nS": _sd(xs)}

    a = stats_by_cond["annealed"]
    c = stats_by_cond["control"]
    n_a = a["n"]
    n_c = c["n"]

    # 7단계 EQ06, EQ07
    s_p = None
    t_val = None
    df = None
    p_val = None
    if n_a + n_c - 2 > 0:
        df = n_a + n_c - 2
    if a["sd_nS"] is not None and c["sd_nS"] is not None and df is not None:
        s_p = math.sqrt(((n_a - 1) * a["sd_nS"] ** 2 + (n_c - 1) * c["sd_nS"] ** 2) / df)
        if s_p > 0.0:
            t_val = (a["mean_nS"] - c["mean_nS"]) / (s_p * math.sqrt(1.0 / n_a + 1.0 / n_c))
            # 양측 p값
            p_val = float(2.0 * stats.t.sf(abs(t_val), df))
        else:
            issues.append({"issue": "합동 표준편차가 0 - t 계산 불가"})
    else:
        issues.append({"issue": "조건별 시료가 2개 미만 - 표준편차, t 계산 불가"})
    if df is not None and df != PLANNED_DF:
        issues.append({"issue": "자유도가 계획서의 18과 다름", "detail": df})

    scipy_check = None
    if n_a >= 2 and n_c >= 2:
        res = stats.ttest_ind(cond_values["annealed"], cond_values["control"], equal_var=True)
        scipy_check = {"t": float(res.statistic), "p_two_sided": float(res.pvalue)}

    # 차이, 8단계 EQ08
    g_diff = None
    g_inc = None
    if a["mean_nS"] is not None and c["mean_nS"] is not None:
        g_diff = a["mean_nS"] - c["mean_nS"]
        if c["mean_nS"] != 0.0:
            g_inc = (a["mean_nS"] - c["mean_nS"]) / c["mean_nS"] * 100.0
        else:
            issues.append({"issue": "대조 평균이 0 - 증가율 계산 불가"})

    results = []
    for cname, _ in DESIGN_CONDITIONS:
        st = stats_by_cond[cname]
        results.append(_result("G_mean__" + cname, "조건별 평균 전도도", st["mean_nS"], "nS", cname, "value", "EQ04"))
    for cname, _ in DESIGN_CONDITIONS:
        st = stats_by_cond[cname]
        results.append(_result("G_sd__" + cname, "조건별 전도도 표본 표준편차", st["sd_nS"], "nS", cname, "value", "EQ05"))
    for cname, _ in DESIGN_CONDITIONS:
        st = stats_by_cond[cname]
        results.append(_result("n_samples__" + cname, "조건별 시료 수", st["n"], None, cname, "n", None))
    results.append(_result("G_diff", "조건 간 평균 전도도 차이(A - C)", g_diff, "nS", None, "difference", None))
    results.append(_result("s_pooled", "합동 표준편차", s_p, "nS", None, "other", "EQ06"))
    results.append(_result("t_stat", "t 검정 통계량", t_val, None, None, "test_statistic", "EQ07"))
    results.append(_result("df", "자유도", df, None, None, "df", "EQ07"))
    results.append(_result("p_value", "양측 p값", p_val, None, None, "p_value", "EQ07"))
    # ASSUMPTION: 증가율 단위는 보고값 목록 표기대로 '%' 로 둔다(값은 x100 된 백분율).
    results.append(_result("G_increase_pct", "어닐링에 따른 전도도 증가율", g_inc, "%", None, "percent_change", "EQ08"))

    intermediate = {
        "file_info": file_info,
        "G_ij_by_sample_position": g_ij,
        "per_sample": per_sample,
        "G_i_nS_by_condition": cond_samples,
        "stats_by_condition": stats_by_cond,
        "t_test": {
            "method": "독립 2표본 t 검정, 등분산, 양측",
            "alpha": ALPHA,
            "planned_df": PLANNED_DF,
            "df": df,
            "t": t_val,
            "p_two_sided": p_val,
            "significant_at_alpha": None if p_val is None else bool(p_val < ALPHA),
            "scipy_ttest_ind_crosscheck": scipy_check,
        },
        "current_out_of_range": out_of_range,
        "current_out_of_range_count": len(out_of_range),
        "validation_issues": issues,
        "skipped_rows": skipped,
        "processed_check": _processed_check(processed, g_i_nS),
    }
    return {"results": results, "intermediate": intermediate}
