"""1-2 지문·시각 — 해시 2종(원본 바이트 + 내용 정규화)과 표의 행별 해시, 이전 실행과의 차이, 측정 시각 2종.

정규화 규칙(버전 norm-1):
  표   글자 인코딩·BOM·줄바꿈(CRLF/LF)·칸 앞뒤 공백·빈 줄·구분자 차이를 무시하고 칸 값만 비교
  Word 글 문단 + 수식(LaTeX)          PDF 쪽마다 글자          글 파일 줄 끝 공백·빈 줄 제거
원본 해시만 다르고 내용 해시가 같으면 '형식만 변경'.
"""
from __future__ import annotations

import re
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

from mtagent import readers
from mtagent.util import sha_file, sha_text

NORM_VERSION = "norm-1"
TEXT_EXT = {".txt", ".md", ".r", ".py", ".m", ".jl", ".sh", ".json", ".yaml", ".yml", ".csv", ".tsv", ".dat"}
_SEP = "\x1f"


def fingerprint(path: Path, open_content: bool = True) -> dict:
    """{sha256, content_hash, kind, ...}. open_content=False 면 내용을 열지 않는다(보고서 — 블라인드)."""
    path = Path(path)
    fp = {"sha256": sha_file(path), "size": path.stat().st_size}
    if not open_content:
        return {**fp, "content_hash": fp["sha256"], "kind": "bytes (열지 않음)"}
    ext = path.suffix.lower()
    try:
        table = readers.read_table(path) if ext in readers.TABLE_EXT else None
        if table:
            header = _SEP.join(table["columns"])
            rows = [sha_text(_SEP.join(r))[:16] for r in table["rows"]]
            return {**fp, "kind": "table", "content_hash": sha_text(header + "\n" + "\n".join(rows)),
                    "columns": table["columns"], "n_rows": len(rows), "row_hashes": rows, "row_lines": table["lines"],
                    "encoding": table["encoding"], "delimiter": table["delimiter"]}
        if ext == ".docx":
            d = readers.read_docx(path)
            body = d["text"] + "\n" + "\n".join(e["latex"] for e in d["equations"])
            return {**fp, "kind": "docx", "content_hash": sha_text(body), "paragraphs": len(d["paragraphs"]),
                    "equations": len(d["equations"])}
        if ext == ".pdf":
            pages = readers.read_pdf_pages(path)
            return {**fp, "kind": "pdf", "content_hash": sha_text("\f".join(readers.normalize_space(p) for p in pages)),
                    "pages": len(pages)}
        if ext in TEXT_EXT:
            lines = [ln.rstrip() for ln in readers.read_text(path).splitlines() if ln.strip()]
            return {**fp, "kind": "text", "content_hash": sha_text("\n".join(lines)), "lines": len(lines)}
    except Exception as e:   # 읽지 못한 파일은 바이트 해시만
        return {**fp, "kind": "bytes", "content_hash": fp["sha256"], "read_error": f"{type(e).__name__}: {e}"}
    return {**fp, "kind": "bytes", "content_hash": fp["sha256"]}


def table_diff(old: dict, new: dict, max_spans: int = 20) -> dict:
    """행·열 차이 — 바뀜·추가·빠짐과 원본 줄 번호."""
    oc, nc = old.get("columns") or [], new.get("columns") or []
    out = {"columns_added": [c for c in nc if c not in oc], "columns_removed": [c for c in oc if c not in nc],
           "columns_reordered": [c for c in nc if c in oc] != [c for c in oc if c in nc],
           "rows_before": old.get("n_rows", 0), "rows_after": new.get("n_rows", 0),
           "changed": 0, "added": 0, "removed": 0, "spans": []}
    a, b = old.get("row_hashes") or [], new.get("row_hashes") or []
    la, lb = old.get("row_lines") or [], new.get("row_lines") or []

    def span(kind, lines, which):
        if lines and len(out["spans"]) < max_spans:
            where = f"{lines[0]}" if len(lines) == 1 else f"{lines[0]}–{lines[-1]}"
            out["spans"].append({"kind": kind, "where": f"{which} {where}줄"})

    for op, i1, i2, j1, j2 in SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == "replace":
            k = min(i2 - i1, j2 - j1)
            out["changed"] += k
            span("바뀜", lb[j1:j1 + k], "새 파일")
            if i2 - i1 > k:
                out["removed"] += i2 - i1 - k
                span("빠짐", la[i1 + k:i2], "옛 파일")
            if j2 - j1 > k:
                out["added"] += j2 - j1 - k
                span("추가", lb[j1 + k:j2], "새 파일")
        elif op == "delete":
            out["removed"] += i2 - i1
            span("빠짐", la[i1:i2], "옛 파일")
        elif op == "insert":
            out["added"] += j2 - j1
            span("추가", lb[j1:j2], "새 파일")
    return out


def compare_sets(old: dict[str, dict], new: dict[str, dict]) -> list[dict]:
    """경로 → 지문 두 묶음의 차이: 추가 · 삭제 · 형식만 변경 · 내용 변경(표는 행·열 차이)."""
    changes = []
    for key in sorted(set(old) | set(new)):
        o, n = old.get(key), new.get(key)
        if o is None:
            changes.append({"file": key, "kind": "추가", "detail": "이전 실행에 없던 파일"})
        elif n is None:
            changes.append({"file": key, "kind": "삭제", "detail": "이번 실행에 없음"})
        elif o["sha256"] == n["sha256"]:
            continue
        elif o["content_hash"] == n["content_hash"]:
            changes.append({"file": key, "kind": "형식만 변경", "detail": "원본 바이트는 다르지만 정규화한 내용은 같음"})
        elif o.get("kind") == n.get("kind") == "table":
            d = table_diff(o, n)
            parts = [f"행 바뀜 {d['changed']} · 추가 {d['added']} · 빠짐 {d['removed']} (행 수 {d['rows_before']} → {d['rows_after']})"]
            if d["columns_added"] or d["columns_removed"]:
                parts.append(f"열 추가 {d['columns_added']} · 열 삭제 {d['columns_removed']}")
            elif d["columns_reordered"]:
                parts.append("열 순서 바뀜")
            changes.append({"file": key, "kind": "내용 변경", "detail": " · ".join(parts), "table": d})
        else:
            changes.append({"file": key, "kind": "내용 변경", "detail": "정규화한 내용이 다름"})
    return changes


# ── 1-2-2 측정 시각 — 두 종류를 모으고, 장비가 적은 시각을 우선한다 ──────────
#   (1) 파일 수정 시각   복사·편집만 해도 바뀌므로 보조 — 원본 시각을 받은 사본만 측정 시각 후보
#   (2) 장비 기록 시각   표의 머리 주석 · 시각 열 · 메모의 날짜 표기
_DT = re.compile(r"(\d{4})[-./](\d{1,2})[-./](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?")
_TIME_COL = re.compile(r"time|date|timestamp|datetime|측정\s*(시각|일시|시간|날짜)|일시|시각", re.I)


def _norm_dt(m: re.Match) -> str:
    y, mo, d, h, mi, s = m.groups()
    out = f"{int(y):04d}-{int(mo):02d}-{int(d):02d}"
    if h is not None:
        out += f" {int(h):02d}:{mi}" + (f":{s}" if s else "")
    return out


def file_mtime(path: Path, origin: str = "upload") -> dict:
    """파일 수정 시각. origin='original' 이면 원본 시각을 옮긴 사본, 'upload' 면 업로드한 때(원본 시각 아님)."""
    ts = datetime.fromtimestamp(Path(path).stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
    note = ("원본 파일 수정 시각 — 복사·편집만 해도 바뀔 수 있음" if origin == "original"
            else "업로드 시각 — 원본 파일 수정 시각을 받지 못함(측정 시각으로 쓰지 않음)")
    return {"value": ts, "origin": origin, "note": note}


def measured_at(device: dict | None, mtime: dict | None) -> dict | None:
    """측정 시각 결정 — 장비 기록이 있으면 그것, 없으면 원본 파일 수정 시각, 둘 다 없으면 None."""
    if device:
        out = {**device, "basis": "device", "status": "장비 기록 시각 (우선) · 잠정 — 3 CONFIRM 에서 확정"}
        # 원본 파일은 마지막 측정이 기록된 뒤에 저장된다 — 그보다 이르면 시각이 어긋남
        if mtime and mtime["origin"] == "original" and mtime["value"][:len(device["last"])] < device["last"]:
            out["conflict"] = f"파일 수정 시각 {mtime['value']} 이 마지막 장비 기록 {device['last']} 보다 이름 — 확인 필요"
        return out
    if mtime and mtime["origin"] == "original":
        return {"first": mtime["value"], "last": mtime["value"], "count": 1, "sources": ["파일 수정 시각"],
                "basis": "file_mtime", "status": "장비 기록 없음 → 파일 수정 시각(복사로 바뀔 수 있음) · 잠정"}
    return None


def measurement_times(path: Path, open_content: bool = True) -> dict | None:
    """장비 기록 시각 — 표의 머리 주석(# measured: ...) · 시각 열 · 글 파일의 날짜 표기에서 찾는다. 못 찾으면 None."""
    if not open_content:
        return None
    path = Path(path)
    found, sources = [], []
    table = readers.read_table(path) if path.suffix.lower() in readers.TABLE_EXT else None
    if table:
        for c in table["comments"]:
            for m in _DT.finditer(c):
                found.append(_norm_dt(m))
                sources.append("머리 주석")
        for ci, col in enumerate(table["columns"]):
            if _TIME_COL.search(col):
                for r in table["rows"]:
                    m = _DT.search(r[ci]) if ci < len(r) else None
                    if m:
                        found.append(_norm_dt(m))
                if found:
                    sources.append(f"열 '{col}'")
    elif path.suffix.lower() in (".txt", ".md"):
        for m in _DT.finditer(readers.read_text(path)):
            found.append(_norm_dt(m))
            sources.append("본문 날짜 표기")
    if not found:
        return None
    return {"first": min(found), "last": max(found), "count": len(found), "sources": sorted(set(sources))}
