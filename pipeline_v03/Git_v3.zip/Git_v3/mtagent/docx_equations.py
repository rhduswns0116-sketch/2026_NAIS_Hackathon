"""Word 문서(.docx) 안의 수식(OMML, m:oMath)을 모두 찾아 LaTeX 문자열로 바꾼다. [PYTHON — LLM 없음]

목적
  연구 계획서의 수식을 글자로 대충 읽지 않고 수식 XML 구조 그대로 변환해, 나중에 LLM 입력으로 쓴다.
  변환기는 dwml 0.3 의 dwml.omml.oMath2Latex. 결과는 고치거나 다듬지 않고 변환기가 낸 그대로 저장한다.
  docx 는 python-docx 없이 zip 으로 열어 word/document.xml 을 lxml 로 읽는다.

  extract(path, plan_sha256) → {plan_sha256, converter, equations[], failed[], plan_text}
    equations[] : {id(EQ01…), sentence, omml_sha256, plan_sha256, latex, status("ok"|"failed"), error(실패 때만)}
    plan_text   : 문단마다 한 줄 — 수식 자리는 "[EQ01] $ LaTeX $", 변환 실패는 "[EQ01] (변환 실패 — 원문 확인 필요)"

알려진 함정 (dwml 0.3 에서 확인)
  1. dwml.omml.load() 는 문서 최상위의 m:oMath 만 찾는다(findall). 문단(w:p) 안의 수식은 여기서 직접 찾아
     요소를 oMath2Latex 에 넘긴다. m:oMathPara 로 감싼 표시 수식도 같은 방식으로 잡힌다.
  2. 속성 요소(분수의 m:fPr, 윗줄의 m:barPr, 괄호의 m:dPr, 악센트의 m:accPr …)가 빠지면 dwml 이 KeyError 로 멈춘다.
     m:r 에 m:t 가 없으면 TypeError. Word 가 저장한 파일엔 보통 있지만 다른 프로그램이 만든 파일엔 빠질 수 있다.
     → 수식마다 예외를 따로 잡아 그 수식만 status="failed" 로 남기고 다음 수식을 계속한다(파일 전체를 실패로 만들지 않음).
       실패한 수식은 사람에게 "이 식을 직접 적어 주세요"라고 물을 후보다.
  3. dwml 을 import 하지 못하면 모듈은 멈추지 않고 모든 수식을 failed(error="dwml 미설치 — pip install dwml"),
     converter=None 으로 남긴다.
  4. 적분: OMML 은 m:naryPr 에 m:chr 가 없으면 기호가 ∫ 라는 뜻(표준 기본값)인데, dwml 은 m:chr 가 없으면 TypeError 로 멈춘다.
     → 변환기에 넘기는 사본에만 표준 기본값(m:chr=∫)을 채우고 filled_defaults 에 기록한다. 해시는 원본으로 계산한다.
  5. Word 의 호환 감싸개(mc:AlternateContent)는 같은 내용을 mc:Choice 와 mc:Fallback 에 두 번 담는다
     → mc:Fallback 안의 문단·수식은 건너뛴다(같은 수식을 두 번 세지 않음).
  6. 문단(w:p) 밖(w:body 바로 아래)에 놓인 수식도 빠뜨리지 않고 한 줄로 처리한다(Word 는 보통 문단 안에 둔다).
문단 글자는 w:t 를 이어 붙이되 탭(w:tab)·줄바꿈(w:br, w:cr)은 공백 하나로 둔다(낱말이 붙지 않게).
"""
from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path

from lxml import etree

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
MC_NS = "http://schemas.openxmlformats.org/markup-compatibility/2006"
W_P, W_T = f"{{{W_NS}}}p", f"{{{W_NS}}}t"
W_SPACES = {f"{{{W_NS}}}tab", f"{{{W_NS}}}br", f"{{{W_NS}}}cr"}
M_OMATH, M_NARY_PR, M_CHR = f"{{{M_NS}}}oMath", f"{{{M_NS}}}naryPr", f"{{{M_NS}}}chr"
MC_FALLBACK = f"{{{MC_NS}}}Fallback"
CONVERTER = "dwml.omml.oMath2Latex"
NOT_INSTALLED = "dwml 미설치 — pip install dwml"
FAILED_MARK = "(변환 실패 — 원문 확인 필요)"


def _converter():
    """dwml 의 oMath2Latex — 없으면 None (부를 때마다 확인해, 미설치여도 모듈 import 는 된다)."""
    try:
        from dwml.omml import oMath2Latex
    except ImportError:
        return None
    return oMath2Latex


def _read_document(path: Path) -> etree._Element:
    with zipfile.ZipFile(path) as z:
        data = z.read("word/document.xml")
    parser = etree.XMLParser(resolve_entities=False, no_network=True, remove_comments=True)
    return etree.fromstring(data, parser)


def _has_ancestor(el, tag: str) -> bool:
    p = el.getparent()
    while p is not None:
        if p.tag == tag:
            return True
        p = p.getparent()
    return False


def _inside_math(el) -> bool:
    """조상 중에 m:oMath 가 있는가."""
    return _has_ancestor(el, M_OMATH)


def _skipped(el) -> bool:
    """수식 안이거나 호환 감싸개의 대체본(mc:Fallback) 안 — 건너뛴다."""
    return _inside_math(el) or _has_ancestor(el, MC_FALLBACK)


def _owner_paragraph(el):
    """이 요소가 속한 가장 가까운 w:p (글상자 안 문단이 바깥 문단 글자에 섞이지 않게)."""
    p = el.getparent()
    while p is not None and p.tag != W_P:
        p = p.getparent()
    return p


def _paragraph_text(p) -> str:
    """본문 글자(w:t)만 — 수식 안 글자(m:t)와 안쪽 문단의 글자는 넣지 않는다. 탭·줄바꿈은 공백."""
    parts = []
    for el in p.iter(W_T, *W_SPACES):
        if _owner_paragraph(el) is p and not _skipped(el):
            parts.append(el.text or "" if el.tag == W_T else " ")
    return "".join(parts)


def _outer_maths(p) -> list:
    """이 문단의 가장 바깥 수식들 (수식 안에 중첩된 m:oMath 는 뺀다)."""
    return [m for m in p.iter(M_OMATH) if _owner_paragraph(m) is p and not _skipped(m)]


def _with_defaults(math) -> tuple[object, list[str]]:
    """변환기에 넘길 사본 — OMML 표준 기본값 중 dwml 이 모르는 것을 채운다(원본은 그대로)."""
    filled = []
    copy = None
    for pr in math.iter(M_NARY_PR):
        if pr.find(M_CHR) is None:
            filled.append("m:naryPr/m:chr=∫ (표준 기본값 — 적분)")
    if filled:
        copy = etree.fromstring(etree.tostring(math))
        for pr in copy.iter(M_NARY_PR):
            if pr.find(M_CHR) is None:
                pr.insert(0, etree.Element(M_CHR, {f"{{{M_NS}}}val": "∫"}))
    return (copy if copy is not None else math), filled


def _units(root):
    """(문단 또는 None, 수식 목록) 을 문서 순서대로 — 문단 밖(w:body 바로 아래) 수식도 한 줄씩."""
    for el in root.iter(W_P, M_OMATH):
        if _skipped(el):
            continue
        if el.tag == W_P:
            yield el, _outer_maths(el)
        elif _owner_paragraph(el) is None:
            yield None, [el]


def _omml_sha256(math) -> str:
    return hashlib.sha256(etree.tostring(math, method="c14n")).hexdigest()


def extract(path: str | Path, plan_sha256: str) -> dict:
    """docx 의 수식을 모두 LaTeX 로. 수식 하나가 실패해도 나머지는 계속 처리한다."""
    convert = _converter()
    root = _read_document(Path(path))
    equations, lines = [], []
    last_sentence = None
    for p, maths in _units(root):
        text = _paragraph_text(p).strip() if p is not None else ""
        if text:
            last_sentence = text
        marks = []
        for math in maths:
            eq = {"id": f"EQ{len(equations) + 1:02d}",
                  "sentence": text or last_sentence,      # 수식만 있는 문단은 앞 문단의 문장
                  "omml_sha256": _omml_sha256(math), "plan_sha256": plan_sha256}
            if convert is None:
                eq.update(latex=None, status="failed", error=NOT_INSTALLED)
            else:
                source, filled = _with_defaults(math)
                if filled:
                    eq["filled_defaults"] = filled
                try:
                    eq.update(latex=str(convert(source).latex).strip(), status="ok")
                except Exception as e:  # dwml 은 속성 요소가 빠지면 KeyError 등 — 이 수식만 실패로
                    eq.update(latex=None, status="failed", error=f"{type(e).__name__}: {e}")
            equations.append(eq)
            marks.append(f"[{eq['id']}] $ {eq['latex']} $" if eq["status"] == "ok" else f"[{eq['id']}] {FAILED_MARK}")
        if text or marks:
            lines.append(" ".join(x for x in [text, *marks] if x))
    return {"plan_sha256": plan_sha256, "converter": CONVERTER if convert else None, "equations": equations,
            "failed": [e["id"] for e in equations if e["status"] != "ok"], "plan_text": "\n".join(lines)}
