"""4 RECOMPUTE — 확정된 식·가공 순서(3 CONFIRM)를 구현한 승인 코드로 RAW(·PROCESSED)에서 다시 계산하고 계산 로그를 남긴다.

4-1 수치 재계산  실행 전 확인: 승인 코드 해시 = 확정 해시 · 추출 결과가 확정 때와 같음 · 데이터 사본 해시 = 1 INGEST 해시 · 정적 점검.
                 하나라도 어긋나면 실행하지 않고 이유를 남긴다. 실행은 격리 프로세스에서 한 번(입력은 RAW·PROCESSED, 보고서 미개봉).
                 승인 코드는 compute(raw, processed) — RAW 와 PROCESSED 를 따로 받는다.
                 PROCESSED 독립성 — PROCESSED 를 비우고 한 번 더 돌려, 값이 바뀌거나 사라지는 결과는 RAW 로 독립 재현되지
                 않은 것(depends_on_processed)으로 표시한다. 5 VALIDATE 에서 그 결과를 쓰는 주장은 E06.
                 PROCESSED 대조 — 승인 코드가 낸 processed_check(가공 파일 값 ↔ RAW 에서 다시 계산한 값)를 파이썬이
                 파일에 적힌 자릿수로 비교한다. 기록만 하고 판정은 바꾸지 않는다.
4-2 계산 로그    commit = ① 사용한 데이터의 해시 2종(파일마다 원본 바이트·내용 정규화 + 묶음 해시)
                          ② 계산 과정(확정 식·단계·코드 해시·중간값) ③ 결과값 그 자체(반올림 전) ④ 결과 해시.
    최신 여부    같은 프로젝트의 이전 계산과 데이터 해시를 비교해 변경(E07)을 기록.
                 새 데이터 폴더가 들어오면 freshness() 로 이 계산에 쓴 해시와 대조한다(최신 파일인지).
(그래프 재생성은 하지 않음)
"""
from __future__ import annotations

import sys
from decimal import Decimal, InvalidOperation
from importlib import metadata
from pathlib import Path

from mtagent import config, design, hashing, lineage, readers, sandbox, store
from mtagent.util import canonical, is_finite_number, now, sha_file, sha_obj, sha_text, write_json

DATA_CATEGORIES = ("raw", "processed")


def _versions() -> dict:
    out = {"python": sys.version.split()[0]}
    for pkg in ("numpy", "scipy", "pandas"):
        try:
            out[pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            out[pkg] = None
    return out


def data_files(ing: dict) -> list[dict]:
    """1 INGEST 기록 중 계산에 들어가는 데이터(RAW·PROCESSED)."""
    return [x for x in ing["files"] if x["zone"] == "data" and x["category"] in DATA_CATEGORIES]


def data_hashes(files: list[dict]) -> dict:
    """① 사용한 데이터의 해시 2종 — 파일마다 원본 바이트·내용 정규화, 그리고 묶음 해시 두 개."""
    inputs = [{"path": x["path"], "category": x["category"], "sha256": x["sha256"], "content_hash": x["content_hash"]}
              for x in files]
    return {"files": inputs,
            "byte_hash": sha_text(canonical([(x["path"], x["sha256"]) for x in inputs])),
            "content_hash": sha_text(canonical([(x["path"], x["content_hash"]) for x in inputs]))}


def run(rid: str) -> dict:
    store.require(rid, "confirm")
    conf = store.read(rid, "confirm/confirmed.json")
    ing = store.read(rid, "ingest.json")
    files_used = data_files(ing)
    base = store.in_dir(rid) / "data"
    started = now()
    hashes = data_hashes(files_used)
    input_hash = hashes["byte_hash"]
    log = {"stage": "4 RECOMPUTE", "run_id": rid, "project": conf["project"], "started_at": started,
           "inputs": hashes["files"], "input_hash": input_hash, "content_input_hash": hashes["content_hash"],
           "confirmed_hash": conf["hash"], "steps": conf.get("steps"),
           "equations": [e["id"] for e in conf.get("equations", [])],
           "code": conf.get("code"), "env": _versions(), "results": [], "intermediate": {}, "checks": []}
    checks = log["checks"]

    def check(name, ok, detail=""):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        return ok

    ok = check("계산 코드 승인", conf.get("code"), "3-1 에서 승인한 코드" if conf.get("code") else
               "승인된 코드 없음(미확정) — 계산하지 않고 막힌 채 기록, 5단계에서 수치 주장은 E06")
    code_path = store.out_dir(rid) / "confirm" / "approved_code.py"
    if ok:
        ok = check("승인 코드 해시", code_path.exists() and sha_file(code_path) == conf["code"]["sha256"],
                   f"확정 해시 {conf['code']['sha256'][:12]}")
    if ok:
        now_hash = (store.read(rid, "extract/summary.json") or {}).get("hash")
        ok = check("추출 결과가 확정 때와 같음", now_hash == conf.get("extract_hash"), f"{(now_hash or '')[:12]}")
    if ok:
        bad = [x["path"] for x in files_used if sha_file(base / x["path"]) != x["sha256"]]
        n_proc = sum(x["category"] == "processed" for x in files_used)
        ok = check("데이터 사본이 1 INGEST 해시와 같음", not bad,
                   ", ".join(bad[:5]) or f"RAW {len(files_used) - n_proc}개 · PROCESSED {n_proc}개 같음")
    if ok:
        code = code_path.read_text(encoding="utf-8")
        problems = sandbox.static_check(code)
        ok = check("정적 점검", not problems, "; ".join(problems[:5]) or "금지 항목 없음")
    if not ok:
        log.update(status="blocked", reason=next(c for c in checks if not c["ok"])["check"] + " 실패")
    else:
        files = {x["path"]: str((base / x["path"]).resolve()) for x in files_used if x["category"] == "raw"}
        processed = {x["path"]: str((base / x["path"]).resolve()) for x in files_used if x["category"] == "processed"}
        res = sandbox.run(code_path, conf["code"]["sha256"], files, config.SANDBOX_TIMEOUT, processed=processed)
        log["sandbox"] = {"seconds": res.get("seconds"), "blocked": res.get("blocked", []), "stdout": res.get("stdout", ""),
                          "timeout": config.SANDBOX_TIMEOUT,
                          "isolation": "별도 프로세스(python -I -B) + 감사 훅 · 최소 환경 변수 · 빈 임시 폴더 — 컨테이너·VM 아님"}
        check("격리 실행", res.get("status") == "ok", res.get("error") or "완료")
        if res.get("status") == "ok":
            conds = (conf.get("design") or {}).get("conditions") or []
            for r in res["results"]:
                r["group"] = design.match_condition(r.get("condition"), conds) if r.get("condition") else None
            intermediate = res.get("intermediate") or {}
            log["processed_dependency"] = _independence(code_path, conf["code"]["sha256"], files, processed, res["results"],
                                                        code_path.read_text(encoding="utf-8"))
            dep = set(log["processed_dependency"].get("ids") or [])
            for r in res["results"]:
                r["depends_on_processed"] = r["id"] in dep
            log.update(status="ok", results=res["results"], intermediate=intermediate,
                       result_hash=sandbox.result_hash(res["results"]),
                       processed_check=processed_check(intermediate.get("processed_check"),
                                                       {x["path"] for x in files_used if x["category"] == "processed"}))
        else:
            log.update(status="error", reason=res.get("error"), traceback=res.get("traceback"))
    log["finished_at"] = now()
    log["commit"] = {
        "data": hashes,
        "process": {"confirmed_hash": conf["hash"], "extract_hash": conf.get("extract_hash"),
                    "equations": [{"id": e["id"], "latex": e.get("latex")} for e in conf.get("equations", [])],
                    "steps": conf.get("steps"), "code_sha256": (conf.get("code") or {}).get("sha256"),
                    "intermediate_hash": sha_obj(log["intermediate"]) if log["intermediate"] else None,
                    "env": log["env"]},
        "results": [{k: r.get(k) for k in ("id", "name", "value", "unit", "condition", "kind", "equation_id")}
                    for r in log["results"]],
        "result_hash": log.get("result_hash")}
    log["e07"] = _e07(rid, ing, log)
    rdir = store.out_dir(rid) / "recompute"
    path = write_json(rdir / "calc_log.json", log)
    write_json(rdir / "history" / f"calc_{log['finished_at'][:19].replace(':', '').replace('-', '')}.json", log)
    lineage.record("4 RECOMPUTE", rid, input_hash, sha_text((conf.get("code") or {}).get("sha256", "") + conf["hash"]),
                   {"confirmed": conf["hash"][:16], "status": log["status"],
                    "content_input_hash": hashes["content_hash"][:16]}, [path])
    store.mark(rid, "recompute", "done" if log["status"] == "ok" else log["status"])
    return log


# ── PROCESSED 독립성 ────────────────────────────────────────────────────
def _independence(code_path, code_sha256: str, raw: dict, processed: dict, results: list[dict], code: str) -> dict:
    """PROCESSED 를 비우고 다시 실행 — 결과가 같으면 RAW 만으로 재현된 것. 다르거나 사라진 결과 id 를 돌려준다.

    independent: True(RAW 만으로 같음) · False(ids 가 PROCESSED 에 기댐 → 5 VALIDATE 에서 E06) · None(시간 초과로 확인 못 함 — 표시만).
    PROCESSED 없이 오류로 멈추면 결과를 PROCESSED 없이 낼 수 없는 것이므로 모두 기댄 것으로 본다(오류 내용은 남김).
    """
    if not processed:
        return {"checked": False, "independent": True, "ids": [], "note": "PROCESSED 데이터 없음 — 모든 결과가 RAW 에서 나옴"}
    if not sandbox.uses_second_arg(code):
        return {"checked": False, "independent": True, "ids": [],
                "note": "승인 코드가 processed 인자를 읽지 않음(정적 확인) — 모든 결과가 RAW 에서 나옴, 다시 실행하지 않음"}
    alone = sandbox.run(code_path, code_sha256, raw, config.SANDBOX_TIMEOUT, processed={})
    run2 = {k: alone.get(k) for k in ("status", "seconds", "blocked", "error")} | {"stdout": (alone.get("stdout") or "")[-2000:]}
    if alone.get("timeout"):
        return {"checked": True, "independent": None, "ids": [], "run": run2,
                "note": f"PROCESSED 없이 다시 실행하다 시간 제한 — 독립성을 확인하지 못함(판정은 바꾸지 않음, 확인 필요)"}
    if alone.get("status") != "ok":
        return {"checked": True, "independent": False, "ids": [r["id"] for r in results], "run": run2,
                "note": f"PROCESSED 없이 실행하면 오류 — 결과를 RAW 만으로 낼 수 없음, 모두 PROCESSED 에 기댄 것으로 봄 "
                        f"({alone.get('error')})"}
    before = {r["id"]: r for r in alone["results"]}
    ids = [r["id"] for r in results
           if r["id"] not in before
           or abs(before[r["id"]]["value"] - r["value"]) > 1e-12 * max(1.0, abs(r["value"]))
           or any(before[r["id"]].get(k) != r.get(k) for k in ("unit", "kind", "condition"))]
    return {"checked": True, "independent": not ids, "ids": ids, "run": run2,
            "note": "모든 결과가 RAW 만으로 같은 값" if not ids else
                    f"PROCESSED 를 빼면 값이 바뀌거나 사라지는 결과 {len(ids)}개 — RAW 로 독립 재현되지 않음 (주장은 E06)"}


# ── PROCESSED 대조 ──────────────────────────────────────────────────────
def _tolerance(text: str) -> float | None:
    """적힌 자릿수의 반올림 허용폭 — '10.948' → 0.0005, '5.69e-09' → 5e-12."""
    try:
        exp = Decimal(text.strip()).as_tuple().exponent
    except (InvalidOperation, AttributeError):
        return None
    return 0.5 * 10.0 ** exp if isinstance(exp, int) else None


def processed_check(items, processed_paths: set[str]) -> dict:
    """가공 파일에 적힌 값 ↔ RAW 에서 다시 계산한 값. 적힌 자릿수로 반올림해 같은지 본다(기록만)."""
    if not processed_paths:
        return {"checked": 0, "matched": 0, "mismatches": [], "problems": [], "rows": [], "note": "PROCESSED 데이터 없음"}
    rows, mismatches, problems = [], [], []
    for i, x in enumerate(items or []):
        if not isinstance(x, dict):
            problems.append(f"{i}번 항목이 dict 가 아님")
            continue
        if not isinstance(x.get("file"), str) or x["file"] not in processed_paths:
            problems.append(f"{i}번 항목의 파일 {x.get('file')!r} 이 PROCESSED 데이터가 아님")
            continue
        rep, rv = str(x.get("reported", "")).strip(), x.get("recomputed")
        val, tol = readers.to_float(rep), _tolerance(rep)
        if val is None or tol is None or not is_finite_number(rv):
            problems.append(f"{x.get('file')} {x.get('line')}줄 {x.get('column')}: 비교할 수 없는 값 ({rep!r}, {rv!r})")
            continue
        row = {"file": x["file"], "line": x.get("line"), "column": x.get("column"), "reported": rep,
               "recomputed": float(rv), "difference": float(rv) - val,
               "match": abs(float(rv) - val) <= tol * (1 + 1e-9) + 1e-15}
        rows.append(row)
        if not row["match"]:
            mismatches.append(row)
    return {"checked": len(rows), "matched": len(rows) - len(mismatches), "mismatches": mismatches,
            "problems": problems, "rows": rows,
            "note": "가공 파일 값 ↔ RAW 재계산 값, 적힌 자릿수로 비교 — 기록만(판정은 바꾸지 않음)"}


# ── 최신 여부 · E07 ─────────────────────────────────────────────────────
def _e07(rid: str, ing: dict, log: dict) -> dict:
    prev = store.previous_run(rid, "recompute")
    if not prev:
        return {"compared_with": None, "note": "같은 프로젝트의 이전 계산 없음"}
    old_ing = store.read(prev, "ingest.json") or {}
    old = {x["path"]: x for x in data_files(old_ing)}
    new = {x["path"]: x for x in data_files(ing)}
    changes = hashing.compare_sets(old, new)
    old_log = store.read(prev, "recompute/calc_log.json") or {}
    ov = {r["id"]: r["value"] for r in old_log.get("results") or []}
    value_changes = [{"id": r["id"], "before": ov[r["id"]], "after": r["value"]}
                     for r in log.get("results") or [] if r["id"] in ov and ov[r["id"]] != r["value"]]
    return {"compared_with": prev, "changes": changes, "result_changes": value_changes,
            "note": "기록만 — 판정은 바꾸지 않음"}


def freshness(rid: str, folder: Path) -> dict:
    """새 데이터 폴더(연구 자료 폴더, 입력 때와 같은 구조)를 이 실행의 계산에 쓴 해시와 대조 — 읽기만 한다.

    계산에 쓴 파일은 경로로 짝짓고, 입력 때 없던 표 파일은 '추가'로 본다. 형식만 바뀐 파일은 같은 데이터로 본다.
    """
    folder = Path(folder)
    if not folder.is_dir():
        raise ValueError(f"폴더가 아님: {folder}")
    log = store.read(rid, "recompute/calc_log.json")
    if not log:
        raise ValueError("이 실행은 아직 4 RECOMPUTE 를 하지 않음")
    if log.get("status") != "ok":
        raise ValueError(f"이 실행의 4 RECOMPUTE 가 계산하지 않음({log.get('status')}: {log.get('reason')}) — 비교할 계산이 없음")
    ing = {x["path"]: x for x in (store.read(rid, "ingest.json") or {}).get("files", []) if x["zone"] == "data"}
    used = {x["path"]: ing.get(x["path"], x) for x in log["inputs"]}
    new = {}
    for p in sorted(folder.rglob("*")):
        rel = p.relative_to(folder).as_posix()
        if p.is_file() and (rel in used or (p.suffix.lower() in readers.TABLE_EXT and rel not in ing)):
            new[rel] = hashing.fingerprint(p)
    changes = hashing.compare_sets(used, new)
    stale = [c for c in changes if c["kind"] != "형식만 변경"]
    return {"run_id": rid, "checked_at": now(), "folder": str(folder), "calc_finished_at": log.get("finished_at"),
            "used_byte_hash": log.get("input_hash"), "used_content_hash": log.get("content_input_hash"),
            "fresh": not stale, "changes": changes,
            "note": ("계산에 쓴 데이터와 같음" if not stale else
                     f"계산 뒤 바뀐 데이터 {len(stale)}건 — 새 실행(1 INGEST 부터)으로 다시 계산해야 함")}
