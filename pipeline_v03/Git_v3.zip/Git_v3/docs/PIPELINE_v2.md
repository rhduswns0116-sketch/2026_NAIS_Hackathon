# MeasureTrace 파이프라인 v2

GIT_v2 · Git_v3 가 따르는 파이프라인 문서. 각 항목 오른쪽 `→` 는 구현 위치.

## 0. 연구자가 갖고 있어야 하는 파일

- RAW_DATA
- PROCESSED_DATA
- 연구 계획서
- 장비 사양 보고서
- 최종 보고서 초안

→ `stages/ingest.py` `REQUIRED` — 1 INGEST 결과 `ingest.json` 의 `required` 점검표. 없으면 `findings` 에 막힘/확인.

## 1. Ingest [Python]

1. **입력 격리·분류**
   1. 경로 격리 — 입력된 파일은 읽기만 한다. 산출물은 입력 밖 폴더에 생성한다. 최종 보고서 초안은 다른 경로로 입력받는다.
      → 사본을 `workspace/inputs/<실행>/data|report` 에 받고 읽기 전용으로 잠금, 산출물은 `workspace/outputs/<실행>/`.
   2. 유형 분류 — raw/processed data · 연구 계획서 · 장비 사양 보고서.
      → `ingest.classify()` (규칙 기반, 확신도·근거 포함).
2. **지문·시각 기록**
   1. 해시 2종 — 원본 바이트 해시 + 내용 정규화 해시. 변경 시 행·열 차이를 파악한다.
      → `hashing.fingerprint()` · `hashing.compare_sets()` (표는 행별 해시로 바뀜·추가·빠짐 + 줄 번호).
   2. 측정 시각 — (1) 파일 수정 시각 (2) 장비가 기록한 시각. 파일 수정 시각은 복사만 해도 바뀔 수 있으므로 장비 헤더 시각을 우선한다.
      → `hashing.file_mtime()` · `hashing.measurement_times()` · `hashing.measured_at()`.
        파일마다 `times = {file_mtime, device}` 와 결정값 `measured_at`(`basis` = device | file_mtime).
        명령줄 입력은 원본 수정 시각을 사본에 옮긴다(`store.add_folder`). 웹 업로드는 원본 시각을 모르므로 측정 시각으로 쓰지 않는다.
3. **파생 이력(lineage) 기록**
   - "입력 해시 + 함수(코드) 버전 + 파라미터 → 출력 해시" 를 적는 장부. 이후 파이프라인이 만드는 모든 중간 산출물이 한 줄씩 적힌다.
     연구자가 가져온 가공 파일은 파이프라인 밖에서 만들어졌으므로 파생 기록이 없다.
   - '파생'은 파일 생성의 줄임말이 아니라 **어떤 입력에서 어떤 코드로 무엇이 나왔는지**의 기록이다. 같은 세 가지면 같은 출력 해시가 나와야 재현된 것.
   → `lineage.py`, `workspace/outputs/lineage.jsonl`.

## 2. Extract

1. **입력 데이터 분석**
   1. 데이터 내용 파악 — 각 데이터 파일이 무엇을 의미하는지. → 2-1a (RAW 묶음 G1…, PROCESSED 묶음 P1…, 숫자 값은 LLM 에 보내지 않음)
   2. 연구 내용 추출
      1. 이론·수식·계산 과정 추출 → 계산용 python 코드 작성. → 2-1b(식은 Word 수식에서 파이썬이 LaTeX 로), 2-1c(`compute(raw, processed)` 초안, 실행 안 함)
      2. 실험 ↔ 데이터 ↔ 식 ↔ 장비 매칭. → 2-1b `matching`
      3. 첨언 — Agent 는 연구실 계산 코드에 접근하지 않으므로 계획서의 계산식을 신뢰한다. 연구자 자신의 계산 코드가 있으면
         Recompute 에서 직접 넣어도 되고, 두 결과를 연구자가 비교해도 된다. (스크립트 파일은 분류만 하고 실행하지 않음)
2. **측정 조건 추출** — 장비 사양 PDF 에서 결과의 정산 범위·오차·유효 범위.
   이상치인지 판단은 여기서 하고, 묻는 것은 Confirm 에서. → 2-2 (범위·정확도·범위 밖 표시값·동작 조건, 인용 원문 대조)
3. **데이터 구조화** [LLM + Python] — RAW/PROCESSED 를 읽고 단위 누락·모호한 단위·누락 데이터·이상치. → 2-3
4. **누락 점검** [LLM] — 계획서와 비교해 결론에 필요한 파일이 다 있는지. → 2-4 (LLM 은 계획서만, 대조는 파이썬)

## 3. Confirm

1. **데이터 해석 승인** — Extract 1 결과와 Extract 4 누락을 묻는다.
   (예) 수식 A 를 사용해 이렇게 계산한 게 맞나요? · 장비 Z 로 측정값 K 를 확인한 게 맞나요? · 실험 ↔ 데이터 ↔ 식 ↔ 장비를 이렇게 쓴 게 맞나요?
   → 3-1 항목. 관계는 도식으로도 보인다(`confirm/relation_diagram.md`, Mermaid + 글).
   LLM 이 잘못 이해했다면 고칠 부분을 입력받고 Extract 로 돌아간다. → '아니오 + 고칠 내용' → 2-1 다시, 바뀐 항목만 다시 물음(최대 3회)
2. **분석 범위 확정** — Extract 2 결과. (예) 측정 조건 ɑ 에서 오차 n% 라고 읽었는데 맞나요? → 3-2 (범위·정확도·측정 조건·범위 밖 표시값)
3. **측정 기준 승인** — Extract 3 결과. (예) 측정 조건 β 에서 오차 범위 m% 인데 raw_data.csv 의 n번 행/k번 열이 위반합니다.
   1. 단위 누락·모호 — 단위를 제안하고 사용자 입력도 받는다. → 3-3:unit (제안 선택 · 기타 직접 입력)
   2. 결측치·이상치 — 사용자가 파일을 확인 후 재업로드하고 Ingest 로 돌아간다. → 3-3:data '아니오 → 새 실행(1 INGEST 부터)'.
      (Git_v1 에서 이어받은 선택지: '값이 맞음 — 그대로 진행'은 E02 로 기록)

## 4. Recompute

1. **수치 재계산** — Extract 2-1b 의 계산 과정 식, Confirm 받은 식, 데이터 ↔ 식 매칭으로 재계산.
   → 승인 코드(해시 고정)를 격리 프로세스에서 RAW·PROCESSED 로 한 번 실행. PROCESSED 값은 RAW 재계산값과 적힌 자릿수로 대조(기록).
2. **계산 로그 생성** — 4가지: ① 사용한 data 의 해시 2종 ② 계산 과정 ③ 결과 값 그 자체 ④ 결과 값의 해시.
   사용한 raw/processed 해시를 저장해 두어, 새 data 파일이 들어오면 비교해 최신화된 파일인지 파악한다.
   → `recompute/calc_log.json` 의 `commit = {data, process, results, result_hash}`,
     `recompute.freshness(실행, 새 폴더)` / `python cli.py freshness`, 같은 프로젝트 재실행 시 E07.

## 5. Validate

1. 최종 보고서 초안 문장(주장) 추출 → 5-1 (보고서는 재계산이 끝난 뒤 처음 연다)
2. Recompute 결과와 비교 — 출력할 때 페이지 번호와 문장 번호. → 5-2 (`p.N 문장 M`)
3. 오류 코드 분류 — **수정 중**. 현재는 Git_v1 의 E01~E07 (README 표). 1. 단위 불일치(누락 포함) = E01.

## 6. Audit

1. Validate 결과 출력 — Supported / Unsupported 항목마다 논문 문장과 재계산값 비교. → `audit.json`, `audit_report.md`
2. 수정 후 재평가 — Unsupported 를 고쳐 다시 돌리면 수정 전·후 비교. → 같은 프로젝트 이름으로 새 실행 시 `reevaluation`
